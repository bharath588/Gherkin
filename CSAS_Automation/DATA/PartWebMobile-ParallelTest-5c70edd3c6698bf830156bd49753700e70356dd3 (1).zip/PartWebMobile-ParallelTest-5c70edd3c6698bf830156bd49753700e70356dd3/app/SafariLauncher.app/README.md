# SafariLauncher

A simple IOS application that automatically launches Mobile Safari after a certain delay. This application is intended to be used with appium for running Web Tests on real IOS devices

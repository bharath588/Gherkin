package com.greatWest.profile;

import java.util.Map;

import lib.Reporter;

import org.testng.annotations.Test;

import com.greatWest.login.UserBaseTest;
import com.greatWest.pageObject.ProfilePage;

public class ProfileTestCases extends UserBaseTest{
	
	
	private ProfilePage profilePage;


	/*
	 * QA - Password change validation - Profile page
	 * This test validate the view and edit functionality of password under profile.* 
	 * Prerequisite : Profile should be enabled for plan/participant

	 */
	
	@Test(dataProvider = "setData")
	public void   PPTMOBILE_Profile_001_DDTC_20244_Password_Change_Validation_Profile_Page(int itr,
			Map<String, String> testdata) {
		profilePage= new ProfilePage();
	try{
	initializeReportForTC(itr);		
	profilePage.get();
	profilePage.verify_Password_Page();
	profilePage.verify_Password_Edit_Page_Details();
	profilePage.Verify_Password_Validation_Message();	
	
	
	} catch (Exception e) {
 
	handleFailure(e);
	}
	catch (Error ae){
		handleError(ae);
	}
	}
	
	
	/*
	 * DDTC 12616 QA-Add username to profile with view and edit
	 * 
	 */
	
	@Test(dataProvider = "setData")
	public void   PPTMOBILE_Profile_002_DDTC_12616_Add_UserName_To_Profile_With_View_And_Edit(int itr,
			Map<String, String> testdata) {
		profilePage= new ProfilePage();
	try{
	initializeReportForTC(itr);		
	profilePage.get();	
	
	profilePage.verify_UserName_Page();
	profilePage.verify_UserName_Edit_Page_Details();
	
	
	
	} catch (Exception e) {
 
	handleFailure(e);
	}
	catch (Error ae){
		handleError(ae);
	}
	}
	
	
	/*
	 * QA-Add contact info to profile with view and add
	 * This test validates that contact info has been added to profile and its working as per the requirements.

	 * 
	 */
	
	@Test(dataProvider = "setData")
	public void   PPTMOBILE_Profile_003_DDTC_12635_Add_Contact_Info_To_Profile_WithView_And_Add(int itr,
			Map<String, String> testdata) {
		profilePage= new ProfilePage();
	try{
	initializeReportForTC(itr);		
	profilePage.get();
	profilePage.verify_Personal_Contact_Info_Page();	
	
	} catch (Exception e) {
 
	handleFailure(e);
	}
	catch (Error ae){
		handleError(ae);
	}
	}
	

	/*
	 * DDTC 12616 QA-Add username to profile with view and edit
	 * 
	 */
	
	@Test(dataProvider = "setData")
	public void   PPTMOBILE_Profile_004_DDTC_12617_Update_UserName_And_Password_And_Verify(int itr,
			Map<String, String> testdata) {
		profilePage= new ProfilePage();
	try{
	initializeReportForTC(itr);		
	profilePage.get();
	profilePage.verify_User_Password_Updated();
	
	
	
	} catch (Exception e) {
 
	handleFailure(e);
	}
	catch (Error ae){
		handleError(ae);
	}
	}
	
	
	/*
	 * QA- Profile Page - Communication Preference page - Electronic
	 * select * From sponsor_comm_preferences where delivery_method_rule in ('MAIL_ONLY');
	 */
	
	@Test(dataProvider = "setData")
	public void   PPTMOBILE_Profile_005_DDTC_12620_and_12621_Communication_Preference_Page(int itr,
			Map<String, String> testdata) throws Exception {
		profilePage= new ProfilePage();
	try{
	initializeReportForTC(itr);		
	profilePage.get();
	profilePage.verify_Communication_Perf_Page();
	
	} catch (Exception e) {
 
	handleFailure(e);
	}
	catch (Error ae){
		handleError(ae);
	}
	finally{
		 Reporter.finalizeTCReport();
	}
	}
	/*
	 * DDTC 12616 QA-Add username to profile with view and edit
	 * 
	 */
	
	@Test(dataProvider = "setData")
	public void   PPTMOBILE_Profile_006_DDTC_12621_Update_UserName_And_Password_And_Verify(int itr,
			Map<String, String> testdata) {
		profilePage= new ProfilePage();
	try{
	initializeReportForTC(itr);		
	profilePage.get();
	profilePage.verify_User_Password_Updated();
	
	
	
	} catch (Exception e) {
 
	handleFailure(e);
	}
	catch (Error ae){
		handleError(ae);
	}
	}
	 
	
	
	
	
	
	
	

}

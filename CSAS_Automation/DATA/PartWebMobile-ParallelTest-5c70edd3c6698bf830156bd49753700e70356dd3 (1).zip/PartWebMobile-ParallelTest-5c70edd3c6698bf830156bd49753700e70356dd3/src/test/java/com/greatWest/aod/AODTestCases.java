package com.greatWest.aod;

import java.util.Map;

import lib.Reporter;

import org.testng.annotations.Test;

import com.greatWest.pageObject.AccOverviewDashboard;
import com.greatWest.pageObject.DeferralsPage;
import com.greatWest.pageObject.EnrollmentPage;
import com.greatWest.pageObject.HomePage;
import com.greatWest.utility.Common;
import com.greatWest.utility.Mobile;

import io.appium.java_client.MobileElement;

import com.aventstack.extentreports.Status;
import com.greatWest.login.UserBaseTest;

public class AODTestCases extends UserBaseTest {
	AccOverviewDashboard aodPage;
	private DeferralsPage deferralsPage;
	private EnrollmentPage enrollmentPage;
	/*
	 * 
	 * DDTC-31685 QA - Account overview Dashboard - Annualized ROR
	 */

	/*
	 * DDTC-31684 QA - Account overview Dashboard - Balance Card section is
	 * displayed when data not available. DDTC-31683 QA - Account overview Dashboard
	 * - Balance Card section is displayed with zero balance DDTC-31682 QA - Account
	 * overview Dashboard - Balance Card section is displayed with current balance.
	 * DDTC-31687 QA - Account overview Dashboard - ROR data unavailable DDTC-31686
	 * QA - Account overview Dashboard - Cumulative ROR Pre-requisites:
	 * Participant's hire_Date should be current year. Participant should be
	 * registered and enrolled into the plan. Participant should have ROR data for
	 * less than one Year DDTC-32515 - QA_AOD_contribution card - After-tax
	 */

	@Test(dataProvider = "setData")
	public void AOD_TC001_Balance_And_ROR_Card_Section(int itr, Map<String, String> testdata) {
		try {
			aodPage = new AccOverviewDashboard();
			initializeReportForTC(itr);
			aodPage.setLiatAmountToVerify(true);
			aodPage.get();
			aodPage.verifyAODCard();

			aodPage.setLiatAmountToVerify(false);
		} catch (Exception e) {

			handleFailure(e);
		} catch (Error ae) {
			handleError(ae);
		}
	}

	/**
	 * 
	 * This test case verifies transaction card with multiple transactions and if
	 * more than 5 transactions are displayed. DDTC-31711 QA- AOD - beneficiaries
	 * card_WNBEN and WUBENE are on DDTC-31723 QA- AOD - transaction history card -
	 * Number of transactions DDTC-31721 QA- AOD - transaction history card - UI -
	 * Iphone DDTC-31719 QA- AOD - transactions on file
	 * 
	 * DDTC-31718 QA- AOD - Multiple beneficiaries
	 * 
	 * @param itr
	 * @param testdata
	 */

	@Test(dataProvider = "setData")
	public void AOD_TC002_Transaction_And_Beneficiary_Card_Section(int itr, Map<String, String> testdata) {
		try {
			initializeReportForTC(itr);
			aodPage = new AccOverviewDashboard();
			aodPage.get();

			String expROR = UserBaseTest.getParaValue("RORContent");
			Mobile.verifyElementPresent(expROR + " rate in ROR card content should be display", expROR,
					expROR + " in ROR card");
			aodPage.verifyTransactionHistoryCard();
			aodPage.verifyBeneficiariesCard();
		} catch (Exception e) {

			handleFailure(e);
		} catch (Error ae) {
			handleError(ae);
		}
	}

	/**
	 * 
	 * DDTC-31710* QA- AOD - beneficiaries card_WNBEN is off DDTC-31716 QA- AOD - no
	 * beneficiaries on file DDTC-DDTC-31712 QA- AOD - beneficiaries card_WNBEN is
	 * on but WUBENE is off with no benes on file
	 * 
	 * @throws Exception
	 * 
	 * 
	 */
	@Test(dataProvider = "setData")
	public void AOD_TC003_Beneficiary_Card_with_WNBEN_and_WUBENE_Option(int itr, Map<String, String> testdata)
			throws Exception {
		try {
			initializeReportForTC(itr);

			aodPage = new AccOverviewDashboard();
			aodPage.get();

			Mobile.verifyElementPresent("Beneficiaries card  should be display", aodPage.beneficiariesCard,
					aodPage.beneficiariesCard + " card");
			Mobile.verifyElementPresent("Beneficiaries card content should be display", aodPage.NoneOnFile,
					"None on file.");
			Mobile.clickElement(aodPage.beneficiariesCard);
			Common.waitForProgressBar();
			Mobile.verifyElementNotPresent("Tap Beneficiaries card and Beneficiaries Page should not be display",
					aodPage.beneficiariesPage, "Beneficiaries Page ");
			new HomePage().logout();
		} catch (Exception e) {

			handleFailure(e);
		} catch (Error ae) {
			handleError(ae);
		} finally {
			Reporter.finalizeTCReport();
		}

	}

	/**
	 * DDTC-32535 QA-AOD-Contribution card - participant with CSOR deferral
	 * DDTC-32534 QA-AOD-Contribution card - hire_Date < 1yrs DDTC-32533
	 * QA-AOD-Contribution card - hire_Date > 1yrs DDTC-32531 QA-AOD-Contribution
	 * card - Terminated participant _with balance DDTC-32512 QA-AOD-Contribution
	 * card - 401a plan_Standard //*[@name='2018 CONTRIBUTIONS']/..
	 * 
	 * DDTC-32509 QA-AOD-Contribution card - 401K plan_Standard & catch-up
	 * 
	 * DDTC-33287 QA_AOD_Verify contribution card in AOD for a LA county participant
	 * with "High limit" and pour Over match is not applicable
	 * 
	 */
	@Test(dataProvider = "setData")
	public void AOD_TC004_Contribution_card(int itr, Map<String, String> testdata) throws Exception {
		try {
			initializeReportForTC(itr);
			aodPage = new AccOverviewDashboard();
			aodPage.get();
			aodPage.verifyContributionCardPage();
			new HomePage().logout();
		} catch (Exception e) {

			handleFailure(e);
		} catch (Error ae) {
			handleError(ae);
		} finally {
			Reporter.finalizeTCReport();
		}

	}

	/**
	 * 
	 * DDTC-32531 QA-AOD-Contribution card - Terminated participant _with balance
	 * 
	 * @param itr
	 * @param testdata
	 * @throws Exception
	 */

	@Test(dataProvider = "setData")
	public void AOD_TC005_DDTC_32531_Contribution_card_Terminated_PPT(int itr, Map<String, String> testdata)
			throws Exception {
		try {
			initializeReportForTC(itr);
			aodPage = new AccOverviewDashboard();
			aodPage.get();
			Mobile.verifyElementNotPresent("Contribution card should not be display", aodPage.contributionCard,
					aodPage.contributionCard + " card");
			new HomePage().logout();

		} catch (Exception e) {

			handleFailure(e);
		} catch (Error ae) {
			handleError(ae);
		} finally {
			Reporter.finalizeTCReport();
		}

	}

	/**
	 * 
	 * DDTC-32511 QA-AOD-Contribution card - 403b plan_Standard
	 * 
	 * @param itr
	 * @param testdata
	 * @throws Exception
	 */

	@Test(dataProvider = "setData")
	public void AOD_TC006_DDTC_Contribution_card_IRS_Limit_Display(int itr, Map<String, String> testdata)
			throws Exception {
		try {
			initializeReportForTC(itr);
			aodPage = new AccOverviewDashboard();
			aodPage.get();
			Mobile.verifyElementPresent("Contribution card should not be display", aodPage.contributionCard,
					aodPage.contributionCard + " card");
			Mobile.verifyElementPresent("IRS Limit card  should be display", aodPage.IRS_Limit, "IRS Limit ");
			new HomePage().logout();

		} catch (Exception e) {

			handleFailure(e);
		} catch (Error ae) {
			handleError(ae);
		} finally {
			Reporter.finalizeTCReport();
		}

	}

	/**
	 * 
	 * DDTC-32513 QA-AOD-Contribution card - 457 & 457b plan_Standard & catch-up
	 * 
	 * @param itr
	 * @param testdata
	 * @throws Exception
	 */

	@Test(dataProvider = "setData")
	public void AOD_TC007_DDTC_32513_Contribution_card_457_Plan(int itr, Map<String, String> testdata)
			throws Exception {
		try {
			initializeReportForTC(itr);
			aodPage = new AccOverviewDashboard();
			aodPage.get();
			Mobile.verifyElementPresent("Contribution card should be display", aodPage.contributionCard,
					aodPage.contributionCard + " card");
			Mobile.verifyElementNotPresent("IRS Limit card  should be display", aodPage.IRS_Limit, "IRS Limit ");
			new HomePage().logout();

		} catch (Exception e) {

			handleFailure(e);
		} catch (Error ae) {
			handleError(ae);
		} finally {
			Reporter.finalizeTCReport();
		}

	}

	/**
	 * DDTC-33284 QA_AOD_Verify contribution card in AOD for a LA county participant
	 * with "High limit" and pour Over match is applicable. DDTC-33286 DDTC-33287
	 * DDTC-33285 95863-01
	 */
	@Test(dataProvider = "setData")
	public void AOD_TC008_LA_County_Contribution_card(int itr, Map<String, String> testdata) throws Exception {
		try {
			initializeReportForTC(itr);
			aodPage = new AccOverviewDashboard();
			aodPage.get();
			if (UserBaseTest.getParaValue("isContributionDisplay").equalsIgnoreCase("true")) {

				Mobile.verifyElementPresent("Contribution card should  be display", aodPage.contributionCard,
						aodPage.contributionCard + " card");
			} else {

				Mobile.verifyElementNotPresent("Contribution card should not be display", aodPage.contributionCard,
						aodPage.contributionCard + " card");
			}
			new HomePage().logout();

		} catch (Exception e) {

			handleFailure(e);
		} catch (Error ae) {
			handleError(ae);
		} finally {
			Reporter.finalizeTCReport();
		}

	}

	/**
	 * QA-AOD-Contribution card - 401K plan_Standard & catch-up _with zero balance
	 */
	@Test(dataProvider = "setData")
	public void AOD_TC009_DDTC_32516_Contribution_card_401K_Zero_Balance(int itr, Map<String, String> testdata)
			throws Exception {
		try {
			initializeReportForTC(itr);
			aodPage = new AccOverviewDashboard();
			aodPage.get();

			aodPage.verifyContributionCardPage();

			new HomePage().logout();

		} catch (Exception e) {

			handleFailure(e);
		} catch (Error ae) {
			handleError(ae);
		} finally {
			Reporter.finalizeTCReport();
		}

	}

	/**
	 * QA AOD Deferral for single plan, single deferral with FDD enabled.
	 * 
	 * PreCondition :-   Delete Elective Deferral record from DB
	 * delete from elective_deferral where ind_id='14547895';
	 * delete from ELECTIVE_DEFERRAL_NOTIFICATION where ind_id = '14547895';
	 * 
	 * DDTC-33756, DDTC-33757
	 */
	@Test(dataProvider = "setData")
	public void AOD_TC010_DDTC_34018_Single_Plan_FDD_Enabled(int itr, Map<String, String> testdata) throws Exception {
		try {
			initializeReportForTC(itr);
			
			enrollmentPage = new EnrollmentPage();
			aodPage = new AccOverviewDashboard();
			deferralsPage = new DeferralsPage();
			
			enrollmentPage.get();		
			
			//DDTC-33758 : Verify FDD is not display in Enrollment Page
			enrollmentPage.verifyFDDIsNotPresentInEnrollmentPage(deferralsPage );
				
			aodPage.get();
			// Verify If Deferral is not selected than Contribution card should not be displayed in AOD page
			
			Mobile.verifyElementNotPresent("Contribution card should not be display in AOD Page ", aodPage.contributionCard,
					aodPage.contributionCard + " card for PPT whose records are deleted from elective deferral DB");
			HomePage.selectMenuOption("MY CONTRIBUTIONS");

	
			deferralsPage.get();
			
			// Verify Auto Increase is Present without selecting FDD option for Before Tax deferral 
			deferralsPage.click_ContributionType_Edit_Add_Button(DeferralsPage.STANDARD);
			Mobile.verifyElementPresent("Fdd select  Option should be display in Contribution Rate Page",
					deferralsPage.getWebElement("FDD_SELECT_OPTION"), "Fdd Select Option ");			
			DeferralsPage.setbVerifyConfirmation(true);
			deferralsPage.VerifyContributionDetailsWithFDD(DeferralsPage.ENTER_CONTRIBUTION_RATE,
					DeferralsPage.BEFORE_TAX, "8", DeferralsPage.IsAutoIncreaseDisplay.True, "");

			//Verify * is not present in AOD Page for FDD not selecting : DDTC-34026
			
			HomePage.selectMenuOption("OVERVIEW");
			String isStarPresentInDonNut = "8"+deferralsPage.getContributionRateType();
			Mobile.verifyElementPresent("Contribution Card should  not contain * in Donut" , isStarPresentInDonNut, isStarPresentInDonNut);
			
			HomePage.selectMenuOption("MY CONTRIBUTIONS");
			
			// Verify FDD is save after change
			deferralsPage.click_ContributionType_Edit_Add_Button(DeferralsPage.STANDARD);
			String expDataSave = deferralsPage.isOneTimeEnableForFDD(true);
			
			// DDTC-33755 checking for the already existing date
			deferralsPage.verify_FDD_Details_Are_Save(expDataSave, true);

			// Verify Auto Increase is not display once FDD is select and click confirmation:- DDTC-34022
			DeferralsPage.setbVerifyConfirmation(true);
			String oneTimeMesssageInConfirmation = "(One-time only " + expDataSave
					+ "; your rate will revert to 8% on your following payroll cycle.)";
			deferralsPage.VerifyContributionDetailsWithFDD(DeferralsPage.ENTER_CONTRIBUTION_RATE,
					DeferralsPage.BEFORE_TAX, UserBaseTest.getParaValue("Contribution_Rate"),  DeferralsPage.IsAutoIncreaseDisplay.False,
					oneTimeMesssageInConfirmation);
			
			HomePage.selectMenuOption("OVERVIEW");
			Reporter.logEvent(Status.INFO, " Account Overview Page for One Time FDD", "", true);
			
			//Verify Selected FDD and DEferral rate are change in AOD page :- DDTC-34019
		
			isStarPresentInDonNut = "8"+deferralsPage.getContributionRateType() + "*";
			String[] expFddValueToDisplay = { isStarPresentInDonNut,
					"* Before Tax scheduled to increase one-time only to 10% on " + expDataSave };

			for (String expValue : expFddValueToDisplay) {
				MobileElement ele = Mobile.findElementWithPredicate(expValue);
				Mobile.verifyElementPresent("Contribution Card should display " + expValue, ele, expValue);
			}
			
			
			//Verify On Going FDD 
			
			HomePage.selectMenuOption("MY CONTRIBUTIONS");
			
			deferralsPage.click_ContributionType_Edit_Add_Button(DeferralsPage.STANDARD);
			 expDataSave = deferralsPage.isOneTimeEnableForFDD(false);
			 
			 oneTimeMesssageInConfirmation = "(to be submitted on "+expDataSave+")";
			 
			 deferralsPage.VerifyContributionDetailsWithFDD(DeferralsPage.ENTER_CONTRIBUTION_RATE,
						DeferralsPage.BEFORE_TAX,"12",  DeferralsPage.IsAutoIncreaseDisplay.False,
						oneTimeMesssageInConfirmation);
			 
				HomePage.selectMenuOption("OVERVIEW");
				Reporter.logEvent(Status.INFO, " Account Overview Page for On Going FDD", "", true);


				 String[] expFddOnGoing = { isStarPresentInDonNut,"* Before Tax scheduled to increase to 12% on " + expDataSave };

				for (String expValue : expFddOnGoing) {
					MobileElement ele = Mobile.findElementWithPredicate(expValue);
					Mobile.verifyElementPresent("Contribution Card should display " + expValue, ele, expValue);
				}
		}

		
		
		
		
		catch (Exception e) {

			handleFailure(e);
		} catch (Error ae) {
			handleError(ae);
		} finally {
			Reporter.finalizeTCReport();
		}

	}
	
}

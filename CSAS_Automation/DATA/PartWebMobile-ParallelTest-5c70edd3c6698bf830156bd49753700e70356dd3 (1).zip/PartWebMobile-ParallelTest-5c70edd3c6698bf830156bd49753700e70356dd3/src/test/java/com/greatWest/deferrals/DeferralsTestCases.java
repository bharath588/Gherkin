package com.greatWest.deferrals;

import java.util.Map;

import lib.*;

import org.testng.annotations.Test;

import com.aventstack.extentreports.Status;
import com.greatWest.login.UserBaseTest;
import com.greatWest.pageObject.DeferralsPage;
import com.greatWest.pageObject.EnrollmentPage;
import com.greatWest.pageObject.HomePage;
import com.greatWest.utility.Common;
import com.greatWest.utility.Mobile;

public class DeferralsTestCases extends UserBaseTest {
	
	
	private DeferralsPage deferralsPage;
	private EnrollmentPage enrollmentPage;
	private HomePage laitPage;
	
	/*
	 * DDTC-7292
	 * QA - Contributions - Maximize to the IRS Limit
	 * Plan is set up with maximizer rules and participant is eligible.
	 * Apple use with Maximizer option enable
	 * DDTC-27902 QA-Contributions - Maximizer-Split rate page - Enter value more than deferral rate
	 * DDTC-27833 QA- My contributions page -Things to know (TTK) - message is available (with less than 200 characters).
	 */
	
	@Test(dataProvider = "setData")
	public void   PPTMOBILE_Deferral_001_DDTC_7292_QA_Contributions_Maximize_to_the_IRS_Limit(int itr,
			Map<String, String> testdata) {
	try{
	initializeReportForTC(itr);		
	   DeferralsPage.setApplePlan(true);
		deferralsPage = new DeferralsPage();
		deferralsPage.get();	
		//DDTC-27833 QA- My contributions page -Things to know (TTK) with less than 200 char
		Mobile.verifyElementPresent("TTK Message light-bulb image should be present", "light-bulb", "light-bulb" );		
		Mobile.verifyElementNotPresent("Tap Expand Button and it should not be display", "Expand", "Expand Button");
		deferralsPage.verify_DDTC_7292_QA_Contributions_Maximize_to_the_IRS_Limit();	
				
		} catch (Exception e) {
		 
			handleFailure(e);
		}
      	catch (Error ae){
		handleError(ae);
	}
	}
	
	
	/*
	 * @Author Siddartha 
	 * @Date : 14 Feb -2017
	 * @Test cases Name :DDTC-7224 Contributions - Maximize to the company match
	 * @Description :This test validates functionality of Contributions - Maximizer - Company Match.
	 * Apple Account User 
	 * 
	 */	
	
	@Test(dataProvider = "setData")
	public void  PPTMOBILE_Deferral_002_DDTC_7224_Contributions_Maximize_to_the_company_match(int itr,
			Map<String, String> testdata) {
	try{
		initializeReportForTC(itr);	
		DeferralsPage.setApplePlan(true);
		deferralsPage = new DeferralsPage();				
		deferralsPage.get();
		deferralsPage.verify_Contributions_Maximize_to_the_company_match();

		} catch (Exception e) {
		 
			handleFailure(e);
		}
      	catch (Error ae){
		handleError(ae);
	}
	}
	

	/*
	 * @Author Siddartha 
	 * @Date : 
	 * @Test cases Name :This test validates maximizer functionality for catch-up type contributions.
	 *  Pre-condition: participant successfully logged into the mobile app and accesses My contributions page.
	 *   And participant is eligible to make catch-up contributions..
	 */
	
	
	@Test(dataProvider = "setData")
	public void  PPTMOBILE_Deferral_003_DDTC_6291_Catch_Up_Maximizer_Changes_in_Standard_selection_type(int itr,
			Map<String, String> testdata) {
	try{
	initializeReportForTC(itr);
	DeferralsPage.setApplePlan(true);	
		deferralsPage = new DeferralsPage();		
		deferralsPage.get();
		DeferralsPage.setApplePlan(true);
		Reporter.logEvent(Status.INFO,"Step 1: Go To My contribution Select Standard->Maximize to IRS limit option and proceed with save and continue. "," Verify confirmation page by saving the maximized to IRS limit value.",false);
	
		deferralsPage.select_Contribution_Details(DeferralsPage.STANDARD, DeferralsPage.MAXIMIZE_LIMIT,DeferralsPage.BEFORE_TAX);
     	//String sStd_contribution_Rate1 =deferralsPage.get_MyContribution_Rate(DeferralsPage.BASE_PAY);
     	//deferralsPage.clickConfirm_And_Continue("Before");

		Reporter.logEvent(Status.INFO,"Step 2: Tap on Edit/Add button at Catch-up type contributions."," Verify Option display Maximize to IRS as Standard.1. Maximize to the IRS limit2. Enter your contribution rate",false);
		//String catch_UP_contribut_Rate = deferralsPage.get_MyContribution_Rate(DeferralsPage.CATCH_UP);
		deferralsPage.click_ContributionType_Edit_Add_Button(DeferralsPage.CATCH_UP);	    
	    deferralsPage.verify_Catch_Up_Option_Display_In_SelectionPage();
		String catch_UP_contribut_Rate = deferralsPage.get_MyContribution_Rate(DeferralsPage.MAXIMIZE_LIMIT);
	  	
	     
	  	Reporter.logEvent(Status.INFO,"Step 3:Select maximize to IRS limit option and proceed with save and continue. "," Verify confirmation page by saving the maximized to IRS limit value.",false);
		DeferralsPage.setbVerifyConfirmation(false);
	  	deferralsPage.select_Standard_Contribution_Page(DeferralsPage.MAXIMIZE_LIMIT, DeferralsPage.CATCH_UP_BEFORE, catch_UP_contribut_Rate);
		
		
		Reporter.logEvent(Status.INFO,"Step 4:Select  Standard -> Maximize to Apple Match option and proceed with save and continue. ","Verify confirmation page by saving the maximized to Apple match value. ",false);
		deferralsPage.click_ContributionType_Edit_Add_Button(DeferralsPage.STANDARD);
		Mobile.clickElement(DeferralsPage.MAXIMIZE_COMPANY_MATCH);
		String sStd_contribution_Rate1 =deferralsPage.get_Maximize_To_Company_Rate(DeferralsPage.CONTRIBUTION_COMPANY);
		DeferralsPage.setbVerifyConfirmation(true);
		deferralsPage.select_Standard_Contribution_Page(DeferralsPage.MAXIMIZE_COMPANY_MATCH, DeferralsPage.BEFORE_TAX, sStd_contribution_Rate1);
		
		
		Reporter.logEvent(Status.INFO,"Step 5: Tap on Edit/Add button at Catch-up type contributions"," verify  following options for the participants who selected Maximize to Company Match.1. Maximize to the IRS limit 2. Enter your contribution rate",false);
		deferralsPage.click_ContributionType_Edit_Add_Button(DeferralsPage.CATCH_UP);	
		deferralsPage.verify_Catch_Up_Option_Display_In_SelectionPage();
		
		Reporter.logEvent(Status.INFO,"Step 6 :Select maximize to IRS limit option and proceed with save and continue. ","Verify confirmation page by saving the maximized to IRS limit value. ",false);
		deferralsPage.select_Standard_Contribution_Page(DeferralsPage.MAXIMIZE_LIMIT, DeferralsPage.CATCH_UP_ROTH, catch_UP_contribut_Rate);
		
		Reporter.logEvent(Status.INFO,"Step 7:Select Standard ->  Enter your contribution rate option and proceed with save and continue. "," Verify confirmation page by saving custom contribution value.",false);
		deferralsPage.click_ContributionType_Edit_Add_Button(DeferralsPage.STANDARD);
		DeferralsPage.setbVerifyConfirmation(false);
		deferralsPage.select_Standard_Contribution_Page(DeferralsPage.ENTER_CONTRIBUTION_RATE, DeferralsPage.ROTH,UserBaseTest.getParaValue("Contribution_Rate"));
		
		
		Reporter.logEvent(Status.INFO,"Step 8 :Tap on Edit/Add button at Catch-up type contributions and validate the options. ","App will provide the following options for the participants who selected custom contribution rate.1.Enter your contribution rate ",false);
		deferralsPage.click_ContributionType_Edit_Add_Button(DeferralsPage.CATCH_UP);	
		Mobile.verifyElementNotPresent("Catch up Contribution Option", DeferralsPage.MAXIMIZE_LIMIT, " MAXIMIZE TO THE IRS LIMIT Option should not be displayed ");
		Mobile.verifyElementPresent("Catch up Contribution Option", DeferralsPage.ENTER_CONTRIBUTION_RATE, " ENTER YOUR CONTRIBUTION RATE Option  Displayed  ");
		Common.clickBackArrow();
		
				
		} catch (Exception e) {
		 
			handleFailure(e);
		}
      	catch (Error ae){
		handleError(ae);
	}
	}
	
	/*
	 * DDTC-6286
	 * Contributions shopping cart page - Registered participants - Prior plan contributions data on file
	 * This test validates the screen elements and validations of prior plan contributions (PPC) in deferrals shopping cart page.
	 * Pre-requisites: 
	 * The participant should be enrolled with the plan and need to be less than one year of employment.
	 * Participant enter PPC contribution details during their enrollment process.
	 * Business Rule:
	 * Participant should be eligible for quick enrollment and in their first year of employment:
	 * Plan should be setup with the prior plan contributions.
	 * select * from employment where hire_date > = '01-JAN-16'
	 * Participants not eligible for prior plan contributions:
	 * select * from employment where hire_date < '01-JAN-16'
	 * 
	 * QA - Enrollment - Ongoing Maximizer rate update with Salary on file & PPC contributions on file - Standard deferral group
	 * DDTC-30861 QA - Enrollment - Ongoing Maximizer rate update with Salary on file & PPC contributions on file - Standard deferral group
	 * DDTC-30863 QA - Enrollment - Ongoing Maximizer rate update with Salary on file & PPC contributions - Standard deferral group
	 * DDTC-30884 QA - Enrollment - Contributions_Onetime Maximizer rate update with Salary on file & PPC contributions - Standard and catch-up deferral group-PPC entered during session
	 */
	
	
	@Test(dataProvider = "setData")
	public void  PPTMOBILE_Deferral_004_Enroll_OnGoing_Maximizer_With_Update_Salary_And_PPC_For_Std_Defferal_Type(int itr,
			Map<String, String> testdata) {
	try{
	initializeReportForTC(itr);
    DeferralsPage.setApplePlan(true);
	enrollmentPage = new EnrollmentPage();	
	enrollmentPage.get();	

	String sValueToEnter = UserBaseTest.getParaValue("year_to_date_amount");	
	deferralsPage = new DeferralsPage();
	deferralsPage.click_Edit_Add_Button("CONTRIBUTIONS");
	
	DeferralsPage.setMaximize_Me_Always(true);
	deferralsPage.select_Contribution_Details(DeferralsPage.STANDARD, DeferralsPage.MAXIMIZE_LIMIT, DeferralsPage.BEFORE_TAX);
	 String beforeTax = deferralsPage.get_MyContribution_Rate_Percentage(DeferralsPage.APPLE_BEFORE_TAX);	
	Mobile.clickElement(DeferralsPage.SAVE_BUT);
	

	 Reporter.logEvent(Status.INFO,"Standard Rate at Shopping cart on File"," Before Tax : "+beforeTax,true);

	  enrollmentPage.enter_PPC_In_Enrollemnt_Page(sValueToEnter);	
	
	 String beforeTax_After_PPC_Update = deferralsPage.get_MyContribution_Rate_Percentage(DeferralsPage.APPLE_BEFORE_TAX);	
	 if(!beforeTax_After_PPC_Update.equals(beforeTax)){
	    	Reporter.logEvent(Status.PASS," Maximizer Rate for Standard Should  change after PPC update ","On File was  :"+beforeTax+  " \n  Actual is : "+beforeTax_After_PPC_Update,false);
	    	
	    }else{
	    	Reporter.logEvent(Status.FAIL,"  Maximizer Rate for Standard Should  change after PPC update ","On File was  :"+beforeTax+  " \n  Actual is : "+beforeTax_After_PPC_Update,false);
	 }
	 
	 Mobile.clickElement(DeferralsPage.PPC_SECTION);		
	deferralsPage.enter_amount_in_PPC("0");
	Mobile.clickElement(DeferralsPage.SAVE_BUT);
	Common.waitForProgressBar();	
	 
	deferralsPage.click_Edit_Add_Button("CONTRIBUTIONS");  
	 
	deferralsPage.update_MyAnnual_Compensation_Salary(DeferralsPage.STANDARD,DeferralsPage.BEFORE_TAX);		
	 String beforeTax_After_Salary_Update = deferralsPage.get_MyContribution_Rate_Percentage(DeferralsPage.APPLE_BEFORE_TAX);	
	 Mobile.clickElement(DeferralsPage.SAVE_BUT);
	 Common.waitForProgressBar();
	 Reporter.logEvent(Status.INFO,"Standard Rate at Shopping cart after Salary Update"," Before Salary update  Rate for Before Tax was : "+beforeTax_After_PPC_Update+"\n After Salary update Rate is :"+beforeTax_After_Salary_Update,true);

	 enrollmentPage.enter_PPC_In_Enrollemnt_Page(sValueToEnter);
	 
	 if(!beforeTax_After_Salary_Update.equals(beforeTax) || !beforeTax_After_Salary_Update.equals(beforeTax_After_PPC_Update) ){
	    	Reporter.logEvent(Status.PASS," Before Tax for Standard Should  change ","On File was  :"+beforeTax+  " \n  Actual is : "+beforeTax_After_Salary_Update,false);
	    	
	    }else{
	    	Reporter.logEvent(Status.FAIL," Before Tax for Standard Should  change ","On File was  :"+beforeTax+  " \n  Actual is : "+beforeTax_After_Salary_Update,false);
	 }
	enrollmentPage.clickEnrollNowButton();		
	Reporter.logEvent(Status.INFO, "Pre-requisites :  Participant should be eligible for quick enrollment and in their first year of employment", "Participant enter PPC contribution details during their enrollment process", false);

	Reporter.logEvent(Status.INFO,"Step 1 -3: Navigate to My contributions page. ","My Contributions page is display ",false);
	deferralsPage.selectDeferralsHomePage();	
	
	Reporter.logEvent(Status.INFO,"Step  4: PPC contributions is display","Verify PPC  section should be display ",false);	
	Mobile.verifyElementPresent("",DeferralsPage.PPC_SECTION, "PPC  section should be display");
	deferralsPage.verify_PPC_Content_Page(sValueToEnter);
	
		
	Reporter.logEvent(Status.INFO,"Step 7:  Tap on  edit link in PPC Section","Verify previously entered values in PPC page is displayed.",false);
	Common.clickEditLink(DeferralsPage.PPC_SECTION);
	deferralsPage.verify_PPC_EditTextBox_Value(sValueToEnter);
	
	Reporter.logEvent(Status.INFO,"Step 8:  Edit value  and click save button","Verify edited entered values in PPC page is displayed.",false);	
	String sEditAmount = UserBaseTest.getParaValue("editAmount");
	deferralsPage.enter_amount_in_PPC(sEditAmount);
	Mobile.clickElement(DeferralsPage.SAVE_BUT);
	Common.waitForProgressBar();
	deferralsPage.verify_My_Contribution_HomePage();	
	deferralsPage.verify_PPC_Content_Page(sEditAmount);
	Common.clickBackArrow();
	//Need to verify DB
	
	
	} catch (Exception e) {
		 
		handleFailure(e);
	}
  	catch (Error ae){
	handleError(ae);
}
}
	
	
	/*
	 * @Author Siddartha 
	 * @Date : 14 Feb -2017
	 * @Test cases Name :DDTC-6302
	 * 
	 * 	QA - Contributions shopping cart page -Registered participants- Prior plan contributions data not on file & catch-up allowed
	
	 * @Description : This test validates the screen elements and validations of prior plan contributions (PPC) in deferrals shopping cart page.
	 * @PreData :- The participant should be enrolled with the plan and need to be less than one year of employment.
	 * Participant do not enter PPC contribution details during their enrollment process.
	 * Participant age should be above than 50Years
	 * 
	 * DDTC-30886 QA - Contributions_Maximizer rate based on PPC rate - Standard and Catch-up deferral group with split deferral rates
	 * DDTC-30887 QA - Contributions_Maximizer rate based on PPC rate - Standard deferral group with split deferral rates
	 *  DDTC-30884
	 * QA - Enrollment - Contributions_Onetime Maximizer rate update with Salary on file & PPC contributions - 
	 * Standard and catch-up deferral group-PPC entered during session
	 * 
	 * DDTC-30888 QA -Enrollment- Contributions_Maximizer rate based on PPC rate - Standard and Catch-up deferral group with split deferral rates
	 *  DDTC-27900 QA-Enrollment- Contributions -Split rate page - Enter value more than deferral rate
	 *
	 */	
	@Test(dataProvider = "setData")
	public void  PPTMOBILE_Deferral_005_Enroll_OneTime_Maximizer_with_PPC_Standard_And_CatchUp_With_Split_Defferal(int itr,
			Map<String, String> testdata) {
	try{
	   initializeReportForTC(itr);	  	
	   DeferralsPage.setApplePlan(true);
	    enrollmentPage = new EnrollmentPage();	
		deferralsPage = new DeferralsPage();
		enrollmentPage.get();	

		DeferralsPage deferralsPage = new DeferralsPage();
		deferralsPage.click_Edit_Add_Button("CONTRIBUTIONS");		
	
		DeferralsPage.setMaximize_Me_Always(false);
		deferralsPage.select_Contribution_Details(DeferralsPage.STANDARD, DeferralsPage.MAXIMIZE_LIMIT, DeferralsPage.BEFORE_TAX);
		deferralsPage.select_Contribution_Details(DeferralsPage.CATCH_UP, DeferralsPage.MAXIMIZE_LIMIT, DeferralsPage.SPLIT);
	    Mobile.clickElement(DeferralsPage.SAVE_BUT);
	    Common.waitForProgressBar();
		String beforeTax = enrollmentPage.get_MyContribution_Rate_Percentage(DeferralsPage.APPLE_BEFORE_TAX);	
	    Reporter.logEvent(Status.INFO,"Standard Rate at Shopping cart on File"," Before Tax : "+beforeTax,true);
		 		 
		String catchUpBeforeRate = enrollmentPage.get_MyContribution_Rate_Percentage(DeferralsPage.CATCH_UP_BEFORE);	
		String catchUpRothRate = enrollmentPage.get_MyContribution_Rate_Percentage(DeferralsPage.CATCH_UP_ROTH);
		Reporter.logEvent(Status.INFO,"CatchUp Rate at Shopping cart on File","CatchUp Before Tax on file : "+catchUpBeforeRate + "\n Catch-Up Roth on File :"+catchUpRothRate,false);
		 		
		Reporter.logEvent(Status.INFO,"Step 12 :Turn  PPC switch to ON ","Verify page  \"Prior Plan Contributions\" ",false);
	    Mobile.switchButton(true);		 
	  	Reporter.logEvent(Status.INFO,"Step 21:  Enter value in the data for Year to date  and Catch Up contributions  text field"," Save button is enable",false);
		String sYearToDateAmount = UserBaseTest.getParaValue("year_to_date_amount");
		String catch_up_amount = UserBaseTest.getParaValue("catch_up_amount");
		deferralsPage.enter_amount_in_PPC(sYearToDateAmount);
		deferralsPage.enter_Amount_in_PPC_CatchUp(catch_up_amount);
	
		Reporter.logEvent(Status.INFO,"Step 23: Click Save button  ","Shopping Cart Page is displayed ",false);
		Mobile.clickElement(DeferralsPage.SAVE_BUT);
		Common.waitForProgressBar();			
		Mobile.verifyElementPresent("Alert Should be displayed", "//XCUIElementTypeAlert", "Alert Pop up");
        Mobile.clickElement("Continue");
        Common.waitForProgressBar();	
		Common.verifyWarningMessage("Because you changed your prior plan contribution amount, your catch-up Maximizer rate is now");
		deferralsPage.select_Contribution_Details(DeferralsPage.CATCH_UP, DeferralsPage.MAXIMIZE_LIMIT, DeferralsPage.SPLIT);
	     Mobile.clickElement(DeferralsPage.SAVE_BUT);	
	     Common.waitForProgressBar();
		
		String beforeTax_After_Update = enrollmentPage.get_MyContribution_Rate_Percentage(DeferralsPage.APPLE_BEFORE_TAX);
		String catchUp_roth_Update = enrollmentPage.get_MyContribution_Rate_Percentage(DeferralsPage.APPLE_CATCH_UP_ROTH);
		
	    if(!beforeTax_After_Update.equals(beforeTax)){
	    	Reporter.logEvent(Status.PASS," Before Tax for Standard Should  change ","On File was  :"+beforeTax+  " \n  Actual is : "+beforeTax_After_Update,true);
	    	
	    }else{
	    	Reporter.logEvent(Status.FAIL," Before Tax for Standard Should not change ","On File was  :"+beforeTax+  " \n  Actual is : "+beforeTax_After_Update,true);
		  }
	    if(!catchUp_roth_Update.equals(catchUpRothRate)){
	    	Reporter.logEvent(Status.PASS,"Catch Up  Rate should be change ","On File was  :"+catchUpRothRate+  " \n  Actual is : "+catchUp_roth_Update,true);
	    	
	    }else{
	    	Reporter.logEvent(Status.FAIL," Catch Up  Rate should be change ","On File was  :"+catchUpRothRate+  " \n  Actual is : "+catchUp_roth_Update,false);
		  }
	    
	    
	    Mobile.clickElement(DeferralsPage.PPC_SECTION);		
		deferralsPage.enter_amount_in_PPC("0");
		deferralsPage.enter_Amount_in_PPC_CatchUp("0");
		Mobile.clickElement(DeferralsPage.SAVE_BUT);
		Common.waitForProgressBar();	
		Mobile.verifyElementPresent("Alert Should be displayed", "//XCUIElementTypeAlert", "Alert Pop up");
        Mobile.clickElement("Continue");
    	Common.waitForProgressBar();
    	deferralsPage.select_Contribution_Details(DeferralsPage.CATCH_UP, DeferralsPage.MAXIMIZE_LIMIT, DeferralsPage.CATCH_UP_BEFORE);
	    Mobile.clickElement(DeferralsPage.SAVE_BUT);
	    Common.waitForProgressBar();
		enrollmentPage.clickEnrollNowButton();		
					
		} catch (Exception e) {
		 
			handleFailure(e);
		}
      	catch (Error ae){
		handleError(ae);
	}
	}
	

	
	
	
	/*
	 * @Author Siddartha 
	 * @Date : 14 Feb -2017
	 * @Test cases Name :QA - Contributions shopping cart page -Registered participants- Prior plan contributions data not on file & catch-up not allowed 
	 * @Description : This test validates the screen elements and validations of prior plan contributions (PPC) in deferrals shopping cart page.
	 * @PreData :- The participant should be enrolled with the plan and need to be less than one year of employment.
	 * Participant do not enter PPC contribution details during their enrollment process.
	 * Participant age should be less than 50Years
	 * 
	 * DDTC-30859 QA - Contributions_Onetime Maximizer rate update with Updated Salary & PPC contributions - Standard deferral group-PPC entered during session
	 * DDTC-30874 QA - Contributions_Onetime Maximizer rate update with Updated Salary & PPC contributions - Standard & Catch-up deferral group
	 * 
	 */	
	@Test(dataProvider = "setData")
	public void  PPTMOBILE_Deferral_006_OneTime_Maximizer_with_Update_Salary_And_PPC_With_Std_And_CatchUp_Defferal_Type(int itr,
			Map<String, String> testdata) {
	try{
	   initializeReportForTC(itr);	
	   DeferralsPage.setApplePlan(true);
		deferralsPage = new DeferralsPage();	
		deferralsPage.get();			
		deferralsPage.DDTC_6289_Prior_plan_contributions_data_not_on_file_and_catch_up_not_allowed();
		
				
		} catch (Exception e) {
		 
			handleFailure(e);
		}
      	catch (Error ae){
		handleError(ae);
	}
	}
	
	
	/*
	 * @Author Siddartha 
	 * @Date : 14 Feb -2017
	 * @Test cases Name :PPTMOBILE_Deferral_022_DDTC_6309_QA - Contributions shopping cart page - Registered participants - Prior plan contributions data entered during session
	 * @Description : This test validates the screen elements and validations of prior plan contributions (PPC) in deferrals shopping cart page.
	 * @PreData :- The participant should be enrolled with the plan and need to be less than one year of employment.
	 * Participant do not enter PPC contribution details during their enrollment process.
	 * Participant age should be above  than 50Years
	 * 
	 * DDTC-30863 QA - Enrollment - Ongoing Maximizer rate update with Salary on file & PPC contributions - Standard deferral group
	 * DDTC-30888 QA -Enrollment- Contributions_Maximizer rate based on PPC rate - Standard and Catch-up deferral group with split deferral rates
	 * DDTC-30882 QA - Enrollment - Ongoing Maximizer rate update with Salary on file & PPC contributions on file - Standard & Catch-up deferral group
	 */	
	@Test(dataProvider = "setData")
	public void  PPTMOBILE_022_Enroll_OnGoing_Maximizer_With_Update_Salary_And_PPC_during_session(int itr,
			Map<String, String> testdata) {
	try{
	   initializeReportForTC(itr);	  	
	   DeferralsPage.setApplePlan(true);
	    enrollmentPage = new EnrollmentPage();	
		deferralsPage = new DeferralsPage();
		enrollmentPage.get();	

		DeferralsPage deferralsPage = new DeferralsPage();
		deferralsPage.click_Edit_Add_Button("CONTRIBUTIONS");		
	
		DeferralsPage.setMaximize_Me_Always(true);
		deferralsPage.select_Contribution_Details(DeferralsPage.STANDARD, DeferralsPage.MAXIMIZE_LIMIT, DeferralsPage.BEFORE_TAX);
		deferralsPage.select_Contribution_Details(DeferralsPage.CATCH_UP, DeferralsPage.MAXIMIZE_LIMIT, DeferralsPage.SPLIT);
		
		/**
		 * if Maximizer RAte is more than 100% , verify warning message and update salary 
		 */
		if(Common.isWarningMsgDisplayed()){
			
		Common.verifyWarningMessage("Warning! The total of the following contributions must be no more than 100%:");
		  deferralsPage.update_MyAnnual_Compensation_Salary(DeferralsPage.STANDARD,DeferralsPage.BEFORE_TAX);	
		  String sMsg = "Your Maximize my Catch-Up contribution rate changed since you manually entered an annual compensation. Please update your Maximize my Catch-Up contributions.";
		  Mobile.verifyElementPresent("Warning message to Change Catch-Up Rate for Maximizer should be display.", sMsg, sMsg);
		  Mobile.scroll_UP();
		  deferralsPage.select_Contribution_Details(DeferralsPage.CATCH_UP, DeferralsPage.MAXIMIZE_LIMIT, DeferralsPage.SPLIT);
		}
		
		
	    Mobile.clickElement(DeferralsPage.SAVE_BUT);
	    Common.waitForProgressBar();
		String beforeTax = enrollmentPage.get_MyContribution_Rate_Percentage(DeferralsPage.APPLE_BEFORE_TAX);	
	    Reporter.logEvent(Status.INFO,"Standard Rate at Shopping cart on File"," Before Tax : "+beforeTax,true);
		 		 
		String catchUpBeforeRate = enrollmentPage.get_MyContribution_Rate_Percentage(DeferralsPage.CATCH_UP_BEFORE);	
		String catchUpRothRate = enrollmentPage.get_MyContribution_Rate_Percentage(DeferralsPage.CATCH_UP_ROTH);
		
		
		Reporter.logEvent(Status.INFO,"CatchUp Rate at Shopping cart on File","CatchUp Before Tax on file : "+catchUpBeforeRate + "\n Catch-Up Roth on File :"+catchUpRothRate,false);
		 
		Reporter.logEvent(Status.INFO,"Step 12 :Turn  PPC switch to ON ","Verify page  \"Prior Plan Contributions\" ",false);
	    Mobile.switchButton(true);		 
	  	Reporter.logEvent(Status.INFO,"Step 21:  Enter value in the data for Year to date  and Catch Up contributions  text field"," Save button is enable",false);
		String sYearToDateAmount = UserBaseTest.getParaValue("year_to_date_amount");
		String catch_up_amount = UserBaseTest.getParaValue("catch_up_amount");
		deferralsPage.enter_amount_in_PPC(sYearToDateAmount);
		deferralsPage.enter_Amount_in_PPC_CatchUp(catch_up_amount);
	
		Reporter.logEvent(Status.INFO,"Step 23: Click Save button  ","Shopping Cart Page is displayed ",false);
		Mobile.clickElement(DeferralsPage.SAVE_BUT);
		Common.waitForProgressBar();			
		Mobile.verifyElementPresent("Alert Should be displayed", "//XCUIElementTypeAlert", "Alert Pop up");
        Mobile.clickElement("Continue");
       Common.waitForProgressBar();	
		Common.verifyWarningMessage("Because you changed your prior plan contribution amount, your catch-up Maximizer rate is now");
		deferralsPage.select_Contribution_Details(DeferralsPage.CATCH_UP, DeferralsPage.MAXIMIZE_LIMIT, DeferralsPage.SPLIT);
	     Mobile.clickElement(DeferralsPage.SAVE_BUT);	
	     Common.waitForProgressBar();
		
		String beforeTax_After_Update = enrollmentPage.get_MyContribution_Rate_Percentage(DeferralsPage.APPLE_BEFORE_TAX);
		String catchUp_roth_Update = enrollmentPage.get_MyContribution_Rate_Percentage(DeferralsPage.APPLE_CATCH_UP_ROTH);
		
	    if(!beforeTax_After_Update.equals(beforeTax)){
	    	Reporter.logEvent(Status.PASS," Before Tax for Standard Should  change ","On File was  :"+beforeTax+  " \n  Actual is : "+beforeTax_After_Update,true);
	    	
	    }else{
	    	Reporter.logEvent(Status.FAIL," Before Tax for Standard Should not change ","On File was  :"+beforeTax+  " \n  Actual is : "+beforeTax_After_Update,true);
		  }
	    if(!catchUp_roth_Update.equals(catchUpRothRate)){
	    	Reporter.logEvent(Status.PASS,"Catch Up  Rate should be change ","On File was  :"+catchUpRothRate+  " \n  Actual is : "+catchUp_roth_Update,true);
	    	
	    }else{
	    	Reporter.logEvent(Status.FAIL," Catch Up  Rate should be change ","On File was  :"+catchUpRothRate+  " \n  Actual is : "+catchUp_roth_Update,false);
		  }
	    
	    
	    Mobile.clickElement(DeferralsPage.PPC_SECTION);		
		deferralsPage.enter_amount_in_PPC("0");
		deferralsPage.enter_Amount_in_PPC_CatchUp("0");
		Mobile.clickElement(DeferralsPage.SAVE_BUT);
		Common.waitForProgressBar();	
		Mobile.verifyElementPresent("Alert Should be displayed", "//XCUIElementTypeAlert", "Alert Pop up");
       Mobile.clickElement("Continue");
      	Common.waitForProgressBar();
     	deferralsPage.select_Contribution_Details(DeferralsPage.CATCH_UP, DeferralsPage.MAXIMIZE_LIMIT, DeferralsPage.SPLIT);
	    Mobile.clickElement(DeferralsPage.SAVE_BUT);
	    Common.waitForProgressBar();
		enrollmentPage.clickEnrollNowButton();		
		
		
		deferralsPage.DDTC_6309_Prior_plan_contributions_data_entered_during_session();				
		} catch (Exception e) {
		 
			handleFailure(e);
		}
      	catch (Error ae){
		handleError(ae);
	}
	}
	
	
	
	
	
	
	
	
	/*
	 * DDTC-5287
	 * QA -Contributions - Maximizer - Catchup - Maximize me Always NOT selected for Standard type
	 * Plan is set up with maximizer rules and participant is eligible for catch up
	 * This test validates functionality of Contributions - Maximizer - Catchup.
	 */
	
	@Test(dataProvider = "setData")
	public void  PPTMOBILE_Deferral_007_DDTC_5287_QA_Contributions_Maximizer_CatchUp_Maximize_Me_Always_NOT_Selected_for_Standard_type(int itr,
			Map<String, String> testdata) {
	try{
	initializeReportForTC(itr);
	DeferralsPage.setApplePlan(true);
		deferralsPage = new DeferralsPage();		
		deferralsPage.get();	
		
		deferralsPage.regular_Maximizer_Me_Always(false);
		
		//Precobdition
		deferralsPage.select_Contribution_Details(DeferralsPage.STANDARD, DeferralsPage.MAXIMIZE_LIMIT, DeferralsPage.BEFORE_TAX);
		
		Reporter.logEvent(Status.INFO,"Step 1: Go to My Contributions page and tap on Add/edit button at CATCH - UP type ","  Following options display 1) MAXIMIZE TO THE IRS LIMIT 2) ENTER YOUR CONTRIBUTION RATE",false);
		deferralsPage.click_ContributionType_Edit_Add_Button(DeferralsPage.CATCH_UP);
		deferralsPage.verify_Catch_Up_Option_Display_In_SelectionPage();		
		
		//Reporter.logEvent(Status.INFO,"Step 2: validate the default option"," ENTER YOUR CONTRIBUTION RATE radio button should be defaulted when the participant lands on the page",false);
	   	     
		Reporter.logEvent(Status.INFO,"Step 3-4:Select MAXIMIZE TO THE IRS LIMIT "," Verify the value of maximizer rate with % below the title",false);
		Mobile.clickElement(DeferralsPage.MAXIMIZE_LIMIT);
		deferralsPage.verify_Maximize_Limit_Rate_Display();		
		
	    //Verified in TC 001_DDTC_7292 
//		Reporter.logEvent(Status.INFO,"Step 5-6 : Tap on the pay per period amount"," Verify Tool Tip disclaimer ",false);
//		deferralsPage.verifyToolTip(DeferralsPage.MAXIMIZE_PER_PAY_PERIOD_VALUE,DeferralsPage.APPLE_MAXIMIZE_TOOLTIP_MSG);
//		
		Reporter.logEvent(Status.INFO,"Step 7 : Verify app displays current year IRS contribution limit under the pay period amount dotted line."," App displays the label \"The [year] IRS contribution limit:\" with the dollar amount. Dollar amount will be displayed in bold text.",false);
		deferralsPage.verify_IRS_Contribution_Limit_Displayed();			
		
		Reporter.logEvent(Status.INFO,"Step 8 : select the Maximixer option and tap on Continue button","Continue button should take the participant to the split page or shopping cart page, depending on if there are more than one catch-up deferral type ",false);
		String contribution_Rate = deferralsPage.get_MyContribution_Rate(DeferralsPage.MAXIMIZE_LIMIT);			
	    DeferralsPage.setbVerifyConfirmation(false);
		deferralsPage.select_Standard_Contribution_Page(DeferralsPage.MAXIMIZE_LIMIT,DeferralsPage.CATCH_UP_ROTH, contribution_Rate);
		 
				
		} catch (Exception e) {
		 
			handleFailure(e);
		}
      	catch (Error ae){
		handleError(ae);
	}
	}
	
	

	/*
	 * DDTC-5301  QA - Contributions - Maximizer - Saving both standard and catchup
	 * This test validates the functionality of saving maximizer elections for both Standard and catchup types.
	 * Pre-condition: Plan is set up with Maximizer and participant is eligible for both standard and catchup type elections
	 * 
	 */
	

	@Test(dataProvider = "setData")
	public void PPTMOBILE_Deferral_008_DDTC_5301_Contribution_Maximizer_Saving_both_standard_and_catchup(int itr,
			Map<String, String> testdata) {
	try{
		initializeReportForTC(itr);	
		DeferralsPage.setApplePlan(true);
		deferralsPage = new DeferralsPage();	
		deferralsPage.get();
		
		Reporter.logEvent(Status.INFO,"Go to My Contributions page  ","My Contribution Page is opened",false);
		
	    Reporter.logEvent(Status.INFO,"Step 1  Select standard -> Maximized to IRS limit and Catch Up -> Maximize to IRS limit and proceed with confirm & Continue","Verify confirmation page by saving the new Maximizer values for both standard and catch up.",false);
	       
	    deferralsPage.select_Contribution_Details(DeferralsPage.STANDARD, DeferralsPage.MAXIMIZE_LIMIT,DeferralsPage.BEFORE_TAX);
	    deferralsPage.select_Contribution_Details(DeferralsPage.CATCH_UP, DeferralsPage.MAXIMIZE_LIMIT,DeferralsPage.CATCH_UP_BEFORE);
	//	deferralsPage.clickConfirm_And_Continue("Before"); 		
		String sStandard_Rate_per_OnFile = deferralsPage.get_MyContribution_Rate(DeferralsPage.STANDARD);		
		String sCatch_Up_Rate_per_OnFile = deferralsPage.get_MyContribution_Rate(DeferralsPage.CATCH_UP);			
	
	  
		Reporter.logEvent(Status.INFO,"Step 2: Select standard -> Maximized to IRS limit and update the salary and proceed with confirm & Continue.","Verify Standard and catch up Rate value is Changed",false);
		deferralsPage.update_MyAnnual_Compensation_Salary(DeferralsPage.STANDARD,DeferralsPage.BEFORE_TAX);		
		deferralsPage.verify_MyContributions_Rate_Percentage_Update(DeferralsPage.STANDARD, sStandard_Rate_per_OnFile,true);
		deferralsPage.verify_MyContributions_Rate_Percentage_Update(DeferralsPage.CATCH_UP, sCatch_Up_Rate_per_OnFile,true);
		
		
		Reporter.logEvent(Status.INFO,"Step 3: Select standard -> Maximize to company match and do not change anything with Catch-up and proceed with confirm & continue","Verify confirmation page with new maximized value for standard type and existing value for catch up type. ",false);
		String changesStandard_Rate = deferralsPage.get_MyContribution_Rate(DeferralsPage.STANDARD);
		deferralsPage.click_ContributionType_Edit_Add_Button(DeferralsPage.STANDARD);    	
		deferralsPage.select_Standard_Contribution_Page(DeferralsPage.MAXIMIZE_COMPANY_MATCH, DeferralsPage.BEFORE_TAX, changesStandard_Rate);
    	deferralsPage.verify_MyContributions_Rate_Percentage_Update(DeferralsPage.STANDARD, sStandard_Rate_per_OnFile,true);
		deferralsPage.verify_MyContributions_Rate_Percentage_Update(DeferralsPage.CATCH_UP, sCatch_Up_Rate_per_OnFile,false);
		sStandard_Rate_per_OnFile = deferralsPage.get_MyContribution_Rate(DeferralsPage.STANDARD);
		sCatch_Up_Rate_per_OnFile = deferralsPage.get_MyContribution_Rate(DeferralsPage.CATCH_UP);
		
		Reporter.logEvent(Status.INFO,"Step 4: Select Catch-up ->Enter your Contribution rate and  proceed with confirm & continue ","Verify confirmation page with new custom value for catch up and existing maximized value for standard type.",false);
		deferralsPage.click_ContributionType_Edit_Add_Button(DeferralsPage.CATCH_UP);  
		DeferralsPage.setbVerifyConfirmation(false);
		deferralsPage.select_Standard_Contribution_Page(DeferralsPage.ENTER_CONTRIBUTION_RATE, DeferralsPage.BEFORE_TAX, sStandard_Rate_per_OnFile);
    	deferralsPage.verify_MyContributions_Rate_Percentage_Update(DeferralsPage.STANDARD, sStandard_Rate_per_OnFile,false);
		deferralsPage.verify_MyContributions_Rate_Percentage_Update(DeferralsPage.CATCH_UP, sCatch_Up_Rate_per_OnFile,true);
		  
		
		} catch (Exception e) {
		 
			handleFailure(e);
		}
      	catch (Error ae){
		handleError(ae);
	}
	}
	
	
	
	/*
	 * DDTC-8187] QA - Contributions - onetime Maximizer - Salary Update 
	 * This test validates the functionality for contributions - maximizer with salary updates
	 * Participant is eleigible for maximizer and catch-up.
	 * Make Catch-Up Maximizer selected as default 
	 * 
	 */
	
	
	@Test(dataProvider = "setData")
	public void  PPTMOBILE_Deferral_009_DDTC_8187_Contributions_Maximizer_Catch_Up_Onetime_Salary_Update(int itr,
			Map<String, String> testdata) {
	try{
		initializeReportForTC(itr);		
		deferralsPage = new DeferralsPage();
		
		DeferralsPage.setApplePlan(true);
		deferralsPage.get();	
		deferralsPage.DDTC_8187_Contributions_Maximizer_Catch_Up_Onetime_Salary_Update();
	
			
		} catch (Exception e) {
		 
			handleFailure(e);
		}
      	catch (Error ae){
		handleError(ae);
	}
	}
	
	
	
	
	
	/*
	 * @Author Siddartha 
	 * @Date : 
	 * @Test cases Name :QA -Contributions - Maximizer - Catchup - Maximize me Always selected for Standard type 
	 * @Description : This test validates functionality of Contributions - Maximizer - Catchup.
	 * Plan is set up with maximizer rules and participant is eligible for catch up
	 */
	
	
	@Test(dataProvider = "setData")
	public void  PPTMOBILE_Deferral_010_DDTC_7197_Maximizer_Catchup_Maximize_me_Always_selected_for_Standard_type(int itr,
			Map<String, String> testdata) {
	try{
		initializeReportForTC(itr);	  
		DeferralsPage.setApplePlan(true);
		deferralsPage = new DeferralsPage();
		deferralsPage.get();		
		deferralsPage.regular_Maximizer_Me_Always(true);	
		deferralsPage.DDTC_7197_Maximizer_Catchup_Maximize_me_Always_selected_for_Standard_type();
		
	
				
		} catch (Exception e) {
		 
			handleFailure(e);
		}
      	catch (Error ae){
		handleError(ae);
	}

	
	}
	
	

	/*
	 * QA - Contributions - Catch Up Maximizer - Changes in Salary
	 * 
	 * This test validates maximizer functionality for catch-up type contributions.
	 *  Pre-condition: participant successfully logged into the mobile app and accesses My contributions page. 
	 *  And participant is eligible to make catch-up contributions.
	 */

	@Test(dataProvider = "setData")
	public void PPTMOBILE_Deferral_011_DDTC_5289_Contribution_Maximize_Catch_Up_Changes_in_Salary(int itr,
			Map<String, String> testdata) {
	try{
	initializeReportForTC(itr);
	DeferralsPage.setApplePlan(true);
	deferralsPage = new DeferralsPage();
	deferralsPage.get();


	deferralsPage.select_Contribution_Details(DeferralsPage.STANDARD, DeferralsPage.MAXIMIZE_LIMIT,DeferralsPage.BEFORE_TAX);
 ///   String sStandard_Rate_per_OnFile = deferralsPage.get_MyContribution_Rate(DeferralsPage.STANDARD);
	
   //Reporter.logEvent(Status.INFO,"Step 2-3: Select Catch-up type  in My Contribution page","Note down Maximize to IRS limit value for catch up ",false);
	deferralsPage.getContributing_Salary_and_Rate_Value_OnFile(DeferralsPage.CATCH_UP,DeferralsPage.MAXIMIZE_LIMIT);
	String sCatch_Up_Rate_OnFile = DeferralsPage.getContributionRate();	
//	String sCatch_Up_PerPay_Period_OnFile = DeferralsPage.getContributionPerPayPeriod();	
	
	
	Reporter.logEvent(Status.INFO,"Step 4-5: Select  Standard-> Maximize and Update salary with new Value","Verify updated the Maximized to IRS limit percent based on the new salary and disable the switch for 'Maximize Me Always'. ",false);
	deferralsPage.update_MyAnnual_Compensation_Salary(DeferralsPage.STANDARD,DeferralsPage.BEFORE_TAX);		
    String sStandard_Rate_per_OnFile =DeferralsPage.getContributionRate();
	
	Reporter.logEvent(Status.INFO,"Step 5: Proceed with Save and continue ","Verify shopping cart page with new values for Standard type as per the updated salary. ",false);
	deferralsPage.verify_MyContributions_Rate_Percentage_Update(DeferralsPage.STANDARD, sStandard_Rate_per_OnFile,true);
	
	
	Reporter.logEvent(Status.INFO,"Step 6-10: Select Catch-Up type contributions"," Verify Catch-up Maximize to IRS limit value based on the new salary entered in Standard type.",false);
	deferralsPage.click_ContributionType_Edit_Add_Button(DeferralsPage.CATCH_UP);
	deferralsPage.verify_MyContributions_Rate_Percentage_Update(DeferralsPage.MAXIMIZE_LIMIT, sCatch_Up_Rate_OnFile,true);	
	
	
//	Reporter.logEvent(Status.INFO,"Step 8 -10: Tap on the pay per period amount ","Verify Tool Tip display",false);
//	deferralsPage.verifyToolTip(DeferralsPage.MAXIMIZE_PER_PAY_PERIOD_VALUE,DeferralsPage.APPLE_MAXIMIZE_TOOLTIP_MSG);

	Reporter.logEvent(Status.INFO,"Step 11:For Catch-Up select only ONE deferal type in split page and Proceed with confirm and continue "," App returns confirmation page with new values for BASE PAY and CATCH UP.",false);
	String contribution_Rate = deferralsPage.get_MyContribution_Rate(DeferralsPage.MAXIMIZE_LIMIT);
	deferralsPage.select_Standard_Contribution_Page(DeferralsPage.MAXIMIZE_LIMIT,DeferralsPage.CATCH_UP_BEFORE, contribution_Rate);
	
		
	Reporter.logEvent(Status.INFO,"Step 12:Select Standard ->  Maximize  and Reset  salary  and select the option 'Maximize Me Always' ","Verify  Maximized to IRS limit percent based on the new salary and displays new values with the message ' Maximize Me Always' on shopping cart page. ",false);
	deferralsPage.regular_Maximizer_Me_Always(true);
	deferralsPage.verify_MyContributions_Rate_Percentage_Update(DeferralsPage.STANDARD, sStandard_Rate_per_OnFile,true);
	deferralsPage.verifyMaximize_Me_Always_Diplayed(DeferralsPage.STANDARD,true);
	
	
	Reporter.logEvent(Status.INFO,"Step 13: Verify CATCH UP percent on shopping cart page based on the current salary.","Verify  Catch-up Maximize to IRS limit value based on the current salary in Standard type. ",false);
	deferralsPage.verify_MyContributions_Rate_Percentage_Update(DeferralsPage.CATCH_UP, sCatch_Up_Rate_OnFile,true);

	
	
	Reporter.logEvent(Status.INFO,"Step 14:Proceed with confirm and continue ","App returns confirmation page with new values for BASE PAY and CATCH UP and with message 'Maximize Me Always' for both BASE PAY and CATCH UP types ",false);
	Mobile.clickElement(DeferralsPage.CONFIRM_AND_CONTINUE_BUT);
	String sLabel = sCatch_Up_Rate_OnFile+"%Catch-Up Before(Maximize Me Always)";
	deferralsPage.verify_Confirmation_Page(DeferralsPage.APPLE_PLAN,sLabel);
	   
	
	
	Reporter.logEvent(Status.INFO,"Step 15-16: Select Standard -> Maximize and Update the participant's salary with a new value."," Verify update  Maximized limit percent based on the new salary and disable the switch for 'Maximize Me Always'. ",false);
	deferralsPage.update_MyAnnual_Compensation_Salary(DeferralsPage.STANDARD,DeferralsPage.BEFORE_TAX);		
		
	
	Reporter.logEvent(Status.INFO,"Step 17: Click Continue Button","Verify new value for CATCH UP - Maximized to IRS will be displayed in shopping cart page based on the updated salary. ",false);
	deferralsPage.verify_MyContributions_Rate_Percentage_Update(DeferralsPage.CATCH_UP, sCatch_Up_Rate_OnFile,true);
	
	
	Reporter.logEvent(Status.INFO,"Step 18:Proceed with Confirm and continue ","App returns confirmation page with new values for BASE PAY and CATCH UP and without Maximized message. ",false);
	Mobile.clickElement(DeferralsPage.CONFIRM_AND_CONTINUE_BUT);						
	deferralsPage.verify_Confirmation_Page(DeferralsPage.APPLE_PLAN,"Catch-Up Before");
	
	
	Reporter.logEvent(Status.INFO,"Step 19: Standard-> Maximize and Reset salary and select the option 'Maximize Me Always' "," Verify  Maximized limit percent based on the new salary and displays new values with the message ' Maximize Me Always' on shopping cart page.",false);
	deferralsPage.regular_Maximizer_Me_Always(true);	
	deferralsPage.verify_MyContributions_Rate_Percentage_Update(DeferralsPage.STANDARD, sStandard_Rate_per_OnFile,true);
	deferralsPage.verifyMaximize_Me_Always_Diplayed(DeferralsPage.STANDARD,true);
	
	
	Reporter.logEvent(Status.INFO,"Step 20: Verify CATCH UP percent on shopping cart page based on the current salary.","App will update Catch-up Maximize to IRS limit value based on the current salary in Standard type. ",false);
	deferralsPage.verify_MyContributions_Rate_Percentage_Update(DeferralsPage.CATCH_UP, sCatch_Up_Rate_OnFile,true);
	
	
	Reporter.logEvent(Status.INFO,"Step 21: For catch up, select more than ONE deferal type in split page and Proceed with confirm and continue ","App returns confirmation page with new values for BASE PAY and CATCH UP ( multiple deferral types) with 'Maximize Me Always' message. ",false);
	deferralsPage.click_ContributionType_Edit_Add_Button(DeferralsPage.CATCH_UP);
	deferralsPage.select_Standard_Contribution_Page(DeferralsPage.MAXIMIZE_LIMIT,DeferralsPage.CATCH_UP_BEFORE, contribution_Rate);
	Mobile.clickElement(DeferralsPage.CONFIRM_AND_CONTINUE_BUT);
	deferralsPage.verify_Confirmation_Page(DeferralsPage.APPLE_PLAN,"Catch-Up Before");
	 
	
	Reporter.logEvent(Status.INFO,"Step 22-23: Select Standard-> Maximize  and Update salary with a new value.","Verify updates the Maximized to IRS limit percent and disable the switch for 'Maximize Me Always'.",false);
//	deferralsPage.regular_Maximizer_Me_Always(false);	
	deferralsPage.update_MyAnnual_Compensation_Salary(DeferralsPage.STANDARD,DeferralsPage.BEFORE_TAX);		
	deferralsPage.verify_MyContributions_Rate_Percentage_Update(DeferralsPage.STANDARD, sStandard_Rate_per_OnFile,true);
	
		
	Reporter.logEvent(Status.INFO,"Step 24: Verify app disables 'confirm & continue' button in shopping cart page and displays a message to update catch up contributions"," App disables 'confirm & continue' button in shopping cart page and displays a following message to update catch up contributions."
			+ "Your Maximize my catch-up contribution rate changed since you manually entered an annual compensation. Please update your Maximize my Catch-Up Contributions.",false);

	Mobile.verifyElementISDisable(DeferralsPage.CONFIRM_AND_CONTINUE_BUT, "CONFIRM AND CONTINUE button is disable");
	

		} catch (Exception e) {
		 
			handleFailure(e);
		}
      	catch (Error ae){
		handleError(ae);
	}
	}

	
	/*
	 * PPTMOBILE_Deferral_012_DDTC_7248_Single_deferral_Type_split_with_catch_up_Percent type_Not_in_Enrollment_flow_ Add _and_Save
	 *Preconditions:
	 *	1)User is enrolled 
	 *2) User has been authenticated and directed to the deferral ui page
	 *3) User qualifies for a plan that has multiple sources
	 *4) User qualifies for a plan that offers percent contribtuions only
	 *5 Plan offers Catch-up contribution type
	 */
	
	@Test(dataProvider = "setData")
	public void PPTMOBILE_Deferral_012_DDTC_7248_7291_Deferrals_Percent_type_Not_in_Enrollment_flow_Add_and_Save(int itr,
			Map<String, String> testdata) {
	try{
		initializeReportForTC(itr);
		DeferralsPage.setApplePlan(true);
		deferralsPage = new DeferralsPage();
		deferralsPage.get();
     	Reporter.logEvent(Status.INFO,"Step 1 User clicks My Contributions link","Shopping Cart page should open",false);	
     	DeferralsPage.setElective_Deferral_Deleated(UserBaseTest.getParaValue("contribution_Rate_Type"),true);    
     	DeferralsPage.setbVerifyConfirmation(false); 
     	
    	Reporter.logEvent(Status.INFO,"Step 2 Select Standard Add button ->Enter Contribution Rate and click continue and save"," Verify Defferal Type with Percentage Rate in Shopping Cart",false);	
     	deferralsPage.verifyEnter_Contribution_Rate(DeferralsPage.STANDARD,DeferralsPage.ENTER_CONTRIBUTION_RATE, DeferralsPage.BEFORE_TAX);
           	
    	Reporter.logEvent(Status.INFO,"Step 3 Select Catch up Add button ->Enter Contribution Rate and click continue and save"," Verify Defferal Type with Percentage Rate in Shopping Cart",false);	
        deferralsPage.verifyEnter_Contribution_Rate(DeferralsPage.CATCH_UP,DeferralsPage.ENTER_CONTRIBUTION_RATE, DeferralsPage.CATCH_UP_BEFORE);
      	
        Reporter.logEvent(Status.INFO,"Step 4 Select After Tax Add button ->Enter Contribution Rate and click continue and save"," Verify Defferal Type with Percentage Rate in Shopping Cart",false);	
       	deferralsPage.verifyEnter_Contribution_Rate(DeferralsPage.AFTER_TAX,DeferralsPage.ENTER_CONTRIBUTION_RATE, "");
	   
     	Reporter.logEvent(Status.INFO,"Step 5 Select Bonus Add button ->Enter Contribution Rate and click continue and save"," Verify Defferal Type with Percentage Rate in Shopping Cart",false);	
     	DeferralsPage.setbVerifyConfirmation(true); 
     	deferralsPage.verifyEnter_Contribution_Rate(DeferralsPage.BONUS,DeferralsPage.ENTER_CONTRIBUTION_RATE, DeferralsPage.BONUS_BEFORE);
		
    	
						
		} catch (Exception e) {
		 
			handleFailure(e);
		}
      	catch (Error ae){
		handleError(ae);
	}
	}
	
	/*
	 * QA- Contributions-Single deferral type (split with catch-up) - Percent type - Not in Enrollment flow - Edit & Save 
	 * Preconditions:
	 * 1)User is not enrolled 
	 * 2) User has been authenticated and directed to the deferral ui page
	 * 3) User qualifies for a plan that has multiple sources
	 * 4) User qualifies for a plan that offers percent contribtuions only
	 * 5) paln offer Age-Catchup contribution type
	 * 	 * 
	 * Select distinct ga_id from DEFERRAL_RULE_CURRENT_VIEW where rule_display_name='Allowed Deferral' and rule_code in ('AGEBEF','AGERTH') and termdate is null;


	 */
	
	
	@Test(dataProvider = "setData")
	public void PPTMOBILE_Deferral_013_DDTC_7291_7248_Deferral_Type_Percent_type_Not_in_Enrollment_flow_Edit_and_Save(int itr,
			Map<String, String> testdata) {
	try{
		initializeReportForTC(itr);
		DeferralsPage.setApplePlan(true);
		deferralsPage = new DeferralsPage();
		deferralsPage.get();
	
	Reporter.logEvent(Status.INFO,"Step 1 User clicks My Contributions link","Shopping Cart page should open",false);	
	DeferralsPage.setElective_Deferral_Deleated(UserBaseTest.getParaValue("contribution_Rate_Type"),false);    
 	DeferralsPage.setbVerifyConfirmation(false); 
 	
 	Reporter.logEvent(Status.INFO,"Step 2 Select Standard Edit button ->Enter Contribution Rate and click continue and save"," Verify Defferal Type with Percentage Rate in Shopping Cart",false);	
 	deferralsPage.verifyEnter_Contribution_Rate(DeferralsPage.STANDARD,DeferralsPage.ENTER_CONTRIBUTION_RATE, DeferralsPage.SPLIT);
    	
	
	Reporter.logEvent(Status.INFO,"Step 3 Select Catch up Edit button ->Enter Contribution Rate and click continue and save"," Verify Defferal Type with Percentage Rate in Shopping Cart",false);	
    deferralsPage.verifyEnter_Contribution_Rate(DeferralsPage.CATCH_UP,DeferralsPage.ENTER_CONTRIBUTION_RATE, DeferralsPage.SPLIT);
 
	
     //Reporter.logEvent(Status.INFO,"Step 4 Select Bonus Tax Edit button ->Enter Contribution Rate and click continue and save"," Verify Defferal Type with Percentage Rate in Shopping Cart",false);	
	//deferralsPage.verifyEnter_Contribution_Rate(DeferralsPage.BONUS,DeferralsPage.ENTER_CONTRIBUTION_RATE,"");
		
	
 	Reporter.logEvent(Status.INFO,"Step 5 Select After Edit button ->Enter Contribution Rate and click continue and save"," Verify Defferal Type with Percentage Rate in Shopping Cart",false);	
	DeferralsPage.setbVerifyConfirmation(true);  
	deferralsPage.verifyEnter_Contribution_Rate(DeferralsPage.AFTER_TAX,DeferralsPage.ENTER_CONTRIBUTION_RATE, "");
    
		} catch (Exception e) {
		 
			handleFailure(e);
		}
      	catch (Error ae){
		handleError(ae);
	}
	}
	
	
	/*
	 * QA- Contributions-Single deferral type (split with catch-up) - Percent type - Not in Enrollment flow - Edit & Save 
	 * Preconditions:
	 * 1)User is not enrolled 
	 * 2) User has been authenticated and directed to the deferral ui page
	 * 3) User qualifies for a plan that has multiple sources
	 * 4) User qualifies for a plan that offers percent contribtuions only
	 * 5) paln offer Age-Catchup contribution type
	 * 	 * 
	 * PPTMOBILE_Deferral_014_DDTC_7207_Single_deferral_type_split_Percent_type_in_Enrollment_flow_Add_and_Save
	 * Select distinct ga_id from DEFERRAL_RULE_CURRENT_VIEW where rule_display_name='Allowed Deferral' and rule_code in ('AGEBEF','AGERTH') and termdate is null;
	 */
	
	
	@Test(dataProvider = "setData")
	public void PPTMOBILE_Deferral_014_DDTC_7299_Deferral_Type_Dollor_Type_Not_In_Enrollment_flow_Add_And_Save(int itr,
			Map<String, String> testdata) {
	try{
		initializeReportForTC(itr);
		deferralsPage = new DeferralsPage();
		deferralsPage.get();
		DeferralsPage.setApplePlan(true);
     	Reporter.logEvent(Status.INFO,"Step 1 User clicks My Contributions link","Shopping Cart page should open",false);	
     	DeferralsPage.setElective_Deferral_Deleated(UserBaseTest.getParaValue("contribution_Rate_Type"),false);    
     	DeferralsPage.setbVerifyConfirmation(false); 
     	
     	Reporter.logEvent(Status.INFO,"Step 2 Select Standard Add button ->Enter Contribution Rate and click continue and save"," Verify Defferal Type with Dollor amount in Shopping Cart",false);	
     	deferralsPage.verifyEnter_Contribution_Rate(DeferralsPage.STANDARD,DeferralsPage.ENTER_CONTRIBUTION_RATE, DeferralsPage.ROTH);
        	
    	
    	Reporter.logEvent(Status.INFO,"Step 3 Select Catch up Add button ->Enter Contribution Rate and click continue and save"," Verify Defferal Type with Dollor amount in Shopping Cart",false);	
        deferralsPage.verifyEnter_Contribution_Rate(DeferralsPage.CATCH_UP,DeferralsPage.ENTER_CONTRIBUTION_RATE, DeferralsPage.CATCH_UP_ROTH);
     
		
//    	Reporter.logEvent(Status.INFO,"Step 4 Select Bonus Tax Add button ->Enter Contribution Rate and click continue and save"," Verify Defferal Type with Dollor amount in Shopping Cart",false);	
//    
//    	deferralsPage.verifyEnter_Contribution_Rate(DeferralsPage.BONUS,DeferralsPage.ENTER_CONTRIBUTION_RATE, DeferralsPage.BONUS_ROTH);
//	    	
		
     	Reporter.logEvent(Status.INFO,"Step 5 Select After Tax  Add button ->Enter Contribution Rate and click continue and save"," Verify Defferal Type with Dollor amount in Shopping Cart",false);	
        DeferralsPage.setbVerifyConfirmation(true); 
		deferralsPage.verifyEnter_Contribution_Rate(DeferralsPage.AFTER_TAX,DeferralsPage.ENTER_CONTRIBUTION_RATE,"");
		
	} catch (Exception e) {
		 
		handleFailure(e);
	}
  	catch (Error ae){
	handleError(ae);
}
}
	
	/*
	 * QA- Contributions-Single deferral type (split with catch-up) - Percent type - Not in Enrollment flow - Edit & Save 
	 * Preconditions:
	 * 1)User is not enrolled 
	 * 2) User has been authenticated and directed to the deferral ui page
	 * 3) User qualifies for a plan that has multiple sources
	 * 4) User qualifies for a plan that offers percent contribtuions only
	 * 5) paln offer Age-Catchup contribution type
	 * 	 * 
	 * PPTMOBILE_Deferral_014_DDTC_7207_Single_deferral_type_split_Percent_type_in_Enrollment_flow_Add_and_Save
	 * Select distinct ga_id from DEFERRAL_RULE_CURRENT_VIEW where rule_display_name='Allowed Deferral' and rule_code in ('AGEBEF','AGERTH') and termdate is null;
	 */


	@Test(dataProvider = "setData")
	public void PPTMOBILE_Deferral_015_DDTC_7215_7299_Deferral_Type_Dollor_type_Not_in_Enrollment_flow_Edit_And_Save(int itr,
			Map<String, String> testdata) {
	try{
		initializeReportForTC(itr);
	//	DeferralsPage.setDuplicateApplePlan(true);
		deferralsPage = new DeferralsPage();
		deferralsPage.get();
	
	Reporter.logEvent(Status.INFO,"Step 1 User clicks My Contributions link","Shopping Cart page should open",false);	
	DeferralsPage.setElective_Deferral_Deleated(UserBaseTest.getParaValue("contribution_Rate_Type"),false);    
 	DeferralsPage.setbVerifyConfirmation(false); 
 	
 	Reporter.logEvent(Status.INFO,"Step 2 Select Standard Edit button ->Enter Contribution Rate and click continue and save"," Verify Defferal Type with Dollor amount in Shopping Cart",false);	
 	deferralsPage.verifyEnter_Contribution_Rate(DeferralsPage.STANDARD,DeferralsPage.ENTER_CONTRIBUTION_RATE, DeferralsPage.SPLIT);
    	
	
	Reporter.logEvent(Status.INFO,"Step 3 Select Catch up Edit button ->Enter Contribution Rate and click continue and save"," Verify Defferal Type with Dollor amount in Shopping Cart",false);	
	
	deferralsPage.verifyEnter_Contribution_Rate(DeferralsPage.CATCH_UP,DeferralsPage.ENTER_CONTRIBUTION_RATE, DeferralsPage.SPLIT);
 
	
//	Reporter.logEvent(Status.INFO,"Step 4 Select Bonus Tax Edit button ->Enter Contribution Rate and click continue and save"," Verify Defferal Type with Dollor amount in Shopping Cart",false);	
//	deferralsPage.verifyEnter_Contribution_Rate(DeferralsPage.BONUS,DeferralsPage.ENTER_CONTRIBUTION_RATE, "");
//		
	
 	Reporter.logEvent(Status.INFO,"Step 5 Select After Edit button ->Enter Contribution Rate and click continue and save"," Verify Defferal Type with Dollor amount in Shopping Cart",false);	
	DeferralsPage.setbVerifyConfirmation(true);  
	deferralsPage.verifyEnter_Contribution_Rate(DeferralsPage.AFTER_TAX,DeferralsPage.ENTER_CONTRIBUTION_RATE, "");
  
	} catch (Exception e) {
		 
		handleFailure(e);
	}
  	catch (Error ae){
	handleError(ae);
}
}
	
	
	
	/*
	 * QA- Contributions-Single deferral type (split with catch-up) - Percent type - Not in Enrollment flow - Edit & Save 
	 * Preconditions:
	 * 1)User is not enrolled 
	 * 2) User has been authenticated and directed to the deferral ui page
	 * 3) User qualifies for a plan that has multiple sources
	 * 4) User qualifies for a plan that offers percent contribtuions only
	 * 5) paln offer Age-Catchup contribution type
	 * 	 * 
	 * PPTMOBILE_Deferral_014_DDTC_7207_Single_deferral_type_split_Percent_type_in_Enrollment_flow_Add_and_Save
	 * Select distinct ga_id from DEFERRAL_RULE_CURRENT_VIEW where rule_display_name='Allowed Deferral' and rule_code in ('AGEBEF','AGERTH') and termdate is null;
	 */

	
	@Test(dataProvider = "setData")
	public void PPTMOBILE_Deferral_016_DDTC_7207_Deferral_Type_Percent_Rate_in_Enrollment_flow_Add_and_Save(int itr,
			Map<String, String> testdata) {
	try{
	initializeReportForTC(itr);
	DeferralsPage.setApplePlan(true);
	enrollmentPage = new EnrollmentPage();	
	deferralsPage = new DeferralsPage();

	Reporter.logEvent(Status.INFO, "Pre-requisites : ", " Participant should be in  enrollment flow", false);
	enrollmentPage.get();		
	enrollmentPage.clickEnrollNowButton();	
	
	Reporter.logEvent(Status.INFO,"Step 1 User clicks My Contributions link","Shopping Cart page should open",false);	
	deferralsPage.selectDeferralsHomePage();	
	DeferralsPage.setElective_Deferral_Deleated(UserBaseTest.getParaValue("contribution_Rate_Type"),true);    
	DeferralsPage.setbVerifyConfirmation(false); 
	
	Reporter.logEvent(Status.INFO,"Step 2 Select Standard Add button ->Enter Contribution Rate and click continue and save"," Verify Defferal Type with Percentage Rate in Shopping Cart",false);	
	deferralsPage.verifyEnter_Contribution_Rate(DeferralsPage.STANDARD,DeferralsPage.ENTER_CONTRIBUTION_RATE, DeferralsPage.SPLIT);
	

	Reporter.logEvent(Status.INFO,"Step 3 Select Catch up Add button ->Enter Contribution Rate and click continue and save"," Verify Defferal Type with Percentage Rate in Shopping Cart",false);	
	deferralsPage.verifyEnter_Contribution_Rate(DeferralsPage.CATCH_UP,DeferralsPage.ENTER_CONTRIBUTION_RATE, DeferralsPage.SPLIT);


	Reporter.logEvent(Status.INFO,"Step 4 Select After Add Edit button ->Enter Contribution Rate and click continue and save"," Verify Defferal Type with Percentage Rate in Shopping Cart",false);	
	DeferralsPage.setbVerifyConfirmation(true);  
	deferralsPage.verifyEnter_Contribution_Rate(DeferralsPage.AFTER_TAX,DeferralsPage.ENTER_CONTRIBUTION_RATE, "");
	

//	Reporter.logEvent(Status.INFO,"Step 4 Select Bonus Add button ->Enter Contribution Rate and click continue and save"," Verify Defferal Type with Percentage Rate in Shopping Cart",false);	
//	DeferralsPage.setbVerifyConfirmation(true);  
//	deferralsPage.verifyEnter_Contribution_Rate(DeferralsPage.BONUS,DeferralsPage.ENTER_CONTRIBUTION_RATE,"");
 				
	} catch (Exception e) {
		 
			handleFailure(e);
		}
      	catch (Error ae){
		handleError(ae);
	}
	}
	
	
	/*
	 * [DDTC-7310] QA - Contributions Shoping Cart_Split allowed_Dollar contributions
	 * This test validates functionality of Contributions - Enter your contribution rate section.
	 * ElECTIVE_ENROLL_DOLLOR_TYPE
	}
	 */

	@Test(dataProvider = "setData")
	public void PPTMOBILE_Deferral_034_DDTC_7310_Shoping_Cart_Allowed_Dollor_Contribution(int itr,
			Map<String, String> testdata) {
	try{
	initializeReportForTC(itr);
	//DeferralsPage.setApplePlan(true);
	enrollmentPage = new EnrollmentPage();	
	//Step 1 Navigate to My Contribution Page
	enrollmentPage.get();	
	DeferralsPage.setbVerifyConfirmation(false); 
	enrollmentPage.verify_Shopping_Cart_Rate_changed();	
	
	
	} catch (Exception e) {
		 
		handleFailure(e);
	}
  	catch (Error ae){
	handleError(ae);
}
}
	
	/*
	 *QA - Contributions Shoping Cart_Split allowed_percent contributions
	 * This test validates functionality of Contributions - Enter your contribution rate section.
	 * 
	}
	 */

	@Test(dataProvider = "setData")
	public void PPTMOBILE_Deferral_035_DDTC_7198_Shoping_Cart_Allowed_Percentage_Contribution(int itr,
			Map<String, String> testdata) {
	try{
		initializeReportForTC(itr);
	//	DeferralsPage.setApplePlan(true);
		enrollmentPage = new EnrollmentPage();	
		//Step 1 Navigate to My Contribution Page
		enrollmentPage.get();	
		DeferralsPage.setbVerifyConfirmation(false); 
		enrollmentPage.verify_Shopping_Cart_Rate_changed();	
	
	} catch (Exception e) {
		 
		handleFailure(e);
	}
  	catch (Error ae){
	handleError(ae);
}
}
	
	
	
	/*
	 * QA- Contributions-Single deferral type (split with catch-up) - Percent type - Not in Enrollment flow - Edit & Save 
	 * Preconditions:
	 * 1)User is not enrolled 
	 * 2) User has been authenticated and directed to the deferral ui page
	 * 3) User qualifies for a plan that has multiple sources
	 * 4) User qualifies for a plan that offers percent contribtuions only
	 * 5) paln offer Age-Catchup contribution type
	 * 	 * 
	 * PPTMOBILE_Deferral_014_DDTC_7207_Single_deferral_type_split_Percent_type_in_Enrollment_flow_Add_and_Save
	 * Select distinct ga_id from DEFERRAL_RULE_CURRENT_VIEW where rule_display_name='Allowed Deferral' and rule_code in ('AGEBEF','AGERTH') and termdate is null;
	 */
	

	@Test(dataProvider = "setData")
	public void PPTMOBILE_Deferral_017_DDTC_7300_Deferral_Type_Dollor_Amount_in_Enrollment_flow_Add_and_Save(int itr,
			Map<String, String> testdata) {
	try{
	initializeReportForTC(itr);
//	DeferralsPage.setApplePlan(true);
	enrollmentPage = new EnrollmentPage();	
	deferralsPage = new DeferralsPage();
	enrollmentPage.get();		
	enrollmentPage.clickEnrollNowButton();	

	Reporter.logEvent(Status.INFO,"Step 1 User clicks My Contributions link","Shopping Cart page should open",false);	
	deferralsPage.selectDeferralsHomePage();	
	DeferralsPage.setElective_Deferral_Deleated(UserBaseTest.getParaValue("contribution_Rate_Type"),true);    
	DeferralsPage.setbVerifyConfirmation(false); 
	
	Reporter.logEvent(Status.INFO,"Step 2 Select Standard Add button ->Enter Contribution Rate and click continue and save"," Verify Defferal Type with dollor amount in Shopping Cart",false);	
	deferralsPage.verifyEnter_Contribution_Rate(DeferralsPage.STANDARD,DeferralsPage.ENTER_CONTRIBUTION_RATE, DeferralsPage.SPLIT);
	

	Reporter.logEvent(Status.INFO,"Step 3 Select Catch up Add button ->Enter Contribution Rate and click continue and save"," Verify Defferal Type with dollor amount in Shopping Cart",false);	
	deferralsPage.verifyEnter_Contribution_Rate(DeferralsPage.CATCH_UP,DeferralsPage.ENTER_CONTRIBUTION_RATE, DeferralsPage.SPLIT);

	Reporter.logEvent(Status.INFO,"Step 4 Select After Tax Add button ->Enter Contribution Rate and click continue and save"," Verify Defferal Type dollor amount Rate in Shopping Cart",false);	
	deferralsPage.verifyEnter_Contribution_Rate(DeferralsPage.AFTER_TAX,DeferralsPage.ENTER_CONTRIBUTION_RATE, "");
	

	Reporter.logEvent(Status.INFO,"Step 5 Select Bonus Add button ->Enter Contribution Rate and click continue and save"," Verify Defferal Type dollor amount Rate in Shopping Cart",false);	
	DeferralsPage.setbVerifyConfirmation(true);
	deferralsPage.verifyEnter_Contribution_Rate(DeferralsPage.BONUS,DeferralsPage.ENTER_CONTRIBUTION_RATE, DeferralsPage.BONUS_SPLIT);
 
	} catch (Exception e) {
		 
		handleFailure(e);
	}
  	catch (Error ae){
	handleError(ae);
}
}
	
	
	/*
	 * 
	 * DDTC_12338 QA- Contributions - View only deferral group - no Values
	 * Preconditions:
	 * This test validates that if view only deferral is $ type then by default participant is able to enter contribution rate only in % type.
	 * 	 * 
	 * Pre-requisites:
	 *  Participant should be enrolled with the plan and should not have contribution rate for the view only Deferrals.
	 *  
	 *  View only deferrals need to be identified through CSAS application and mention the contribution types in below query to identify the participants who has read only deferrals in particular plan.
	 *
	 *
	 * Change the in CSAS 
	 *5% ROTH WITH 5% BEFORE TAX
	 *DDTC-27834 QA- My contributions page -Things to know (TTK) -message is not available
	 */
	

	@Test(dataProvider = "setData")
	public void PPTMOBILE_Deferral_018_DDTC_12338_View_Only_After_Tax_Deferral_Group_With_No_Values(int itr,
			Map<String, String> testdata) {
	try{
	initializeReportForTC(itr);
	
	deferralsPage = new DeferralsPage();
	Reporter.logEvent(Status.INFO, "Pre-requisites : ", "Participant should be enrolled with the plan and should not have contribution rate for the view only Deferrals ", false);
	Reporter.logEvent(Status.INFO,"Step 1-2  User clicks My Contributions link","Verify there is no values available for view only deferral groups.",false);	
	deferralsPage.get();	
	
	Reporter.logEvent(Status.INFO,"Step 3 Check that Edit/Add button is not enabled for view only deferral group.","Edit/Add button is not enabled for view only deferral group",false);	
	String contributionType = UserBaseTest.getParaValue("contribution_Type");	
	String sObjContributionType = "//*[@name='"+contributionType+"']/preceding-sibling::*[contains(@name,'Add')]";
	Mobile.verifyElementISDisable(sObjContributionType, "After Tax Edit/Add button");
	
	//DDTC-27834 QA- My contributions page -Things to know (TTK) -message is not available
	Mobile.verifyElementNotPresent("TTK Message  should not be present", "light-bulb", "light-bulb" );

//	Reporter.logEvent(Status.INFO,"Step 4 Repeat the above steps with different deferral group and make sure it is working as expected"," Verify Defferal Type dollor amount Rate in Shopping Cart",false);	
//	Mobile.verifyElementISDisable("", "Catch -up Edit/Add button is disable");
	
	} catch (Exception e) {		
		handleFailure(e);
	}
  	catch (Error ae){
	handleError(ae);
}
}
	
	
	/*
	 * QA- Contributions - 2 deferrals - One view only deferral & one non-view deferral
	 * This test validates that application functionality if deferral group has one view onyl deferral & one non-view only deferrals.
	 * Pre-requisites:
	 * Participant should be enrolled with the plan and should have contribution rate for the view only Deferrals.
	 * View only deferrals need to be identified through CSAS application and mention the contribution types in below query to identify the participants who has read only deferrals in particular plan

	 */
	
	
	@Test(dataProvider = "setData")
	public void PPTMOBILE_Deferral_019_DDTC_12339_Bonus_One_View_Only_And_One_Non_View_Deferral(int itr,
			Map<String, String> testdata) {
	try{
	initializeReportForTC(itr);
	
	deferralsPage = new DeferralsPage();
	Reporter.logEvent(Status.INFO, "Pre-requisites : ", " Plan for Participant should have 2 deferral - One view only and non view deferral", false);
	
	Reporter.logEvent(Status.INFO,"Step 1-2 User clicks My Contributions link","Verify participant is able to view read only deferrals in contributions list.",false);	
	deferralsPage.get();	
	
	deferralsPage.DDTC_12339_Bonus_One_View_Only_And_One_Non_View_Deferral();
	
	
	} catch (Exception e) {
		 
		handleFailure(e);
	}
  	catch (Error ae){
	handleError(ae);
}
}
	
	
	/*
	 * 
	 * This test validates that participant is able to view and not allowed to edit the view only deferrals in split rate page. 
	 * Participant should be enrolled with the plan and should have contribution rate for the view only Deferrals
	 */
	
	@Test(dataProvider = "setData")
	public void PPTMOBILE_Deferral_020_DDTC_DTC_12334_View_Only_Other_with_split_contributions(int itr,
			Map<String, String> testdata) {
	try{
	initializeReportForTC(itr);
	
	deferralsPage = new DeferralsPage();
	Reporter.logEvent(Status.INFO,"Step 1-2  User clicks My Contributions link","Participant is able to view read only deferrals in contributions list.",false);	
	deferralsPage.get();	
	deferralsPage.DDTC_DTC_12334_View_Only_Other_with_split_contributions();
	
	
	
	} catch (Exception e) {
		 
		handleFailure(e);
	}
  	catch (Error ae){
	handleError(ae);
}
}
	
	
	/*
	 * DDTC-12340

	 */
	@Test(dataProvider = "setData")
	public void PPTMOBILE_Deferral_021_DDTC_DTC_12340_Validation_If_Contribution_Rate_Less_Than_View_Only_Deferrals(int itr,
			Map<String, String> testdata) {
	try{
	initializeReportForTC(itr);
	deferralsPage = new DeferralsPage();
	Reporter.logEvent(Status.INFO, "Pre-requisites : ", "Participant should be enrolled with the plan and should not have contribution rate for the view only Deferrals ", false);
	Reporter.logEvent(Status.INFO,"Step 1-2  User clicks My Contributions link","Verify there is no values available for view only deferral groups.",false);	
	deferralsPage.get();	
	
	Reporter.logEvent(Status.INFO,"Step 3 Tap on Bonus  Edit/Add button  deferral group.","Application returns to contribution rate selection page.",false);	
	String deferralType = UserBaseTest.getParaValue("contribution_Type");
	String sViewOnlyRate =  deferralsPage.get_MyContribution_Rate(UserBaseTest.getParaValue("ViewOnlyDeferralType"));
	deferralsPage.click_ContributionType_Edit_Add_Button(deferralType);

	Reporter.logEvent(Status.INFO,"Step 4 Enter the rate less tha view only deferrals contribution rate and tap on continue."," Applcation displays following validation message successfully",false);	
	String sView_MinRate = Integer.toString(Integer.parseInt(sViewOnlyRate) -1);
	deferralsPage.enter_Contribution_Rate_PerCentage(sView_MinRate);
	String sErrormsg = "Contributions for "+deferralType+" must be at least "+sViewOnlyRate+"%.";
	//Mobile.verifyErrorMessage(DeferralsPage.ERROR_MESSAGE_XPATH, sErrormsg, false);
	Mobile.verifyElementPresent("Message should be display", sErrormsg, sErrormsg);
	  	
	//Reporter.logEvent(Status.INFO,"Step 5 Repeat the above steps for all the deferral groups and make sure it is working as expected.","As Expected",false);	
	
	
	} catch (Exception e) {
		 
		handleFailure(e);
	}
  	catch (Error ae){
	handleError(ae);
}
}
	
	
	/*
	 * PPTMOBILE_Deferral_023_DDTC_12335_View_Only_Deferral_Group
	 * This test validates that participant is not allowed to edit the view only deferral group in contribution list.  
	 * https://jira.retirementpartner.com/browse/PWMA-2254
	 * Pre-requisites:
	 * Participant should be enrolled with the plan and should have contribution rate for the view only Deferrals.

	 */
	
	@Test(dataProvider = "setData")
	public void PPTMOBILE_Deferral_023_DDTC_12335_View_Only_Deferral_Group(int itr,
			Map<String, String> testdata) {
	try{
	initializeReportForTC(itr);
	
	deferralsPage = new DeferralsPage();
	Reporter.logEvent(Status.INFO, "Pre-requisites : ", "Participant should be enrolled with the plan and should not have contribution rate for the view only Deferrals ", false);
	Reporter.logEvent(Status.INFO,"Step 1-2  User clicks My Contributions link","Participant is able to view Read only deferrals contributions list.",false);	
	deferralsPage.get();
	String[] deferralTypeList = UserBaseTest.getParaValue("ViewOnlyDeferralType").split("::");
//	String sViewOnlyRate = UserBaseTest.getParaValue("ViewOnlyDeferralRate");	
	for (String type : deferralTypeList) {
		String sViewOnlyRate =  deferralsPage.get_MyContribution_Rate(type);
		deferralsPage.verify_MyContributions_Rate_Percentage(type, sViewOnlyRate);  
	} 
	
	Reporter.logEvent(Status.INFO,"Step 3 Check that Edit/Add button is not enabled for view only deferral group.","Edit/Add button is not enabled for view only deferral group",false);	
	String contributionType = UserBaseTest.getParaValue("contribution_Type");	
	String sObjContributionType = "//*[@name='"+contributionType+"']/following-sibling::*[@name='EDIT / ADD']";
	Mobile.verifyElementNotPresent("Add/ Edit button should not be displayed for  :"+contributionType, sObjContributionType, "Catch-Up Tax Edit/Add button Not dispayed");

	
	} catch (Exception e) {
		 
		handleFailure(e);
	}
  	catch (Error ae){
	handleError(ae);
}
}
	
	/*
	 * QA- Contributions - View only catch-up deferrals 
	 * Created: April 17 2017
	 * This test validates that maximizer is not displayed for catch-up deferral group if view only catch-up deferral is available. 
	 */
	
	
	@Test(dataProvider = "setData")
	public void PPTMOBILE_Deferral_024_DDTC_12342_Maximizer_Catch_Up_View_Only_Deferral_Group(int itr,
			Map<String, String> testdata) {
	try{
	initializeReportForTC(itr);
	DeferralsPage.setApplePlan(true);
	//String sViewOnlyRate = UserBaseTest.getParaValue("ViewOnlyDeferralRate");
	
	deferralsPage = new DeferralsPage();
	Reporter.logEvent(Status.INFO, "Pre-requisites : ", "Maximizer functionality should be enabled for plan and One Deferral Type for Catch up  should be View only", false);
	deferralsPage.get();
	
	deferralsPage.DDTC_12342_Maximizer_Catch_Up_View_Only_Deferral_Group();
		
	} catch (Exception e) {		 
		handleFailure(e);
	}
  	catch (Error ae){
	handleError(ae);
}
}
	
	
	/*
	 * QA- Contributions - View only catch-up deferrals 
	 * Created: April 17 2017
	 * This test validates that maximizer is not displayed for standard deferral group if view only deferrals available. 
	 */
	
	
	@Test(dataProvider = "setData")
	public void PPTMOBILE_Deferral_025_DDTC_12341_Maximizer_Standard_View_Only_Deferral_Group(int itr,
			Map<String, String> testdata) {
	try{
		initializeReportForTC(itr);
		DeferralsPage.setApplePlan(true);
	//	String sViewOnlyRate = UserBaseTest.getParaValue("ViewOnlyDeferralRate");
	
		
		deferralsPage = new DeferralsPage();
		Reporter.logEvent(Status.INFO, "Pre-requisites : ", "Maximizer functionality should be enabled for plan and One Deferral Type for Standard up  should be View only", false);
		deferralsPage.get();		
		deferralsPage.DDTC_12341_Maximizer_Standard_View_Only_Deferral_Group();	
	
	} catch (Exception e) {		 
		handleFailure(e);
	}
  	catch (Error ae){
	handleError(ae);
}
}
	
	/*
	 * DDTC-12353] QA- Contributions -Split rate page - View only deferrals
	 * This test validates that split rate page default selection is displaying as per the requirement. 
	 * Pre-requisites:
	 * Participant is enrolled with the plan and have values on file with view only deferrals.
	 * 
	 */
	
	@Test(dataProvider = "setData")
	public void PPTMOBILE_Deferral_026_DDTC_12353_Split_Rate_Page_View_Only_Deferral(int itr,
			Map<String, String> testdata) {
	try{
		initializeReportForTC(itr);

		deferralsPage = new DeferralsPage();
		Reporter.logEvent(Status.INFO, "Pre-requisites : ", " Participant is enrolled with the plan and have values on file with view only deferrals", false);
		deferralsPage.get();	
		
		deferralsPage.DDTC_12353_Split_Rate_Page_View_Only_Deferral();
		
	
		
		} catch (Exception e) {		 
			handleFailure(e);
		}
	  	catch (Error ae){
		handleError(ae);
	}
	}

 
	
	
	/*
	 * 
	 * This test validates that split rate page default selection is displaying as per the requirement. 
	 * https://jira.retirementpartner.com/browse/PWMA-2254
	 * Pre-requisites:
	 * Participant is enrolled with the plan and have values on file with view one deferrals
	 * Roth Bonus should be having value under Bonus deferral group.
	 * In the above plan after-tax bonus must be 10% or above.
	 * 
	 * Minimium value to set in Plan setting
	 * 
	 */

	@Test(dataProvider = "setData")
	public void PPTMOBILE_Deferral_027_DDTC_12354_Split_Page_One_Deferral_Enter_Rate_Less_Than_Minimum(int itr,
			Map<String, String> testdata) {
	try{
	initializeReportForTC(itr);
	
	deferralsPage = new DeferralsPage();	
	Reporter.logEvent(Status.INFO,"Step 1-2 User clicks My Contributions link","Verify My contributions page and participant is able to view read only deferrals in contributions list.",false);	
	deferralsPage.get();	
	deferralsPage.DDTC_12354_Split_Page_One_Deferral_Enter_Rate_Less_Than_Minimum();
	
	
	
	} catch (Exception e) {		 
		handleFailure(e);
	}
  	catch (Error ae){
	handleError(ae);
}
}

	
	/*
	 * DDTC-5294  QA - Adding Company match in deferrals/contributions page 
	 */
	

	@Test(dataProvider = "setData")
	public void PPTMOBILE_Deferral_028_DDTC_5294_Adding_Company_Match_In_Contribution_Page(int itr,
			Map<String, String> testdata) {
	try{
	initializeReportForTC(itr);
	
	deferralsPage = new DeferralsPage();
	DeferralsPage.setApplePlan(true);
	Reporter.logEvent(Status.INFO, "Pre-requisites : ", " Participant should be in  enrollment flow", false);
	deferralsPage.get();	
	deferralsPage.regular_Maximizer_Me_Always(false);	
	deferralsPage.DDTC_5294_Adding_Company_Match_In_Contribution_Page();
	
	} catch (Exception e) {
		 
		handleFailure(e);
	}
  	catch (Error ae){
	handleError(ae);
}
}

	
	
	
	
	/*
	 * [DDTC-5311] QA - Adding Company match in Custom Enrollement 
	 * This test vaidates that participant is able to view the company match rule applicable to them and 
	 * Pre-requisites:A registered participant who has not completed their enrollment.
	 * The participant should have a Custom enrollment plan.
	 */
	
	@Test(dataProvider = "setData")
	public void PPTMOBILE_Deferral_029_DDTC_5311_Adding_Company_Match_in_Custom_Enrollement(int itr,
			Map<String, String> testdata) throws Exception {
	try{
	initializeReportForTC(itr);
	DeferralsPage.setApplePlan(true);
	enrollmentPage = new EnrollmentPage();
	deferralsPage = new DeferralsPage();	
	enrollmentPage.get();		
	//STEP 3 :-"Step 3 Tap on Edit/Add ", "Verify Participant is able to change his/her contributions 
	deferralsPage.click_Edit_Add_Button("CONTRIBUTIONS");
 	deferralsPage.click_ContributionType_Edit_Add_Button(DeferralsPage.STANDARD);
	Mobile.selectRadioButton(DeferralsPage.ENTER_CONTRIBUTION_RATE);	
	String contribution_Rate =UserBaseTest.getParaValue("contribution_Rate");	
//	Reporter.logEvent(Status.INFO, "Step 5 -6 ", "Verify company match is getting calculated based on the participant contribution and plan tier rule. ", false);
	deferralsPage.verifyAdding_Company_Match(contribution_Rate);
	deferralsPage.verifyAdding_Company_Match(Common.subStringValue(contribution_Rate, 2));
	deferralsPage.verifyAdding_Company_Match(Common.addStringValue(contribution_Rate, 2));
	
	new HomePage().logout();	

	} catch (Exception e) {
		 
		handleFailure(e);
	}
  	catch (Error ae){
	handleError(ae);
}
	finally{
		 Reporter.finalizeTCReport();
	}
}
	
	
	/*
	 * DDTC-8189] QA - Enrollment - Custom Enrollment with suppressed company match 
	 * This test vaidates that participant is able to view the company match rule applicable 
	 * to them and chooses the custom enrollment as their choice of enrollment.
	 * 
	 * Pre-requisites:
	 *  A registered participant who has not completed their enrollment.
	 *   The participant qualifies for a plan that has a quick enrollment option where 
	 *   the company match rules are not in rule4, rule10, rule13 or rule15.
	
	 * 	Select * From DC_EMPLOYER_MATCH_RULES where plan_nbr='194159-01' and rule_type='RULE14';.
	 *   RULE14_COMPANY_MATCH_SUPPRESSED=881207213ABC
	 */

	@Test(dataProvider = "setData")
	public void PPTMOBILE_Deferral_030_DDTC_8189_Custom_Enrollment_with_suppressed_Company_Match(int itr,
			Map<String, String> testdata) throws Exception {
	try{
	initializeReportForTC(itr);
	
	enrollmentPage = new EnrollmentPage();
	Reporter.logEvent(Status.INFO, "Pre-requisites : ", " Participant should be in  enrollment flow", false);
	//Step 1 Navigate to My Contribution Page
	enrollmentPage.get();	
	enrollmentPage.verify_Company_Match_Is_Not_Displayed();
	
	} catch (Exception e) {
		 
		handleFailure(e);
	}
  	catch (Error ae){
	handleError(ae);
}
	finally{
		 Reporter.finalizeTCReport();
	}
}
	
	/*
	 * [DDTC-27410] QA-Test to verify Company Match Rule when salary(Variable) gets updated from "Income Goal" pages.
	 * Pre-requisite:
		1. DC Participant site should be loaded properly.
		2. Participant should be Registered & enrolled (active User).
		3. Access DC Participant site
		4.Participant should have Variable Salary.		Participant should be able to access Liat next gen site
		This test cases is for Plan RULE 13 - 150551-01
		
	 */
	
	
	
	@Test(dataProvider = "setData")
	public void PPTMOBILE_Deferral_031_DDTC_27410_Company_Match_Rule_When_Salary_Variable_Gets_Updated_From_Income_Goal_Pages(int itr,
			Map<String, String> testdata) throws Exception {
	try{
	initializeReportForTC(itr); 	
	laitPage = new HomePage();	
	laitPage.get();	
	laitPage.verify_Company_Match_Rule_From_Income_Goal(HomePage.OTHER_VARIABLE_COMPENSATION);

	} catch (Exception e) {
		 
		handleFailure(e);
	}
  	catch (Error ae){
	handleError(ae);
}
	finally{
		 Reporter.finalizeTCReport();
	}
}
	
	/*
	 * DDTC-27411] QA-Test to verify Company Match Rule when salary(Base) gets updated from "Income Goal" pages.
	 * 
	 */
	

	@Test(dataProvider = "setData")
	public void PPTMOBILE_Deferral_032_DDTC_27411_Company_Match_Rule_When_Salary_Base_Gets_Updated_From_Income_Goal_Pages(int itr,
			Map<String, String> testdata) throws Exception {
	try{
		initializeReportForTC(itr);   
		
		laitPage = new HomePage();	
		laitPage.get();		
		laitPage.verify_Company_Match_Rule_From_Income_Goal(HomePage.CURRENT_SALARY);		
	

	} catch (Exception e) {
		 
		handleFailure(e);
	}
  	catch (Error ae){
	handleError(ae);
}
	finally{
		 Reporter.finalizeTCReport();
	}
}
	
	/*
	 * DDTC-27411] QA-Test to verify Company Match Rule when salary(Base) gets updated from "Income Goal" pages.
	 * 
	 */
	

	@Test(dataProvider = "setData")
	public void PPTMOBILE_Deferral_033_DDTC_27707_Company_Match_Rule_When_Salary_BaseAndSalary_Gets_Updated_From_Income_Goal_Pages(int itr,
			Map<String, String> testdata) throws Exception {
	try{
		initializeReportForTC(itr);  		
		laitPage = new HomePage();		
		laitPage.get();		
		laitPage.verify_Company_Match_Rule_From_Income_Goal("BOTH");	
	} catch (Exception e) {
		 
		handleFailure(e);
	}
  	catch (Error ae){
	handleError(ae);
}
	finally{
		 Reporter.finalizeTCReport();
	}
}
	
	

	
	/*
	 * DDTC-27836
	 * QA- My contributions page -Things to know (TTK) message is available - Contributions changes are not available
	This test validates that TTK message is present in the my contributions page as per the following requirement.
	
	  DDTC-27832 QA- My contributions page -Things to know (TTK) message is available - more than 200 characters
	   * DDTC-27835
	 * QA- My contributions page -Things to know (TTK) message is available - less than 200 characters
	 *  - multiple bulletin messages
	 */

	@Test(dataProvider = "setData")
	public void PPTMOBILE_Deferral_036_DDTC_27836_Contribution_TTK_Message(int itr,
			Map<String, String> testdata) {
	try{
	initializeReportForTC(itr);
	
	deferralsPage = new DeferralsPage();
//	HomePage.setMultiplePlan(true,"ESOUTGMMCTHSO DSCOFU, HOE. 401(L) COF NSSHHT UGCSHOI NMCO" );
	Reporter.logEvent(Status.INFO, "Pre-requisites : ", " Participant should be in  enrollment flow", false);
	//Step 1 Navigate to My Contribution Page
	
	deferralsPage.get();	
	deferralsPage.validate_TTK_message_inContribution_Page();
	
	} catch (Exception e) {
		 
		handleFailure(e);
	}
  	catch (Error ae){
	handleError(ae);
}
}
	
	


	
	/*
	 * DDTC-5292 QA - Contributions - Auto Increase - Add pop-up message for change in election as 0%
	 */
	
	

	@Test(dataProvider = "setData")
	public void PPTMOBILE_Deferral_037_DDTC_5292_Auto_Increase_Add_PopUp_Message_For_Change_In_Selection_Percentage(int itr,
			Map<String, String> testdata) throws Exception {
	try{
	initializeReportForTC(itr);
	DeferralsPage.setApplePlan(true);
	deferralsPage = new DeferralsPage();
	deferralsPage.get();	
	deferralsPage.verify_Add_Auto_PopUp_Message();
	} catch (Exception e) {
		 
		handleFailure(e);
	}
  	catch (Error ae){
	handleError(ae);
  	}finally{
	 Reporter.finalizeTCReport();
  	}
	}
	
	/*
	 * PPTMOBILE_Deferral_038_DDTC_5275_Auto_Increase_Add_PopUp_Message_For_Change_In_Election_With_Dollor
	 */
	
	

	@Test(dataProvider = "setData")
	public void PPTMOBILE_Deferral_038_DDTC_5275_Auto_Increase_Add_PopUp_Message_For_Change_In_Selection_With_Dollor(int itr,
			Map<String, String> testdata) throws Exception {
	try{
	initializeReportForTC(itr);
//	DeferralsPage.setApplePlan(true);
	deferralsPage = new DeferralsPage();
	deferralsPage.get();	
	deferralsPage.verify_Add_Auto_PopUp_Message();
	} catch (Exception e) {
		 
		handleFailure(e);
	}
  	catch (Error ae){
	handleError(ae);
  	}finally{
	 Reporter.finalizeTCReport();
  	}
	}
	
	
	
	/*
	 * DDTC-7225 
	 * QA - Contributions - Auto Increase - Standard - Percentage
	 */
	
	

	@Test(dataProvider = "setData")
	public void PPTMOBILE_Deferral_039_DDTC_7225_Auto_Increase_Standard_Percentage(int itr,
			Map<String, String> testdata) throws Exception {
	try{
	initializeReportForTC(itr);
	DeferralsPage.setApplePlan(true);
	deferralsPage = new DeferralsPage();
	deferralsPage.get();	
	deferralsPage.verify_Auto_Increase_Percentage();
	} catch (Exception e) {
		 
		handleFailure(e);
	}
  	catch (Error ae){
	handleError(ae);
  	}finally{
	 Reporter.finalizeTCReport();
  	}
	}
	
	
	
	/*
	 * QA - Contributions - Auto Increase - Standard - Percentage
	 * 
	 * DDTC-27897 QA- Contributions -Split rate page - Enter value more than deferral rate
	 */


	@Test(dataProvider = "setData")
	public void PPTMOBILE_Deferral_040_DDTC_7267_Auto_Increase_Standard_Dollor(int itr,
			Map<String, String> testdata) throws Exception {
	try{
	initializeReportForTC(itr);
	//DeferralsPage.setApplePlan(true);
	deferralsPage = new DeferralsPage();
	deferralsPage.get();	
	deferralsPage.verify_Auto_Increase_Dollor();
	} catch (Exception e) {
		 
		handleFailure(e);
	}
  	catch (Error ae){
	handleError(ae);
  	}finally{
	 Reporter.finalizeTCReport();
  	}
	}
	/*
	 * QA - Contributions - Auto Increase - Standard - Percentage
	 */


	@Test(dataProvider = "setData")
	public void PPTMOBILE_Deferral_041_DDTC_7236_Auto_Increase_Roth_Percentage(int itr,
			Map<String, String> testdata) throws Exception {
	try{
	initializeReportForTC(itr);
	DeferralsPage.setApplePlan(true);
	deferralsPage = new DeferralsPage();
	deferralsPage.get();	
	deferralsPage.verify_Auto_Increase_Percentage();

	} catch (Exception e) {
		 
		handleFailure(e);
	}
  	catch (Error ae){
	handleError(ae);
  	}finally{
	 Reporter.finalizeTCReport();
  	}
	}
	/*
	 * QA - Contributions - Auto Increase - Standard - Percentage
	 */


	@Test(dataProvider = "setData")
	public void PPTMOBILE_Deferral_042_DDTC_7221_Auto_Increase_Roth_Dollor(int itr,
			Map<String, String> testdata) throws Exception {
	try{
	initializeReportForTC(itr);
//	DeferralsPage.setApplePlan(true);
	deferralsPage = new DeferralsPage();
	deferralsPage.get();	
	deferralsPage.verify_Auto_Increase_Dollor_With_Roth();
	} catch (Exception e) {
		 
		handleFailure(e);
	}
  	catch (Error ae){
	handleError(ae);
  	}finally{
	 Reporter.finalizeTCReport();
  	}
	}
	
	
	
	/*
	 * DDTC-31321 User is trying to change the deferrals in case of grandfathered deferrals_$ to % 
	 *DDTC-31322  User is trying to change the deferrals in case of grandfathered deferrals_% to $
	 *DDTC-31320  User does not change the deferrals in case of grandfathered deferrals. 
	
	 * 
	 */
	@Test(dataProvider = "setData")
	public void DDTC_31321_32322_TC_043_Grandfathered_Deferrral_Type_change(int itr,
			Map<String, String> testdata) throws Exception {
	try{
		initializeReportForTC(itr);
		deferralsPage = new DeferralsPage();
		deferralsPage.get();		
		deferralsPage.click_ContributionType_Edit_Add_Button(UserBaseTest.getParaValue("contribution_Type"));	
		
		String sValue = Mobile.getElementValue(deferralsPage.getWebElement("TEXTFILED"));
		if(sValue.equals("0")){			
				Reporter.logEvent(Status.PASS,"Default value should be 0" ,"Default value is 0" ,false);
			}else{			
			     Reporter.logEvent(Status.FAIL,"Default value should be 0","Default value is not 0",true);
			}			
		deferralsPage.verifyWarningMessage();
		Common.clickBackArrow();
		
	}
	catch (Exception e) {
		 
		handleFailure(e);
	}
  	catch (Error ae){
	handleError(ae);
  	}finally{
	 Reporter.finalizeTCReport();
  	}
	}
	
	/*
	 *  *DDTC-31318  Change  deferrals in case of grandfathered deferrals_PCT to AMTPCT for one deferral type 
	 *DDTC-31316 combined rules are applicable in case of grandfathered deferrals_Same Amount types for each deferral 
	 */
	@Test(dataProvider = "setData")
	public void DDTC_31318_31316_31319_TC_044_Grandfathered_Deferrral_Combined_Rule(int itr,
			Map<String, String> testdata) throws Exception {
	try{
		initializeReportForTC(itr);
		deferralsPage = new DeferralsPage();
		deferralsPage.get();		
		deferralsPage.select_Contribution_Details(UserBaseTest.getParaValue("contribution_Type"), DeferralsPage.ENTER_CONTRIBUTION_RATE,DeferralsPage.BEFORE_TAX);
		String sMsg = "Warning! Your plan no longer supports contributions by dollar amount. If you make any changes, you must change all applicable contribution rates.";
		Mobile.verifyElementPresent("Warning message should be displayed", sMsg,"Message displayed :\n"+sMsg );
		deferralsPage.select_Contribution_Details(DeferralsPage.AFTER_TAX, DeferralsPage.ENTER_CONTRIBUTION_RATE,"");
		sMsg = "Warning! Your plan no longer supports contributions by percent. If you make any changes, you must change all applicable contribution rates.";
		Mobile.verifyElementPresent("Warning message should be displayed", sMsg,"Message displayed :\n"+sMsg );
		deferralsPage.select_Contribution_Details(DeferralsPage.CATCH_UP, DeferralsPage.ENTER_CONTRIBUTION_RATE,"");
		Mobile.verifyElementEnable("CONFIRM & CONTINUE","Confirm & Continue button");		 
	}
	catch (Exception e) {
		 
		handleFailure(e);
	}
  	catch (Error ae){
	handleError(ae);
  	}finally{
	 Reporter.finalizeTCReport();
  	}
	}
	
	

	

	/*
	 * DDTC-31325 Change through LIAT with non grnadfathered deferrals. 

	 */
	@Test(dataProvider = "setData")
	public void DDTC_31323_TC_045_LIAT_With_Single_Grandfathered_Deferral(int itr,
			Map<String, String> testdata) throws Exception {
	try{
		initializeReportForTC(itr);
		laitPage = new HomePage();
		deferralsPage = new DeferralsPage();
		laitPage.get();			
		Mobile.clickElement(laitPage.getWebElement("Edit"));
		String[] param = UserBaseTest.getParaValue("setSliderValue").split("=");
		Common.setSliderValueInLIATPage(param[0], param[1]);
		Mobile.clickElement(laitPage.reviewChangeBut);		
		deferralsPage.verifyWarningMessage();		
		Mobile.clickElement("OK");	
		Mobile.clickElement("Collapse");
	}
	catch (Exception e) {
		 
		handleFailure(e);
	}
  	catch (Error ae){
	handleError(ae);
  	}finally{
	 Reporter.finalizeTCReport();
  	}
	}
	

	/*
	 * QA_LIAT_Grandfathered deferral scenario_To verify Grandfathered Deferrals Change through LIAT with multiple deferrals 

	 */
	@Test(dataProvider = "setData")
	public void DDTC_31324_TC_046_LIAT_With_Multiple_Grandfathered_Deferral(int itr,
			Map<String, String> testdata) throws Exception {
	try{
		initializeReportForTC(itr);
		laitPage = new HomePage();
		deferralsPage = new DeferralsPage();
		laitPage.get();	
		Mobile.clickElement(laitPage.getWebElement("Edit"));
		String[] param = UserBaseTest.getParaValue("setSliderValue").split("=");
		Common.setSliderValueInLIATPage(param[0], param[1]);
		param = UserBaseTest.getParaValue("setSliderSecondValue").split("=");
		Common.setSliderValueInLIATPage(param[0], param[1]);	
		Mobile.clickElement(laitPage.reviewChangeBut);				
		deferralsPage.verifyWarningMessage();		
		Mobile.clickElement("OK");
		Mobile.clickElement("Collapse");
	}
	catch (Exception e) {
		 
		handleFailure(e);
	}
  	catch (Error ae){
	handleError(ae);
  	}finally{
	 Reporter.finalizeTCReport();
  	}
	}
	
	

	/*
	 * DDTC-31325 Change through LIAT with non grnadfathered deferrals. 

	 */
	@Test(dataProvider = "setData")
	public void DDTC_31325_TC_047_LIAT_Grandfathered_Deferral_With_Age(int itr,
			Map<String, String> testdata) throws Exception {
	try{
		initializeReportForTC(itr);
		laitPage = new HomePage();
		deferralsPage = new DeferralsPage();
		laitPage.get();			
		Mobile.clickElement(laitPage.getWebElement("Edit"));
		String[] param = UserBaseTest.getParaValue("setSliderValue").split("=");
		Common.setSliderValueInLIATPage(param[0], param[1]);
		param = UserBaseTest.getParaValue("setSliderSecondValue").split("=");
		String sValue = Common.getSliderValueInLIATPage(param[0]);
		if(sValue.equals(param[1])){
			param[1] = Common.addStringValue(param[1], 5);
		}
		
		Common.setSliderValueInLIATPage(param[0], param[1]);	
		Mobile.clickElement(laitPage.reviewChangeBut);			
		deferralsPage.verifyWarningMessage();		
		Mobile.clickElement("SUBMIT");
		Mobile.waitForPageToLoad("Confirmation");
		String confirmMsg ="You have successfully increased your retirement age to "+param[1]+".";
		String confirmMsg2 ="You have successfully decreased your retirement age to "+param[1]+".";
		if(Mobile.isElementPresent(confirmMsg) || Mobile.isElementPresent(confirmMsg2) ){
			Reporter.logEvent(Status.PASS,"Confirmation message for retirement should be display" ,confirmMsg+ "  is Displayed " ,false);
		}else{			
		     Reporter.logEvent(Status.FAIL,"Confirmation message for retirement should be display",confirmMsg+"  is not Displayed",true);
					          
		}		
	
		Mobile.clickElement("DONE");
		
	}
	catch (Exception e) {
		 
		handleFailure(e);
	}
  	catch (Error ae){
	handleError(ae);
  	}finally{
	 Reporter.finalizeTCReport();
  	}
	}
	
	
	/**
	 * DDTC-30890 QA_Verify the Deferral Restriction message on My Contributions page_Error core E-3020
	 * Verify that the Deferral Restriction message on "My Contributions" page for the Error code E-3020 - 
	 * "The Open deferral change window does not start until #date." 
	 * Also verify the opt out message and its corresponding modal.
	 * @Author : Siddartha
	 * @since : 8/Feb/2018
	 * 
	 * @Query : Update window_schedule set base_date='01-APR-19', projected_run_date='1-MAR-19' where ga_id='194193-01' and sched_type in ('DEFERRAL_CHG') and process_dpdate_time is null;
	 */
	@Test(dataProvider = "setData")
	public void DDTC_30890_TC_048_Deferral_Restriction_Error_Core_3020(int itr,
			Map<String, String> testdata) throws Exception {
	try{
		initializeReportForTC(itr);
		deferralsPage = new DeferralsPage();
		deferralsPage.get();
		deferralsPage.verifyWarningMessage();				
		Mobile.verifyElementNotPresent("EDIT / ADD button should not be display", "EDIT / ADD", "EDIT / ADD");
		// click stop all contribution link.
	}
	catch (Exception e) {
		 
		handleFailure(e);
	}
  	catch (Error ae){
	handleError(ae);
  	}finally{
	 Reporter.finalizeTCReport();
  	}
	}

	/*
	 * DDTC-30895 QA - Verify the Deferral Restriction message on My Contributions page_Error core E-3050_period frequency
	 *  is days
	 *  To verify the Deferral Restriction message on "My Contributions" page for the Error code E-3050 - 
	 *  (where period type frequency is days) - "Change not allowed,
	 *   unless changing your deferral to zero. Plan allows X change every Y 
	 *    * Update plan set allow_defrl_change_nbr=2, allow_defrl_freq=1, allow_defrl_freq_code='D' , defrl_restrc_start_date='01-JAN-2018', defrl_restrc_level='I' where id in (Select plan_id From group_account where id='194193-01');
	 * 
	 * Revert :- Update plan set allow_defrl_change_nbr=null, allow_defrl_freq=null, allow_defrl_freq_code=null , defrl_restrc_start_date=null, defrl_restrc_level=null where id='504434';

	 */
	@Test(dataProvider = "setData")
	public void DDTC_30895_TC_049_Deferral_Restriction_Error_Core_3050(int itr,
			Map<String, String> testdata) throws Exception {
	try{
		initializeReportForTC(itr);
		deferralsPage = new DeferralsPage();
		deferralsPage.get();
		deferralsPage.verifyWarningMessage();	
		Mobile.verifyElementNotPresent("EDIT / ADD button should not be display", "EDIT / ADD", "EDIT / ADD");
	}
	catch (Exception e) {
		 
		handleFailure(e);
	}
  	catch (Error ae){
	handleError(ae);
  	}finally{
	 Reporter.finalizeTCReport();
  	}
	}
	
	/**
	 * 
	 * Update plan set allow_defrl_change_nbr=2, allow_defrl_freq=1, allow_defrl_freq_code='D' , defrl_restrc_start_date='01-JAN-2018', defrl_restrc_level='P' where id in (Select plan_id From group_account where id='194193-01');
	 * 
	 * Revert :- Update plan set allow_defrl_change_nbr=null, allow_defrl_freq=null, allow_defrl_freq_code=null , defrl_restrc_start_date=null, defrl_restrc_level=null where id='504434';
	  @param itr
	 * @param testdata
	 * @throws Exception
	 */
	
	@Test(dataProvider = "setData")
	public void DDTC_30894_TC_053_Deferral_Restriction_Error_Core_3050_Period_Frequency(int itr,
			Map<String, String> testdata) throws Exception {
	try{
		initializeReportForTC(itr);
		deferralsPage = new DeferralsPage();
		deferralsPage.get();
		deferralsPage.verifyWarningMessage();		
		Mobile.verifyElementNotPresent("EDIT / ADD button should not be display", "EDIT / ADD", "EDIT / ADD");
	}
	catch (Exception e) {
		 
		handleFailure(e);
	}
  	catch (Error ae){
	handleError(ae);
  	}finally{
	 Reporter.finalizeTCReport();
  	}
	}
	
	
	

	/*
	 * DDTC-30892 QA_Verify the Deferral Restriction message on My Contributions page_Error core E-3021
	 * To verify the Deferral Restriction message on "My Contributions" page for the Error code E-3021 - "Deferral changes, 
	 * other than setting deferrals to zero, are allowed between #date and #date based on plan and eligibility." 

	 */
	@Test(dataProvider = "setData")
	public void DDTC_30892_TC_050_Deferral_Restriction_Error_Core_3021(int itr,
			Map<String, String> testdata) throws Exception {
	try{
		initializeReportForTC(itr);
		deferralsPage = new DeferralsPage();
		deferralsPage.get();
		deferralsPage.verifyWarningMessage();		
		Mobile.verifyElementNotPresent("EDIT / ADD button should not be display", "EDIT / ADD", "EDIT / ADD");
	}
	catch (Exception e) {
		 
		handleFailure(e);
	}
  	catch (Error ae){
	handleError(ae);
  	}finally{
	 Reporter.finalizeTCReport();
  	}
	}
	
	
	/**
	 * 
	 * To verify the Deferral Restriction message on "My Contributions" page for the 
	 * Error code E-3016 - "Enrollment may be completed between #date and #date based on plan and eligibility." 
	 * 
	 * 
	 * Update window_schedule set base_date='01-MAR-19', projected_run_date='15-FEB-19',freq_code='X' 
	 *  where ga_id='194193-01' and sched_type in ('ENROLLMT_ACCESS') and process_dpdate_time is null;
	 *  --Revert back: 
	 *  Update window_schedule set base_date='01-JAN-18', projected_run_date='15-DEC-17',freq_code='O'  
	 *  where ga_id='194193-01' and sched_type in ('ENROLLMT_ACCESS') and process_dpdate_time is null;
	 * @param itr
	 * @param testdata
	 * @throws Exception
	 */
	
	@Test(dataProvider = "setData")
	public void DDTC_30893_TC_051_Deferral_Restriction_Error_Core_3016(int itr,
			Map<String, String> testdata) throws Exception {
	try{
		initializeReportForTC(itr);
		deferralsPage = new DeferralsPage();
		deferralsPage.get();
		deferralsPage.verifyWarningMessage();		
		Mobile.verifyElementNotPresent("EDIT / ADD button should not be display", "EDIT / ADD", "EDIT / ADD");
	}
	catch (Exception e) {
		 
		handleFailure(e);
	}
  	catch (Error ae){
	handleError(ae);
  	}finally{
	 Reporter.finalizeTCReport();
  	}
	}
	
	/**
	 * 
	 * Update window_schedule set base_date='15-MAR-19', projected_run_date='28-FEB-19' where ga_id='194193-01' and sched_type in ('ENROLLMT_ACCESS') and process_dpdate_time is null;
		Revert 
		Update window_schedule set base_date='01-JAN-18', projected_run_date='15-DEC-17',freq_code='O'  where ga_id='194193-01' and sched_type in ('ENROLLMT_ACCESS') and process_dpdate_time is null;


	 * @param itr
	 * @param testdata
	 * @throws Exception
	 */
	@Test(dataProvider = "setData")
	public void DDTC_30891_TC_052_Deferral_Restriction_Error_Core_3044(int itr,
			Map<String, String> testdata) throws Exception {
	try{
		initializeReportForTC(itr);
		deferralsPage = new DeferralsPage();
		deferralsPage.get();
		deferralsPage.verifyWarningMessage();		
	
	}
	catch (Exception e) {
		 
		handleFailure(e);
	}
  	catch (Error ae){
	handleError(ae);
  	}finally{
	 Reporter.finalizeTCReport();
  	}
	}
	
	/**
	 * 
	 * DDTC-30886 QA - Contributions_Maximizer rate based on PPC rate - Standard and Catch-up deferral group with split deferral rates
	 * @param itr
	 * @param testdata
	 */
	
	@Test(dataProvider = "setData")
	public void DDTC_30886_TC_054_PPC_Rate_For_Standard_And_Catch_Up_With_Split_Option(int itr,
			Map<String, String> testdata) throws Exception {
	try{
		initializeReportForTC(itr);
		deferralsPage = new DeferralsPage();
		deferralsPage.get();
		
		deferralsPage.click_ContributionType_Edit_Add_Button(DeferralsPage.STANDARD);
	//	deferralsPage.select_Standard_Contribution_Page(DeferralsPage.MAXIMIZE_LIMIT,DeferralsPage.CATCH_UP_ROTH, contribution_Rate);
		 
		deferralsPage.select_Contribution_Details(DeferralsPage.STANDARD, DeferralsPage.MAXIMIZE_LIMIT,DeferralsPage.SPLIT);
		String sStandard_Rate_per_OnFile = deferralsPage.get_MyContribution_Rate(DeferralsPage.STANDARD);
		deferralsPage.select_Contribution_Details(DeferralsPage.STANDARD, DeferralsPage.MAXIMIZE_LIMIT,DeferralsPage.SPLIT);
		String sCatchUp_Rate_per_OnFile = deferralsPage.get_MyContribution_Rate(DeferralsPage.CATCH_UP);
		
	
	}
	catch (Exception e) {
		 
		handleFailure(e);
	}
  	catch (Error ae){
	handleError(ae);
  	}finally{
	 Reporter.finalizeTCReport();
  	}
	}
	
	/**
	 * 
	 *QA - Contributions_Onetime Maximizer 
	 *rate update with Updated Salary & PPC contributions - Standard & Catch-up deferral group
	 *
	 *
	 * @param itr
	 * @param testdata
	 */
	
	@Test(dataProvider = "setData")
	public void DDTC_30874_TC_054_PPC_Rate_For_Standard_And_Catch_Up_With_Split_Option(int itr,
			Map<String, String> testdata) throws Exception {
	try{
		initializeReportForTC(itr);
		deferralsPage = new DeferralsPage();
		deferralsPage.get();
		
		deferralsPage.click_ContributionType_Edit_Add_Button(DeferralsPage.STANDARD);
	//	deferralsPage.select_Standard_Contribution_Page(DeferralsPage.MAXIMIZE_LIMIT,DeferralsPage.CATCH_UP_ROTH, contribution_Rate);
		 
		deferralsPage.select_Contribution_Details(DeferralsPage.STANDARD, DeferralsPage.MAXIMIZE_LIMIT,DeferralsPage.SPLIT);
		String sStandard_Rate_per_OnFile = deferralsPage.get_MyContribution_Rate(DeferralsPage.STANDARD);
		deferralsPage.select_Contribution_Details(DeferralsPage.STANDARD, DeferralsPage.MAXIMIZE_LIMIT,DeferralsPage.SPLIT);
		String sCatchUp_Rate_per_OnFile = deferralsPage.get_MyContribution_Rate(DeferralsPage.CATCH_UP);
		
	
	}
	catch (Exception e) {
		 
		handleFailure(e);
	}
  	catch (Error ae){
	handleError(ae);
  	}finally{
	 Reporter.finalizeTCReport();
  	}
	}
	
	
	
	/*
	 * PPTMOBILE_Deferral_021_DDTC_12351_Split rate page - Multiple deferrals on file with same deferral group
	 * This test validates that split rate page default selection is displaying as per the requirement. 
	 * https://jira.retirementpartner.com/browse/PWMA-2254
	 * Pre-requisites:
	 * Participant is enrolled with the plan and having values for the contribution rate for one deferral.

	 */
	
	@Test(dataProvider = "setData")
	public void PPTMOBILE_Deferral_021_DDTC_12351_Split_Rate_Page_Multiple_Deferrals_On_File_With_Same_Deferral_Group(int itr,
			Map<String, String> testdata) {
	try{
	initializeReportForTC(itr);
	
	deferralsPage = new DeferralsPage();
	Reporter.logEvent(Status.INFO, "Pre-requisites : ", " Participant should be in  enrollment flow", false);
	deferralsPage.get();	

	Reporter.logEvent(Status.INFO,"Step 1-2 User clicks My Contributions link","Verify My contributions page and participant is able to view read only deferrals in contributions list.",false);	
	
	Reporter.logEvent(Status.INFO,"Step 3 Tap on the Edit/Add button for the deferral group where view only deferral values available on file","Application returns to contribution rate selection page.",false);	
	
	Reporter.logEvent(Status.INFO,"Step 4 Enter the contribution rate and tap on continue button"," Application returns to split rate page and defaults the selection to Split rate contributions.",false);	
	
	Reporter.logEvent(Status.INFO,"Step 5 Check that deferral values are pre-filled with value on file is available in split rate "," Deferral values are pre-filled with value on file is available in split rate.",false);	
		
	Reporter.logEvent(Status.INFO,"Step 6  Check that participant is able to split the value to available deferrals. ","Participant is able to split the value to available deferrals.",false);	
	
	Reporter.logEvent(Status.INFO,"Step 7  Check that continue button is disabled until the total split rate contribution equals to contributions rate.","Continue button is getting enable once the total split rate contribution equals to contributions rate. ",false);	
		
	Reporter.logEvent(Status.INFO,"Step 8 Submit the contribution and check that contribution values are displayed correctly  "," Application returns to contribution confirmation page with the entered contribution details",false);	
	
	
	
	} catch (Exception e) {
		 
		handleFailure(e);
	}
  	catch (Error ae){
	handleError(ae);
}
}
	
	//DDTC-27902 QA-Contributions - Maximizer-Split rate page - Enter value more than deferral rate
	
	//DDTC-27900 QA-Enrollment- Contributions -Split rate page - Enter value more than deferral rate
	
	//DDTC-27897 QA- Contributions -Split rate page - Enter value more than deferral rate
	
	//QA- My contributions page -Things to know (TTK) -message is not available
	
}

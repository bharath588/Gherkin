package com.greatWest.login;


import java.util.LinkedHashMap;
import java.util.Map;

import lib.*;

import com.greatWest.utility.Mobile;

import org.openqa.selenium.By;
import org.testng.annotations.Test;

import com.aventstack.extentreports.Status;
import com.greatWest.pageObject.HomePage;
import com.greatWest.pageObject.LoginPage;
import com.greatWest.pageObject.LookUpAccountPage;
import com.greatWest.pageObject.MFAPage;
import com.greatWest.utility.Common;

import core.framework.Globals;





public class LoginTestCases  extends UserBaseTest{
	public LoginPage loginPage;
	public MFAPage  mfaPage;
	public LookUpAccountPage registerPage;



	public String tcName;
//
//	@BeforeClass	
//	public void InitTest()  throws Exception {	   
//		System.out.println("Before Class  In UserBase Class");
//		System.out.println("*****TEST CASES NAME *******"+this.getClass().getSimpleName());	
//
//		    Reporter.initializeModule(this.getClass().getSimpleName());
//		    Thread.sleep(5000);
//		    System.out.println("In before class"+Thread.currentThread().getId());
//		    if(Mobile.mobilePlatform){
//		    //	Web.getDriver().manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
//		    }		    
//
//			}
//	
//	@AfterTest
//	 protected void tearDown() throws Exception{
//		 System.out.println("**********After Test**********");
//		 Reporter.finalizeTCReport();
//		 
//	 }
//	@DataProvider
//	public Object[][] setData(Method tc) throws Exception {
//		prepTestData(tc);		
//		return Stock.setDataProvider(this.testData);		
//		
//	}
//
//	private void prepTestData(Method testCase) throws Exception {
//		this.testData = Stock.getTestData(this.getClass().getPackage()
//				.getName(), testCase.getName());
//	}
//		
//	public static  String  getParaValue(String key){		 
//		 return lib.Stock.GetParameterValue(key);
//		 }
//
//
//		 protected void handleFailure(Exception e){
//			 e.printStackTrace();
//				Globals.exception = e;
//				Throwable t = e.getCause();
//				String msg = "Unable to retrive cause from exception. Click below link to see stack track.";
//				if (null != t) {
//					msg = t.getMessage();
//				//	Mobile.reportStatus = true;
//					
//				}
//				Reporter.logEvent(Status.FAIL, "A run time exception occured.", msg, true);
//		 }
//		 
//		 protected void handleError(Error ae){
//			    ae.printStackTrace();
//		        Globals.error = ae;
//		      //  Mobile.reportStatus = true;
//		        Reporter.logEvent(Status.FAIL, "Assertion Error Occured","Assertion Error Occured =="+ ae.getMessage(), true);
//		 }
//	
//	
	
	/*
	 * Verify Mobile App - Login Screen Elements
	 * @Author : Siddartha Pradhan
	 * @Date : 18-Jan-2017
	 */

	@Test(dataProvider = "setData")	
	public void PPTMOBILE_Login_001_DDTC_7841_Verify_Mobile_App_Login_Screen_Elements(int itr,
			Map<String, String> testdata) {
	try{
		LoginPage.setUserLogIn("");
		initializeReportForTC(itr);	
		loginPage = new LoginPage();	
		loginPage.get();			
	
		Reporter.logEvent(Status.INFO,"Step 2 Verify Login Screen ","Verify Empower Retirement Symbol is displayed in  upper portion of the page",false);
		Mobile.verifyElementPresent("Empower Retirement Symbol should be displayed", LoginPage.LOGO_IMG,"Empower Retirement Symbol");
		//Step 5	
		Mobile.verifyElementPresent("\"First time user?\" link should be displayed", LoginPage.FIRST_TIME_TEXT,"First time user? link");
		
		Mobile.verifyElementPresent("Login Button should be displayed", LoginPage.butLogin_ID,"Login Button");
	
		Reporter.logEvent(Status.INFO,"Verify Menu Option","Verify that the menu in the upper left hand corner \n Menu will contain the links for LOG IN, CONTACT US, and DISCLOSURES",false);		
		loginPage.verifyMenuOption("LOG IN" ,LoginPage.DISCLOSURES,LoginPage.CONTACT_US);	
	
	
	} catch (Exception e) {			 
		handleFailure(e);
	}
  	catch (Error ae){
	handleError(ae);
}
}
	
	/*
	 * Verify Mobile App - Login Screen - Entry Fields and Links
	 * @Author : Siddartha Pradhan
	 * @Date : 18-Jan-2017
	 */
		 public void initializeReportForTC(int itr) throws Exception{
				Reporter.initializeReportForTC(itr, Globals.GC_MANUAL_TC_NAME);
				  if(!LoginPage.getUserLogIN().equals(""))
					    if(!LoginPage.is_Same_User_Already_LogIN()){
					    	int i = 0;
					    	while(!Mobile.assertElementPresent(By.name(LoginPage.inputUserName_ID)) && i <2)
							new HomePage().logout();			
							 i++;
							}
					    

			}
	@Test(dataProvider = "setData")
	
	public void PPTMOBILE_Login_002_DDTC_7302_Verify_Mobile_App_Login_Screen_Entry_Fields_and_Links(int itr,
			Map<String, String> testdata) {
	try{
		LoginPage.setUserLogIn("");
	initializeReportForTC(itr);
	loginPage = new LoginPage();
	loginPage.get();	
	//Step 3
	Reporter.logEvent(Status.INFO,"Tap Contact link in menu Option "," Verify  link opens the Contact Us screen ",false);
	loginPage.verifyContactLink();
	
	Reporter.logEvent(Status.INFO,"TapClick Disclosure Link"," Verify  Link opens the Disclosures screen",false);
	loginPage.verifyDisclosuresLink();
	
	Mobile.clickElement("LOG IN");
	Mobile.verifyElementPresent("Tap Login menu and Login Screen should be display", LoginPage.inputUserName_ID, "Re open Login Screen");
	
	//Reporter.logEvent(Status.INFO,"Enter  the Username field and verify KeyBoard ","Verify the Keyboard displays",false);
	Mobile.setEdit(LoginPage.inputUserName_ID,"test");
	Common.verifyKeyBoardIsOpen();

	Reporter.logEvent(Status.INFO,"Enter the Password field ","Verify the keyboard displays",false);
	Mobile.setEdit(LoginPage.inputPassWord_ID,"test");
	Common.verifyKeyBoardIsOpen();
	Mobile.hideKeyboard();	

//	step 8
	loginPage.verifyLookUpAccountPage();
	
	
		
	} catch (Exception e) {	
		 
		handleFailure(e);
	}
  	catch (Error ae){
	handleError(ae);
}
}
	
	/**
	 * Verify Mobile App - MFA Verification Screen - Basic Fields and Functionality
	 * @Author : Siddartha Pradhan
	 * @Date : 2-Feb-2017
	 * @Description :- 
	 */

	@Test(dataProvider = "setData")
	public void  PPTMOBILE_Login_003_DDTC_7272_MFA_Verification_Screen_Basic_Fields_and_Functionality(int itr,
			Map<String, String> testdata) {
	try{
	initializeReportForTC(itr);     
		mfaPage = new MFAPage();
		mfaPage.get();	
		mfaPage.verify_MFA_Verification_Screen_Basic_Fields_and_Functionality();
	
						
		} catch (Exception e) {
		 
			handleFailure(e);
		}
      	catch (Error ae){
		handleError(ae);
	}
	}
	
	/**
	 * This methos will verify Login_Add_online_agreement_message_button_and_modal_disclosure
	 * @param itr
	 * @param testdata
	 */

	@Test(dataProvider = "setData")
	public void PPTMOBILE_Login_004_DDTC_7240_QA_Login_Add_online_agreement_message_button_and_modal_disclosure(int itr,
			Map<String, String> testdata) {
	try{
	initializeReportForTC(itr);

	mfaPage = new MFAPage();	
	
		mfaPage.get();	
		Mobile.verifyElementPresent("Disclosure Message in MFA Page should be displayed", MFAPage.DISCLOSURE, MFAPage.DISCLOSURE );	
		
	//	Reporter.logEvent(Status.INFO,"Step 3: Click  Empower Retirement Messaging Agreement button ","Verify Empower Retirement Messaging Agreement page Open  ",false);
		Mobile.clickElement(MFAPage.DISCLOSURE);
		Mobile.verifyElementPresent("Tap Empower Retirement Messaging  and verify  Message Agreement Header ", MFAPage.MESSAGE_AGREEMENT_HEADER, "Message Agreement page");
		//Common.verifyHomePageHeader("Message Agrement Header Dsiplayed", MFAPage.MESSAGE_AGREEMENT_HEADER);
		
		
		//Reporter.logEvent(Status.INFO,"Step 4: Click Privacy Policy link","Verify The privacy policy page should be displayed",false);
		
		Mobile.clickElement(MFAPage.PRIVACY_POLICY);
		Common.waitForProgressBar();
		Common.verifyPageIsDisplayed("Tap Privacy Policy  and Page should be displayed", MFAPage.PRIVACY_POLICY_HEADER);
		Common.clickBackButton();			
		
		//Reporter.logEvent(Status.INFO,"Step 5: Click Contact Us link","Verify Contact us Page is displayed",false);
        Mobile.clickElement(MFAPage.CONTACT_US);
	    Mobile.verifyElementPresent("Tap Contact Us link and Contact  Page should be displayed", "Contact us","Contact Link Page");
		Common.clickBackButton();
		Common.clickBackButton();
		
				
		} catch (Exception e) {
		 
			handleFailure(e);
		}
      	catch (Error ae){
		handleError(ae);
	}
	}
	
	
	
	@Test(dataProvider = "setData")
	public void PPTMOBILE_Login_005_DDTC_7231_Code_Sent_Screen_Negative_Code_Entered
	(int itr,Map<String, String> testdata) {
	try{
		initializeReportForTC(itr);
		mfaPage = new MFAPage();
		mfaPage.get();
		mfaPage.verify_Code_Sent_Screen_Negative_Code_Entered();
				
		} catch (Exception e) {
		 
			handleFailure(e);
		}
      	catch (Error ae){
		handleError(ae);
	}
	}
	
	
	/**
	 * QA - Login Screen - Negative Flow 
	 * @Author : Siddartha Pradhan
	 * @Date : 19-Jan-2017
	 */
	
	@Test(dataProvider = "setData")
	public void PPTMOBILE_Login_006_DDTC_7238_QA_Login_Screen_Negative_Flow (int itr,
			Map<String, String> testdata) {
	try{
		initializeReportForTC(itr);
		loginPage = new LoginPage();
		loginPage.get();			
		loginPage.verify_Login_Screen_Negative_Flow();					
		} catch (Exception e) {
		 
			handleFailure(e);
		}
      	catch (Error ae){
		handleError(ae);
	}
	}
	
	
	/**
	 * Verify Mobile App - Login Screen - Login - Prevent Lock Account
	 * @Author : Siddartha Pradhan
	 * @Date : 19-Jan-2017
	 * @Description :- 
	 */

	
	@Test(dataProvider = "setData")
	public void PPTMOBILE_Login_007_DDTC_7234_Login_Scree_Login_Prevent_Lock_Account(int itr,
			Map<String, String> testdata) {
	try{
		LoginPage.setUserLogIn("");
	initializeReportForTC(itr);
	Reporter.logEvent(Status.INFO,"Step 1","Login screen is opened",false);
		loginPage = new LoginPage();
		loginPage.get();	
		loginPage.verify_Login_Scree_Login_Prevent_Lock_Account();
				
		} catch (Exception e) {
		 
			handleFailure(e);
		}
      	catch (Error ae){
		handleError(ae);
	}
	}
	
	
	
	
	@Test(dataProvider = "setData")
	public void PPTMOBILE_Login_008_DDTC_7227_Login_Screen_Login_Lock_Account(int itr,
			Map<String, String> testdata) {
	try{
		LoginPage.setUserLogIn("");
	initializeReportForTC(itr);
	Reporter.logEvent(Status.INFO,"Step 1","Login screen is opened",false);
		loginPage = new LoginPage();
		loginPage.get();
		loginPage.verify_Login_Screen_Login_Lock_Account();
	
				
		} catch (Exception e) {
		 
			handleFailure(e);
		}
      	catch (Error ae){
		handleError(ae);
	}
	}
	
	/**
	 *  DDTC-6308 QA - Participant Registration flow - 5 point Authentication - Plan enhanced security is On -
	 *   Contact info is not available 	 *  
	 * Pre - requisite:
	 *  User is not registered with the Empower retirement app & contact info details are not available in database.
	 *   In KTMG transaction enhanced security is enabled for the user's plan.

	 */
	
		
	@Test(dataProvider = "setData")
	public void PPTMOBILE_Reg_MFA_ON_TC01_DDTC_6308_5Point_registration_Contact_Info_Not_Available(int itr,
			Map<String, String> testdata) {
	try{
	initializeReportForTC(itr);
	registerPage = new LookUpAccountPage();
	registerPage.get();	
	registerPage.enterRegisterLookUpPage();
	String sMsg1= "Something is missing";
	String sMsg = "We need some additional information to complete your registration. Please contact a Participant Services Representative to continue.";

	Mobile.verifyElementPresent("Something is missing page should be displayed" , sMsg1, sMsg1);
	Mobile.verifyElementPresent("Message details should be displayed" , sMsg, sMsg);
	registerPage.verifyContactUsButton();					
		} catch (Exception e) {
		 
			handleFailure(e);
		}
      	catch (Error ae){
		handleError(ae);
	}
	}
	
	/**
	 *  QA - Participant Registration flow - 5 point Authentication - 
	 * Plan enhanced security is On - Contact info is available
	 * @param itr
	 * @param testdata
	 */
	
	
	@Test(dataProvider = "setData")
	public void PPTMOBILE_Reg_MFA_ON_TC02_DDTC_6265_5Point_registration_Contact_Info_Available(int itr,
			Map<String, String> testdata) {
	try{
	initializeReportForTC(itr);
	registerPage = new LookUpAccountPage();
	registerPage.get();	
	registerPage.enterRegisterLookUpPage();
	Mobile.verifyElementNotPresent("Contact Information page should not be display", "We found you!", "Contact Infomation");
	registerPage.enterNewLoginDetails();
	registerPage.submitVerificationCode();
	registerPage.verifyRegistrationSummaryPage();
	registerPage.verifyLIATPageIsDisplayed();
	new HomePage().logout();
	} catch (Exception e) {
		 
			handleFailure(e);
		}
      	catch (Error ae){
		handleError(ae);
	}
	}
	
	
	/**
	 *  DDTC-6287 QA - Participant Registration flow -
	 *  5 point Authentication - Plan enhanced security is off - Contact info is available
	 * @param itr
	 * @param testdata
	 * 
	 * DDDTC-7304 and DDTC-6264 This test validates the 2nd step of registartion - username rules.
	 * DDTC-7253 QA - Authentication - Change text for username and password rules
	 * 
	 * DDTC-20242 -QA - QA - Password change validation - Registration flow

	 */
	
	
	@Test(dataProvider = "setData")
	public void PPTMOBILE_Reg_MFA_OFF_TC03_DDTC_6287_6264_7253_7304_Point_registration_Contact_Info_Available(int itr,
			Map<String, String> testdata) {
	try{
	initializeReportForTC(itr);
	System.out.println("Inside Test Method");
	registerPage = new LookUpAccountPage();
	registerPage.get();		
	registerPage.enterRegisterLookUpPage();
	//registerPage.enterUserContactPage();
	registerPage.verifyUserNameAndPassWordTextBox();
	registerPage.enterNewLoginDetails();
	registerPage.submitVerificationCode();
	registerPage.verifyRegistrationSummaryPage();
	registerPage.verifyLIATPageIsDisplayed();
	new HomePage().logout();
		} catch (Exception e) {
		 
			handleFailure(e);
		}
      	catch (Error ae){
		handleError(ae);
	}
	}
	
	/**
	 * QA - Participant Registration flow - 5 point Authentication -
	 *  Plan enhanced security is off - Contact info is not available
	 * @param itr
	 * @param testdata
	 * Verify Mobile App - Alternative Authentication - 1st Step - registration screen for contact information
	 * 
	 */
	

	@Test(dataProvider = "setData")
	public void PPTMOBILE_Reg_MFA_OFF_TC04_DDTC_6306_6271_5Point_registration_Contact_Info_Not_Available(int itr,
			Map<String, String> testdata) {
	try{
	initializeReportForTC(itr);
	registerPage = new LookUpAccountPage();
	registerPage.get();	
	registerPage.enterRegisterLookUpPage();
//	registerPage.verifyUserContactInformationPage();	
//	registerPage.enterUserContactPage();	
	registerPage.enterNewLoginDetails();
	registerPage.submitVerificationCode();
	registerPage.verifyRegistrationSummaryPage();
	registerPage.verifyLIATPageIsDisplayed();
	new HomePage().logout();
	
		} catch (Exception e) {
		 
			handleFailure(e);
		}
      	catch (Error ae){
		handleError(ae);
	}
	}
	
	/**
	 * Verify Mobile App - Participant Registration
	 * 
	 * @param itr
	 * @param testdata
	 */
	
	
	@Test(dataProvider = "setData")
	public void PPTMOBILE_Reg_MFA_OFF_TC05_DDTC_6267_Verify_Registration_Page(int itr,
			Map<String, String> testdata) {
	try{
	initializeReportForTC(itr);
	registerPage = new LookUpAccountPage();
	registerPage.get();	
	registerPage.verifyRegistrationPage();	
	Common.clickBackArrow();
		} catch (Exception e) {
		 
			handleFailure(e);
		}
      	catch (Error ae){
		handleError(ae);
	}
	}
	
	
	
	
	
	/**
	 *DDTC-20243 QA - Password change validation - Forgot password flow
	 * 
	 * @param itr
	 * @param testdata
	 */
	
	
	@Test(dataProvider = "setData")
	public void PPTMOBILE_Reg_TC06_20243_DDTC_PassWord_Change_Validation(int itr,
			Map<String, String> testdata) {
	try{
	initializeReportForTC(itr);
	loginPage = new LoginPage();
	loginPage.get();
	loginPage.clickForgotPasswordLink();
	registerPage = new LookUpAccountPage();
	registerPage.get();	
	registerPage.enterRegisterLookUpPage();
	registerPage.enterNewLoginDetails();
	registerPage.submitVerificationCode();
	registerPage.verifyRegistrationSummaryPage();
	registerPage.verifyLIATPageIsDisplayed();
	new HomePage().logout();

	} catch (Exception e) {		 
		handleFailure(e);
	}
  	catch (Error ae){
	handleError(ae);
}
}
	
	/**
	 *DDTC-6282 QA - Username/Password Reset flow for Un-registered user
	 * 
	 * @param itr
	 * @param testdata
	 */
	
	
	@Test(dataProvider = "setData")
	public void PPTMOBILE_Reg_TC07_6282_DDTC_UserName_Change_Validation(int itr,
			Map<String, String> testdata) {
	try{
	initializeReportForTC(itr);
	loginPage = new LoginPage();
	loginPage.get();
	loginPage.clickForgotUserLink();
	registerPage = new LookUpAccountPage();
	registerPage.get();	
	registerPage.enterRegisterLookUpPage();
	registerPage.enterNewLoginDetails();
	registerPage.submitVerificationCode();
	registerPage.verifyRegistrationSummaryPage();
	registerPage.verifyLIATPageIsDisplayed();
	new HomePage().logout();

	} catch (Exception e) {		 
		handleFailure(e);
	}
  	catch (Error ae){
	handleError(ae);
}
}

	/**
	 * DDTC-5302 QA - Magic login - GWRS plan participants
	 * This test validates magic login functionality for GWRS plan participants

	 */
	
	@Test(dataProvider = "setData")
	public void PPTMOBILE_Login_TC08_DDTC_5302_Magic_login_GWRS_Plan(int itr,
			Map<String, String> testdata) {
	try{
	initializeReportForTC(itr);
	MFAPage mfaPage = new MFAPage();
	mfaPage.get();
	mfaPage.verify_Magic_Login_For_GWRS_Plan();	
	new HomePage().logout();
	} catch (Exception e) {		 
		handleFailure(e);
	}
  	catch (Error ae){
	handleError(ae);
}
}

	
	/**
	 * DDTC-5300 - QA - Magic login - Putnam plan participants
	 * This test validates magic login functionality for GWRS plan participants
	 * find plans for PUTNAM( INST Database - 198010-01)

	 */
	
	@Test(dataProvider = "setData")
	public void PPTMOBILE_Login_TC09_DDTC_5300_Magic_login_Putnam_Plan(int itr,
			Map<String, String> testdata) {
	try{
	initializeReportForTC(itr);
	MFAPage mfaPage = new MFAPage();
	mfaPage.get();
	mfaPage.verify_Magic_Login_For_Putnam_Plan();	
	new HomePage().logout();
	} catch (Exception e) {		 
		handleFailure(e);
	}
  	catch (Error ae){
	handleError(ae);
}
	}
	

	/**
	 * DDTC-5300 - QA - Magic login - Putnam plan participants
	 * QA - Magic login - Participant with multiple plans

	 */
	
	@Test(dataProvider = "setData")
	public void PPTMOBILE_Login_TC10_DDTC_6263_Magic_login_With_Multiple_Plans(int itr,
			Map<String, String> testdata) {
	try{
	initializeReportForTC(itr);
	MFAPage mfaPage = new MFAPage();
	mfaPage.get();
	mfaPage.verify_Magic_Login_With_Multiple_Plan();	
	new HomePage().logout();
	} catch (Exception e) {		 
		handleFailure(e);
	}
  	catch (Error ae){
	handleError(ae);
}
	
	
}

	
	
	
	
	
	@Test(dataProvider = "setData")
	public void Mobile01_TC02_Verify_valid_Userid_and_Password(int itr,
			Map<String, String> testdata) {
	try{
		initializeReportForTC(itr);

		loginPage = new LoginPage();
		loginPage.get();	
		Common.verifyPageIsDisplayed("Step 1", getParaValue("expHomePage"));				
		
		 
		
		} catch (Exception e) {
			handleFailure(e);
		}catch (Error ae){
			handleError(ae);
		}
	}

	
	
	
	
}
	
	
	

			  
		
	
	
	
	






package com.greatWest.login;

	import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.ios.IOSElement;
import io.appium.java_client.remote.AutomationName;
import io.appium.java_client.remote.IOSMobileCapabilityType;
import io.appium.java_client.remote.MobileCapabilityType;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;
	 
	public class ParallelSuiteTest
	{
		//public AppiumDriver<MobileElement> driver = null;
	    String devices = "";
	    String UDID_ = "";
	    String platformVersion_ = "";
	    String URL_ = "";
	    String wdaPort = "";
	    public static   WebDriver webdriver = null;
	    public static String USERNAME_INPUT = "GWMUsernameTextField";
		public static String PASSWORD_INPUT = "GWMPasswordTextField";  
		public static String LOGIN_BUTTON = "GWMLoginButton";
		public static String MENULABEL = "menu";
		public static String envlabel = "Environments"; 
		public static String LOG_IN = "LOG IN";  
		public static String DISCLOSURES ="DISCLOSURES";
		public static String CONTACT_US = "Contact us.";	
		//private static ThreadLocal<MobileElement> driver = new ThreadLocal<MobileElement>();
		private static Map<Long,IOSDriver<MobileElement>> driver = new LinkedHashMap<>();
		
		public String CANCEL_BUT = "CANCEL";
		public String SAVE_BUT = "SAVE";
		public String CLOSE_BUT = "Close";
		public String BACK_BUT = "Back";
		public String NEXT_BUT = "Next";
		public String DONE_BUT = "Done";
		 DesiredCapabilities capabilities = new DesiredCapabilities();
	    @BeforeTest
	    @Parameters({ "deviceName_","UDID_","platformVersion_", "URL_","wdaPort" })
	    public void beforeTest(String deviceName_,String UDID_,String platformVersion_,String URL_,String wdaPort) throws Exception {
	        this.devices = deviceName_;
	        this.UDID_ = UDID_;
	        this.platformVersion_ = platformVersion_;
	        this.URL_ = URL_;
	        this.wdaPort = wdaPort;
	        
	        long id = Thread.currentThread().getId();
	        System.out.println("Before test " + devices + ". Thread id is: " + id);
	        
	        webdriver  = iosNative( this.URL_);
	      
	        driver.put(Thread.currentThread().getId(), (IOSDriver<MobileElement>) webdriver);
	        
			
	        testMethodOne(); 
	        
	    }
	 
	    @BeforeClass
	    public void beforeClass() {
	        long id = Thread.currentThread().getId();
	        System.out.println("Before test-class " + devices + ". Thread id is: "
	                + id);
	        
	    }
	 
	
	    public void testMethodOne()  throws Exception {
	        long id = Thread.currentThread().getId();
	        System.out.println("Sample test-method " + devices
	                + ". Thread id is: " + id);
	        Thread.sleep(3000);   
	        selectEnv();        
	        submitLogin("122588185ABC","Test@1234");        
	        submitVerificationCode();         
	        profilePage();        
	        logOut();
	        
	        
	        
	    }
	 
	    @AfterClass
	    public void afterClass() {
	        long id = Thread.currentThread().getId();
	        System.out.println("After test-method  " + devices
	                + ". Thread id is: " + id);
	        
	        
	    }
	 
	    @AfterTest
	    public void afterTest() {
	        long id = Thread.currentThread().getId();
	        System.out.println("After test  " + devices + ". Thread id is: " + id);	       
	     
	        
	    }
	    
	   	public  void logOut() throws InterruptedException{	
	   		getDriver().findElement(By.name(MENULABEL)).click();	
	   		getDriver().findElement(By.name("LOG OUT")).click();	
	   	}
	    
	 
	   	
	   	public static AppiumDriver< MobileElement> getDriver() {
				
			return (AppiumDriver)driver.get(Thread.currentThread().getId());
	   	}
	   	
	   	
	   	public void profilePage(){   		
			
	   		getDriver().findElement(By.name(MENULABEL)).click();		
	    	getDriver().findElement(By.name("PROFILE")).click();
	    	wait(6000);
		    getDriver().findElement(By.name("Username")).click();
		    getDriver().findElement(By.name("EDIT USERNAME")).click();
		    Verify_Password_Validation_Message();	
	   		
	   	}
	   	
	   	
		private  AppiumDriver<MobileElement>   iosNative(String url) throws MalformedURLException {
			AppiumDriver<MobileElement> driver1 = null;
			System.out.println("Setting iOS Desired Capabilities:");
			capabilities.setCapability(MobileCapabilityType.APPIUM_VERSION,
					"1.7.1");
			capabilities.setCapability("waitForQuiescence",false);
			
			capabilities.setCapability(MobileCapabilityType.AUTOMATION_NAME,
					AutomationName.IOS_XCUI_TEST);
			capabilities.setCapability(MobileCapabilityType.NEW_COMMAND_TIMEOUT,
					5000);	
			capabilities.setCapability(MobileCapabilityType.PLATFORM_VERSION,
					"10.0");

			 capabilities.setCapability(IOSMobileCapabilityType.WDA_LOCAL_PORT, wdaPort);
				
		
			capabilities.setCapability(MobileCapabilityType.NO_RESET, true);		
			capabilities.setCapability(MobileCapabilityType.PLATFORM_VERSION, "iOS");
			capabilities.setCapability(IOSMobileCapabilityType.INTER_KEY_DELAY,
					"5000");
	
		
				capabilities.setCapability(MobileCapabilityType.TAKES_SCREENSHOT,
						true);
				
				capabilities.setCapability(MobileCapabilityType.UDID,this.UDID_);
			
				capabilities.setCapability(IOSMobileCapabilityType.BUNDLE_ID,"com.empower-retirement.ios.Participant-Mobile");
					capabilities.setCapability(MobileCapabilityType.APP,
							"/Users/gwgmobilelab/Desktop/eclipse_projects/MobileTest_WorkSpace/APPIUM POC/App/device/Empower.app");

			
			capabilities.setCapability(IOSMobileCapabilityType.AUTO_ACCEPT_ALERTS,
					true);
			capabilities.setCapability(MobileCapabilityType.DEVICE_NAME,this.devices );
			System.out.println("Return Capabilities:"+capabilities);
				
			 driver1 = new IOSDriver<>(new URL(url),capabilities );
			return driver1;
		}
		
	   	
	   	
	   	public void Verify_Password_Validation_Message(){
			List<MobileElement> textBoxList =   (List<MobileElement>) getDriver().findElements(By.className("XCUIElementTypeTextField"));	
			IOSElement username = 	(IOSElement) textBoxList.get(0);
			username.click();	
			//	Reporter.logEvent(Status.INFO ,"Enter Upper Cases Letter in Current Password ", "Verify Message  displayed",false);
			username.clear();
			username.sendKeys("Test@123456789101112");	 	
			username.clear();
			username.sendKeys("Test@12345678");		
			getDriver().findElement(By.name(DONE_BUT)).click();
			getDriver().findElement(By.name(CANCEL_BUT)).click();
			getDriver().findElement(By.name(BACK_BUT)).click();
			 
			
		}
		
		
	   	
	   	
	    
		public  void submitLogin(String user,String Password) throws InterruptedException{			

		
			getDriver().findElement(By.name(USERNAME_INPUT)).sendKeys(user);
			getDriver().findElement(By.name(PASSWORD_INPUT)).sendKeys(Password);
			hideKeyboard();
			getDriver().findElement(By.name(LOGIN_BUTTON)).click();
			wait(10000);	
		}
		
		private  void selectEnv(){
			getDriver().findElement(By.name(MENULABEL)).click();	
			
			wait(2000);		
			getDriver().findElement(By.name(envlabel)).click();
			getDriver().findElement(By.name("Proj2")).click();
			getDriver().findElement(By.name(MENULABEL)).click();	
			wait(2000);
			getDriver().findElement(By.name(LOG_IN)).click();	

			
		}
		
		private  void submitVerificationCode(){
			String ALREADY_CODE_LINK = "Already have a code?";
			String VERIFICATION_CODE_INPUT = "VERIFICATION CODE";
		    wait(5000);	
			getDriver().findElement(By.name(ALREADY_CODE_LINK)).click();
			getDriver().findElement(By.name(VERIFICATION_CODE_INPUT)).sendKeys("74196385");
			getDriver().findElement(By.name("Done")).click();
			getDriver().findElement(By.name("GWMConfirmCodeButton")).click();	
			waitTillElementNotDisplay("GWMConfirmCodeButton");
		    wait(10000);	

		}
		
		public  void hideKeyboard() {
			getDriver().getKeyboard().pressKey("\n");
		
		}
		
	    public  void waitTillElementNotDisplay(String sElement){
	  	  int iTimeInSecond=80;
	         try{
	                int iCount = 0;
	                while (FindElement_Acc_ID(sElement).isDisplayed()){
	                       if(iCount ==iTimeInSecond){
	                             break;
	                       }   	                         
	                       System.out.println("Element is still diplaying...");
	                       Thread.sleep(1000);                       
	                       iCount++;
	                }
	                
	         }catch(Exception e){
	                
	         }
	         
	      }
	    
	    public  MobileElement FindElement_Acc_ID(String sElement){
			getDriver().manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
	       return (IOSElement) getDriver().findElementByAccessibilityId(sElement);
	    }
	    
		public  void wait(int inmillSec) {
			try {
				Thread.sleep(inmillSec);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
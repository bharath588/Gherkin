package com.greatWest.investment;

import java.util.Map;

import com.greatWest.utility.Mobile;

import org.testng.annotations.Test;

import com.greatWest.login.UserBaseTest;
import com.greatWest.pageObject.DeferralsPage;
import com.greatWest.pageObject.EnrollmentPage;
import com.greatWest.pageObject.HomePage;
import com.greatWest.pageObject.investment.MyInvestmentPage;
import com.greatWest.pageObject.investment.MyInvestmentPage.InvestmentOption;
import com.greatWest.pageObject.investment.MyInvestmentPage.buttonName;
import com.greatWest.pageObject.investment.MyInvestmentPage.fundAllocationType;
import com.greatWest.utility.Common;

public class MyInvestmentsTestClass extends UserBaseTest {
	
	private MyInvestmentPage myInvestmentPage;
	private EnrollmentPage enrollmentPage;
	private HomePage homePage;
	
	/*
	 *  DDTC-5303 QA - My Investments page view

	 */
	
	@Test(dataProvider = "setData")
	public void   PPTMOBILE_Investment_001_DDTC_5303_My_Investments_Page_View(int itr,
			Map<String, String> testdata) {
	try{
	initializeReportForTC(itr);	
	DeferralsPage.setApplePlan(true);
	myInvestmentPage = new MyInvestmentPage();
	myInvestmentPage.get();
	myInvestmentPage.verify_MyInvestments_Page();
	
	
		
	} catch (Exception e) {
	 
		handleFailure(e);
	}
  	catch (Error ae){
	handleError(ae);
}
}
	
	
	
	/*
	 *  DDTC-5291 QA - Change My Investments/How would you like to invest page- Content and label views

	 */
	
	@Test(dataProvider = "setData")
	public void   PPTMOBILE_Investment_002_DDTC_5291_And_5272_Change_My_Investments(int itr,
			Map<String, String> testdata) {
	try{
	initializeReportForTC(itr);			
	myInvestmentPage = new MyInvestmentPage();
	myInvestmentPage.get();
	myInvestmentPage.verify_Change_My_Investments_Page();
	
	
		
	} catch (Exception e) {
	 
		handleFailure(e);
	}
  	catch (Error ae){
	handleError(ae);
}
}
	
	/*
	 * QA - Change My Investments/How would you like to invest page- DO IT FOR ME (DIFM) -Already Enrolled in Morning star
	 * QA - Change My Investments/How would you like to invest page- DO IT FOR ME (DIFM) -Already Enrolled
	 * This test validates the content and functionality of DO IT FOR ME option in
	 *  How would you like to invest? page is displaying as per the requirement.
	 */
	
	@Test(dataProvider = "setData")
	public void   PPTMOBILE_Investment_003_DDTC_5304_DIFM_Already_Enrolled_In_Morning_Star(int itr,
			Map<String, String> testdata) {
	try{
	initializeReportForTC(itr);			
	myInvestmentPage = new MyInvestmentPage();
	myInvestmentPage.get();
	myInvestmentPage.verify_Do_It_For_Me_In_Moring_Star();	
	
		
	} catch (Exception e) {
	 
		handleFailure(e);
	}
  	catch (Error ae){
	handleError(ae);
}
}
	
	
	/*
	 * QA - Change My Investments/How would you like to invest page for Apple plans
	 * DDTC_6270
	 */
	
	@Test(dataProvider = "setData")
	public void   PPTMOBILE_Investment_004_DDTC_6303_6270_Change_My_Investments_Page_For_Apple_Plan(int itr,
			Map<String, String> testdata) {
	try{
		
	initializeReportForTC(itr);	
	DeferralsPage.setApplePlan(true);
	myInvestmentPage = new MyInvestmentPage();
	myInvestmentPage.get();
	myInvestmentPage.verify_Change_My_Investments_Page_For_Apple_Plan();	
	
		
	} catch (Exception e) {
	 
		handleFailure(e);
	}
  	catch (Error ae){
	handleError(ae);
}
}
	
	/*
	 *   DDTC-8624  QA - Enrollment - Allocation/Investment flow - Already participant enrolled with MA
	 */
	@Test(dataProvider = "setData")
	public void   PPTMOBILE_Investment_005_DDTC_8624_Already_Participant_Enrolled_With_MA(int itr,
			Map<String, String> testdata) {
	try{
		
	initializeReportForTC(itr);	
	enrollmentPage = new EnrollmentPage();
	enrollmentPage.get();
	enrollmentPage.verify_Already_Participant_With_MA();
		
	
		
	} catch (Exception e) {
	 
		handleFailure(e);
	}
  	catch (Error ae){
	handleError(ae);
}
}
	
	
	
	/*
	 * QA - Change My Investments/How would you like to invest page- DO IT FOR ME (DIFM) -Already Enrolled in FE
	 * select distinct pa.ga_id, i.id, i.ssn, a.zip_code, i.last_name, I.BIRTH_DATE, a.first_line_mailing, PA.PIN_AUTH_CODE ,
	 *   --substr(decrypt(i.encrypted_pass_code),1,10) as PIN,
	 *     u.username , substr(decrypt(u.encrypted_pass_code),1,10),u.CUSREG_CODE 
	 *     from individual i
	 *     join part_agrmt pa on pa.ind_id = i.id
	 *     join access_customization_view av on pa.ga_id=av.ga_id
	 *     join address a on (a.ind_id = i.id)
	 *     join employment e on (e.ind_id = i.id)
	 *     left join username_registry_link u on (u.ssn = i.ssn)
	 *     --join (Select ind_id,gc_id, count(*) From income_data group by ind_id, gc_id having count(*)>1) x on i.id=x.ind_id
	 *     where pa.ga_id in (Select distinct ga_id From ga_service where sdsv_subcode='FINANCIAL_ENGINES' and termdate is null and sdsv_code='ASSET_ALLOC') and ---i.id='14453627' and
	 *     pa.status_code = 'A' and u.username is not null  and PA.PIN_AUTH_CODE in ('I','U') and i.id in (select ind_id from part_service where sdsv_subcode='FINANCIAL_ENGINES' and status_code='A' and status_reason_code='ENROLLED')
	 *       and E.EMP_TERMDATE is null and av. accu_code = 'Empower'
	 *         and av. access_type_code = 'PPT_WEB'
	 *        and av.published_access_ind = 'Y'
	 *         order by pa.ga_id, i.id;-


	 * 
	 */
	@Test(dataProvider = "setData")
	public void   PPTMOBILE_Investment_006_DDTC_28835_DIFM_Already_enrolled_In_Financial_Engine(int itr,
			Map<String, String> testdata) {
	try{		
	initializeReportForTC(itr);	
	DeferralsPage.setApplePlan(true);
	myInvestmentPage = new MyInvestmentPage();
	myInvestmentPage.get();
	myInvestmentPage.verify_Do_It_For_Me_In_Financial_Engine();	
		
	} catch (Exception e) {
	 
		handleFailure(e);
	}
  	catch (Error ae){
	handleError(ae);
}
}
	
	/*
	 * QA - Enrollment - Allocation/Investment flow - Help me do it.
	 */
	
	@Test(dataProvider = "setData")
	public void   PPTMOBILE_Investment_007_DDTC_8602_HMDI_Enrollement_Flow(int itr,
			Map<String, String> testdata) {
	try{
		
	initializeReportForTC(itr);	
	DeferralsPage.setApplePlan(true);
	enrollmentPage = new EnrollmentPage();
	enrollmentPage.get();
	myInvestmentPage = new MyInvestmentPage();
	myInvestmentPage.verify_HMDI_Enrollement_Flow();	
	enrollmentPage.clickEnrollment_Button_Till_ConfiramtionPage();
	enrollmentPage.verifyMyInvestementConfirmationPage();
		
	} catch (Exception e) {
	 
		handleFailure(e);
	}
  	catch (Error ae){
	handleError(ae);
}
}
	
	
	/*
	 * DDTC-8529 QA - Change My Investments/How would you like to invest page- HELP ME DO IT (HMDI) - Based on a model portfolio - Multiple model portfolio
	 * DDTC-8532 QA - My investments view page - Based on Model portfolio
	 */
	
	@Test(dataProvider = "setData")
	public void   PPTMOBILE_Investment_008_DDTC_8529_8532_HMDI_Based_On_A_Module_Portfolio(int itr,
			Map<String, String> testdata) {
	try{
		
	initializeReportForTC(itr);	
	myInvestmentPage = new MyInvestmentPage();
	myInvestmentPage.get();
	myInvestmentPage.verify_HMDI_Multiple_Based_Model_Portfolio();	
		
	} catch (Exception e) {
	 
		handleFailure(e);
	}
  	catch (Error ae){
	handleError(ae);
}
	}
	
	/*
	 * Digital Delivery Testing
	 * DDTC-5307
	 * QA - Change My Investments/How would you like to invest page- HELP ME DO IT (HMDI) - CHOOSE A TARGET DATE FUND
	 */
	
	@Test(dataProvider = "setData")
	public void   PPTMOBILE_Investment_009_DDTC_5307_and_6268_HMDI_Choose_A_Target_Date_Fund(int itr,
			Map<String, String> testdata) {
	try{
		
	initializeReportForTC(itr);	
	DeferralsPage.setApplePlan(true);
	myInvestmentPage = new MyInvestmentPage();
	myInvestmentPage.get();
	
	myInvestmentPage.verify_HMDI_Choose_A_Target_Date_Fund();	
		
	} catch (Exception e) {
	 
		handleFailure(e);
	}
  	catch (Error ae){
	handleError(ae);
}
	
	}
	/*
	 * Digital Delivery Testing
	 * DDTC-5307
	 * QA - Change My Investments/How would you like to invest page- HELP ME DO IT (HMDI) - ACCESS ONLINE ADVICE
	 */
	
	@Test(dataProvider = "setData")
	public void   PPTMOBILE_Investment_010_DDTC_5305_HMDI_Access_Online_Advice(int itr,
			Map<String, String> testdata) {
	try{
		
	initializeReportForTC(itr);	
	DeferralsPage.setApplePlan(true);
	myInvestmentPage = new MyInvestmentPage();
	myInvestmentPage.get();
	myInvestmentPage.verify_Access_Online_Advice();	
		
	} catch (Exception e) {
	 
		handleFailure(e);
	}
  	catch (Error ae){
	handleError(ae);
}
	
}
	
	/*
	 * QA - Change My Investments/How would you like to invest page- HELP ME DO IT (HMDI) - Risk Based Funds
	 */
	@Test(dataProvider = "setData")
	public void   PPTMOBILE_Investment_011_DDTC_6277_HMDI_Risk_Based_Fund(int itr,
			Map<String, String> testdata) {
	try{
		
	initializeReportForTC(itr);		
	myInvestmentPage = new MyInvestmentPage();
	myInvestmentPage.get();
	myInvestmentPage.verify_HMDI_Risk_Base_Fund();	
		
	} catch (Exception e) {
	 
		handleFailure(e);
	}
  	catch (Error ae){
	handleError(ae);
}
	
}
	
	/*
	 *  DDTC-8531 QA - Change My Investments/How would you like to invest page- HELP ME DO IT (HMDI) - 
	 *  Based on a model portfolio - Single model portfolio
	 */
	
	
	@Test(dataProvider = "setData")
	public void   PPTMOBILE_Investment_012_DDTC_8531_HMDI_Single_Module_Portfolio(int itr,
			Map<String, String> testdata) {
	try{

	initializeReportForTC(itr);	
	HomePage.setMultiplePlan(true, "PERSHING_PLAN TESTING");	
	myInvestmentPage = new MyInvestmentPage();
	myInvestmentPage.get();
	myInvestmentPage.verify_HMDI_Single_Based_Model_Portfolio();	
		
	} catch (Exception e) {
	 
		handleFailure(e);
	}
  	catch (Error ae){
	handleError(ae);
}
	}
	//HELP IT MYSELF 
	
	/**
	 * QA - Change My Investments/How would you like to invest page- 
	 * DO IT MYSELF (DIM)- CHOOSE INDIVIDUAL FUNDS - Build your own portfolio with model
	 * Test cases 5286  also covered by this test cases
	 * 
	 * DDTC-8533 QA - Change My Investments/How would you like to invest page- DO IT MYSELF (DIM)- 
	 * CHOOSE INDIVIDUAL FUNDS - Build your own portfolio with modelsmodel portfolio - Multiple model portfolio

	 * s
	 */
	@Test(dataProvider = "setData")
	public void   PPTMOBILE_Investment_013_DDTC_8533_5286_5306_6275_6272_DIM_CIF_Build_Your_Own_Portfolio_With_Models(int itr,
			Map<String, String> testdata) {
	try{
	initializeReportForTC(itr);	
	myInvestmentPage = new MyInvestmentPage();
	myInvestmentPage.get();
	
	
	myInvestmentPage.verify_DIM_CIF_Build_Your_Own_Portfolio_With_Models();	
		
	} catch (Exception e) {
	 
		handleFailure(e);
	}
  	catch (Error ae){
	handleError(ae);
}
	}
	
	
	/**
	 * 
	 * <h1> TESTCASE:	PPTMOBILE_Investment_015_DDTC_6275_6272_DIM_CIF_Build_Your_Own_Portfolio_Asset_Allocation_Link_Not_Enrolled</h1>
	 * 
	 * DESCRIPTION:	QA - Change My Investments/How would you like to invest page- DO IT MYSELF (DIM)- CHOOSE INDIVIDUAL FUNDS 
	 *  Build your own portfolio - Asset allocation disclosure Link - Not Enrolled
	 *  
	 *  This test method also verify for 
	 *   DDTC-6272 QA - Change My Investments/How would you like to invest page- DO IT MYSELF
	 *  (DIM)- CHOOSE INDIVIDUAL FUNDS - Build your own portfolio - Asset allocation disclosure Link
	 *
	 * @RETURNS  nothing
	 * @Author  Siddartha 
	 * @since   27-07-17    
	 * 
	 * @param   
	 * 
	 */ 
	
	@Test(dataProvider = "setData")
	public void   PPTMOBILE_Investment_015_DDTC_6275_6272_DIM_CIF_Build_Your_Own_Portfolio_Asset_Allocation_Link(int itr,
			Map<String, String> testdata) {
	try{

	initializeReportForTC(itr);	
	HomePage.setMultiplePlan(true, "PERSHING_PLAN TESTING");	
	myInvestmentPage = new MyInvestmentPage();
	myInvestmentPage.get();
	myInvestmentPage.verify_DIM_CIF_Verify_Assest_allocation_Link();			
	} catch (Exception e) {
	 
		handleFailure(e);
	}
  	catch (Error ae){
	handleError(ae);
}
	}
	
	
	/**
	 *  TESTCASE:
	 *  DDTC-8613 QA - Enrollment - Allocation/Investment flow - DO IT MYSELF (DIM)- CHOOSE INDIVIDUAL FUNDS - No default investments

	 *  
	 *  
	 *  DESCRIPTION:
	 * 
	 */
	
	@Test(dataProvider = "setData")
	public void   PPTMOBILE_Investment_Enrollment_016_DDTC_8613_DIM_CIF_No_Default_Investement(int itr,
			Map<String, String> testdata) {
	try{

	initializeReportForTC(itr);	
	enrollmentPage = new EnrollmentPage();
	myInvestmentPage = new MyInvestmentPage();
	
	enrollmentPage.get();	
	enrollmentPage.click_My_Investment_Option();
	myInvestmentPage.verify_DIM_CIF_No_Default_Investement();
	enrollmentPage.clickEnrollment_Button_Till_ConfiramtionPage();
	enrollmentPage.verifyMyInvestementConfirmationPage();
	 new HomePage().logout();
	
	} catch (Exception e) {
	 
		handleFailure(e);
	}
  	catch (Error ae){
	handleError(ae);
}
	}
	
	/**
	 *  TESTCASE:
	 *  DDTC-8607 QA - Enrollment - Allocation/Investment flow - DO IT MYSELF (DIM)- CHOOSE INDIVIDUAL FUNDS - Default investment is model portfolio

	 *  
	 *  
	 *  DESCRIPTION:
	 * 
	 */
	
	@Test(dataProvider = "setData")
	public void   PPTMOBILE_Investment_Enrollment_017_DDTC_8607_DIM_CIF_Default_Investement_Is_Model_Portfolio(int itr,
			Map<String, String> testdata) {
	try{

		initializeReportForTC(itr);	
		enrollmentPage = new EnrollmentPage();
		myInvestmentPage = new MyInvestmentPage();
		enrollmentPage.get();	
		enrollmentPage.click_My_Investment_Option();
		myInvestmentPage.verify_DIM_CIF_Default_Investement_Is_Model_Portfolio();
		enrollmentPage.clickEnrollment_Button_Till_ConfiramtionPage();
		enrollmentPage.verifyMyInvestementConfirmationPage_percentage();
		 new HomePage().logout();
	
	} catch (Exception e) {
	 
		handleFailure(e);
	}
  	catch (Error ae){
	handleError(ae);
}
	}
	
	
	/**
	 *  TESTCASE: DDTC-8610
	 * QA - Enrollment - Allocation/Investment flow - DO IT MYSELF (DIM)- CHOOSE INDIVIDUAL FUNDS - Model portfolio is not default invesments
	 */
	

	@Test(dataProvider = "setData")
	public void   PPTMOBILE_Investment_Enrollment_018_DDTC_8610_DIM_CIF_Model_Portfolio_Is_Not_default_Investment(int itr,
			Map<String, String> testdata) {
	try{

		initializeReportForTC(itr);	
		enrollmentPage = new EnrollmentPage();
		myInvestmentPage = new MyInvestmentPage();
		enrollmentPage.get();	
		enrollmentPage.click_My_Investment_Option();
		myInvestmentPage.verify_DIM_CIF_Model_Portfolio_Is_Not_default_Investment();
		enrollmentPage.clickEnrollment_Button_Till_ConfiramtionPage();
		enrollmentPage.verifyMyInvestementConfirmationPage();
		 new HomePage().logout();
	
	} catch (Exception e) {
	 
		handleFailure(e);
	}
  	catch (Error ae){
	handleError(ae);
}
	}
	
	
	/**
	 *  
	 * 
	 */
	

	@Test(dataProvider = "setData")
	public void   DDTC_29773_TC019_Investment_DIFM_Enroll_In_Manage_Account_For_financial_Engines_Single_Plan(int itr,
			Map<String, String> testdata) {
	try{

		initializeReportForTC(itr);	
		myInvestmentPage = new MyInvestmentPage();
		myInvestmentPage.get();
		myInvestmentPage.Verify_DIFM_Enroll_In_Manage_Account_For_financial_Engines();	
		new HomePage().logout();
		
	} catch (Exception e) {
	 
		handleFailure(e);
	}
  	catch (Error ae){
	handleError(ae);
}
	}
	
	
	@Test(dataProvider = "setData")
	public void   DDTC_29779_TC020_Investment_DIFM_Enroll_In_Manage_Account_For_financial_Engines_Single_Plan(int itr,
			Map<String, String> testdata) {
	try{

		initializeReportForTC(itr);	
		myInvestmentPage = new MyInvestmentPage();	
		myInvestmentPage.get();
		myInvestmentPage.Verify_DIFM_Enroll_In_Manage_Account_For_financial_Engines();	
		 new HomePage().logout();
	
	} catch (Exception e) {
	 
		handleFailure(e);
	}
  	catch (Error ae){
	handleError(ae);
}
	}
	
	/**
	 * Verify LIAT DIFM Enroll In manage Account
	 * @param itr
	 * @param testdata
	 * DDTC-29774QA - LIAT flow - FE express enrollment  -Single plan
	 * DDTC-29780QA - LIAT flow - FE express enrollment  -Single plan
	 */
	
	@Test(dataProvider = "setData")
	public void   DDTC_29780_29774_TC021_Investment_LIAT_DIFM_Enroll_In_Manage_Account_For_financial_Engines_Single_Plan(int itr,
			Map<String, String> testdata) {
	try{
		initializeReportForTC(itr);	
		myInvestmentPage = new MyInvestmentPage();
		homePage = new HomePage();
		homePage.get();		
		homePage.selectInvestmentOptionInLIAT_Page("Plan savings",InvestmentOption.HMDI,MyInvestmentPage.PREVIOUS_PICKER_VALUE);
		myInvestmentPage.Verify_LIAT_DIFM_Enroll_In_Manage_Account_For_financial_Engines();	
		 new HomePage().logout();		
	} catch (Exception e) {
	 
		handleFailure(e);
	}
  	catch (Error ae){
	handleError(ae);
}
	}
	
	
	/**
	 *DDTC-29770QA - Allocation overview - Morning star express enrollment -only one plan
	 */
	@Test(dataProvider = "setData")
	public void   DDTC_29770_29772_TC022_Investment_DIFM_Enroll_In_Manage_Account_For_Moring_Star_Single_Plan(int itr,
			Map<String, String> testdata) {
	try{
		initializeReportForTC(itr);	
		homePage = new HomePage();
		homePage.get();		
		homePage.selectInvestmentOptionInLIAT_Page("Plan savings",InvestmentOption.DIFM,MyInvestmentPage.PREVIOUS_PICKER_VALUE);
		myInvestmentPage.Verify_LIAT_DIFM_Enroll_In_Manage_Account_Service_for_MoringStar();
		Common.clickBackArrow();
		myInvestmentPage = new MyInvestmentPage();
		myInvestmentPage.get();
		myInvestmentPage.Verify_DIFM_Enroll_In_Manage_Account_For_MorningStar();	
	
		new HomePage().logout();
		
	} catch (Exception e) {
	 
		handleFailure(e);
	}
  	catch (Error ae){
	handleError(ae);
}
	}
	

	
	/**
	 *DDTC-29769 QA - Allocation overview - Morning star express enrollment -Multiple plan
	 *DDTC-29771 QA - LIAT - Morning star express enrollment  -Multiple plan
	 *
	 */
	@Test(dataProvider = "setData")
	public void   DDTC_29769_29771_TC024_Investment_DIFM_Enroll_In_Manage_Account_For_Moring_Star_Multiple_Plan(int itr,
			Map<String, String> testdata) {
	try{
		initializeReportForTC(itr);	
		myInvestmentPage = new MyInvestmentPage();
		myInvestmentPage.get();
		myInvestmentPage.Verify_DIFM_Enroll_In_Manage_Account_For_MorningStar();
		Common.clickBackArrow();
		homePage = new HomePage();
		homePage.get();		
		homePage.selectInvestmentOptionInLIAT_Page("Plan savings",InvestmentOption.DIFM,MyInvestmentPage.PREVIOUS_PICKER_VALUE);
		myInvestmentPage.Verify_LIAT_DIFM_Enroll_In_Manage_Account_Service_for_MoringStar();
		myInvestmentPage.verifyConfirmationForMoringStar();
	} catch (Exception e) {
	 
		handleFailure(e);
	}
  	catch (Error ae){
	handleError(ae);
}
	}
	
	
	/**
	 * DDTC-29776 QA - Allocation overview -Rebalancer flow- Morning star express enrollment -only one plan
	 * 
	 */
	
	@Test(dataProvider = "setData")
	public void   DDTC_29776_TC025_Investment_Rebalancer_DIFM_Enroll_In_Manage_Account_For_Moring_Star_Single_Plan(int itr,
			Map<String, String> testdata) {
	try{
		initializeReportForTC(itr);	
		myInvestmentPage = new MyInvestmentPage();
		myInvestmentPage.get();
		myInvestmentPage.Verify_DIFM_Enroll_In_Manage_Account_For_MorningStar();	
	} catch (Exception e) {
	 
		handleFailure(e);
	}
  	catch (Error ae){
	handleError(ae);
}
	}
	
	/**
	 * DDTC-29775QA - Allocation overview _Rebalancer flow - Morning star express enrollment -Multiple plan
	 * 
	 */
	
	@Test(dataProvider = "setData")
	public void   DDTC_29775_TC026_Investment_Rebalancer_DIFM_Enroll_In_Manage_Account_For_Moring_Star_Multiple_Plan(int itr,
			Map<String, String> testdata) {
	try{
		initializeReportForTC(itr);	
		myInvestmentPage = new MyInvestmentPage();
		myInvestmentPage.get();
		myInvestmentPage.Verify_DIFM_Enroll_In_Manage_Account_For_MorningStar();	
	} catch (Exception e) {
	 
		handleFailure(e);
	}
  	catch (Error ae){
	handleError(ae);
}
	}
	
	
	

	
	/**
	 * DDTC_27482_Rebal_And_Sync_Allocation_HMDI_Target_Date_Offer_All_Mntype
	 * Description
	 * HMDI -> Targtet Date Funds
	 *  Rebalance my investments radio button-> Also direct future this way -> continue -> Select Target Date Funds button
	 *  PPT able to do Full Rebal once and Sync allocations with Target date funds and a pending transfer is created
	 * 
	 */
	@Test(dataProvider = "setData")
	public void   DDTC_27482_TC028_Rebal_And_Sync_Allocation_HMDI_Target_Date_Offer_All_Mntype(int itr,
			Map<String, String> testdata) {
	try{
		initializeReportForTC(itr);	
		DeferralsPage.setApplePlan(true);
		myInvestmentPage = new MyInvestmentPage();
		myInvestmentPage.get();
		String sMoneyTypeGroupingValue = UserBaseTest.getParaValue("moneyTypeGrouping");	
		
		sMoneyTypeGroupingValue= myInvestmentPage.clickChangeMyInvestmentButton(sMoneyTypeGroupingValue,MyInvestmentPage.PREVIOUS_PICKER_VALUE);
	
		myInvestmentPage.verify_Rebal_And_Sync_Allocation_Target_Date_Offer_With_MTGType_Options(InvestmentOption.HMDI,sMoneyTypeGroupingValue);
	
			
	} catch (Exception e) {
	 
		handleFailure(e);
	}
  	catch (Error ae){
	handleError(ae);
}
	}
	
	
	
	
	/*
	 * 
	 */
	
	@Test(dataProvider = "setData")
	public void   DDTC_27483_TC029_Rebal_And_Sync_Allocation_HMDI_Target_Date_Offer_No_Mntype(int itr,
			Map<String, String> testdata) {
	try{
		initializeReportForTC(itr);	
		myInvestmentPage = new MyInvestmentPage();
		myInvestmentPage.get();
		String sMoneyTypeGroupingValue = UserBaseTest.getParaValue("moneyTypeGrouping");
		sMoneyTypeGroupingValue = myInvestmentPage.clickChangeMyInvestmentButton(sMoneyTypeGroupingValue,MyInvestmentPage.NEXT_PICKER_VALUE);
	   //Step 8- 15
		myInvestmentPage.verify_Rebal_And_Sync_Allocation_Target_Date_Offer_With_MTGType_Options(InvestmentOption.HMDI,sMoneyTypeGroupingValue);
				
		
		
	} catch (Exception e) {
	 
		handleFailure(e);
	}
  	catch (Error ae){
	handleError(ae);
}
	}
	
	
	
	/*
	 * 
	 */
	
	@Test(dataProvider = "setData")
	public void   DDTC_27484_TC30_Rebal_And_Sync_Allocation_HMDI_Target_Date_DoesNotOffer_All_Mntype(int itr,
			Map<String, String> testdata) {
	try{
		initializeReportForTC(itr);	
		myInvestmentPage = new MyInvestmentPage();
		myInvestmentPage.get();
		String sMoneyTypeGroupingValue = UserBaseTest.getParaValue("moneyTypeGrouping");
		sMoneyTypeGroupingValue =myInvestmentPage.clickChangeMyInvestmentButton(sMoneyTypeGroupingValue,MyInvestmentPage.NEXT_PICKER_VALUE);	
	
		//Step 8- 15
		myInvestmentPage.verify_Rebal_And_Sync_Allocation_Target_Date_Offer_With_MTGType_Options(InvestmentOption.HMDI,sMoneyTypeGroupingValue);
				
	
		
	} catch (Exception e) {
	 
		handleFailure(e);
	}
  	catch (Error ae){
	handleError(ae);
}
	}

	
	
	/**
	 * DDTC_27771_Rebal_Sync_HMDI_RiskBased_Offer_All_Mntype
	 */
	
	@Test(dataProvider = "setData")
	public void   DDTC_27473_TC031_Rebal_Sync_HMDI_RiskBased_Offer_All_Mntype(int itr,
			Map<String, String> testdata) {
	try{
		initializeReportForTC(itr);	
		myInvestmentPage = new MyInvestmentPage();
		myInvestmentPage.get();
		String sMoneyTypeGroupingValue = UserBaseTest.getParaValue("moneyTypeGrouping");
		sMoneyTypeGroupingValue =myInvestmentPage.clickChangeMyInvestmentButton(sMoneyTypeGroupingValue,MyInvestmentPage.NEXT_PICKER_VALUE);
		Mobile.verifyElementPresent("Money Type Grouping should be displayed", sMoneyTypeGroupingValue, sMoneyTypeGroupingValue);
		myInvestmentPage.verify_Rebal_Sync_RiskBased_Offer_MTGTypes(InvestmentOption.HMDI,sMoneyTypeGroupingValue);
			
	
	} catch (Exception e) {
	 
		handleFailure(e);
	}
  	catch (Error ae){
	handleError(ae);
}
	}
	
	
	

	
	/**
	 * 
	 * DDTC_29177_

	 * 
	 */

	@Test(dataProvider = "setData")
	public void   DDTC_27474_TC32_Rebal_Sync_HMDI_RiskBased_DoesNotOffer_All_Mntype(int itr,
			Map<String, String> testdata) {
	try{
		initializeReportForTC(itr);	
		myInvestmentPage = new MyInvestmentPage();
		myInvestmentPage.get();
		String sMoneyTypeGroupingValue = UserBaseTest.getParaValue("moneyTypeGrouping");
		sMoneyTypeGroupingValue =myInvestmentPage.clickChangeMyInvestmentButton(sMoneyTypeGroupingValue,MyInvestmentPage.NEXT_PICKER_VALUE);
		
		myInvestmentPage.selectRebalanceOption(sMoneyTypeGroupingValue);
		
		Common.verifyPageIsDisplayed("Change my Investement Page should be display.", myInvestmentPage.CHANGE_INVESTEMENT_TITLE);
		
		myInvestmentPage.selectInvestmentOption(InvestmentOption.HMDI);    			
		myInvestmentPage.selectFundType(fundAllocationType.CHOOSE_A_RISK_BASED_FUND);	
	
		
		//Step 9
		Common.verifyPageIsDisplayed("Tap \"CHOOSE RISK BASED FUND\" Button and  Participant should  navigate to rebalancer investment page.", myInvestmentPage.rebalanceInvestmentsPageTitle);
		Common.clickBackArrow();	
		Common.verifyPageIsDisplayed("Tap Back Arrow button and Participant should  navigate to allocation option page.", myInvestmentPage.CHANGE_INVESTEMENT_TITLE);
		 
		myInvestmentPage.selectFundType(fundAllocationType.CHOOSE_A_RISK_BASED_FUND);				
		
		myInvestmentPage.addInvestement();		
	
		String sExpFunds = "Risk based fund 100% " + myInvestmentPage.sFundSelected;
		
		// Step Verify Review Your Change Page
		myInvestmentPage.clickButton(buttonName.CONTINUE);
		Common.verifyPageIsDisplayed("Participant should  navigate to Review Change page.", myInvestmentPage.REVIEW_CHANGE_TITLE);
	
		//Step 13
		Common.clickBackArrow();
		Common.verifyPageIsDisplayed("Tap Back Arrow and Participant should  navigate to rebalancer investment page.", myInvestmentPage.rebalanceInvestmentsPageTitle);
		
		myInvestmentPage.clickButton(buttonName.CONTINUE);
		
				
		//Verify Review Page
		myInvestmentPage.verify_Review_Your_change_Page(sExpFunds);
		
		// Step 15 Verify Confiramtion Page
		myInvestmentPage.verifyConfirmationPage(myInvestmentPage.investment_From_Option, sExpFunds);		
		
		//myInvestmentPage.verify_Rebal_Sync_RiskBased_Offer_MTGTypes(InvestmentOption.HMDI,sMoneyTypeGroupingValue);
	  	myInvestmentPage.verify_Pending_Transfer_OnFile_Alert_Msg(sMoneyTypeGroupingValue);
			
	} catch (Exception e) {
	 
		handleFailure(e);
	}
  	catch (Error ae){
	handleError(ae);
}
	}
	
	
	/**
	 * DDTC_27472_TC33_Rebal_Sync_HMDI_RiskBased_Offer_No_Mntype
	 * DDTC_27771
	 * Description
	 * HMDI -> Risk Based Funds
	 *  Rebalance my investments radio button-> Also direct future this way -> continue -> Select Target Date Funds button
	 *  PPT able to do Full Rebal once and Sync allocations with Target date funds and a pending transfer is created
	 * 
	 */

	@Test(dataProvider = "setData")
	public void   DDTC_27767_27472_TC33_LIAT_With_UnRestricted_Funds_RiskBased_Offer_No_Mntype(int itr,
			Map<String, String> testdata) {
	try{
		initializeReportForTC(itr);	
		myInvestmentPage = new MyInvestmentPage();
		homePage = new HomePage();	
		homePage.get();
		homePage.selectInvestmentOptionInLIAT_Page("Plan savings", InvestmentOption.DIM, MyInvestmentPage.NEXT_PICKER_VALUE);
		
		Common.verifyPageIsDisplayed("Change my Investement Page should be display.", myInvestmentPage.CHANGE_INVESTEMENT_TITLE);	
			
  	
	  	myInvestmentPage.selectInvestmentOption(MyInvestmentPage.InvestmentOption.HMDI);  
	  	myInvestmentPage.selectFundType(fundAllocationType.CHOOSE_A_RISK_BASED_FUND);	
	  	
	  	Mobile.verifyElementPresent("Tap \"CHOOSE A RISK BASE FUND\" Button ", myInvestmentPage.CHANGE_INVESTEMENT_TITLE,myInvestmentPage.CHANGE_INVESTEMENT_TITLE);
		Mobile.verifyElementPresent("Future Allocation Fund should be display", myInvestmentPage.Smart_Restriction_Future_Current_Allcation_Msg, myInvestmentPage.Smart_Restriction_Future_Current_Allcation_Msg);
		
		myInvestmentPage.addInvestement();		
	
		Mobile.verifyElementPresent("Select fund","Select a Risk based fund", "Investement Fund selected : \n"
						+ MyInvestmentPage.sFundSelected);	
		
	
		String sExpFunds = "Risk based fund 100% " + MyInvestmentPage.sFundSelected;

		// Step 12		
		myInvestmentPage.clickButton(buttonName.CONTINUE);
		Common.waitForProgressBar();
		
		Common.verifyPageIsDisplayed("Participant should  navigate to Review Change page.", myInvestmentPage.REVIEW_CHANGE_TITLE);
		
		
		//Step 14
		myInvestmentPage.verify_Review_Your_change_Page(sExpFunds);
		// Step 15
		MyInvestmentPage.isSmartRestriction = true;
		myInvestmentPage.verifyConfirmationPage(myInvestmentPage.investment_From_Option, myInvestmentPage.investment_To_Option);
	  		
		myInvestmentPage.get();
		String sMoneyTypeGroupingValue = UserBaseTest.getParaValue("moneyTypeGrouping");
	  	myInvestmentPage.verify_Pending_Transfer_OnFile_Alert_Msg(sMoneyTypeGroupingValue);
		
		
	} catch (Exception e) {
	 
		handleFailure(e);
	}
  	catch (Error ae){
	handleError(ae);
}
	}
	
	
	
	

	/**
	 * DDTC_27464_TC034_Rebal_Only_HMDI_Target_Date_Offer_All_Mntype
	 * Description
	 * HMDI -> Targtet Date Funds
	 *  Rebalance my investments radio button-> Also direct future this way -> continue -> Select Target Date Funds button
	 *  PPT able to do Full Rebal once and Sync allocations with Target date funds and a pending transfer is created
	 * 
	 */
	@Test(dataProvider = "setData")
	public void   DDTC_27464_27766_27770_TC034_Rebal_Only_HMDI_Target_Date_Offer_All_Mntype(int itr,
			Map<String, String> testdata) {
	try{
		initializeReportForTC(itr);				
		myInvestmentPage = new MyInvestmentPage();
		homePage = new HomePage();
		myInvestmentPage.get();
		String sMoneyTypeGroupingValue = UserBaseTest.getParaValue("moneyTypeGrouping");	
		
		sMoneyTypeGroupingValue = myInvestmentPage.clickChangeMyInvestmentButton(sMoneyTypeGroupingValue,MyInvestmentPage.PREVIOUS_PICKER_VALUE);
	
		myInvestmentPage.verify_Rebal_And_Sync_Allocation_Target_Date_Offer_With_MTGType_Options(InvestmentOption.HMDI,sMoneyTypeGroupingValue);
			
		myInvestmentPage.verify_Pending_Transfer_OnFile_Alert_Msg(UserBaseTest.getParaValue("moneyTypeGrouping"));
	
		HomePage.selectMenuOption("BACK","RETIREMENT INCOME");
		
		homePage.selectInvestmentOptionInLIAT_Page("Plan savings", InvestmentOption.HMDI, MyInvestmentPage.PREVIOUS_PICKER_VALUE);
		myInvestmentPage.selectInvestmentOption(InvestmentOption.HMDI);  
		myInvestmentPage.selectFundType(fundAllocationType.CHOOSE_A_TARGET_DATE_FUND);	
		Mobile.verifyElementNotPresent("Tap \"CHOOSE A TARGET DATA FUND\" Button and  Participant should not  navigate to rebalancer investment page", myInvestmentPage.rebalanceInvestmentsPageTitle, myInvestmentPage.rebalanceInvestmentsPageTitle);
		Mobile.verifyElementPresent("Future Allocation Fund should be display", myInvestmentPage.Smart_Restriction_Future_Allocation_Only_Msg, myInvestmentPage.Smart_Restriction_Future_Allocation_Only_Msg);
		
		myInvestmentPage.addInvestement();		
		String sExpText2 = "Target Date fund 100% " + MyInvestmentPage.sFundSelected;

		// Step 12		
		myInvestmentPage.clickButton(buttonName.CONTINUE);
		
		Common.verifyPageIsDisplayed("Participant should  navigate to Review Change page.", myInvestmentPage.REVIEW_CHANGE_TITLE);
		
		myInvestmentPage.clickButton(buttonName.CONTINUE);
		//Step 14
		myInvestmentPage.verify_Review_Your_change_Page(sExpText2);
		// Step 15
		MyInvestmentPage.isSmartRestriction = true;
		myInvestmentPage.verifyConfirmationPage(myInvestmentPage.investment_From_Option, myInvestmentPage.investment_To_Option);
	
		
		
			
	} catch (Exception e) {
	 
		handleFailure(e);
	}
  	catch (Error ae){
	handleError(ae);
}
	}
	
	

	
	
	
	/**
	 * 
	 * DDTC_27470_TC035_Rebal_Only_HMDI_Target_Date_DoesNotOffer_All_Mntype
	 * 
	 * Form LIAT Page verify warning messags for NOn ALL MTG 
	 * HMDI -> Target Date 
	 *  Rebalance my investments radio button -> NO MTG/MTG/Not allMTG  	
	 *    Without Also direct future this way -> continue -> Select Target Date Funds button
	 *    
	 *    
	 * 
	 */
	
	@Test(dataProvider = "setData")
	public void   DDTC_27470_27763_TC035_LIAT_Smart_Restriction_Target_Date_Not_All_Mntype(int itr,
			Map<String, String> testdata) {
	try{
		initializeReportForTC(itr);	
		homePage = new HomePage();
		homePage.get();
		homePage.verify_Unable_To_Complete_Transaction_Message();
		
		myInvestmentPage = new MyInvestmentPage();
		myInvestmentPage.get();
		String sMoneyTypeGroupingValue = UserBaseTest.getParaValue("moneyTypeGrouping");
		sMoneyTypeGroupingValue =myInvestmentPage.clickChangeMyInvestmentButton(sMoneyTypeGroupingValue,MyInvestmentPage.NEXT_PICKER_VALUE);	
	
		//Step 8- 15
		myInvestmentPage.verify_Rebal_And_Sync_Allocation_Target_Date_Offer_With_MTGType_Options(InvestmentOption.HMDI,sMoneyTypeGroupingValue);
				
	
		
	} catch (Exception e) {
	 
		handleFailure(e);
	}
  	catch (Error ae){
	handleError(ae);
}
	}
	
	
	
	/**
	 * 
	 * DDTC_27469_TC036_Rebal_Only_HMDI_Target_Date_Offer_No_Mntype
	 * HMDI -> Target Date 
	 *  Rebalance my investments radio button -> NO MTG/MTG/Not allMTG  	
	 *    Without Also direct future this way -> continue -> Select Target Date Funds button
	 * 
	 */
	@Test(dataProvider = "setData")
	public void  DDTC_27469_TC036_Rebal_Only_HMDI_Target_Date_Offer_No_Mntype(int itr,
			Map<String, String> testdata) {
	try{
		initializeReportForTC(itr);	
		myInvestmentPage = new MyInvestmentPage();
		myInvestmentPage.get();
		String sMoneyTypeGroupingValue = UserBaseTest.getParaValue("moneyTypeGrouping");
		sMoneyTypeGroupingValue = myInvestmentPage.clickChangeMyInvestmentButton(sMoneyTypeGroupingValue,MyInvestmentPage.NEXT_PICKER_VALUE);
		//Step 8- 15
		myInvestmentPage.verify_Rebal_And_Sync_Allocation_Target_Date_Offer_With_MTGType_Options(InvestmentOption.HMDI,sMoneyTypeGroupingValue);
				
		
		
	} catch (Exception e) {
	 
		handleFailure(e);
	}
  	catch (Error ae){
	handleError(ae);
}
	}

	
	/**
	 * 
	 * DDTC_27454_TC038_Rebal_Only_HMDI_RiskBased_DoesNotOffer_All_Mntype
	 * HMDI -> Risk Based
	 *  Rebalance my investments radio button -> NO MTG/MTG/Not allMTG  	
	 *    Without Also direct future this way -> continue -> Select Target Date Funds button
	 * 
	 */
	
	@Test(dataProvider = "setData")
	public void   DDTC_27466_TC037_Rebal_Only_HMDI_RiskBased_Offer_All_Mntype(int itr,
			Map<String, String> testdata) {
	try{
		initializeReportForTC(itr);	
		myInvestmentPage = new MyInvestmentPage();
		myInvestmentPage.get();
		String sMoneyTypeGroupingValue = UserBaseTest.getParaValue("moneyTypeGrouping");
		sMoneyTypeGroupingValue =myInvestmentPage.clickChangeMyInvestmentButton(sMoneyTypeGroupingValue,MyInvestmentPage.NEXT_PICKER_VALUE);
	
		myInvestmentPage.verify_Rebal_Sync_RiskBased_Offer_MTGTypes(InvestmentOption.HMDI,sMoneyTypeGroupingValue);
			
	
	} catch (Exception e) {
	 
		handleFailure(e);
	}
  	catch (Error ae){
	handleError(ae);
}
	}
	
	
	

	
	/**
	 * 
	 * DDTC_27454_TC038_Rebal_Only_HMDI_RiskBased_DoesNotOffer_All_Mntype
	 * HMDI -> Risk Based
	 *  Rebalance my investments radio button -> NO MTG/MTG/Not allMTG  	
	 *    Without Also direct future this way -> continue -> Select Target Date Funds button
	 * 
	 */
	@Test(dataProvider = "setData")
	public void   DDTC_27454_TC038_Rebal_Only_HMDI_RiskBased_DoesNotOffer_All_Mntype(int itr,
			Map<String, String> testdata) {
	try{
		initializeReportForTC(itr);	
		myInvestmentPage = new MyInvestmentPage();
		myInvestmentPage.get();
		String sMoneyTypeGroupingValue = UserBaseTest.getParaValue("moneyTypeGrouping");
		sMoneyTypeGroupingValue =myInvestmentPage.clickChangeMyInvestmentButton(sMoneyTypeGroupingValue,MyInvestmentPage.NEXT_PICKER_VALUE);
		myInvestmentPage.verify_Rebal_Sync_RiskBased_Offer_MTGTypes(InvestmentOption.HMDI,sMoneyTypeGroupingValue);
	  			
	} catch (Exception e) {
	 
		handleFailure(e);
	}
  	catch (Error ae){
	handleError(ae);
}
	}
	
	
	/**
	 * 
	 * DDTC_27462_TC039_Rebal_Only_HMDI_RiskBased_Offer_No_Mntype
	 * HMDI -> Risk Based
	 *  Rebalance my investments radio button -> NO MTG/MTG/Not allMTG  	 *  
 -> Without Also direct future this way -> continue -> Select Target Date Funds button

	 * 
	 */

	@Test(dataProvider = "setData")
	public void   DDTC_27462_TC039_Rebal_Only_HMDI_RiskBased_Offer_No_Mntype(int itr,
			Map<String, String> testdata) {
	try{
		initializeReportForTC(itr);	
		HomePage.setMultiplePlan(true, "DSHUG EHTH GONMSHGGU' FGHGSSGF ESONGOUCTHSO NMCO");	
		myInvestmentPage = new MyInvestmentPage();
		myInvestmentPage.get();
		String sMoneyTypeGroupingValue = UserBaseTest.getParaValue("moneyTypeGrouping");
		sMoneyTypeGroupingValue =myInvestmentPage.clickChangeMyInvestmentButton(sMoneyTypeGroupingValue,MyInvestmentPage.NEXT_PICKER_VALUE);
	    myInvestmentPage.verify_Rebal_Sync_RiskBased_Offer_MTGTypes(InvestmentOption.PATH1,sMoneyTypeGroupingValue);
		
	} catch (Exception e) {
	 
		handleFailure(e);
	}
  	catch (Error ae){
	handleError(ae);
}
	}
	

	
	/**
	 * 
	 * DDTC_27457_Rebal_Only_Allocation_DIM_Choose_Individual_Funds_Offer_All_Mntype
	 * HMDI -> Risk Based
	 *  Rebalance my investments radio button -> NO MTG/MTG/Not allMTG  	
	 *    
     Without Also direct future this way -> continue -> Select Target Date Funds button

	 * 
	 */

	@Test(dataProvider = "setData")
	public void   DDTC_27457_TC040_Rebal_Only_Allocation_DIM_Choose_Individual_Funds_Offer_All_Mntype(int itr,
			Map<String, String> testdata) {
	try{
		initializeReportForTC(itr);			
		myInvestmentPage = new MyInvestmentPage();
		myInvestmentPage.get();
		String sMoneyTypeGroupingValue = UserBaseTest.getParaValue("moneyTypeGrouping");
		sMoneyTypeGroupingValue = "NA";//myInvestmentPage.clickChangeMyInvestmentButton(sMoneyTypeGroupingValue,MyInvestmentPage.NEXT_PICKER_VALUE);
	  
		if(!sMoneyTypeGroupingValue.equalsIgnoreCase("NA")){
			Mobile.verifyElementPresent("Money Type Grouping should be displayed", sMoneyTypeGroupingValue, sMoneyTypeGroupingValue);
			}
		myInvestmentPage.verify_Rebal_Sync_Choose_Individual_Offer_MTGTypes(InvestmentOption.DIM,sMoneyTypeGroupingValue);
		
	} catch (Exception e) {
	 
		handleFailure(e);
	}
  	catch (Error ae){
	handleError(ae);
}
	}
	

	/**
	 * 
	 * DDTC_31514_TC041_Rebal_Only_Allocation_DIM_Choose_Individual_Funds_DoesNotOffer_All_Mntype
	 * DIM -> Choose Individual Funds
	 *  Rebalance my investments radio button -> NO MTG/MTG/Not allMTG  	
	 *    
     Without Also direct future this way -> continue -> Select Choose Individual Funds button

	 * 
	 */

	@Test(dataProvider = "setData")
	public void   DDTC_31514_TC041_Rebal_Only_Allocation_DIM_Choose_Individual_Funds_DoesNotOffer_All_Mntype(int itr,
			Map<String, String> testdata) {
	try{
		initializeReportForTC(itr);			
		myInvestmentPage = new MyInvestmentPage();
		myInvestmentPage.get();
		String sMoneyTypeGroupingValue = UserBaseTest.getParaValue("moneyTypeGrouping");
		sMoneyTypeGroupingValue =myInvestmentPage.clickChangeMyInvestmentButton(sMoneyTypeGroupingValue,MyInvestmentPage.PREVIOUS_PICKER_VALUE);
	  
		if(!sMoneyTypeGroupingValue.equalsIgnoreCase("NA")){
			Mobile.verifyElementPresent("Money Type Grouping should be displayed", sMoneyTypeGroupingValue, sMoneyTypeGroupingValue);
			}
		myInvestmentPage.verify_Rebal_Sync_Choose_Individual_Offer_MTGTypes(InvestmentOption.DIM,sMoneyTypeGroupingValue);
		
	} catch (Exception e) {
	 
		handleFailure(e);
	}
  	catch (Error ae){
	handleError(ae);
}
	}
	/**
	 * 
	 * DDTC_31515_TC042_Rebal_Only_Allocation_DIM_Choose_Individual_Funds_Offer_No_Mntype
	 * DDTC_27765QA- Smart Restrictions - Participant with balance and No MTG & without smart restrictions on current balance funds and no pending transfer

	 * DIM -> Choose Individual Funds
	 *  Rebalance my investments radio button -> NO MTG/MTG/Not allMTG  	
	 *    
     Without Also direct future this way -> continue -> Select Choose Individual Funds button

	 * 
	 */

	@Test(dataProvider = "setData")
	public void   DDTC_31515_27765_TC042_Rebal_Only_Allocation_DIM_Choose_Individual_Funds_Offer_No_Mntype(int itr,
			Map<String, String> testdata) {
	try{
		initializeReportForTC(itr);	
		homePage = new HomePage();
		myInvestmentPage = new MyInvestmentPage();
		homePage.get();
		homePage.selectInvestmentOptionInLIAT_Page("Plan savings", InvestmentOption.HMDI, MyInvestmentPage.NEXT_PICKER_VALUE);
			
		myInvestmentPage.verify_Smart_Restriction_Withonly_UnRetsricted_Fund();
		
//	
//		String sMoneyTypeGroupingValue = UserBaseTest.getParaValue("moneyTypeGrouping");
//		sMoneyTypeGroupingValue =myInvestmentPage.clickChangeMyInvestmentButton(sMoneyTypeGroupingValue,MyInvestmentPage.PREVIOUS_PICKER_VALUE);
//	  
//		if(!sMoneyTypeGroupingValue.equalsIgnoreCase("NA")){
//			Mobile.verifyElementPresent("Money Type Grouping should be displayed", sMoneyTypeGroupingValue, sMoneyTypeGroupingValue);
//			}
//		myInvestmentPage.verify_Rebal_Sync_Choose_Individual_Offer_MTGTypes(InvestmentOption.DIM,sMoneyTypeGroupingValue);
//		
	} catch (Exception e) {
	 
		handleFailure(e);
	}
  	catch (Error ae){
	handleError(ae);
}
	}

	
	/**
	 * 
	 * DDTC_31517_TC044_Rebal_Sync_Allocation_DIM_Choose_Individual_Funds_DoesNotOffer_All_Mntype
	 * DIM -> Choose Individual Funds
	 *  Rebalance my investments radio button -> NO MTG/MTG/Not allMTG  	
	 *    
	 *  Select  Also direct future this way -> continue -> Select Choose Individual Funds button
	 * 
	 */

	@Test(dataProvider = "setData")
	public void   DDTC_31517_TC044_Rebal_Sync_Allocation_DIM_Choose_Individual_Funds_DoesNotOffer_All_Mntype(int itr,
			Map<String, String> testdata) {
	try{
		initializeReportForTC(itr);			
		myInvestmentPage = new MyInvestmentPage();
		myInvestmentPage.get();
		String sMoneyTypeGroupingValue = UserBaseTest.getParaValue("moneyTypeGrouping");
		sMoneyTypeGroupingValue =myInvestmentPage.clickChangeMyInvestmentButton(sMoneyTypeGroupingValue,MyInvestmentPage.PREVIOUS_PICKER_VALUE);
	  
		if(!sMoneyTypeGroupingValue.equalsIgnoreCase("NA")){
			Mobile.verifyElementPresent("Money Type Grouping should be displayed", sMoneyTypeGroupingValue, sMoneyTypeGroupingValue);
			}
		myInvestmentPage.verify_Rebal_Sync_Choose_Individual_Offer_MTGTypes(InvestmentOption.DIM,sMoneyTypeGroupingValue);
		
	} catch (Exception e) {
	 
		handleFailure(e);
	}
  	catch (Error ae){
	handleError(ae);
}
	}

	/**
	 * 
	 * DDTC_31518_TC045_Rebal_Sync_Allocation_DIM_Choose_Individual_Funds_Offer_No_Mntype
	 * DIM -> Choose Individual Funds
	 *  Rebalance my investments radio button -> NO MTG/MTG/Not allMTG  	
	 *    
	 *  Select  Also direct future this way -> continue -> Select Choose Individual Funds button
	 * 
	 */

	@Test(dataProvider = "setData")
	public void   DDTC_31518_TC045_Rebal_Sync_Allocation_DIM_Choose_Individual_Funds_Offer_No_Mntype(int itr,
			Map<String, String> testdata) {
	try{
		initializeReportForTC(itr);			
		myInvestmentPage = new MyInvestmentPage();
		myInvestmentPage.get();
		String sMoneyTypeGroupingValue = UserBaseTest.getParaValue("moneyTypeGrouping");
		sMoneyTypeGroupingValue =myInvestmentPage.clickChangeMyInvestmentButton(sMoneyTypeGroupingValue,MyInvestmentPage.PREVIOUS_PICKER_VALUE);
	  
		if(!sMoneyTypeGroupingValue.equalsIgnoreCase("NA")){
			Mobile.verifyElementPresent("Money Type Grouping should be displayed", sMoneyTypeGroupingValue, sMoneyTypeGroupingValue);
			}
		myInvestmentPage.verify_Rebal_Sync_Choose_Individual_Offer_MTGTypes(InvestmentOption.DIM,sMoneyTypeGroupingValue);
		
	} catch (Exception e) {
	 
		handleFailure(e);
	}
  	catch (Error ae){
	handleError(ae);
}
	}
	
	/**
	 * This test case verifies the smart restriction flows on the LIAT page.
	 *  Make sure the test data is Participant with Zero balance and All MTG
	 * @param itr
	 * @param testdata
	 * 
	 * User INV_APPLE_ZERO_ACCOUNT
	 */
	
	

	@Test(dataProvider = "setData")
	public void   DDTC_27768_TC046_Smart_Restrictions_PPT_with_Zero_balance_And_All_MTG(int itr,
			Map<String, String> testdata) {
	try{
		initializeReportForTC(itr);	
		homePage = new HomePage();
		myInvestmentPage = new MyInvestmentPage();
		homePage.get();
		homePage.selectInvestmentOptionInLIAT_Page("Plan savings", InvestmentOption.DIM, MyInvestmentPage.NEXT_PICKER_VALUE);
		
		Common.verifyPageIsDisplayed("Change my Investement Page should be display.", myInvestmentPage.CHANGE_INVESTEMENT_TITLE);
		
		Mobile.verifyElementNotPresent("Rebalance my current balance option should not be display", "Rebalance my current balance", "Rebalance my current balance");
		
		myInvestmentPage.selectInvestmentOption(InvestmentOption.DIM);  
		myInvestmentPage.selectFundType(fundAllocationType.CHOOSE_INDIVIDUAL_FUNDS);	
		
	    Mobile.verifyElementPresent("Build Your Own Portfolio contain message for Future Contribution", myInvestmentPage.Smart_Restriction_Future_Allocation_Only_Msg, myInvestmentPage.Smart_Restriction_Future_Allocation_Only_Msg);
		Common.clickBackArrow();
		Common.clickBackArrow();
		new HomePage().logout();
		
		
	} catch (Exception e) {
	 
		handleFailure(e);
	}
  	catch (Error ae){
	handleError(ae);
}
	}
	/**
	 * DDTC_27767_LIAT_Smart_Restriction_Rebalance_LandingPage_Withonly_UnRetsricted_Fund
	 * DDTC_27764 QA - Smart Restriction - Participant with balance and ALL MTG & without smart restrictions on current balance funds and no pending transfer
	 * This test case verifies the logic to show models also remains the same as used for Build your own portfolio
	 * @param itr
	 * @param testdata
	 */
	@Test(dataProvider = "setData")
	public  void DDTC_27769_27764_31516_TC47_LIAT_Smart_Restriction_Rebalance_LandingPage_Withonly_UnRetsricted_Fund(int itr,
			Map<String, String> testdata) {
	try{
		initializeReportForTC(itr);	
		homePage = new HomePage();
		myInvestmentPage = new MyInvestmentPage();
		homePage.get();
		homePage.selectInvestmentOptionInLIAT_Page("Plan savings", InvestmentOption.DIM, MyInvestmentPage.NEXT_PICKER_VALUE);
		
		Common.verifyPageIsDisplayed("Change my Investement Page should be display.", myInvestmentPage.CHANGE_INVESTEMENT_TITLE);	
			
		myInvestmentPage.verify_Smart_Restriction_Withonly_UnRetsricted_Fund(); 		
	  	myInvestmentPage.verify_Pending_Transfer_OnFile_Alert_Msg("");
	  	
	  	HomePage.selectMenuOption("BACK","RETIREMENT INCOME");		
		homePage.selectInvestmentOptionInLIAT_Page("Plan savings",  InvestmentOption.DIM, MyInvestmentPage.NEXT_PICKER_VALUE);
		myInvestmentPage.selectInvestmentOption(InvestmentOption.DIM);  
		myInvestmentPage.selectFundType(fundAllocationType.CHOOSE_INDIVIDUAL_FUNDS);	
		Mobile.verifyElementPresent("Future Allocation Fund should be display", myInvestmentPage.Smart_Restriction_Future_Allocation_Only_Msg, myInvestmentPage.Smart_Restriction_Future_Allocation_Only_Msg);
		Common.clickBackArrow();
		Common.clickBackArrow();
		
	} catch (Exception e) {
	 
		handleFailure(e);
	}
  	catch (Error ae){
	handleError(ae);
}
	}

	
	
	/**
	 * DDTC_27773_27772_TC48_LIAT_Smart_Restriction_Model_portoflio_funds
	 * This test case verifies the logic to show models also remains the same as used for future allocations.
	 * This test case verifies the logic to show models also remains the same as used for allocations in rebalance flow.
	 * @param itr
	 * @param testdata
	 */
	@Test(dataProvider = "setData")
	public  void DDTC_27773_27772_TC48_LIAT_Smart_Restriction_Model_portoflio_funds(int itr,
			Map<String, String> testdata) {
	try{
		initializeReportForTC(itr);	
		homePage = new HomePage();
		myInvestmentPage = new MyInvestmentPage();
		homePage.get();
		homePage.selectInvestmentOptionInLIAT_Page("Plan savings", InvestmentOption.DIM, MyInvestmentPage.NEXT_PICKER_VALUE);
		
		Common.verifyPageIsDisplayed("Change my Investement Page should be display.", myInvestmentPage.CHANGE_INVESTEMENT_TITLE);	
		
		myInvestmentPage.selectInvestmentOption(InvestmentOption.HMDI);  
		myInvestmentPage.selectFundType(fundAllocationType.BASED_ON_A_MODEL_PORTFOLIO);	
		Common.waitForProgressBar();
		myInvestmentPage.addInvestement();	
		myInvestmentPage.clickButton(MyInvestmentPage.buttonName.CONTINUE);
		Common.waitForProgressBar();
		Mobile.verifyElementPresent("Future Allocation Fund should be display", myInvestmentPage.FUTURE_CONTRIBUTION_MSG1, myInvestmentPage.FUTURE_CONTRIBUTION_MSG1);
		Common.clickBackArrow();
		Common.clickBackArrow();
		
	} catch (Exception e) {
	 
		handleFailure(e);
	}
  	catch (Error ae){
	handleError(ae);
}
	}
	
	
	
	
	
	
	
	
	
	
//	/*
//	 * DDTC_27774_TC028_Rebal_Sync_Allocation_DIM_Choose_Individual_Funds_Offer_All_Mntype
//	 * 
//	 * 
//	 */
//	
//	@Test(dataProvider = "setData")
//	public void   DDTC_27774_TC028_Rebal_Sync_Allocation_DIM_Choose_Individual_Funds_Offer_All_Mntype(int itr,
//			Map<String, String> testdata) {
//	try{
//		initializeReportForTC(itr);	
//		HomePage.setMultiplePlan(true, "SYMANTEC 401L PLAN");	
//		myInvestmentPage = new MyInvestmentPage();
//		myInvestmentPage.get();
//		String sMoneyTypeGroupingValue = UserBaseTest.getParaValue("moneyTypeGrouping");
//		sMoneyTypeGroupingValue =myInvestmentPage.clickChangeMyInvestmentButton(sMoneyTypeGroupingValue,MyInvestmentPage.NEXT_PICKER_VALUE);
//		Mobile.verifyElementPresent("Money Type Grouping should be displayed", sMoneyTypeGroupingValue, sMoneyTypeGroupingValue);
//		myInvestmentPage.choseInvestmentOption("Rebalance Current Balance");
//		
//		myInvestmentPage.selectFrequencyForRebalance(UserBaseTest.getParaValue("RebalFrequency"));
//		myInvestmentPage.selectFutureInvestmentCheckBox(false);
//		if(UserBaseTest.getParaValue("selectFutureInvestmentCheckBox").equalsIgnoreCase("NO")){
//			myInvestmentPage.selectFutureInvestmentCheckBox(false);
//	
//		}
//	//	myInvestmentPage.verify_Rebal_Sync_HMDI_RiskBased_Offer_All_Mntype();
//			
//	
//	} catch (Exception e) {
//	 
//		handleFailure(e);
//	}
//  	catch (Error ae){
//	handleError(ae);
//}
//	}
//	
	
	
}

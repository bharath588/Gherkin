package com.greatWest.login;

import java.lang.reflect.Method;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import lib.Reporter;
import lib.Stock;
import lib.Web;

import appium.utils.Reader;

import com.greatWest.utility.Mobile;

import org.openqa.selenium.By;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;

import appium.iOS.FigletHelper;
import appium.iOS.IOSDriverManager;

import com.aventstack.extentreports.Status;
import com.greatWest.pageObject.DeferralsPage;
import com.greatWest.pageObject.HomePage;
import com.greatWest.pageObject.LoginPage;
import com.greatWest.utility.Common;
import com.greatWest.utility.TestDataFromDB;

import core.framework.Globals;



public class UserBaseTest {
	
	
	private LinkedHashMap<Integer, Map<String, String>> testData = null;		
	private static HashMap<String, String> testDataFromDB = null;

	public String tcName;
	private static String className;
	
	private static  void getClassName(){
		 String fullClassName=	Thread.currentThread().getStackTrace()[2].getClassName();
			 className = fullClassName.substring(fullClassName.lastIndexOf('.') + 1);
	}
	
	
	
	public void prepareLoginTestData(String quesryNmae,String... queryParam) {
		try {
			testDataFromDB = TestDataFromDB.getParticipantDetails(
					quesryNmae, queryParam);
			TestDataFromDB.addUserDetailsToGlobalMap(testDataFromDB);
		} catch (SQLException e) {
			e.printStackTrace();
		}

	}
	
	@BeforeSuite
	@Parameters({"env","browser"})
	public void beforeSuiteTest(){		
		System.out.println(" Before Suite");
		 new Web().setWebDriver( IOSDriverManager.setIOSNativeCapabilities());				
	}
	
	
	@BeforeClass
	@Parameters({"env","browser"})	
	public void InitTest(@Optional("") final String env,@Optional("") final String browser) throws Exception {	   
		System.out.println("Before Class  In UserBase Class");
		System.out.println("*****TEST CASES NAME *******"+this.getClass().getSimpleName());	
		System.out.println(env);
		System.out.println(browser);
		    Reporter.initializeModule(this.getClass().getSimpleName());
		    if(Mobile.mobilePlatform){
		    	Web.getDriver().manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
		    }		    

			}
	
	@BeforeMethod
	public void setLogInUser(){
		System.out.println("****BEFORE METHOD*******");
	
		if(Reader.getConfigParam("PLAN_TYPE").equalsIgnoreCase("APPLE")){
			DeferralsPage.setApplePlan(true);		
		}else{
		DeferralsPage.setApplePlan(false);	
		}
		HomePage.setMultiplePlan(false, "");
		
		DeferralsPage.setDuplicateApplePlan(false);
		DeferralsPage.setElective_Deferral_Deleated("%", false);
		DeferralsPage.setbVerifyConfirmation(true);
		DeferralsPage.setMaximize_Me_Always(false);
		DeferralsPage.contrbution_rate = "";
		 if(Mobile.is_Element_Displayed(By.name("Close"))){
				Mobile.clickElement("Close");
			}   
			if(Mobile.is_Element_Displayed(By.name("Back"))){
				Common.clickBackArrow();
			}			 		
//    		if(Mobile.assertElementPresent(By.xpath(DeferralsPage.ALERT_MSG))){
//    			Mobile.clickElement("Exit");			
//    		}    			
    			
		}
//		
//		Mobile.reportStatus = false;
		
//	}
	
	
	@AfterMethod
	public void setUpDefault(){
		System.out.println("****After METHOD*******");	
		
//		if(Mobile.reportStatus){			
//			if(Mobile.assertElementPresent(By.name(HomePage.CLOSE_IMG))){
//				Mobile.clickElement(HomePage.CLOSE_IMG);
//			}
//			if(Mobile.assertElementPresent(By.name("Back"))){
//				Common.clickBackArrow();
//			}
//			if(!Mobile.assertElementPresent(By.name(LoginPage.inputUserName_ID))){
//			HomePage.selectMenuOption("BACK","RETIREMENT INCOME");
//			 if(Mobile.assertElementPresent(By.name("Exit"))){
//				 Mobile.clickElement("Exit");
//					HomePage.selectMenuOption("RETIREMENT INCOME");
//			 }
//			}
//		
//			
//		}
		
	}
	
	
	
	

	@DataProvider
	public Object[][] setData(Method tc) throws Exception {
		prepTestData(tc);		
		return Stock.setDataProvider(this.testData);		
		
	}

	private void prepTestData(Method testCase) throws Exception {
		this.testData = Stock.getTestData(this.getClass().getPackage()
				.getName(), testCase.getName());
		System.out.println("*********Test Name****** \n"+ testCase.getName());
	}

	public void initializeReportForTC(int itr) throws Exception{
		Reporter.initializeReportForTC(itr, Globals.GC_MANUAL_TC_NAME);
		  if(!LoginPage.getUserLogIN().equals(""))
			    if(!LoginPage.is_Same_User_Already_LogIN()){
			    	int i = 0;
			    	while(!Mobile.assertElementPresent(By.name(LoginPage.inputUserName_ID)) && i <2){
			    		System.out.println("initializeReportForTC");
					   new HomePage().logout();			
					 i++;
					}
			    }
			    

	}

	
	@AfterTest
	 protected void tearDown() throws Exception{
		 System.out.println("**********After Test**********");
		 Reporter.finalizeTCReport();
		 
	 }
	
	@AfterSuite
	 public static void cleanupSessions() {	
		int i = 0;	
		System.out.println("After Suite in User base");
		 System.out.println( "**************Closing Session****************");
	 if(Mobile.getDriver() != null && i == 0){				
			 System.out.println( "**************Closing Mobile App ****************");
		    	 Mobile.getDriver().closeApp();
		    	 Mobile.getDriver().quit();					
				i++;
//				if (Reader.getConfigParam("APPIUMSEVER").equalsIgnoreCase("PROGRAM")) 
//			     new AppiumManager().destroyAppiumNode();
				
				Mobile.figlet("Test Complete");
			
		 }
	 else {
		 System.out.println( "**************Killing Mobile Instance ****************");
			//	Web.getDriver().close();
		 Mobile.getDriver().quit();		
			FigletHelper.figlet("Test Complete");		

	 }
	}
	


	 
	 /*
	  * Return Param value for Data XML
	  */
	 public static  String  getParaValue(String key){		 
	 return lib.Stock.GetParameterValue(key);
	 }


	 protected void handleFailure(Exception e){
		 e.printStackTrace();
			Globals.exception = e;
			Throwable t = e.getCause();
			String msg = "Unable to retrive cause from exception. Click below link to see stack track.";
			if (null != t) {
				msg = t.getMessage();
			//	Mobile.reportStatus = true;
				
			}
			Reporter.logEvent(Status.FAIL, "A run time exception occured.", msg, true);
	 }
	 
	 protected void handleError(Error ae){
		    ae.printStackTrace();
	        Globals.error = ae;
	      //  Mobile.reportStatus = true;
	        Reporter.logEvent(Status.FAIL, "Assertion Error Occured","Assertion Error Occured =="+ ae.getMessage(), true);
	 }
}

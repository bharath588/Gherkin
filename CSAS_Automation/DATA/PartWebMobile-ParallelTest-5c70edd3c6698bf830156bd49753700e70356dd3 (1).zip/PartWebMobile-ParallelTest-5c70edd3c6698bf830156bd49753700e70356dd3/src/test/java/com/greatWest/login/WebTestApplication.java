package com.greatWest.login;

import java.util.Map;
import java.util.concurrent.TimeUnit;

import com.greatWest.utility.Mobile;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

public class WebTestApplication  extends UserBaseTest{
	
	//Run in terminal ios_webkit_debug_proxy -c bd4f254c81b0ca007f813a4a59f5433dce8a9446:27753 -d

	
	

	private static String url = "https://proj2.retirementpartner.com/participant/#/login?accu=Empower";


	@Test(dataProvider = "setData")
	   public void LoginToPPTWeb(int itr,
		Map<String, String> testdata) {
			try{
				initializeReportForTC(itr);

	   logInToPPTWeb();
			}
		   catch (Exception e) {
				 
				handleFailure(e);
			}
	      	catch (Error ae){
			handleError(ae);
		}
		   
	     }
	 
	   
	   public  void logInToPPTWeb() {

			// Launch ppt web app
		   Mobile.getDriver().manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);	
			Mobile.getDriver().get(url);
		
			// Dismiss pre-login bulletin
			Mobile.clickElement("(//button[@data-dismiss='modal'])[1]");
		
			
			Mobile.setEdit("usernameInput", getParaValue("userName"));
			Mobile.setEdit("passwordInput", getParaValue("passWord"));
			Mobile.clickElement("submit");
			


			// Enhance code text
			(new WebDriverWait(Mobile.getDriver(), 10))
					.until(ExpectedConditions.presenceOfElementLocated(By
							.xpath("//*[contains(text(),'Enhanced security')]")));
		
			
			Mobile.clickElement("//a[contains(text(),'Already have a code?') and @class='secondary-cta']");
			
			Mobile.setEdit("verification_codeInput", getParaValue("verificationCode"));

			Mobile.clickElement("signin");
	        if(Mobile.isElementPresent("//button[@class = 'skipBtn btn btn-link btn-cancel reset-padding']")){
	        	Mobile.clickElement("//button[@class = 'skipBtn btn btn-link btn-cancel reset-padding']");
	        }
			
	        if(Mobile.isElementPresent("//button[@class = 'btn btn-link btn-cancel btn-block ng-binding']"))
			Mobile.clickElement("//button[@class = 'btn btn-link btn-cancel btn-block ng-binding']");
			
			
			//LIAT Home page
//			(new WebDriverWait(Mobile.getDriver(), 30)).until(ExpectedConditions
//					.presenceOfElementLocated(By
//							.xpath("//div[@class = 'svg-wrap']")));
//			if (Mobile.isElementPresent("//div[@class = 'svg-wrap']")) {
//				System.out.println("LIAT home page opened successfully");
//			} else {
//				System.out.println("LIAT home page didn't open.");
//			}
		}
	   }




	



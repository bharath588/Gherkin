package com.greatWest.login;

import java.util.Map;

import lib.Reporter;

import org.testng.annotations.Test;

import com.aventstack.extentreports.Status;
import com.greatWest.pageObject.LookUpAccountPage;


public class LookUpAccountTestCases extends UserBaseTest {
	
	
	public LookUpAccountPage lookUpPage;
	
	@Test(dataProvider = "setData")
	public void TC_01_LookUp(int itr,Map<String, String> testdata) {
	try{
	initializeReportForTC(itr);
	  lookUpPage = new LookUpAccountPage();
	  lookUpPage.get();	
	  lookUpPage.enterRegisterLookUpPage();
	   Reporter.logEvent(Status.PASS,"Step 1","LookUpAccountPage  Display successfully",true);
				
		} catch (Exception e) {
		 
			handleFailure(e);
		}
      	catch (Error ae){
		handleError(ae);
	}
	}
}

package com.greatWest.accountSummary;

import java.util.Map;

import lib.Reporter;

import org.testng.annotations.Test;

import com.greatWest.login.UserBaseTest;
import com.greatWest.pageObject.AccountSummaryPage;

public class AccountSummaryTestCases extends UserBaseTest{
	AccountSummaryPage accountSummaryPage;
	
	
	/*TRS will contain only one + sign
	 * DB will contain two ++ sign
	 * 
	 * QA- Account Summary - DB /TRS Plan only with Payout status
	 */
	
	@Test(dataProvider = "setData")
	public void   PPTMOBILE_AccountSummary_001_DDTC_12347_DB_Plan_Only_With_PayOut_Status(int itr,
			Map<String, String> testdata) {
	try{
	initializeReportForTC(itr);	
	accountSummaryPage = new AccountSummaryPage();
	accountSummaryPage.get();
	accountSummaryPage.verify_DB_Plan_With_PayOutStatus();
		
	} catch (Exception e) {
		 
		handleFailure(e);
	}
  	catch (Error ae){
	handleError(ae);
}
}
	
	/*
	 * 
	 * QA- Account Summary - DB /TRS only plans
	 */
	
	@Test(dataProvider = "setData")
	public void   PPTMOBILE_AccountSummary_002_DDTC_12344_DB_Plan_Only(int itr,
			Map<String, String> testdata) throws Exception {
	try{
	initializeReportForTC(itr);	
	accountSummaryPage = new AccountSummaryPage();
	accountSummaryPage.get();
	accountSummaryPage.verifyDbTrsPlanOnly();
	
	} catch (Exception e) {
		 
		handleFailure(e);
	}
  	catch (Error ae){
	handleError(ae);
}
	finally{
		 Reporter.finalizeTCReport();
	  	}
		}
	
	/*
	 * 
	 *DDTC-12345 QA- Account Summary - DB /TRS Plan with DC plans
	 */
	
	@Test(dataProvider = "setData")
	public void   PPTMOBILE_AccountSummary_003_DDTC_12345_DB_TRS_Plan_With_DC_Plan(int itr,
			Map<String, String> testdata) throws Exception {
	try{
	initializeReportForTC(itr);	
	
	accountSummaryPage = new AccountSummaryPage();
	accountSummaryPage.get();
	accountSummaryPage.verify_DB_TRS_Plan_With_DC_Plan();
	
	} catch (Exception e) {
		 
		handleFailure(e);
	}
  	catch (Error ae){
	handleError(ae);
}finally{
	 Reporter.finalizeTCReport();
	}
}
	
	/*
	 * 
	 *DDTC-12346 QA- Account Summary - DC plans & DB /TRS Plan with Payout status
	 */
	
	@Test(dataProvider = "setData")
	public void   PPTMOBILE_AccountSummary_004_DDTC_12346_DB_TRS_Plan_With_DC_Plan_With_PayOut_Status(int itr,
			Map<String, String> testdata) throws Exception {
	try{
	initializeReportForTC(itr);	
	accountSummaryPage = new AccountSummaryPage();
	accountSummaryPage.get();
	accountSummaryPage.verify_DB_TRS_Plan_With_DC_Plan_With_PayOutStatus();
	
	} catch (Exception e) {
		 
		handleFailure(e);
	}
  	catch (Error ae){
	handleError(ae);
}finally{
	 Reporter.finalizeTCReport();
	}
}	
	/*
	 * DDTC-12348 QA- Account Summary - DB /TRS Plan Estimated benefit - Based on Accrued-Benefit_Freq
	 * This test validates that participant is able to view DB/TRS plan estimated benefit per month in account summary benefits header
	 *  section and calculation is working for Monthly, Yearly, half yearly.
	 */

	@Test(dataProvider = "setData")
	public void   PPTMOBILE_AccountSummary_005_DDTC_12348_DB_TRS_Plan_Estimated_Benefit_Based_On_Accrued_Benefit_Feq(int itr,
			Map<String, String> testdata) throws Exception {
	try{
	initializeReportForTC(itr);	
	accountSummaryPage = new AccountSummaryPage();
	accountSummaryPage.get();
	accountSummaryPage.verify_DB_TRS_Plan_Estimated_Benefit();
	
	} catch (Exception e) {
		 
		handleFailure(e);
	}
  	catch (Error ae){
	handleError(ae);
}
	finally{
		 Reporter.finalizeTCReport();
	  	}
		}

}

package com.greatWest.pageObject;

import static io.appium.java_client.pagefactory.LocatorGroupStrategy.CHAIN;
import io.appium.java_client.MobileElement;
import io.appium.java_client.ios.IOSElement;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.pagefactory.HowToUseLocators;
import io.appium.java_client.pagefactory.iOSFindBy;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import lib.DB;
import lib.Reporter;
import lib.Stock;

import org.openqa.selenium.By;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.LoadableComponent;
import org.testng.Assert;

import appium.utils.Reader;

import com.aventstack.extentreports.Status;
import com.greatWest.login.UserBaseTest;
import com.greatWest.utility.Common;
import com.greatWest.utility.Mobile;

public class MFAPage extends LoadableComponent<LoginPage>{
	private LoadableComponent<?> parent;
	
	 @iOSXCUITFindBy(className = "XCUIElementTypeTextField")
	 public MobileElement VERBIAGE;
	 
	 @iOSXCUITFindBy(className = "XCUIElementTypeSwitch")
	 public MobileElement REMINDER_SWITCH;
	 
	 @HowToUseLocators(iOSAutomation = CHAIN)
	 @iOSXCUITFindBy(className = "XCUIElementTypeCell")
	 @iOSXCUITFindBy(className = "XCUIElementTypeStaticText")
	 private List<MobileElement>  multiplePlanList;
	    
	    
	 @HowToUseLocators(iOSAutomation = CHAIN)
	 @iOSXCUITFindBy(className = "XCUIElementTypeCell")
	 @iOSXCUITFindBy(className = "XCUIElementTypeButton")
	 private List<MobileElement>  multiplePlanViewButtonList;

		
	private static String  ALREADY_CODE_LINK = "GWMAlreadyHaveCodeButton";
	
	@iOSFindBy(id ="GWMEnterCodeTextField")
	@CacheLookup
	private MobileElement inputVerificationCode;
	
	@iOSFindBy(id ="Done")
	@CacheLookup
	private MobileElement DONE_BUTTON;
	@iOSFindBy(id ="CANCEL")
	@CacheLookup
	private MobileElement butCancel;
	
	
	
	@iOSFindBy(id ="GWMConfirmCodeButton")
	@CacheLookup
	private MobileElement butSignIn;
	
	@iOSFindBy(id ="SEND CODE")
	@CacheLookup
	private MobileElement butSendCode;
	
	@iOSFindBy(id ="Continue to Legacy")
	private MobileElement butContinueToLegacy;
	
	@iOSFindBy(id ="Next Gen")
	private MobileElement butNextGen;
	
	@iOSFindBy(id ="Cancel")	
	private MobileElement butAlertCancel;
	
	@iOSFindBy(id ="Continue")	
	private MobileElement butAlertContinue;
	
	@iOSFindBy(id ="Close")
	private MobileElement butClose;
	
	@iOSXCUITFindBy(className = "XCUIElementTypeTextField")
	private List<MobileElement>  textListType;
	
	
	


	
	
  //  @iOSXCUITFindBy(iOSClassChain = "XCUIElementTypeOther/*/XCUIElementTypeStaticText")
	private MobileElement ERROR_MESSAGE_XPATH;
 
	
	
	
	/** Empty args constructor
	 * 
	 */
	public MFAPage() {
		this.parent = new LoginPage();
		PageFactory.initElements(new AppiumFieldDecorator(Mobile.getDriver()), this);
	}
	
	/**
	 * Constructor taking parent as input
	 * 
	 * @param parent
	 */
	public MFAPage(LoadableComponent<?> parent) {
		// this.driver = DriveSuite.webDriver;
		this.parent = parent;
		PageFactory.initElements(new AppiumFieldDecorator(Mobile.getDriver()), this);
	}

	
	public static String VERBIAGE_SELECT_OPTION = "//XCUIElementTypePickerWheel[1]";
	public static String AGREE_BUT ="GWMTermsOfUseAgreeButton";
	public static String SKIP_TOUR_BUT = "skip";
	public static String BUT_CANCEL = "CANCEL";
	public static String SKIP_TOUR ="iPhone-Tour-1";
	public static String ENHANCED_SECURITY ="Enhanced security";
	//public static String ERROR_MESSAGE_XPATH = "//XCUIElementTypeTextField/following-sibling::XCUIElementTypeStaticText";
	public static String TERM_OF_USE = "Terms of Use";
	public static String PRIVACY_POLICY ="privacy policy";
	public static String PRIVACY_POLICY_HEADER ="Privacy Notice";
	
	public static String CONTACT_US ="contact us";
	// ERROR MESSAGE 
	public static String ERROR_MSG_VERI_CODE_REQ_8_DIGIT = "Verification code must be 8 digits.";
	public static String ERROR_MSG_VERI_CODE_INVALID = "Invalid code entered. Please try again.";
	
	public static String DISCLOSURE  = "By electing to receive your verification code by text, you understand and agree to the Empower Retirement Messaging Agreement.";
										    
	public static String MESSAGE_AGREEMENT  ="By electing to receive your verification code by text you are opting in for a one-time alert and have expressly consented to receive a text message of your verification code from "
			+ "Empower Retirement on your mobile phone. You acknowledge, understand and agree to the privacy policy and that receipt of your text message may be delayed and that neither Empower Retirement nor your carrier is liable "
			+ "for any delays or failure to deliver. Text HELP to six nine six seven five or contact us for assistance."
			+ " Message and data rates may apply through your service carrier. Service may not be available on all carriers. "
			+ "See your carrier agreement for details.";
	
	
	public static String MESSAGE_AGREEMENT_HEADER ="Messaging Agreement";
	
	
	

	

	@Override
	protected void isLoaded() throws Error {
		// TODO Auto-generated method stub
		Assert.assertTrue(Mobile.assertElementPresent(By.name(ALREADY_CODE_LINK)),"Enhance Security Page not loaded.");
		
	}

	@Override
	protected void load() {
		try {		
		
			LoginPage login = (LoginPage) this.parent;
			this.parent.get();			
		    login.submitLogin(Reader.getUserNameParam(UserBaseTest.getParaValue("userName")),Reader.getUserNameParam("passWord"));
		} catch (Exception e) {
			e.printStackTrace();
		}
		}
	
	/**<pre> Method to submit verification code
	 * Actions performed:
	 * 	1. Enter verification code
	 * 	2. select 'remember this device' checkbox based on user input and check box availability
	 * 	3. click on 'Sign in' button</pre>
	 * 
	 * @param verificationCode
	 * @param rememberDevice
	 */
	public void submitVerificationCode(String verificationCode, boolean OptionDisplayed_rememberDevice, boolean rememberDevice) throws Exception{
		{
		try {
			
		 if(verificationCode.equalsIgnoreCase("EMAIL")){
				selectDeliveryOption("EMAIL");
				verificationCode = getVerificationCode(false);
				if (isActivationCodeGenerated(Stock
						.GetParameterValue("deliveryOption"))) {
					Reporter.logEvent(Status.PASS,
							"Verify activation code is generated",
							"Activation code is successfully generated",
							false);
				} else {
					Reporter.logEvent(Status.FAIL,
							"Verify activation code is generated",
							"Activation code is not generated", false);
				}
			}
			 else{			 
				 
				Mobile.clickElement(ALREADY_CODE_LINK);					
				enterVerificationCode(getVerificationCode(true));
				
			
			}	
			 
		
		 	 
		   Common.waitForProgressBar();	
		 	Mobile.clickElement(butSignIn);
			Common.waitTillElementNotDisplay("GWMConfirmCodeButton");
			Mobile.clickElement(butNextGen);		 
			Common.waitForProgressBar();			
			 if(Mobile.assertElementPresent(By.name("We found you!"))){
		 			MobileElement emailElement = textListType.get(0);
		 			MobileElement phoneElement = textListType.get(1);		 		
		 			Mobile.setEdit(emailElement,"testauto@gmail.com");
		 			Mobile.setEdit(phoneElement,"1234567891");
		 			Mobile.clickElement("Done");
		 			Mobile.clickElement("NEXT");
			}
			
			if(Mobile.assertElementPresent(By.name("NEXT"))){
				Mobile.scroll_Down();
				Mobile.clickElement("NEXT");
				Common.waitForProgressBar();	
			}
			
			if(Mobile.assertElementPresent(By.name(TERM_OF_USE))){
				Mobile.scroll_Down();
				Mobile.scroll_Down();
				Mobile.clickElement(AGREE_BUT);
				Common.waitForProgressBar();	
				Common.waitTillElementNotDisplay("GWMConfirmCodeButton");
				Common.waitForProgressBar();	
			    Mobile.wait(2000);
			}								
			  if(Mobile.assertElementPresent(By.name(SKIP_TOUR_BUT))){
				Mobile.clickElement(SKIP_TOUR_BUT);
				Common.waitForProgressBar();
				Mobile.clickElement(butCancel);
			}
			
		
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	}
	public static IOSElement FindElementByXpath(String sElement){
        return (IOSElement) Mobile.getDriver().findElement(By.xpath(sElement));
     }

	/** Method to select delivery Option for Verification code
	 * 
	 * @param  value to select from drop Down
	 * @return select the Option for verification code to be delivery
	 */
	
	public  void selectDeliveryOption(String option){
		
		Mobile.clickElement(VERBIAGE);		
		if(option.equalsIgnoreCase("EMAIL")){
			
			IOSElement ele = Mobile.findElementBy(By.xpath(VERBIAGE_SELECT_OPTION));
			
			
		Mobile.setValue(VERBIAGE_SELECT_OPTION, "Email: *****@ujj.bjks, 5 of 5");	
		}
		Mobile.clickElement(DONE_BUTTON);	
		
	}
	

	/** Method to click send Code Button
	 * 
	 * @param  value to select from drop Down
	 * @return  Once click will display Code send page 
	 */
	
	public  void clickSendCodeButton(){
		Mobile.clickElement(butSendCode);
		Common.waitTillElement_Is_Display(By.name("VERIFICATION CODE"));
		
	}
	
	/** Method to click send Code Button
	 * 
	 * @param  value to select from drop Down
	 * @return  Once click will display Code send page 
	 */
	
	public  void enterVerificationCode(String sValue){	
		Reporter.logEvent(Status.INFO,"Enter a value in  VERIFICATION CODE ",sValue,false);		
		Mobile.setEdit(inputVerificationCode, sValue);
		Mobile.clickElement(DONE_BUTTON);
		
	}
	
	
	/** Method to fetch and return verification/activation code
	 * 
	 * @param bGetDefaultCode - 'true' to return default code, 'false' otherwise
	 * @return Verification Code - String
	 */
	public String getVerificationCode(boolean bGetDefaultCode) {
		String verificationCode = "";
		if (bGetDefaultCode) {
			verificationCode =Stock.getConfigParam("defaultActivationCode");
		}
		else {
			// Code to fetch activation/verification code from database
			String[] sqlQuery = null;
			
			try {
				sqlQuery = Stock.getTestQuery("fetchActivationCode");
			} catch (Exception e1) {
				
				e1.printStackTrace();
			}
			if (sqlQuery.length == 0) {
				Reporter.logEvent(Status.FAIL, "Get SQL Query [fetchActivationCode]", "Query with the name [fetchActivationCode] not found in SQL_Queries sheet", false);
				return verificationCode;
			}
			
			ResultSet recSet = DB.executeQuery(sqlQuery[0], sqlQuery[1]);
			
			if (DB.getRecordSetCount(recSet) > 0) {
				try {
					recSet.first();
					verificationCode = recSet.getString("TAG_VALUE");
				} catch (SQLException e) {
					e.printStackTrace();
					Reporter.logEvent(Status.WARNING, "Get verification code from DB", "No verification code generated.", false);
				}
			}
			
			try {
				recSet.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
		return verificationCode;
	}
	/**Method to check if ActivationCode is generated. Query used from query sheet is <b>isActivationCodeGenerated</b>
	 * 
	 * @param codeDeliveryOption - TEXT ME, CALL ME, EMAIL
	 * @return <b>boolean - true</b> if code is generated after delivery option is selected. <b>false</b> otherwise 
	 */
	public boolean isActivationCodeGenerated(String codeDeliveryOption) {
		boolean isGenerated = false;
		Date dt = new Date();
		SimpleDateFormat month = new SimpleDateFormat("MM");
		SimpleDateFormat day = new SimpleDateFormat("dd");
		SimpleDateFormat dtTime = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
		String[] sqlQuery = null;
		try {
			sqlQuery = Stock.getTestQuery("isActivationCodeGenerated");
		} catch (Exception e1) {
			
			e1.printStackTrace();
		}
		ResultSet rSet = DB.executeQuery(sqlQuery[0], sqlQuery[1],
				(codeDeliveryOption.trim().equalsIgnoreCase("TEXT_ME")? "TEXT":
					(codeDeliveryOption.trim().equalsIgnoreCase("CALL_ME")? "VOICE" : "EMAIL")),
				month.format(dt), day.format(dt),dtTime.format(dt));
		
		if (DB.getRecordSetCount(rSet) == 1) {
			isGenerated = true;
		}
		
		try {
			rSet.close();
		} catch (SQLException e) {
			// Do Nothing
		}
		
		return isGenerated;
	}
	
	public void verify_MFA_Verification_Screen_Basic_Fields_and_Functionality(){
			
		Mobile.verifyElementPresent("Enter  username and Password and Submit and verify MFA page should be displayed ", MFAPage.ENHANCED_SECURITY, "Enhanced Security Page");	
	
		Reporter.logEvent(Status.INFO," Verify that under the verbiage is a field displaying one or more means of contact ","MFA delivery options TEXT ME, CALL ME, EMAIL in drop down menu with default value 'TEXT ME'",false)  ;
	    Mobile.verifyText(VERBIAGE, "text me at   * *",false);		
		
		Mobile.clickElement(ALREADY_CODE_LINK);
		Mobile.verifyElementPresent("Tap the link \"Already have a code\" and verify \"Code Sent\" screen Page should be displayed", inputVerificationCode, "Code Sent\" screen Page");		
		
		Common.clickBackArrow();
		Mobile.verifyElementPresent("Click Back Arrow ", VERBIAGE, "MFA verification code request screen is displayed");	
		
	//	Reporter.logEvent(Status.INFO,"Step 9:  Verify \"SEND CODE\" Button is displayed ","SEND CODE Button should be  display",false);
		Mobile.verifyElementPresent("\"SEND CODE\" Button is displayed", butSendCode, "SEND CODE Button");	
		
	//	Reporter.logEvent(Status.INFO,"Step 10  Click Back Arrow Button"," Login Screen is display",false);
		Common.clickBackArrow();
		Mobile.verifyElementPresent(" Click Back Arrow Button", LoginPage.inputUserName_ID, "Login Page");	

	}
	
	public void verify_Code_Sent_Screen_Negative_Code_Entered(){
	   //  Reporter.logEvent(Status.INFO,"Enter valid User name and Password "," MFA page is displayed",false);
			
		//Reporter.logEvent(Status.INFO,"Step 5: Verify that under the verbiage is a field displaying one or more means of contact ","MFA delivery options TEXT ME, CALL ME, EMAIL in drop down menu with default value 'TEXT ME'",false)  ;
	   // Reporter.logEvent(Status.INFO,"Step 6 -7:Select any of the means of contact and click Send Code Button ","Code Sent screen is displayed",false);
		//clickSendCodeButton();
		
		Mobile.clickElement(ALREADY_CODE_LINK);				
		Mobile.verifyElementPresent("Select any of the means of contact and Tap Send Code Button", inputVerificationCode, "Code Sent screen page");
		
		
	//	Reporter.logEvent(Status.INFO,"Step 8 -9 : Enter a bad code in the field with the title of VERIFICATION CODE  123 ","Verify The device will give error message of Verification Code must be 8 characters",false);
		enterVerificationCode(UserBaseTest.getParaValue("invalidVerCode1"));
		verifyErrorMessage( ERROR_MSG_VERI_CODE_REQ_8_DIGIT);
		
		//Reporter.logEvent(Status.INFO,"Step 10: Enter a bad code in the field with the title of VERIFICATION CODE ","Input :12345678 ",false);
		enterVerificationCode(UserBaseTest.getParaValue("invalidVerCode2"));
	
		Reporter.logEvent(Status.INFO,"Tap Confirm code link","The device will give error message of \"Invalid code entered. Please try again\" ",false);
		Mobile.clickElement(butSignIn);
		verifyErrorMessage(ERROR_MSG_VERI_CODE_INVALID);
		
		Reporter.logEvent(Status.INFO,"Enter empty code in  VERIFICATION CODE","",false);
		enterVerificationCode("");
		Mobile.verifyElementISDisable(butSignIn,"SIGN IN should be  disabled");
		verifyErrorMessage(ERROR_MSG_VERI_CODE_REQ_8_DIGIT);		
		
		Reporter.logEvent(Status.INFO,"Step 14 :Enter more than 8 characters in the field with the title of VERIFICATION CODE ","Unable to enter more than 8 characters in the field",false);
		enterVerificationCode(UserBaseTest.getParaValue("invalidVerCode3"));	
		Mobile.verifyText(inputVerificationCode, "one two three four five six seven eight",true);
		Common.clickBackButton();
		Common.clickBackButton();
		
	}
	
    
    public  static void verifyErrorMessage(String sExpText){
 	   
    	  Mobile.verifyElementPresent("Error Message should be displayed :\n"+sExpText, sExpText, sExpText);
 	  
    }
    
    public  void verify_Magic_Login_For_GWRS_Plan() throws InterruptedException{
    	Mobile.clickElement(ALREADY_CODE_LINK);					
    	enterVerificationCode(getVerificationCode(true));
    	Mobile.clickElement(butSignIn);    
		Common.waitForProgressBar();	
		if(Mobile.assertElementPresent(By.name(TERM_OF_USE))){
			Mobile.scroll_Down();
			Mobile.scroll_Down();
			Mobile.clickElement(AGREE_BUT);
			Common.waitForProgressBar();	
			Common.waitTillElementNotDisplay("GWMConfirmCodeButton");
			Common.waitForProgressBar();	
		    Mobile.wait(2000);
		}		
		
		
		Common.waitTillElement_Is_Display(By.name("Continue to Next Gen"));
		Reporter.logEvent(Status.INFO, "Tap Sign In Button", "Alert Message should be displayed", true);
		Mobile.verifyElementPresent("\"Continue to Next Gen\" Alert should be Present","Continue to Next Gen", "\"Continue to Next Gen\" Alert");
		String alertText = "Would you like to go to Next Gen mobile application or Legacy Web site?";
	    Mobile.verifyElementPresent("Verify message in  Alert Text",alertText, alertText);
	    Mobile.clickElement(butContinueToLegacy);
	    String alertText2= "We're working hard to update this app";	  
	    Mobile.verifyElementPresent("Tap \"Continue to Legacy\" button and verify  Alert Text message",alertText2, alertText2);
	    String test2 = "This app will soon be optimized for your plan. Until it's fully ready, tap \"Continue\" to view your plan's mobile website.";
	    Mobile.verifyElementPresent("Verify Alert message",test2, test2);
	    Mobile.clickElement(butAlertContinue);
	    Common.waitTillElementNotDisplay("GWMConfirmCodeButton");
	    Common.waitForProgressBar();		
		Common.waitTillElement_Is_Display(By.name("Close"));
	    Mobile.scroll_Down();
	    Mobile.clickElement(butClose);	    
	    Mobile.verifyElementPresent("Tap Continue button and Lagecy App should be loaded","At a Glance", "Legacy App ");
	    Mobile.scroll_UP();
	    Mobile.clickElement("Logout");
	    Common.waitForProgressBar();	
	    Mobile.verifyElementPresent("Tap Logout from Lagecy app and Login Page should be display", "GWMUsernameTextField", " Login Page");    
	    new LoginPage().submitLogin(Reader.getUserNameParam(UserBaseTest.getParaValue("userName")),Reader.getUserNameParam("passWord")); 
		Mobile.clickElement(ALREADY_CODE_LINK);					
    	enterVerificationCode(getVerificationCode(true));
    	Mobile.clickElement(butSignIn);  
     	Common.waitForProgressBar();	
    	Common.waitTillElement_Is_Display(butNextGen,30);
	   Mobile.clickElement(butNextGen);	   
	   Common.waitForProgressBar();
		Common.waitTillElementNotDisplay("GWMConfirmCodeButton");
	   Common.waitForProgressBar();
		Assert.assertTrue(new HomePage().isHomePageDisplayed(),"Home Page is not loaded");	 
    }
    
    
    public  void verify_Magic_Login_For_Putnam_Plan() throws InterruptedException{
    	Mobile.clickElement(ALREADY_CODE_LINK);					
    	enterVerificationCode(getVerificationCode(true));
    	Mobile.clickElement(butSignIn);    
		Common.waitForProgressBar();
		
		if(Mobile.assertElementPresent(By.name(TERM_OF_USE))){
			Mobile.scroll_Down();
			Mobile.scroll_Down();
			Mobile.clickElement(AGREE_BUT);
			Common.waitForProgressBar();	
			Common.waitTillElementNotDisplay("GWMConfirmCodeButton");
			Common.waitForProgressBar();	
		    Mobile.wait(2000);
		}				
		Common.waitTillElement_Is_Display(By.name("Continue to Next Gen"));
		Reporter.logEvent(Status.INFO, "Tap Sign In Button", "Alert Message should be displayed", true);
		Mobile.verifyElementPresent("\"Continue to Next Gen\" Alert should be Present","Continue to Next Gen", "\"Continue to Next Gen\" Alert");
	     Mobile.clickElement(butContinueToLegacy);
	    String alertText2= "We're working hard to update this app";	  
	    Mobile.verifyElementPresent("Tap \"Continue to Legacy\" button and verify  Alert Text message",alertText2, alertText2);
	    String test2 = "This app will soon be optimized for your plan. Until it's fully ready, tap \"Continue\" to view your plan's mobile website.";
	    Mobile.verifyElementPresent("Verify Alert message",test2, test2);
	    Mobile.clickElement(butAlertCancel);
	   	Mobile.clickElement(butSignIn);  
     	Common.waitForProgressBar();	
    	Common.waitTillElement_Is_Display(butNextGen,30);
	   Mobile.clickElement(butNextGen);	   
	   Common.waitForProgressBar();
		Common.waitTillElementNotDisplay("GWMConfirmCodeButton");
		Assert.assertTrue(new HomePage().isHomePageDisplayed(),"Home Page is not loaded");	    
    }
    
    public void verify_Magic_Login_With_Multiple_Plan(){    	
    	Mobile.clickElement(ALREADY_CODE_LINK);					
    	enterVerificationCode(getVerificationCode(true));
    	Mobile.clickElement(butSignIn);    
		Common.waitForProgressBar();	
		if(Mobile.assertElementPresent(By.name(TERM_OF_USE))){
			Mobile.scroll_Down();
			Mobile.scroll_Down();
			Mobile.clickElement(AGREE_BUT);
			Common.waitForProgressBar();	
			Common.waitTillElementNotDisplay("GWMConfirmCodeButton");
			Common.waitForProgressBar();	
		    Mobile.wait(2000);
		}	
		Reporter.logEvent(Status.INFO, "Tap Sign In Button", "Account Selection Page should be displayed", true);
		Mobile.verifyElementPresent("\"Account selection\" Page should be displayed","Account selection", "\"	Account selection\" Page");
		 String alertText2= "Your account is tied to multiple plans. Which would you like to view?";	  
		Mobile.verifyElementPresent("Account selection Page content",alertText2, alertText2);
		if(multiplePlanList != null ){		
		    if(multiplePlanList.size() >= 2 && multiplePlanList.size() == multiplePlanViewButtonList.size() )
			Reporter.logEvent(Status.PASS,"Multiple Plan should be  displayed" ,"Multiple Plan  and View button are displayed"  ,false);
		    multiplePlanViewButtonList.get(1).click();
		    Common.waitForProgressBar();
		    Mobile.wait(3000);
			Reporter.logEvent(Status.INFO, "Tap View Button ", "HomePage should be displayed with multiple Plan", true);
		    Assert.assertTrue(new HomePage().isHomePageDisplayed(),"Home Page is not loaded");		 
		    
		}else{			
		    Reporter.logEvent(Status.FAIL,"Multiple Plan should be  displayed","Multiple Plan are not displayed",false);
	    	
    }
    
    }

}







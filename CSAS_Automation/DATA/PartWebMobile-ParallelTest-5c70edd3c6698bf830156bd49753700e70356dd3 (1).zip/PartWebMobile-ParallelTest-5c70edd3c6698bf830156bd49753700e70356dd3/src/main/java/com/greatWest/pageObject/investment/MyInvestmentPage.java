package com.greatWest.pageObject.investment;

import io.appium.java_client.MobileBy;
import io.appium.java_client.MobileElement;
import io.appium.java_client.ios.IOSElement;
import io.appium.java_client.pagefactory.HowToUseLocators;
import io.appium.java_client.pagefactory.LocatorGroupStrategy;
import io.appium.java_client.pagefactory.iOSFindBy;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import static io.appium.java_client.pagefactory.LocatorGroupStrategy.ALL_POSSIBLE;
import static io.appium.java_client.pagefactory.LocatorGroupStrategy.CHAIN;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import lib.Reporter;
import lib.Stock;

import com.greatWest.utility.Mobile;

import io.appium.java_client.pagefactory.AppiumFieldDecorator;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.LoadableComponent;
import org.testng.Assert;

import com.aventstack.extentreports.Status;
import com.greatWest.login.UserBaseTest;
import com.greatWest.pageObject.DeferralsPage;
import com.greatWest.pageObject.EnrollmentPage;
import com.greatWest.pageObject.HomePage;
import com.greatWest.utility.Common;
import com.greatWest.utility.DateUtility;



public class MyInvestmentPage extends LoadableComponent<MyInvestmentPage> {

	private LoadableComponent<?> parent;

	
	public static String investment_From_Option = "";
	public static String investment_To_Option = "";
	public static String sFundSelected = "";
	public Map<String, String> mapInvestmentOptionsReviewPage = new HashMap<String, String>();
	
	public static Map<String, String> mapInvestmentOptions = new HashMap<String, String>();
	public static Map<String, String> mapCurrentInvestmentOptionsPecentage = new HashMap<String, String>();
	static Map<Integer, String> mapdeleteInvestmentOptions = new HashMap<Integer, String>();
	
	public static final  String PREVIOUS_PICKER_VALUE = "previous";
	public static final String NEXT_PICKER_VALUE = "next";
	
	 @HowToUseLocators(iOSAutomation = ALL_POSSIBLE)
	    @iOSXCUITFindBy(iOSNsPredicate = "label contains 'Delete'")
	    @iOSXCUITFindBy(className = "XCUIElementTypeButton")
		@CacheLookup
	    private MobileElement firstDeleteImageButton;
	 
	   @HowToUseLocators(iOSAutomation = ALL_POSSIBLE)
	    @iOSXCUITFindBy(iOSNsPredicate = "label contains 'Delete'")
	    @iOSXCUITFindBy(className = "XCUIElementTypeButton")
	    private MobileElement  btnRemoveInvestments;
	 
	  
	    @iOSXCUITFindBy(className = "XCUIElementTypeCell")
	    private List<MobileElement>  inpInvestmentOptionFutureAllocation;
	    
	    	    
	    @iOSFindBy(xpath =  "//XCUIElementTypeCell[1]")
	    private MobileElement  first_inpInvestmentOptionFutureAllocation;
	    
	    @HowToUseLocators(iOSAutomation = CHAIN)
	    @iOSFindBy(xpath =  "//XCUIElementTypeCell[1]")
	    @iOSXCUITFindBy(className = "XCUIElementTypeStaticText")
	    private MobileElement  first_inpInvestmentOptionFutureAllocationText;
	    
	    @HowToUseLocators(iOSAutomation = CHAIN)
	    @iOSXCUITFindBy(className = "XCUIElementTypeCell")
	    @iOSXCUITFindBy(className = "XCUIElementTypeStaticText")
	    private List<MobileElement>  inpInvestmentOptionFutureAllocationText;
	 	 
	 
	 @HowToUseLocators(iOSAutomation = ALL_POSSIBLE)
	    @iOSXCUITFindBy(iOSNsPredicate = "label contains 'DELETE'")
	    @iOSXCUITFindBy(className = "XCUIElementTypeButton")
		@CacheLookup
	    private MobileElement DELETEButton;
	 
		@iOSFindBy(accessibility = "DELETE")
		@CacheLookup
		private MobileElement butDelete;
		@iOSFindBy(accessibility = "Go to Professional Management Program")
		@CacheLookup
		private MobileElement butGo_to_Professional_Management_Program;
		
		
	 
	  @iOSXCUITFindBy(iOSNsPredicate = "label contains 'Warning'")
	  private MobileElement Asset_allocation_disclosure_Link;
	  
	private static String MY_INVESTMENTS = "My Investments";

	@iOSXCUITFindBy(iOSNsPredicate = "label BEGINSWITH 'AS OF'")
	@CacheLookup
	private MobileElement CURRENT_DATE_BUT;

	@iOSFindBy(id = "blue-down-arrow")
	@CacheLookup
	private MobileElement ARROW_DOWN;
	
	private static String ARROW_DOWN_ID="blue-down-arrow";
	
	
	@iOSFindBy(accessibility = "SHOW FILTERS")
	private MobileElement butShowFilters;
	
	@iOSFindBy(accessibility = "HIDE FILTERS")
	private MobileElement butHideFilters;
	
	@iOSFindBy(accessibility = "ASSET CLASS")
	private MobileElement labAssetClass;
	
	@iOSFindBy(accessibility = "RATE OF RETURN")
	private MobileElement labRateOfReturn;
	
	@iOSFindBy(accessibility = "GROSS EXPENSE RATIO")
	private MobileElement labGrossExpenseRatio;	

	
	

	@iOSFindBy(id = "allocations overview ellipses")
	@CacheLookup
	private MobileElement OVERVIEW_EXPAND;

	@iOSFindBy(id = "allocations overview close but")
	@CacheLookup
	private MobileElement OVERVIEW_CLOSE;
	@iOSFindBy(id = "Build Your Own Portfolio")
	@CacheLookup
	private MobileElement pageBuildYourOwnPortfolio;
	
	

	// @iOSFindBy(id ="CONTINUE")
	// @CacheLookup
	private static String CONTINUE_BUT = "CONTINUE";
	
	private static String butAdd = "ADD";

	@iOSFindBy(id = "DO IT FOR ME")
	@CacheLookup
	private MobileElement DO_IT_FOR_ME;

	@iOSFindBy(id = "HELP ME DO IT")
	@CacheLookup
	private MobileElement HELP_ME_DO_IT;
	

	@iOSFindBy(id = "WE BUILD IT")
	@CacheLookup
	private MobileElement WE_BUILD_IT;
	
	@iOSFindBy(id = "YOU BUILD IT")
	@CacheLookup
	private MobileElement YOU_BUILD_IT;
	
	@iOSFindBy(id = "PATH 1")
	@CacheLookup
	private MobileElement PATH_1;
	
	 static String PATH1= "Path_1";
	

	@iOSFindBy(id = "DO IT MYSELF")
	@CacheLookup
	private MobileElement DO_IT_MYSELF;
	
	@iOSFindBy(id = "View All Funds")
	private MobileElement VIEW_ALL_FUNDS_PAGE;
	
	

	@iOSFindBy(id = "OK")
	@CacheLookup
	private MobileElement OK_BUTTON;

	@iOSXCUITFindBy(className = "XCUIElementTypePickerWheel")
	private MobileElement PICKER_WHEEL;

	@iOSXCUITFindBy(className = "XCUIElementTypeTextView")
	private MobileElement TEXT_VIEW;
	@iOSXCUITFindBy(className = "XCUIElementTypeSwitch")
	private MobileElement switchType;
	
	
	@iOSXCUITFindBy(className = "XCUIElementTypeTextField")
	private MobileElement TEXT_FIELD;
	
	@iOSXCUITFindBy(className = "XCUIElementTypeTextField")
	private List<MobileElement> listOfTextFields;
	
	//@iOSFindBy(id = "tick-mark_gray")
	private static String  radioTick_Mark_Gray ="tick-mark_gray";

	
	
	
	@iOSFindBy(id = "Back")
	@CacheLookup
	private MobileElement butBack;
	

	@iOSFindBy(id = "Done")
	private MobileElement webButDone;
	
	

	@iOSFindBy(id = "I ENROLLED IN PROFESSIONAL MANAGEMENT PROGRAM")
	private MobileElement I_ENROLLED_IN_PROFESSIONAL_MP;

	@iOSFindBy(id = "I IMPLEMENTED ONLINE ADVICE RECOMMENDATIONS")
	private MobileElement I_IMPLEMENTED_ONLINE_ADVICE;

	@iOSFindBy(id = "I DID NOT PERFORM A TRANSACTION")
	private MobileElement I_DID_NOT_PERFORM;

	@iOSFindBy(id = "Continue")
	private MobileElement CONTINUE_ALERT_BUT;

	@iOSFindBy(id = "Cancel")
	private MobileElement CANCEL_ALERT_BUT;

	@iOSFindBy(id = "Advisory Services")
	private MobileElement ADVISORY_SERVICES;

	@iOSFindBy(id = "You are now accessing Advisory Services")
	@CacheLookup
	private MobileElement ALERT_MSG;

	@iOSFindBy(id = "Allocation_ribbon")
	private MobileElement ALLOCATION_RIBBON;

	@iOSXCUITFindBy(iOSClassChain = "XCUIElementTypeButton[-1]")
	private MobileElement lastText;
	
//	@iOSFindBy(xpath = "//XCUIElementTypeStaticText[@name='Total Allocation']/preceding-sibling::XCUIElementTypeStaticText")
	private static String  txttotalInvestmentPercent = "//XCUIElementTypeStaticText[@name='Total Allocation']/preceding-sibling::XCUIElementTypeStaticText";

	
	private String CHOOSE_A_TARGET_DATE_FUND_BUT = "CHOOSE A TARGET DATE FUND";
	private String CHOOSE_A_TARGET_DATE_FUND_CONTENT = "Target Date funds provide a single diversified fund based on the approximate year you would like to retire (which is assumed to be at age 65) and/or begins withdrawing money. The principal value of the funds is not guaranteed at any time, including the target date.";

	private String TARGET_DATE_FUND_CHANGE_CONTENT = "The above shading illustrates funds associated with your date of birth on file and your anticipated retirement age as designated by you or your plan. This is for informational purposes only, is not considered investment advice, and should not be relied upon as investment advice. For more information, please refer to your plan materials. A target date fund will gradually shift its emphasis from more aggressive investments to more conservative ones based on its target date (which is the assumed retirement date for an investor). For more information, please refer to the fund prospectus and/or disclosure document.";

	private String BASED_ON_A_MODEL_PORTFOLIO_BUT = "BASED ON A MODEL PORTFOLIO ";
	private String butChoooseIndividualFund = "CHOOSE INDIVIDUAL FUNDS";

	private String ACCESS_ONLINE_ADVICE_BUT = "ACCESS ONLINE ADVICE";
	private String CHOOSE_A_RISK_BASED_FUND_BUT = "CHOOSE A RISK BASED FUND";
	private String RISK_BASED_FUND_CHANGE_CONTENT = "Risk-based funds provide a single diversified fund based on the level of risk you're willing to accept. Diversification does not ensure a profit and does not protect against loss in declining markets.";

	private String CHOOSE_A_RISK_BASED_FUND_CONTENT = "Select a diversified fund that is based on the level of risk you are willing to take.";
	//private String ACCESS_ONLINE_ADVICE_CONTENT = "Online investment advice can help you select investments that align with your retirement objectives.";
	private String ACCESS_ONLINE_ADVICE_CONTENT = "Online Advice can help you select investments that align with your retirement objectives.";
	private String ENROLL_IN_PROFESSIONAL_MANAGEMENT_PROGRAM_BUT = "ENROLL IN PROFESSIONAL MANAGEMENT PROGRAM";
	private String but_Enroll_In_Managed_Account_Service = "ENROLL IN MANAGED ACCOUNT SERVICE";
	private String but_Enroll_In_Managed_Account_Service_In_LIAT = "Enroll In Managed Account service";


	private String CHANGE_MY_INVESTEMENT_BUT = "CHANGE MY INVESTMENTS";

	@iOSFindBy(id = "GO TO PROFESSIONAL MANAGEMENT PROGRAM")
	@CacheLookup
	private MobileElement GO_TO_PROFESSIONAL_BUTTON;

	@iOSFindBy(id = "GO TO MANAGED ACCOUNT SERVICE")
	private MobileElement GO_TO_MANAGED_ACCOUNTS_BUTTON;

	@iOSFindBy(id = "INVESTMENT")
	@CacheLookup
	private MobileElement INVESTMENT_BUT;

	@iOSFindBy(id = "ASSET CLASS")
	@CacheLookup
	private MobileElement ASSET_CLASS;

	@iOSFindBy(id = "Change how my future contributions will be invested")
	@CacheLookup
	private MobileElement radioChangeFutureInvestmentOption;
	
	@iOSFindBy(id = "Rebalance my current balance")
	@CacheLookup
	private MobileElement radioRebalance;
	
	@iOSFindBy(id = "Remove funds")
	@CacheLookup
	private MobileElement butRemoveFunds;
	
	@iOSFindBy(id = "Add/View all funds")
	@CacheLookup
	private MobileElement  butaddViewAllFunds;
	
	@iOSFindBy(id = "Done")
	@CacheLookup
	private MobileElement  butDone;
	
	@iOSFindBy(id = "URL")
	private MobileElement URL;
	
	@iOSFindBy(id = "Safari")
	private MobileElement SafariBrowser;
	
	@iOSFindBy(id = "Return to Empower")
	@CacheLookup
	private MobileElement butReturnToEmpower1;
	
	
	
	
	
	
	@HowToUseLocators(iOSAutomation = LocatorGroupStrategy.CHAIN)
    @iOSXCUITFindBy(className = "XCUIElementTypeOther")
    @iOSXCUITFindBy(iOSNsPredicate = "name like 'Answer'")
    private MobileElement answer;
	
	
	
	
	
	
	
	private static String butReset = "RESET";
	private static String   butReviewChange ="REVIEW CHANGES";
	private static String butSlideLock ="sliderLock";
	

	private static String CONFIRM_CHANGE_BUT = "CONFIRM CHANGE";

	private static String RETURN_TO_MY_INVESTMENTS_BUT = "RETURN TO MY INVESTMENTS";

	private static String ALLOCATION_RIBBON_BUTTON_NAME = "//*[@name='Allocation_ribbon']/following-sibling::XCUIElementTypeButton";

	private String FUTURE_ALLOCATION = "FUTURE ALLOCATION";

	private String BUTTON_TYPE = "XCUIElementTypeButton";
	private String STATIC_TEXT_FIELD = "XCUIElementTypeStaticText";
	private String STATIC_TEXT_VIEW = "XCUIElementTypeTextView";
	 

	// private String CHANGE_MY_FUTURE_RADIO_BUT
	// ="Change how my future contributions will be invested";
	private String label_Content = "Dollar-cost averaging and/or rebalancing do not ensure a profit and do not protect against loss in declining markets.";


	 
	// DO IT FOR ME
	public String CHANGE_INVESTEMENT_TITLE = "Change My Investments";
	private String ALREADY_ENROLLED_IN_MA = "You are already enrolled in Managed Account service.";
	private String ALREADY_ENROLLED_IN_MA_MSG4 = "Professional Management Program automatically matches investments to your objectives and monitors and adjusts your investment strategy as you near retirement age or you update your personal financial information.";

	
	private String ALREADY_ENROLLED_IN_PROF_MA = "You are already enrolled in Professional Management Program.";
	
	
	private String ALREADY_ENROLLED_IN_MA_MSG3 = "Managed Account service automatically matches investments to your objectives and monitors and adjusts your investment strategy as you near retirement age or you update your personal financial information.";
	public String FUTURE_CONTRIBUTION_MSG1 = "The investment allocation(s) you select here will apply to only your future contributions.";
	private String FUTURE_CONTRIBUTION_MODEL_PORTFOLIO_MSG2 = "Select a model portfolio";
	private String FUTURE_CONTRIBUTION_MODEL_PORTFOLIO_MSG3 = "Model portfolios are not, nor are they intended to be a security. You should review the prospectus and/or disclosure documents for information regarding the investments, including fees and other charges.";

	private String RADIO_OPTION = "XCUIElementTypeImage";

	// private String CONTINUE_BUT ="CONTINUE";

	private String MY_INVESTEMTN_MORING_STAR_MSG1 = "Click OK to be redirected back to the Empower website. We will update your information with the enrollment and strategy changes you made in Advisory Services.";

	private String IMPLEMENTED_CONTENT = "Your Online Advice transactions will reflect as pending until implemented.";

	private String ENROLLED_CONTENT = "Your request to enroll in Professional Management Program will be processed and your enrollment status will be reflected as soon as administratively possible.";

	private String GO_TO_PROFESSIONAL_MANAGEMENT_BUT = "GO TO PROFESSIONAL MANAGEMENT PROGRAM";

	private String FOOTER_CONTENT_FE = "Assets Group, LLC (AAG) uses Financial Engines Advisors L.L.C. (FEA) to provide sub-advisory services. AAG and FEA are federally registered investment advisers. AAG is a wholly owned subsidiary of Great-West Life & Annuity Insurance Company (GWL&A). FEA is a wholly-owned subsidiary of Financial Engines, Inc. More information can be found at www.adviserinfo.sec.gov. Financial Engines, Inc. is an independent company that is not affiliated with Empower Retirement, AAG, its parent company GWL&A, or any other affiliated companies and/or subsidiaries. Financial Engines® is a registered trademark of Financial Engines, Inc. All trademarks, logos, service marks, and design elements used are owned by their respective owners and are used by permission. © 2005-2016 Financial Engines, Inc. All rights reserved. Future results are not guaranteed by FEA, AAG or any other party. Professional Management Program and Online Advice are part of the Empower Retirement Advisory Services suite of services offered by AAG.";

//	private String DISCLOSURE_CONTENT_MORNING_STAR = "Advised Assets Group, LLC (AAG) uses Morningstar Investment Management LLC (Morningstar Investment Management) to provide sub-advisory services. AAG and Morningstar Investment Management are federally registered investment advisers. AAG is a wholly-owned subsidiary of Great-West Life & Annuity Insurance Company (GWL&A). Morningstar Investment Management is a subsidiary of Morningstar, Inc. More information can be found at www.adviserinfo.sec.gov. Morningstar Investment Management and Morningstar, Inc. are not affiliated with Empower Retirement, AAG, its parent company GWL&A, or any other affiliated companies and/or subsidiaries. The trademarks, logos, service marks, and design elements used are owned by their respective owners and are used by permission. Managed Account service and Online Investment Advice are part of the Empower Retirement Advisory Services suite of services offered by AAG.";
	//private String DISCLOSURE_CONTENT_MORNING_STAR = "Advised Assets Group, LLC (AAG) uses Morningstar Investment Management LLC (Morningstar Investment Management) to provide sub-advisory services. AAG and Morningstar Investment Management are federally registered investment advisers. AAG is a wholly-owned subsidiary of Great-West Life & Annuity Insurance Company (GWL&A). Morningstar Investment Management is a subsidiary of Morningstar, Inc. More information can be found at www.adviserinfo.sec.gov. Morningstar Investment Management and Morningstar, Inc. are not affiliated with Empower Retirement, AAG, its parent company GWL&A, or any other affiliated companies and/or subsidiaries. The trademarks, logos, service marks, and design elements used are owned by their respective owners and are used by permission. Managed Account service and Online Advice are part of the Empower Retirement suite of services offered by AAG.";

	private String DISCLOSURE_CONTENT_MORNING_STAR = "Advised Assets Group, LLC uses Morningstar Investment Management LLC to provide sub-advisory services. AAG and Morningstar Investment Management are registered investment advisers. AAG is a subsidiary of Great-West Life & Annuity Insurance Company. Morningstar Investment Management is a subsidiary of Morningstar, Inc. Morningstar Investment Management and Morningstar, Inc. are not affiliated with Empower Retirement, AAG, GWL&A, or any other affiliated companies and/or subsidiaries. Managed Account service and Online Advice are part of the Empower Retirement Advisory Services suite of services offered by AAG.";
	// private String ADVISORY_SERVICES="Advisory Services";

	// REview your Changes

	public String REVIEW_CHANGE_TITLE = "Review Your Changes";
    public String rebalanceInvestmentsPageTitle="Rebalance investments";
    public String rebalanceYourPrortfolioPageTitle="Rebalance your portfolio";
	private String FROM_TEXT = "FROM:";
	private String TO_TEXT = "TO:";	
	
	private String ENROLL_PROF_MANAGE_PROGRAM_TITLE = "Enroll in Professional Management Program";
	private String ENROLL_MANAGE_PROGRAM_TITLE = "Enroll in Managed Account service";
	private String ENROLL_PMP_REVIEW_LABEL = "Please review your personal information, and confirm your enrollment into Professional Management Program.";
	private String ENROLL_PMP_LABEL2 = "Confirm your enrollment into Professional Management Program:";
	private String ENROLL_PMP_LABEL3 = "•  You will be enrolled into Professional Management Program, and you will receive a Welcome Kit in about two weeks.  •  Enrollment into Professional Management Program may cause an allocation change or rebalance to take place on your account.  •  There is no guarantee that participating in any of the advisory services will result in a profit, that the account will outperform a self-managed portfolio or that an investor will achieve their financial goals.  •  You can cancel your enrollment anytime, for any reason, without penalty.  •  Additional fees apply to members of Professional Management Program. Program fees will be deducted directly from your retirement account, so it won't reduce your take-home pay.  •  Below are the applicable fees, which are based on your average assets under management. Fees are charged in the frequency and manner detailed in the Supplement to Professional Management Program Terms and Conditions.";
	private String ENROLL_MA_MORNING_STAR_LABEL1 ="Confirm your enrollment into Managed Account service:";
	private String ENROLL_MA_MORNING_STAR_LABEL2 ="•  You will be enrolled into Managed Account service, and you will receive a Welcome Kit in about two weeks.  •  Enrollment into Managed Account service may cause an allocation change or rebalance to take place on your account.  •  There is no guarantee that participating in any of the advisory services will result in a profit, that the account will outperform a self-managed portfolio or that an investor will achieve their financial goals.  •  You can cancel your enrollment anytime, for any reason, without penalty.  •  Additional fees apply to members of Managed Account service. Program fees will be deducted directly from your retirement account, so it won't reduce your take-home pay.  •  Below are the applicable fees, which are based on your average assets under management. Fees are charged in the frequency and manner detailed in the Advised Assets Group, LLC Advisory Services Agreement.";
	//private String ENROLL_MA_MORNING_STAR_LABEL3 = "By tapping the \"I agree, enroll now\" button, you confirm you have reviewed and agree to the Advised Assets Group, LLC Advisory Services Agreement, and you acknowledge that you have received the AAG Disclosure Brochure.";
	private String ENROLL_MA_MORNING_STAR_LABEL3 = "By tapping the \"I agree, enroll now\" button, you confirm you have reviewed and agree to the Advised Assets Group, LLC Advisory Services Agreement, and you acknowledge that you have received the AAG Disclosure Brochure and the Great-West Family of Companies Privacy Policy.";
	private String ENROLL_MORNING_STAR_REVIEW_LABEL = "Please review your personal information, and confirm your enrollment into Managed Account service.";
	
	
	private String ENROLL_PMP_LABEL4 = "By tapping the \"I agree, enroll now\" button, you confirm you have reviewed and agree to the AAG Terms and Conditions (including Supplement), "
			+ "the Methodology and Assumptions, and you acknowledge that you have received the Great-West Family of Companies Privacy Policy and AAG Disclosure Brochure.";
	
		
//	private String ENROLL_PMP_LABEL5 = "Advised Assets Group, LLC (AAG) uses Financial Engines Advisors L.L.C. (FEA) to provide sub-advisory services. "
//			+ "AAG and FEA are federally registered investment advisers. AAG is a wholly owned subsidiary of Great-West Life & Annuity Insurance Company (GWL&A)."
//			+ " FEA is a wholly-owned subsidiary of Financial Engines, Inc. More information can be found at www.adviserinfo.sec.gov. "
//			+ "Financial Engines, Inc. is an independent company that is not affiliated with Empower Retirement, AAG, its parent company GWL&A,"
//			+ " or any other affiliated companies and/or subsidiaries. Financial Engines® is a registered trademark of Financial Engines, Inc. "
//			+ "All trademarks, logos, service marks, and design elements used are owned by their respective owners and are used by permission. © 2005-2016 Financial Engines, Inc. "
//			+ "All rights reserved. Future results are not guaranteed by FEA, AAG or any other party. Professional Management Program and "
//			+ "Online Advice are part of the Empower Retirement Advisory Services suite of services offered by AAG.";
//	
	
	private String ENROLL_PMP_LABEL5 ="Advised Assets Group, LLC uses Financial Engines Advisors L.L.C. to provide sub-advisory services. AAG and FEA are registered investment advisers. AAG is a subsidiary of Great-West Life & Annuity Insurance Company. FEA is a wholly owned subsidiary of Financial Engines, Inc. Financial Engines, Inc. is an independent company that is not affiliated with Empower Retirement, AAG, GWL&A, or any other affiliated companies and/or subsidiaries. Financial Engines® is a registered trademark of Financial Engines, Inc. © 2017 Financial Engines, Inc. Empower Retirement provides plan recordkeeping and administrative services. Future results are not guaranteed by FEA, AAG or any other party. Professional Management Program and Online Advice are part of the Empower Retirement Advisory Services suite of services offered by AAG.";
	
	
	private String  Asset_Allocation_Disclosure_Link_Warning_Msg="Warning! Your plan account is currently allocated among funds associated with a model portfolio, specifically AdviseMe! C. To view other investment strategies before building your own portfolio, go back. The fund allocations below may be rounded and may not total 100%.";
	private String  With_Default_Model_Protfolio_Warning_Msg = "Warning! The investment election shown illustrates how your plan account will be allocated if you hit submit. You can modify this by selecting the Add / View all funds button. To view other investment strategies before building your own portfolio, go back. The fund allocations below may be rounded and may not total 100%.";
	private String WithOut_default_Model_Protfolio_Warning_Msg= "Warning! The investment election shown illustrates how your plan account will be allocated if you hit submit. You can modify this by selecting the Add / View all funds button. To view other investment strategies before building your own portfolio, go back.";
	
	 @iOSXCUITFindBy(iOSClassChain = "XCUIElementTypeCell/XCUIElementTypeStaticText1]")
	    private MobileElement firstAddFund;
	 @iOSXCUITFindBy(iOSClassChain = "XCUIElementTypeCell/XCUIElementTypeStaticText[1]")
	    private MobileElement secondAddFund;
	 
	public String Smart_Restriction_Future_Current_Allcation_Msg = "Changing your investment allocation will result in your future contributions being allocated to your selected investment(s). Your current account balance also will be allocated to your selected investment(s) unless such investment(s) are restricted, requiring you to separately select your current account balance investment(s).";
	
	
	String Smart_Restriction_Rebalancer_Review_Meg ="This change to your investment mix will rebalance your current unrestricted investments.";


	
	//Future Investments

	
	String Smart_Restriction_Future_Review_Meg ="This change to your investment mix will redirect your future contributions.";
	
	public String Smart_Restriction_Future_Allocation_Only_Msg = "Changing your investment allocation will result in your future contributions being allocated to your selected investment(s)";

	//The investment allocation(s) you have selected will apply to your future contributions.
	 public static Boolean isSmartRestriction = false;
	 
	 
	 
	 public enum fundAllocationType{	
	
		 CHOOSE_A_TARGET_DATE_FUND,	 
		 GO_TO_MANAGED_ACCOUNTS,
		 CHOOSE_A_RISK_BASED_FUND,
		 BASED_ON_A_MODEL_PORTFOLIO,
		 ACCESS_ONLINE_ADVICE,
		 ENROLL_IN_PROFESSIONAL_MANAGEMENT_PROGRAM,
		 CHOOSE_INDIVIDUAL_FUNDS
		 
	 }
	 
	 public enum buttonName{
		 CONTINUE,
		 SAVE,
		 ADD,
		 OK,
		 BACK_ARROW,
	 }
	 
	 public enum InvestmentOption{				
		 PATH1,	 
		 PATH2,
		 HMDI,
		 DIFM,
		 DIM,
		 WBI,
		 YBI
	 }
	 
	 
	 

	/**
	 * Empty args constructor
	 * 
	 */
	public MyInvestmentPage() {
		this.parent = new HomePage();
		PageFactory.initElements(new AppiumFieldDecorator(Mobile.getDriver()),
				this);
	}

//	/**
//	 * Constructor taking parent as input
//	 * 
//	 * @param parent
//	 */
//	public MyInvestmentPage(LoadableComponent<?> parent) {
//		// this.driver = DriveSuite.webDriver;
//		this.parent = parent;
//		PageFactory.initElements(new AppiumFieldDecorator(Mobile.getDriver()),
//				this);
//	}

	@Override
	protected void isLoaded() throws Error {

		Assert.assertTrue(Mobile.assertElementPresent(By.name(MY_INVESTMENTS)),
				"My Investment Page is not displayed");

	}

	@Override
	protected void load() {	
	
		this.parent.get();
		String allocationOverViewMenu = "ALLOCATION OVERVIEW"; 
		try {
			if (HomePage.isMultiplePlan()) {
				HomePage.selectMenuOption(HomePage.sPlanName,
						allocationOverViewMenu);
				HomePage.setMultiplePlan(false, "");

			} else if (DeferralsPage.getApplePlan()) {
				HomePage.selectMenuOption("MY ACCOUNT", "APPLE 401(K) PLAN",
						allocationOverViewMenu);
			} else {
				HomePage.selectMenuOption("MY ACCOUNT", allocationOverViewMenu);
			}
		} catch (Exception e) {
		
			e.printStackTrace();
		}
		if(Common.ifServerError()){
			Assert.fail("Investment Page is not  loaded successfully");
		}
		
		Reporter.logEvent(	Status.INFO,"Navigate to Investment Page","Investment Page is loaded successfully", false);

	}
	
	
	public MobileElement getWebElement(String fieldName) {
		
		if (fieldName.trim().equalsIgnoreCase("Rebalance Current Balance")) {
			return this.radioRebalance;
		} else if(fieldName.trim().equalsIgnoreCase("Slider")) {
			return this.TEXT_FIELD;
		}			
		return null;
	}
	
	
	
	/**
	 * <pre>
	 * Method to Click on Change My Investments Button for Particular Money Type Grouping
	 * 
	 * </pre>
	 * 
	 * @param String - moneyTypeGrouping
	 */
	public String clickChangeMyInvestmentButton(String moneyTypeGrouping,String pickerRotationOption) {
	  
		String moneyType = moneyTypeGrouping;
		 
		if(moneyTypeGrouping != null){
		try{	
		
		Reporter.logEvent(Status.INFO, "In Allocation OverView Page  and Select MoneyTypeGrouping", moneyType, false);
		if(Mobile.isElementPresent(ARROW_DOWN_ID)){
		Mobile.clickElement(ARROW_DOWN);
		Mobile.selectPickerValue(moneyTypeGrouping, pickerRotationOption);		
		}
		else if(moneyTypeGrouping.equals("All Sources")){
			moneyType= "ALL";
		}
		else{
			moneyTypeGrouping= "NA";
			moneyType = "NA";
		}
			
		}catch(NoSuchElementException e){
			moneyType = "NA";
		}
		}else{
			moneyType = "NA";
		}
		
		
		Mobile.clickElement(CHANGE_MY_INVESTEMENT_BUT);
		Common.waitForProgressBar();			
			
		return moneyType;
		
	}
	
	
	/**
	 * Method will chose Investement Option in Change my Investement Page
	 * 
	 * @param String investmentOption
	 */
	
	public void choseInvestmentOption(String investmentOption) {
		MobileElement ele = null;
		
		if(investmentOption.contains("Rebalance")){
			ele=radioRebalance;
		}
			else{
				ele=radioChangeFutureInvestmentOption;	
			}
			
			if(Mobile.is_Element_Displayed(ele)){
			Mobile.clickElement(ele);
			Reporter.logEvent(Status.PASS, investmentOption
					+ " option should be display.", investmentOption
					+ " option is displayed.", false);
			}else{
				Reporter.logEvent(Status.FAIL,  investmentOption
						+ " option should be display.", investmentOption
						+ " option not displayed.", true);			
		}
		
	}	
		
	/**
	 * <pre>
	 * Method to Select the Frequency For Rebalance
	 * 
	 * </pre>
	 * 
	 * @param String - frequencyType
	 */
	public void selectFrequencyForRebalance(String frequencyType) {
		Mobile.clickElement(ARROW_DOWN);
		Mobile.selectPickerValue(frequencyType, "next");
			
	}

	/**
	 * <pre>
	 * Method to Select/UnSelect Direct My Future Investment Check Box For Rebalance
	 * 
	 * </pre>
	 * 
	 * @param boolean - select
	 */
	public void selectFutureInvestmentCheckBox(boolean select ) {		
			Mobile.switchButton(select);		
	}
	
	/**
	 * This method will select Investment option from Change my Investment Page 
	 * @param sOption
	 */
	
	public void selectInvestmentOption(InvestmentOption sOption){
	
		 try{
		    switch (sOption) {
			case PATH1:
				   if(Mobile.is_Element_Displayed(PATH_1)){
					   Mobile.clickElement(PATH_1);
				   }
				   else{
					   if(Mobile.is_Element_Displayed(HELP_ME_DO_IT))
					   Mobile.clickElement(HELP_ME_DO_IT);	 
				   }
				 
				break;
			case HMDI:				
				  if(Mobile.is_Element_Displayed(HELP_ME_DO_IT)){
					  Mobile.clickElement(HELP_ME_DO_IT);
				  }
				   else if(WE_BUILD_IT.isDisplayed()){
					   Mobile.clickElement(WE_BUILD_IT); 
				   }
				break;
			case DIM:
				  if(Mobile.is_Element_Displayed(DO_IT_MYSELF)){
				  Mobile.clickElement(DO_IT_MYSELF);
				  }
				  else if(YOU_BUILD_IT.isDisplayed()){
					   Mobile.clickElement(YOU_BUILD_IT); 
				   }
				  
				break;
			case DIFM:
				 if(DO_IT_FOR_ME.isDisplayed())
				  Mobile.clickElement(DO_IT_FOR_ME);
				break;

			default:		
				Reporter.logEvent(Status.WARNING, "Select Investement Option is not Correct", "Please enter correct investement option", false);
				break;
			}	 
		 }catch(NoSuchElementException e){		 
		    	Reporter.logEvent( Status.FAIL," Investement Option is not display", getInvestmentOption(sOption), true);
		    	Assert.fail();
		    }    
		 
	}
	
	/**
	 * This method will select Investment option from Change my Investment Page 
	 * @param sOption
	 */
	
	public static String getInvestmentOption(InvestmentOption sOption){
		  String result = "";
		    switch (sOption) {
			case PATH1:
				result= "Path 1";				 
				break;
			case HMDI:
				result= "Help Me Do It";
				break;
			case DIM:
				result= "Do It Myself";
				break;
			case DIFM:
				result= "Do It For Me";
				break;

			default:		
				Reporter.logEvent(Status.WARNING, "Select Investement Option is not Correct", "Please enter correct investement option", false);
				break;
			}	    
		    return result;
		  //  Common.waitForProgressBar();
	}
	
	
	public void clickButton(buttonName bName){
		
		  switch (bName) {
			case CONTINUE:
				  Mobile.clickElement(CONTINUE_BUT);
				break;
			case OK:
				  Mobile.clickElement(OK_BUTTON);
				break;
			case ADD:
				  Mobile.clickElement(butAdd);
				break;
			case BACK_ARROW:
				  Mobile.clickElement(butBack);
				break;				
				
			default:		
				Reporter.logEvent(Status.WARNING, "Button Name  is not Correct in My Investment Page", "Please enter correct button Name for investement page", false);
				break;
			}	
		    
			Reporter.logEvent(Status.INFO, "Click Button ", bName.toString(), false);    
		    Common.waitForProgressBar();
				
		
		
	}
	
	/**
	 * this method will select Fund Type from change My Investement Page
	 * @param sFundType
	 */
	public void selectFundType(fundAllocationType sFundType){
		
		
   switch (sFundType) {
	case CHOOSE_A_RISK_BASED_FUND:
		 Mobile.clickElement(CHOOSE_A_RISK_BASED_FUND_BUT);
		break;
	case CHOOSE_A_TARGET_DATE_FUND:
		  Mobile.clickElement(CHOOSE_A_TARGET_DATE_FUND_BUT);
		break;
	case ACCESS_ONLINE_ADVICE:
		  Mobile.clickElement(ACCESS_ONLINE_ADVICE_BUT);
		break;
	case BASED_ON_A_MODEL_PORTFOLIO:
		  Mobile.clickElement(BASED_ON_A_MODEL_PORTFOLIO_BUT);
		break;
	case ENROLL_IN_PROFESSIONAL_MANAGEMENT_PROGRAM:
		  Mobile.clickElement(ENROLL_IN_PROFESSIONAL_MANAGEMENT_PROGRAM_BUT);
		break;
	case GO_TO_MANAGED_ACCOUNTS:		
		  Mobile.clickElement(GO_TO_MANAGED_ACCOUNTS_BUTTON);
		break;
	case CHOOSE_INDIVIDUAL_FUNDS:		
		  Mobile.clickElement(butChoooseIndividualFund);
		break;

	default:
		Reporter.logEvent(Status.WARNING, "Fund Allocation option is not correct", "Please enter correct Fund allocation opyion", false);
		break;
	}	
	Common.waitForProgressBar();
    
		
	}
	
	
	public void verify_Rebal_Sync_Choose_Individual_Offer_MTGTypes(InvestmentOption investmentOption,String sMoneyTypeGroupingValue){
 
		
		selectRebalanceOption(sMoneyTypeGroupingValue);		
		Common.verifyPageIsDisplayed("Change my Investement Page should be display.", CHANGE_INVESTEMENT_TITLE);
		
		selectInvestmentOption(investmentOption);  
	    selectFundType(fundAllocationType.CHOOSE_INDIVIDUAL_FUNDS);			
		//Step 9
		Common.verifyPageIsDisplayed("Tap \"CHOOSE INDIVIDUAL FUNDS\" Button and  Participant should  navigate to rebalancer investment page.", rebalanceYourPrortfolioPageTitle);
		Mobile.clickElement(butRemoveFunds);	
		removeAllIvestments();
		Mobile.clickElement(butaddViewAllFunds);	
		verifyShowFiltersFunds("ASSET CLASS", "Balanced");
		Common.waitForProgressBar();
		MobileElement sFund = first_inpInvestmentOptionFutureAllocation;	
		MobileElement sFundName = sFund.findElement(By.className("XCUIElementTypeStaticText"));
	    sFundSelected = sFundName.getText();     	    
	    //Step 10 
	//	verifySafariBrowserOpen(sFundName);			
		//Step 11 Select Fund
        Mobile.clickElement(sFund); 
        
    	Reporter.logEvent(Status.INFO, "Investment Fund should be selected ", sFundSelected, true);    	
	    Mobile.clickElement(butAdd);		
	
        //Step 16 Change slider value  and verify  Reset Button and Review Change button
       Mobile.setSliderValue(TEXT_FIELD, "100"); 
     //   Common.setSliderValue(sFundSelected,"100");
        Mobile.verifyElementEnable(butReviewChange, "REVIEW CHANGE Button ");   
        verifyTotal_Allocation_Percentage("100%");   
        //Step 17 Verify Review Change Page 
        Mobile.clickElement(butReviewChange);  
        Common.waitForProgressBar();

        String sExpFunds = "Build your own portfolio 100% " + sFundSelected ;
		Common.verifyPageIsDisplayed("Participant should  navigate to Review Change page.", REVIEW_CHANGE_TITLE);
		
		//Verify Review Page
		verify_Review_Your_change_Page(sExpFunds);
		
		// Step 15 Verify Confiramtion Page
		verifyConfirmationPage(investment_From_Option, sExpFunds);	
		
		
	}
	
	/**
	 * 
	 */
	
	/**
	 * DDTC_27767_LIAT_Smart_Restriction_Rebalance_LandingPage_Withonly_UnRetsricted_Fund
	 */
	
	public void verify_Smart_Restriction_Withonly_UnRetsricted_Fund(){	
		selectInvestmentOption(InvestmentOption.DIM);  
		selectFundType(fundAllocationType.CHOOSE_INDIVIDUAL_FUNDS);			
	    Mobile.verifyElementPresent("Build Your Own Portfolio contain message for Future  and Reblancer Contribution", Smart_Restriction_Future_Current_Allcation_Msg, Smart_Restriction_Future_Current_Allcation_Msg);
	    List<IOSElement> listOfElement =  Mobile.getListOfElements_By_Class("XCUIElementTypeCell");
	    if(listOfElement.size() == 1){
//	    	Mobile.clickElement(butRemoveFunds);	
//	 		removeAllIvestments();
	    	Mobile.clickElement(butaddViewAllFunds); 
	    	addFundsInvestments(1);    	
	    }     	
	    Mobile.setSliderValue(getWebElement("Slider"), "70");
	   
	    Mobile.clickElement(butReviewChange);  
        Common.waitForProgressBar();    
    	Common.verifyPageIsDisplayed("Tap \"REVIEW CHANGES\" Button and  Participant should  navigate to rebalancer your protfolio page.", rebalanceYourPrortfolioPageTitle);
        Mobile.setSliderValue(getWebElement("Slider"), "60");
        Mobile.clickElement(butReviewChange);  
        Common.waitForProgressBar();
        ArrayList<String> sActListText = Common.get_Element_Lists(STATIC_TEXT_FIELD,"Tap Review Change button and Review Change Page");
		String[] contain_list = { rebalanceYourPrortfolioPageTitle,"Future Investments","Rebalance your portfolio",Smart_Restriction_Future_Review_Meg,Smart_Restriction_Rebalancer_Review_Meg };
		Common.verify_Value_InList_Contain(sActListText, contain_list,
				"page should be displayed");
		
		Reporter.logEvent(Status.INFO,
				"Tap \"CONFIRM CHNAGE  \" button in Review Your Change  page",
				"Verify Confirmation page is displayed", false);

		Mobile.clickElement(CONFIRM_CHANGE_BUT);
		Common.waitTillElementNotDisplay("CONFIRMING CHANGE");
		Common.waitForProgressBar();
		if (Mobile.assertElementPresent(By.name("Confirmation"))) {
		//[Confirmation, CONFIRMATION NUMBER, 1090343648, Your investment allocation request for current account balance, and future contributions, has been received as of Friday, December 8, 2017, 5:19 PM, and will be processed as soon as administratively feasible. Your confirmation number for your future contribution change is 1090343648, and rebalance is 1090343649., Future Investments, This change to your investment mix will redirect your future contributions., FROM:, Build your own portfolio, 50%, Dodge & Cox International Stock, 50%, Vanguard Institutional 500 Index Trust, TO:, Build your own portfolio, 100%, Dodge & Cox International Stock, Rebalance your portfolio, This change to your investment mix will rebalance your current unrestricted investments., FROM:, Build your own portfolio, 27%, LifePath Index 2035 Account A, 31%, Vanguard Total Bond Market Index Trust, 42%, Vanguard Institutional 500 Index Trust, TO:, Build your own portfolio, 100%, LifePath Index 2035 Account A]	
			List<String> dates = DateUtility.getInvestmentsSubmissionTime();
			 sActListText = Common
					.get_Element_Lists(STATIC_TEXT_FIELD,"Tap Confirmation Change Button");
			 
				String[] contain_list2 = { "Confirmation","Future Investments","Rebalance your portfolio",Smart_Restriction_Future_Review_Meg,Smart_Restriction_Rebalancer_Review_Meg };
				Common.verify_Value_InList_Contain(sActListText, contain_list2,
						"page should be displayed");
				String confirmation_Num = Common.get_Value_ArrayList(sActListText,
						"CONFIRMATION NUMBER", 1);
				if (confirmation_Num != "") {
					Reporter.logEvent(Status.PASS,
							"Confirmation number should be displayed",
							"Confirmation Number :" + confirmation_Num, false);
				} else {
					Reporter.logEvent(Status.FAIL,
							"Confirmation number should be displayed",
							"Confirmation Number is not displayed", true);
				}
			verifyConfirmationMessageForSmartRestriction(sActListText, dates);
			Mobile.clickElement(RETURN_TO_MY_INVESTMENTS_BUT);
			Common.waitForProgressBar();
					
		}else{
			{
				Reporter.logEvent(Status.FAIL,"Confirmation Page should be display","Confirmation Page is not displayed", true);
				Mobile.clickElement(butBack);
				Mobile.clickElement(butBack);
				Mobile.clickElement(butBack);
				Mobile.clickElement(butBack);
				Assert.fail("Confirmation Page is not displayed");
			}
		}
	
		
	}
	
	
	
	
	
	
	/**
	 * This method will verify Rebalancer functionality for Risk based with different MTG offer 
	 * HMDI -> Risk Based
	 *  Rebalance my investments radio button -> NO MTG/MTG/Not allMTG  	
	 *    Without Also direct future this way -> continue -> Select Target Date Funds button
	 * @param investmentOption
	 * @param sMoneyTypeGroupingValue
	 */
	
	public void verify_Rebal_Sync_RiskBased_Offer_MTGTypes(InvestmentOption investmentOption,String sMoneyTypeGroupingValue){
					
		selectRebalanceOption(sMoneyTypeGroupingValue);
		
		Common.verifyPageIsDisplayed("Change my Investement Page should be display.", CHANGE_INVESTEMENT_TITLE);
		
		selectInvestmentOption(investmentOption);   			
		selectFundType(fundAllocationType.CHOOSE_A_RISK_BASED_FUND);	
	
		
		//Step 9
		Common.verifyPageIsDisplayed("Tap \"CHOOSE RISK BASED FUND\" Button and  Participant should  navigate to rebalancer investment page.", rebalanceInvestmentsPageTitle);

		sFundSelected = addInvestement();
		Mobile.verifyElementPresent(
				"Tap \"CHOOSE RISK BASEED FUND\" Button and select fund",
				"Select a Risk based fund", "Investement Fund selected : \n"
						+ sFundSelected);
		String sExpFunds = "Risk based fund 100% " + sFundSelected;
		mapInvestmentOptions.put("investmentFundName0",sFundSelected);
		// Step Verify Review Your Change Page
		Mobile.clickElement(CONTINUE_BUT);
		Common.waitForProgressBar();
		Common.verifyPageIsDisplayed("Participant should  navigate to Review Change page.", REVIEW_CHANGE_TITLE);
	
		//Step 13
	
//		
				
		//Verify Review Page
		verify_Review_Your_change_Page(sExpFunds);
		
		// Step 15 Verify Confiramtion Page
		verifyConfirmationPage(investment_From_Option, sExpFunds);	
		
	}	
	
	
	public void verify_My_Investement_Page_For_All_MnType(String sMoneyTypeGroupingValue){
		
		Mobile.verifyElementPresent("Money Type Grouping should be displayed", sMoneyTypeGroupingValue, sMoneyTypeGroupingValue);
		Mobile.verifyElementPresent("Expand button should be display", OVERVIEW_EXPAND, "Allocations overview ellipses");
		Mobile.verifyElementPresent("Drop down should contain Annually as default value", "Annually", "Annually drop down option");
			
		
	}
	
	/**
	 * Verify Pending Transfer Alert message for Rebalancer.
	 *  PPT once submit the rebalancer will display alert message saying Pending transfer on file.
	 * @param sMoneyTypeGroupingValue
	 */
	
	public void verify_Pending_Transfer_OnFile_Alert_Msg(String sMoneyTypeGroupingValue){	
		
		clickChangeMyInvestmentButton(sMoneyTypeGroupingValue,NEXT_PICKER_VALUE);
		Mobile.clickElement(CONTINUE_BUT);		
		Common.waitForProgressBar();		
		Common.verifyAlertMessage("Pending transfer on file", "OK");
     	Common.clickBackArrow();
	}
	
	
	/**
	 * This method will select rebalancer Option 
	 * @param sMoneyTypeGroupingValue
	 */
	
	public void selectRebalanceOption(String sMoneyTypeGroupingValue){
		
		  choseInvestmentOption("Rebalance Current Balance");
		   String sFreq= UserBaseTest.getParaValue("RebalFrequency"); 
			selectFrequencyForRebalance(sFreq);
			if(UserBaseTest.getParaValue("selectFutureInvestmentCheckBox").equalsIgnoreCase("NO")){
				selectFutureInvestmentCheckBox(false);
		
			}
			if(sMoneyTypeGroupingValue.contains("All")){
				Mobile.verifyElementPresent("Money Type Grouping should be displayed", "ALL", sMoneyTypeGroupingValue);
				}			
			else if(!sMoneyTypeGroupingValue.equalsIgnoreCase("NA")){
			Mobile.verifyElementPresent("Money Type Grouping should be displayed", sMoneyTypeGroupingValue, sMoneyTypeGroupingValue);
			}
			
			Reporter.logEvent(Status.INFO, "Select Rebalance option and Frequency Type as "+sFreq, "Direct My Future Investment CheckBox as : "+UserBaseTest.getParaValue("selectFutureInvestmentCheckBox"), true);
			
			
			//Step 8
			Mobile.clickElement(CONTINUE_BUT);
			Common.waitForProgressBar();
			if(Mobile.assertElementsPresent(rebalanceInvestmentsPageTitle)){
				List<IOSElement> eleList = Mobile
						.getListOfElements_By_Class("XCUIElementTypeImage");
				if(eleList != null){
					eleList.get(0).click();
				}
				Mobile.clickElement(CONTINUE_BUT);
				Common.waitForProgressBar();
			}
			
	}
	
	
	/**
	 * 
	 * This method will verify Rebalancer Current Balance functionality for Target Data Funds.
	 *  HMDI -> Targtet Date Funds
	 *  Rebalance my investments radio button-> Also direct future this way -> continue -> Select Target Date Funds button
	 *  PPT able to do Full Rebal once and Sync allocations with Target date funds and a pending transfer is created
	 * @param investmentOption : HDMI
	 * @param sMoneyTypeGroupingValue : NA is there is no option to select MTG value from picker value
	 */
	
	

	
	public void verify_Rebal_And_Sync_Allocation_Target_Date_Offer_With_MTGType_Options(InvestmentOption investmentOption,String sMoneyTypeGroupingValue){
		
		
		selectRebalanceOption(sMoneyTypeGroupingValue);
		
		//Step 8
		Common.verifyPageIsDisplayed("Tap Continue  and Change my Investement Page should be display.", CHANGE_INVESTEMENT_TITLE);
		
		selectInvestmentOption(investmentOption);  
		selectFundType(fundAllocationType.CHOOSE_A_TARGET_DATE_FUND);		
	
//		if(!sMoneyTypeGroupingValue.equalsIgnoreCase("NA")){
//		Mobile.verifyElementPresent("Money Type Grouping should be displayed", sMoneyTypeGroupingValue, sMoneyTypeGroupingValue);
//		}
		//Step 9
		Common.verifyPageIsDisplayed("Tap \"CHOOSE A TARGET DATA FUND\" Button and  Participant should  navigate to rebalancer investment page.", rebalanceInvestmentsPageTitle);

		//Step 10-12
		
		sFundSelected = addInvestement();			
		mapInvestmentOptions.put("investmentFundName0",sFundSelected);
		Mobile.verifyElementPresent(
				"Again Tap \"CHOOSE A TARGET DATA FUND\" Button and select fund",
				"Select a Target date fund", "Investement Fund selected : \n"
						+ sFundSelected);
		
		String sExpText = "Target Date fund 100% " + sFundSelected;

		// Step 12
		Mobile.clickElement(CONTINUE_BUT);
		Common.waitForProgressBar();	
		Common.verifyPageIsDisplayed("Participant should  navigate to Review Change page.", REVIEW_CHANGE_TITLE);
		
	
		//Step 14
		verify_Review_Your_change_Page(sExpText);
		// Step 15
		verifyConfirmationPage(investment_From_Option, investment_To_Option);

		
	}

	

	public void verify_MyInvestments_Page() {

		Mobile.clickElement(ARROW_DOWN);
		Mobile.verifyElementPresent(
				"Tap Arrow down and verify Picker wheel should be displayed",
				PICKER_WHEEL, "Picker wheel ");
		// Mobile.selectPickerValue("MTG","next");
		Mobile.clickElement(butDone);
		Mobile.clickElement(OVERVIEW_EXPAND);
		Mobile.clickElement(OVERVIEW_CLOSE);
		Mobile.clickElement(CURRENT_DATE_BUT);
		String[] sExpTextForMTG3 = { "CURRENT BALANCE", "FUTURE ALLOCATION",
				"6 Months", "One Year", "Two Years", "Three Years" };
		Common.verify_Value_InList_Contain(STATIC_TEXT_FIELD, sExpTextForMTG3,
				" should be displayed");
		Mobile.clickElement(CURRENT_DATE_BUT);

		if (Mobile.assertElementPresentByPageFactor(INVESTMENT_BUT)) {
			Mobile.clickElement(INVESTMENT_BUT);
			verify_Asset_Class_In_My_Investment_Page();
			Mobile.clickElement(ASSET_CLASS);
			verify_Investment_In_My_Investment_Page();

		} else {
			Mobile.clickElement(ASSET_CLASS);
			verify_Investment_In_My_Investment_Page();
			Mobile.clickElement(INVESTMENT_BUT);
			verify_Asset_Class_In_My_Investment_Page();
		}
	}

	public void verify_Change_My_Investments_Page() {
		Mobile.scroll_Down();
		Mobile.clickElement(CHANGE_MY_INVESTEMENT_BUT);
		String[] sExpText = { "Change My Investments",
				"How would you like to change your investments?",
				"Rebalance my current balance", label_Content };
		Common.verify_Value_InList_Contain(STATIC_TEXT_FIELD, sExpText,
				" should be displayed");
		Mobile.clickElement(radioChangeFutureInvestmentOption);
		Mobile.clickElement(CONTINUE_BUT);
		Common.waitForProgressBar();
		Common.verify_Is_element_Displayed(DO_IT_FOR_ME, "DO IT FOR ME button");
		Common.verify_Is_element_Displayed(HELP_ME_DO_IT,
				"HELP ME DO IT button");
		Common.verify_Is_element_Displayed(DO_IT_MYSELF, "DO IT MYSELF button");
		Common.clickBackArrow();
		Common.clickBackArrow();

	}

	public void verify_Change_My_Investments_Page_For_Apple_Plan() {
		go_To_Change_MyInvestment_Option(radioChangeFutureInvestmentOption,
				HELP_ME_DO_IT);

		Common.verify_Is_element_Displayed(DO_IT_MYSELF, "DO IT MYSELF button");
		Common.verify_Is_element_Displayed(HELP_ME_DO_IT,
				"HELP ME DO IT button");
		Common.verify_element_Is_Not_Displayed(DO_IT_FOR_ME,
				"DO IT FOR ME button for Apple plan ");
		String[] sExpButton = { CHOOSE_A_TARGET_DATE_FUND_BUT,
				BASED_ON_A_MODEL_PORTFOLIO_BUT, ACCESS_ONLINE_ADVICE_BUT,
				ENROLL_IN_PROFESSIONAL_MANAGEMENT_PROGRAM_BUT };
		Common.verify_Value_InList_Contain(BUTTON_TYPE, sExpButton,
				" Button should be displyed on Taping \"HELP ME DO IT\" button ");
		Mobile.clickElement(DO_IT_MYSELF);
		Mobile.verifyElementPresent(
				"Tap \"DO IT MYSELF\" Button and Choose individual fund button should be displayed",
				butChoooseIndividualFund, butChoooseIndividualFund);
		Mobile.clickElement(butBack);
		Mobile.clickElement(butBack);

	}



	public void verify_Do_It_For_Me_In_Financial_Engine() {
		Mobile.scroll_Down();
		Mobile.clickElement(CHANGE_MY_INVESTEMENT_BUT);
		Common.waitForProgressBar();
		String[] sExpText = { CHANGE_INVESTEMENT_TITLE,
				ALREADY_ENROLLED_IN_PROF_MA };
		Common.verify_Value_InList_Contain(STATIC_TEXT_FIELD, sExpText,
				" should be displayed");
		
		String[] sExpText2 = { 	 ALREADY_ENROLLED_IN_MA_MSG4 };
		Common.verify_Value_InList_Contain(STATIC_TEXT_VIEW, sExpText2,
				"Already Enrolled Message should be displayed");

		Common.verify_element_Is_Not_Displayed(DO_IT_FOR_ME,
				"DO IT FOR ME button");
		click_Perfessional_Management_Button();
		Common.verify_Is_element_Displayed(I_DID_NOT_PERFORM,
				"I DID NOT PERFORM A TRANSACTION button");
		Mobile.clickElement(OK_BUTTON);
		Mobile.verifyElementPresent("Tap OK Button and "
				+ CHANGE_INVESTEMENT_TITLE
				+ " Allocation Page should be displayed ",
				CHANGE_INVESTEMENT_TITLE, CHANGE_INVESTEMENT_TITLE + " Page");
		click_Perfessional_Management_Button();

		Reporter.logEvent(
				Status.INFO,
				"Tap I IMPLEMENTED ONLINE ADVICE RECOMMENDATIONS radio option and click OK Button",
				"Verify the content", false);
		Mobile.clickElement(I_IMPLEMENTED_ONLINE_ADVICE);
		Mobile.verifyElementPresent(IMPLEMENTED_CONTENT
				+ " Content should be displayed", IMPLEMENTED_CONTENT,
				IMPLEMENTED_CONTENT);
		Mobile.clickElement(OK_BUTTON);
		Common.waitTillElement_Is_Display(By.name("My Investments"));
		Mobile.verifyElementPresent("My Investments Page should be display",
				"My Investments", "My Investments page ");

		Common.waitForProgressBar();
		Mobile.scroll_Down();
		Mobile.clickElement(CHANGE_MY_INVESTEMENT_BUT);
		Common.waitForProgressBar();
		click_Perfessional_Management_Button();

		Reporter.logEvent(
				Status.INFO,
				"Tap I ENROLLED IN PROFESSIONAL MANAGEMENT PROGRAM radio option and Click OK  button",
				"Verify the content", false);
		Mobile.clickElement(I_ENROLLED_IN_PROFESSIONAL_MP);
		Mobile.verifyElementPresent(ENROLLED_CONTENT
				+ " Content should be displayed", ENROLLED_CONTENT,
				ENROLLED_CONTENT);
		Mobile.clickElement(OK_BUTTON);
		Common.waitForProgressBar();
		Common.waitTillElement_Is_Display(By.name("My Investments"));
		Mobile.verifyElementPresent("My Investments Page should be display",
				"My Investments", "My Investments page ");

	}
	
	/**
	 * Verify_DIFM_Enroll_In_Manage_Account_For_financial_Engines
	 * Verify 
	 */
	public void Verify_DIFM_Enroll_In_Manage_Account_For_financial_Engines(){
	
		//Step 2-8
		
		String change_My_Investement_Option = UserBaseTest.getParaValue("changeInvestmentOption");		
		
		if(change_My_Investement_Option.equalsIgnoreCase("Future Contributions")){			
				
			go_To_Change_MyInvestment_Option(radioChangeFutureInvestmentOption,HELP_ME_DO_IT);
		}else 	if(change_My_Investement_Option.equalsIgnoreCase("Rebalance")){		
			go_To_Change_MyInvestment_Option(radioRebalance,HELP_ME_DO_IT);
		}
	
		
		Mobile.clickElement(ENROLL_IN_PROFESSIONAL_MANAGEMENT_PROGRAM_BUT);		
	   Common.waitForProgressBar();
	   verifyEnrollmentExpress_For_Financial_Engine();
	
	}
	
	
	/**
	 * Verify_DIFM_Enroll_In_Manage_Account_For_financial_Engines
	 * Verify 
	 */
	public void Verify_DIFM_Enroll_In_Manage_Account_For_MorningStar(){
	
		//Step 2-8
		
		String change_My_Investement_Option = UserBaseTest.getParaValue("changeInvestmentOption");		
		
		if(change_My_Investement_Option.equalsIgnoreCase("Future Contributions")){			
				
			go_To_Change_MyInvestment_Option(radioChangeFutureInvestmentOption,DO_IT_FOR_ME);
		}else 	if(change_My_Investement_Option.equalsIgnoreCase("Rebalance")){		
			go_To_Change_MyInvestment_Option(radioRebalance,DO_IT_FOR_ME);		
			}	
		
		Mobile.clickElement(but_Enroll_In_Managed_Account_Service);		
	   Common.waitForProgressBar();
	   verifyEnrollmentExpress_For_Morning_Star();
		verifyConfirmationForMoringStar();
	   Mobile.verifyElementNotPresent("Enroll in Manage Account Service button should not be displayed", but_Enroll_In_Managed_Account_Service_In_LIAT, "Enroll In Manage Account Service");
	
	}
	
	
	private void verifyEnrollmentExpress_For_Morning_Star(){
		   
				String[] sExpText = { ENROLL_MANAGE_PROGRAM_TITLE,
						ENROLL_MORNING_STAR_REVIEW_LABEL, ENROLL_MA_MORNING_STAR_LABEL1,ENROLL_MA_MORNING_STAR_LABEL2 };
				Common.verify_Value_InList_Contain(STATIC_TEXT_FIELD, sExpText,
						" should be displayed");
			
				List<IOSElement> listOfElement =   Mobile.getListOfElements_By_Class("XCUIElementTypeTextField");
				if(listOfElement.size() == 8 ){
					 Reporter.logEvent(Status.PASS," Eight Text Field  Should be display." ,"Text Field are displayed",false);	
					}
					else{
						 Reporter.logEvent(Status.FAIL,"Text Field  Should be display in Enroll Review page.","Text Field are  not displayed",true);	
					}
				for (IOSElement iosElement : listOfElement) {
					 Reporter.logEvent(Status.PASS,iosElement.getAttribute("value")+" text field  should be displayed" ,iosElement.getAttribute("value")+" is displayed",false);	
					
				}						
				String[] sExpText2 = { ENROLL_MA_MORNING_STAR_LABEL3,
						DISCLOSURE_CONTENT_MORNING_STAR };
				Common.verify_Value_InList_Contain("XCUIElementTypeTextView", sExpText2," should be displayed");		
				
			
	}
	
	public void verifyConfirmationForMoringStar(){
		new EnrollmentPage().clickEnrollment_Button_Till_ConfiramtionPage();
		String label = "You are now enrolled in Managed Account service. Here are your initial investment allocations.";
		
		Mobile.verifyElementPresent("Verify Enroll Confirmation  Page", label, label);		
		String label1= "Here's what you can expect next:";
		Mobile.verifyElementPresent("Verify Enroll Confirmation  Page", label1, label1);
		String[] label2 = {"• Your future investment allocations have been changed to match the initial investment allocations listed above. Your initial investment allocations may change over time due to a variety of factors such as market movement. • You will receive a Welcome Kit in the next few weeks. It includes your Retirement Plan and other helpful information to review. • After we send your Welcome Kit, we start to put your strategy into action. • You will receive quarterly updates so you can see what we've been doing. • You will continue to monitor your account making changes as needed, to keep you on track. You can call an Investment Advisor Representative any time at 1-844-277-4401 to review your strategy and personalize your retirement age, risk tolerance or add investment accounts. • At any time, you can review your current investment strategy, update your profile or investment information, and access electronic versions of your Progress Reports online. • You can cancel at any time, for any reason, without penalty."};
		Common.verify_Value_InList_Contain("XCUIElementTypeTextView", label2," should be displayed");	
		Mobile.scroll_Down();
		Mobile.clickElement("CONTINUE TO YOUR ACCOUNT");
		Common.waitForProgressBar();
	}
	
	private void verifyEnrollmentExpress_For_Financial_Engine(){
		 		String[] sExpText = { ENROLL_PROF_MANAGE_PROGRAM_TITLE,
						ENROLL_PMP_REVIEW_LABEL, ENROLL_PMP_LABEL2,ENROLL_PMP_LABEL3 };
				Common.verify_Value_InList_Contain(STATIC_TEXT_FIELD, sExpText,
						" should be displayed");
			
				List<IOSElement> listOfElement =   Mobile.getListOfElements_By_Class("XCUIElementTypeTextField");
				if(listOfElement.size() == 8 ){
					 Reporter.logEvent(Status.PASS,"Text Field  Should be display." ,"Text Field are displayed",false);	
					}
					else{
						 Reporter.logEvent(Status.FAIL,"Text Field  Should be display in Enroll Review page.","Text Field are  not displayed",true);	
					}
				for (IOSElement iosElement : listOfElement) {
					 Reporter.logEvent(Status.PASS,"Text Field  Should be displayed" ,iosElement.getAttribute("value")+" is displayed",false);	
					
				}
						
				String[] sExpText2 = { ENROLL_PMP_LABEL4,
						ENROLL_PMP_LABEL5 };
				Common.verify_Value_InList_Contain("XCUIElementTypeTextView", sExpText2," should be displayed");		
					
				new EnrollmentPage().clickEnrollment_Button_Till_ConfiramtionPage();
				String label = "You are now enrolled in Professional Management Program. Here are your initial investment allocations.";
				Mobile.verifyElementPresent("Verify Enroll Confirmation  Page", label, label);		
				Mobile.scroll_Down();
				String label1= "Here's what you can expect next:";								
			//	Mobile.verifyElementPresent("Verify Enroll Confirmation  Page label", label1, label1);
		  //String[] label2 = {"• Your future investment allocations have been changed to match the initial investment allocations listed above. Your initial investment allocations may change over time due to a variety of factors such as market movement. • You will receive a Welcome Kit in the next few weeks. It includes your Retirement Plan and other helpful information to review. • After we send your Welcome Kit, we start to put your strategy into action. • You will receive quarterly updates so you can see what we've been doing. • You will continue to monitor your account making changes as needed, to keep you on track. You can call an Investment Advisor Representative any time at 1-844-277-4401 to review your strategy and personalize your retirement age, risk tolerance or add investment accounts. • At any time, you can review your current investment strategy, update your profile or investment information, and access electronic versions of your Progress Reports online. • You can cancel at any time, for any reason, without penalty."};
			//	Common.verify_Value_InList_Contain("XCUIElementTypeTextView", label2," should be displayed");	
				Mobile.clickElement("CONTINUE TO YOUR ACCOUNT");
				Common.waitForProgressBar();
	}
	
	
	
	
	/**
	 * Verify_DIFM_Enroll_In_Manage_Account_For_financial_Engines
	 * Verify 
	 */
	public void Verify_LIAT_DIFM_Enroll_In_Manage_Account_Service_for_MoringStar( ){
		Mobile.clickElement(but_Enroll_In_Managed_Account_Service_In_LIAT);		
	   Common.waitForProgressBar();
	   verifyEnrollmentExpress_For_Morning_Star();
	   }
	
	
	

	/**
	 * Verify_DIFM_Enroll_In_Manage_Account_For_financial_Engines
	 * Verify 
	 */
	public void Verify_LIAT_DIFM_Enroll_In_Manage_Account_For_financial_Engines( ){
	
		//Step 2-8
		Reporter.logEvent(
				Status.INFO,
				"Go to Change My Investement Page  and select Change Future Radio Option -> Tap Continue button",
				"Verify Do It For ME button Persent", false);
		
		String change_My_Investement_Option = UserBaseTest.getParaValue("changeInvestmentOption");
		
		
		if(change_My_Investement_Option.equalsIgnoreCase("Future Contributions")){						
		
			String sButtonName = HELP_ME_DO_IT.getText();
			Mobile.verifyElementPresent(sButtonName
					+ " Button should be display and Tap on " + sButtonName,
					HELP_ME_DO_IT, sButtonName + " Button ");
			Mobile.clickElement(HELP_ME_DO_IT);
			Common.waitForProgressBar();
			
		}
		
		Mobile.clickElement(ENROLL_IN_PROFESSIONAL_MANAGEMENT_PROGRAM_BUT);		
	   Common.waitForProgressBar();
	   verifyEnrollmentExpress_For_Financial_Engine();
	   }
	
	
	/**
	 * go_To_Change_MyInvestment_Option
	 * @param wayToChangeInvesment
	 * @param invest_Option
	 */

	public void go_To_Change_MyInvestment_Option(
			MobileElement wayToChangeInvesment, MobileElement invest_Option) {		   
		try{
			
			
		Mobile.clickElement(CHANGE_MY_INVESTEMENT_BUT);
		Common.waitForProgressBar();
		try{
		String invest_Balance = wayToChangeInvesment.getText();

		Mobile.clickElement(wayToChangeInvesment);
		Mobile.clickElement(CONTINUE_BUT);
		Common.waitForProgressBar();		
		Reporter.logEvent(
				Status.INFO,
				"Go to Change My Investement Page  and select "+invest_Balance+" -> Tap Continue button",
				"", false);
	
		
		
		if(invest_Balance != null)
		if(invest_Balance.contains("Rebalance")){
			Mobile.selectRadioButton("Roth AFT");
			Mobile.clickElement(CONTINUE_BUT);
			Common.waitForProgressBar();
			
		}
		}catch(NoSuchElementException e){

			Reporter.logEvent(
					Status.INFO,
					"Go to Change My Investement Page  and Select Investment Option",
					"", true);
		}
		
		String sButtonName = invest_Option.getText();
		Mobile.verifyElementPresent(sButtonName
				+ " Button should be display and Tap on " + sButtonName,
				invest_Option, sButtonName + " Button ");
		Mobile.clickElement(invest_Option);
		Common.waitForProgressBar();
		}catch(Exception e){
			System.out.println("Not able to select Investement Option ");
			Assert.fail("Not able to select Investement Option ");
		}

	}

	public void verifyConfirmationPage(String sExpFromCard, String sExpToCard) {
		
//		sExpFromCard =investment_From_Option;
//		sExpToCard = investment_To_Option;
		Reporter.logEvent(Status.INFO,
				"Tap \"CONFIRM CHNAGE  \" button in Review Your Change  page",
				"Verify Confirmation page is displayed", false);

		Mobile.clickElement(CONFIRM_CHANGE_BUT);
		Common.waitTillElementNotDisplay("CONFIRMING CHANGE");
		Common.waitForProgressBar();
		if (Mobile.assertElementPresent(By.name("Confirmation"))) {
			List<String> dates = DateUtility.getInvestmentsSubmissionTime();
			ArrayList<String> sActListText = Common
					.get_Element_Lists(STATIC_TEXT_FIELD,"Tap Confirmation Change Button");
			verifyConfirmationMessageForChangeFutureFlow(sActListText, dates);
//			Common.verify_Value_Between_List(sActListText, sExpFromCard,
//					FROM_TEXT, TO_TEXT,
//					"FORM : Card in Confirmation page should display with  Investement Fund");
			Common.verify_Value_Between_List(sActListText, sExpToCard, TO_TEXT,
					"last",
					"TO : Card in Confirmation page  should be display with Investement Fund : ");

				String confirmation_Num = Common.get_Value_ArrayList(sActListText,
					"CONFIRMATION NUMBER", 1);
			if (confirmation_Num != "") {
				Reporter.logEvent(Status.PASS,
						"Confirmation number should be displayed",
						"Confirmation Number :" + confirmation_Num, false);
			} else {
				Reporter.logEvent(Status.FAIL,
						"Confirmation number should be displayed",
						"Confirmation Number is not displayed", true);
			}
			Mobile.clickElement(RETURN_TO_MY_INVESTMENTS_BUT);
			Common.waitForProgressBar();
			String sFundsAdded = mapInvestmentOptions.get("investmentFundName0");
			
			if(!UserBaseTest.getParaValue("changeInvestmentOption").contains("Rebalance")){	
				if(sFundsAdded != null)
				Mobile.verifyElementPresent("My Investement page  should  displayed fund  :\n" +sFundSelected, sFundSelected, sFundSelected);
	
			}
			
						
			
		} else {
			Reporter.logEvent(Status.FAIL,"Confirmation Page should be display","Confirmation Page is not displayed", true);
			Mobile.clickElement(butBack);
			Mobile.clickElement(butBack);
			Mobile.clickElement(butBack);
			Mobile.clickElement(butBack);
			Assert.fail("Confirmation Page is not displayed");
		}
	}

	
	
	
	
	
	public void verify_HMDI_Enrollement_Flow() {

		click_Edit_Add_Button("INVESTMENT OPTION");
		// Verify Current flag not displayed
		Common.verify_Is_element_Displayed(HELP_ME_DO_IT,
				"HELP ME DO IT button");
		Common.verify_Is_element_Displayed(DO_IT_MYSELF, "DO IT MYSELF button");
		Mobile.clickElement(HELP_ME_DO_IT);
		List<IOSElement> sButtonList = Mobile
				.getListOfElements_By_Class("XCUIElementTypeButton");
		for (IOSElement iosElement : sButtonList) {
			String sButtonName = iosElement.getAttribute("name");
			if (sButtonName.equals(CHOOSE_A_TARGET_DATE_FUND_BUT)) {
				Mobile.clickElement(CHOOSE_A_TARGET_DATE_FUND_BUT);
				verify_investement_select_Option_In_Enrollement("Target Date fund 100%");
				break;

			} else if (sButtonName.equals(BASED_ON_A_MODEL_PORTFOLIO_BUT)) {
				Mobile.clickElement(BASED_ON_A_MODEL_PORTFOLIO_BUT);
				verify_investement_select_Option_In_Enrollement("Model Portfolio 100%");
				break;
			} else if (sButtonName.equals(CHOOSE_A_RISK_BASED_FUND_BUT)) {
				Mobile.clickElement(CHOOSE_A_RISK_BASED_FUND_BUT);
				verify_investement_select_Option_In_Enrollement("Risk based fund 100%");
				break;
			}

		}


	}

	private void verify_investement_select_Option_In_Enrollement(
			String sFundType) {
		sFundSelected = "";
		sFundSelected = addInvestement();
		Mobile.clickElement(CONTINUE_BUT);
		Reporter.logEvent(Status.INFO,
				"Tap \"CONTINUE  \" button in My Investemnt Change page",
				"Verify Review page is displayed", false);
		Common.waitTillElement_Is_Display(By.name(REVIEW_CHANGE_TITLE));
		ArrayList<String> sActListText = Common
				.get_Element_Lists(STATIC_TEXT_FIELD,"Review Page");
		String[] contain_list = { REVIEW_CHANGE_TITLE };
		Common.verify_Value_InList_Contain(sActListText, contain_list,
				"page should be displayed");
		String Allocation_Text = sFundType + " " + sFundSelected;
		Common.verify_Value_For_FollowingSibling(sActListText, "ALLOCATIONS",
				1, 3, Allocation_Text, " Investment Fund should contain : \n "
						+ Allocation_Text);
		Mobile.verifyElement_Is_Not_Displayed(
				"From : Card is not displayed in Review change Page",
				By.name(FROM_TEXT), "FROM :  Card ");
		Mobile.clickElement("SAVE");
		Mobile.verifyElementPresent(
				"Selected fund should be present in Enrollement Page :\n"
						+ sFundSelected, sFundSelected, sFundSelected
						+ " \n Fund in Enrollement Page");

	}

	private void click_Edit_Add_Button(String sLabel) {
		Common.waitForProgressBar();
//		String sObjToClick = "//*[@name='" + sLabel
//				+ "']/following-sibling::*[@name='EDIT / ADD']";
		
		MobileElement ele = Mobile.findElementWithPredicate(sLabel);
		
		Mobile.clickElement(ele);
		Common.waitForProgressBar();
	}

	public void verify_HMDI_Multiple_Based_Model_Portfolio() {
	
		// Step 1 to 7
		Reporter.logEvent(
				Status.INFO,
				"Go to Change My Investement Page  and select Change Future Radio Option -> Tap Continue button",
				"Verify Help Me do It button Persent", false);

		go_To_Change_MyInvestment_Option(radioChangeFutureInvestmentOption,
				HELP_ME_DO_IT);

		// Step 11
		Reporter.logEvent(Status.INFO,
				"Tap BASED ON A MODEL PORTFOLIO  button",
				"Verify Change Your Investement Page is displayed", false);

		Mobile.clickElement(BASED_ON_A_MODEL_PORTFOLIO_BUT);
		Common.waitForProgressBar();
		String[] sExpText1 = { CHANGE_INVESTEMENT_TITLE,
				FUTURE_CONTRIBUTION_MSG1,
				FUTURE_CONTRIBUTION_MODEL_PORTFOLIO_MSG2,
				FUTURE_CONTRIBUTION_MODEL_PORTFOLIO_MSG3 };
		Common.verify_Value_InList_Contain(STATIC_TEXT_FIELD, sExpText1,
				" should be displayed");
		sFundSelected = addInvestement();
		String sExpText = "Model Portfolio 100% " + sFundSelected;

		// Step 12
		Mobile.clickElement(CONTINUE_BUT);
		verify_Review_Your_change_Page(sExpText);
		// Step 13
		verifyConfirmationPage(investment_From_Option, investment_To_Option);
		//Test cases 8532
		
		
	}

	public void verify_HMDI_Single_Based_Model_Portfolio() {
		Reporter.logEvent(
				Status.INFO,
				"Go to Change My Investement Page  and select Change Future Radio Option -> Tap Continue button",
				"Verify Help Me do It button Persent", false);
		go_To_Change_MyInvestment_Option(radioChangeFutureInvestmentOption,
				HELP_ME_DO_IT);
		Reporter.logEvent(Status.INFO,
				"Tap BASED ON A MODEL PORTFOLIO  button",
				"Verify Change Your Investement Page is displayed", false);

		Mobile.clickElement(BASED_ON_A_MODEL_PORTFOLIO_BUT);
		Common.waitForProgressBar();
		List<IOSElement> eleList = Mobile.getListOfElements_By_Class("XCUIElementTypeImage");
		if(eleList.size() == 1){
			Reporter.logEvent(Status.PASS,
					"Only one module Portfolio should be display",
					"Only one module Portfolio is displayed", false);
		}else{
			Reporter.logEvent(Status.FAIL,
					"Only one module Portfolio should be display",
					"More module Portfolio is displayed", true);
		}
		
		for (IOSElement iosElement : eleList) {
			System.out.println(iosElement.getAttribute("name"));
			if (iosElement.getAttribute("name").equalsIgnoreCase("tick-mark_gray")) {
				Reporter.logEvent(Status.PASS,
						"Module Portfolio should be pre selected",
						"Module Portfolio is pre selected", false);
			}else{
				Reporter.logEvent(Status.FAIL,
						"Module Portfolio should be pre selected",
						"Module Portfolio is not pre selected", true);
			}
		}
		
		

	Mobile.clickElement(butBack);
	Mobile.clickElement(butBack);
	Mobile.clickElement(butBack);
	}

	public void verify_HMDI_Choose_A_Target_Date_Fund() {
		// Step 1 to 7
		Reporter.logEvent(
				Status.INFO,
				"Go to Change My1 Investement Page  and select Change Future Radio Option -> Tap Continue button",
				"Verify Help Me do It button Persent", false);
		go_To_Change_MyInvestment_Option(radioChangeFutureInvestmentOption,
				HELP_ME_DO_IT);
//		Mobile.verifyElementPresent(
//				"Verify CHOOSE A TARGET DATA FUND  Content is displayed",
//				CHOOSE_A_TARGET_DATE_FUND_CONTENT,
//				CHOOSE_A_TARGET_DATE_FUND_CONTENT);
		
		String[] exp1= {ACCESS_ONLINE_ADVICE_CONTENT,CHOOSE_A_TARGET_DATE_FUND_CONTENT}; 
		Common.verify_Value_InList_Contain(STATIC_TEXT_VIEW, exp1, "Should be displayed");
		
		
		// Step 11
		Mobile.clickElement(CHOOSE_A_TARGET_DATE_FUND_BUT);
		Common.waitForProgressBar();
		sFundSelected = addInvestement();
		Mobile.verifyElementPresent(
				"Tap \"CHOOSE A TARGET DATA FUND\" Button and select fund",
				"Select a Target date fund", "Investement Fund selected : \n"
						+ sFundSelected);
		Mobile.scroll_Down();
		Common.verify_Label_Text("The above shading illustrates",
				TARGET_DATE_FUND_CHANGE_CONTENT,
				"Verify Target Data fund content in \"Change My Investment Page\"");
		// Mobile.verifyElementPresent("Verify Target Data fund content in \"Change My Investment Page\"",
		// TARGET_DATE_FUND_CHANGE_CONTENT,"Target Data Fund Content" );

		String sExpText = "Target Date fund 100% " + sFundSelected;

		// Step 12
		Mobile.clickElement(CONTINUE_BUT);
		verify_Review_Your_change_Page(sExpText);
		// Step 13
		verifyConfirmationPage(investment_From_Option, investment_To_Option);

	}

	public void verify_Access_Online_Advice() {
		Reporter.logEvent(
				Status.INFO,
				"Go to Change My Investement Page  and select Change Future Radio Option -> Tap Continue button",
				"Verify Help Me do It button Persent", false);
		go_To_Change_MyInvestment_Option(radioChangeFutureInvestmentOption,
				HELP_ME_DO_IT);
		
//		Mobile.verifyElementPresent(
//				"Verify ACCESS ONLINE ADVICE Content is displayed",
//				ACCESS_ONLINE_ADVICE_CONTENT, ACCESS_ONLINE_ADVICE_CONTENT);

		// Step 11
		Mobile.clickElement(ACCESS_ONLINE_ADVICE_BUT);
		verify_Advisory_Services_Page();

	}

	public void verify_HMDI_Risk_Base_Fund() {
		Reporter.logEvent(
				Status.INFO,
				"Go to Change My Investement Page  and select Change Future Radio Option -> Tap Continue button",
				"Verify Help Me do It button Persent", false);
		go_To_Change_MyInvestment_Option(radioChangeFutureInvestmentOption,
				HELP_ME_DO_IT);
//		Mobile.verifyElementPresent(
//				"Verify RISK BASED FUND Content is displayed",
//				CHOOSE_A_RISK_BASED_FUND_CONTENT,
//				CHOOSE_A_RISK_BASED_FUND_CONTENT);
		
		String[] exp1= {CHOOSE_A_RISK_BASED_FUND_CONTENT}; 
		Common.verify_Value_InList_Contain(STATIC_TEXT_VIEW, exp1, "Should be displayed");
		

		// Step Add fund from Change My Investment Page
		Mobile.clickElement(CHOOSE_A_RISK_BASED_FUND_BUT);
		Common.waitForProgressBar();
		Mobile.verifyElementPresent("Select a Risk based fund page should be displayed", "Select a Risk based fund", "Select a Risk based fund");
		Common.verify_Label_Text("Risk-based funds provide", RISK_BASED_FUND_CHANGE_CONTENT, "Risk based Disclosure");
		sFundSelected = addInvestement();
		String sExpText = "Risk based fund 100% " + sFundSelected;
		// Step Verify Review Your Change Page
		Mobile.clickElement(CONTINUE_BUT);
		verify_Review_Your_change_Page(sExpText);
		// Step Verify Confirmation Page
		verifyConfirmationPage(investment_From_Option, sExpText);

	}

	private void verify_Advisory_Services_Page() {
		Common.verify_Is_element_Displayed(ALERT_MSG, "Tap  ACCESS ONLINE ADVICE and  Alert Text popUp");
		Mobile.clickElement(CONTINUE_ALERT_BUT);
		Common.waitForProgressBar();
		Common.waitTillElement_Is_Display(By.name("Advisory Services"));
		Common.waitForProgressBar();
		Common.verify_Is_element_Displayed(ADVISORY_SERVICES,
				"Tap Continue button and Advisory Service page");
		Mobile.clickElement(butBack);
		Common.waitTillElement_Is_Display(By.name("My Investments"));
		Mobile.clickElement(I_IMPLEMENTED_ONLINE_ADVICE);		
		Mobile.verifyElementPresent("Verify Implemented online Advice Content", IMPLEMENTED_CONTENT, IMPLEMENTED_CONTENT);
		Mobile.clickElement(OK_BUTTON);
		Common.waitForProgressBar();
		Common.waitTillElement_Is_Display(By.name("My Investments"));

	}

	/*
	 * Method to add Fund from Review Change Page Return String
	 */

	public String addInvestement() {
		String sFundResult = "";
		List<IOSElement> eleList = Mobile
				.getListOfElements_By_Class("XCUIElementTypeImage");
		for (IOSElement iosElement : eleList) {
			System.out.println(iosElement.getAttribute("name"));
			if (!iosElement.getAttribute("name").equalsIgnoreCase(
					"tick-mark_gray")) {
				iosElement.click();
				break;
				
			}
		}
		sFundResult = Mobile
				.getText("//XCUIElementTypeImage[@name='select-on']/following-sibling::XCUIElementTypeStaticText");
		
		sFundSelected= sFundResult;
		mapInvestmentOptions.put("investmentFundName0",sFundSelected);
		Reporter.logEvent(Status.INFO, "Fund selected:", sFundSelected, true);
		
		return sFundResult;
		

	}

	/**
	 * <pre>
	 * Method to get the Current Funds from Review changes and Confirmation Pages
	 * Returns map
	 * </pre>
	 * 
	 * @return mapInvestmentOptions
	 */
	public String getCurrentFunds(ArrayList<String> sActListText, String from,
			String to) {
		String result = "";
		result = Common.get_Value_Between_FollowingSibling(sActListText,
				FROM_TEXT, TO_TEXT);

		return result;
	}

	public void verify_Review_Your_change_Page(String sExpText) {
		investment_To_Option = "";
		Reporter.logEvent(Status.INFO,
				"Tap \"CONTINUE  \" button after selecting fund",
				"Verify Review Your Change page is display", false);
		Common.waitTillElement_Is_Display(By.name(REVIEW_CHANGE_TITLE));
//		ArrayList<String> sActListText = Common
//				.get_Element_Lists(STATIC_TEXT_FIELD,"Review Change Page");
//		String[] contain_list = { REVIEW_CHANGE_TITLE };
//		Common.verify_Value_InList_Contain(sActListText, contain_list,
//				"page should be displayed");
//		investment_From_Option = Common.get_Value_Between_FollowingSibling(
//				sActListText, FROM_TEXT, TO_TEXT);
////		Mobile.verifyElementPresent(
////				"Down Arrow should be present between From and To card",
////				"allocationsArrow-Gray", "Down Arrow");
//		Common.verify_Value_Between_List(sActListText, investment_From_Option,
//				FROM_TEXT, TO_TEXT,
//				" FROM : card  Investment Fund contain should be display ");
//		investment_To_Option = Common.get_Value_ArrayList_TillLast(
//				sActListText, TO_TEXT);
//		Common.verify_Value_For_FollowingSibling(sActListText, TO_TEXT, 1, 3,
//				sExpText,
//				"Selected fund in  TO : card  in Review Your Change Page should be display");

	}
	
	
	

	private void click_Perfessional_Management_Button() {
		Mobile.clickElement(GO_TO_PROFESSIONAL_MANAGEMENT_BUT);
		Mobile.wait(1000);
		Common.verify_Is_element_Displayed(ALERT_MSG, "Tap  "
				+ GO_TO_PROFESSIONAL_MANAGEMENT_BUT + " and  Alert Text popUp");
		Mobile.clickElement(CONTINUE_ALERT_BUT);
		Mobile.wait(6000);
		Common.waitForProgressBar();
		Common.verify_Is_element_Displayed(ADVISORY_SERVICES,
				"Tap Continue button and Advisory Service page");
		Common.waitForProgressBar();
		Mobile.clickElement(butBack);
		Mobile.wait(2000);
		Common.waitTillElement_Is_Display(By.name("My Investments"));

	}

	public void verify_Do_It_For_Me_In_Moring_Star() {
          Mobile.scroll_Down(); 
		Mobile.clickElement(CHANGE_MY_INVESTEMENT_BUT);
		Common.waitForProgressBar();
		String[] sExpText = { CHANGE_INVESTEMENT_TITLE,
				ALREADY_ENROLLED_IN_MA };
		Common.verify_Value_InList_Contain(STATIC_TEXT_FIELD, sExpText,
				" should be displayed");	
		
		
		String[] exp1= {ALREADY_ENROLLED_IN_MA_MSG3}; 
		Common.verify_Value_InList_Contain(STATIC_TEXT_VIEW, exp1, "Should be displayed");
		
		String[] sExpText2 = { DISCLOSURE_CONTENT_MORNING_STAR };
		Common.verify_Value_InList_Contain("XCUIElementTypeTextView", sExpText2,
				" should be displayed");
		
	//	Mobile.verifyText(TEXT_VIEW, DISCLOSURE_CONTENT_MORNING_STAR, false);
		Common.verify_element_Is_Not_Displayed(DO_IT_FOR_ME,
				"DO IT FOR ME button");
		Mobile.clickElement(GO_TO_MANAGED_ACCOUNTS_BUTTON);		
		Mobile.wait(3000);
		Common.waitForProgressBar();
		Common.verify_Is_element_Displayed(webButDone,
				"Tap Go To Manage Account Button and Advisory Service page");
		Mobile.clickElement(webButDone);
		Common.waitTillElement_Is_Display(By.name("My Investments"));
		Mobile.verifyElementPresent(
				"My Investement Content should be displayed",
				MY_INVESTEMTN_MORING_STAR_MSG1, MY_INVESTEMTN_MORING_STAR_MSG1);
		Mobile.clickElement(OK_BUTTON);
		Mobile.verifyElementPresent("Tap OK Button and "
				+ CHANGE_INVESTEMENT_TITLE
				+ " Allocation Page should be displayed ",
				CHANGE_INVESTEMENT_TITLE, CHANGE_INVESTEMENT_TITLE + " Page");
		Mobile.clickElement(butBack);
		Common.waitForProgressBar();

	}

	private void verify_Asset_Class_In_My_Investment_Page() {
		Reporter.logEvent(Status.INFO, "Tap Asset Class Button ",
				"Under Asset Class name should display all  investement name",
				true);
		if (ASSET_CLASS.isDisplayed()) {
			Reporter.logEvent(
					Status.PASS,
					"Under Asset Class name should display all  investement name ",
					"  All investement name is displayed under Asset class name",
					false);
		} else {
			Reporter.logEvent(Status.FAIL,
					"Asset Class name should  be displayed only once",
					" Asset Class name is displayed more then once", true);
		}

	}

	private void verify_Investment_In_My_Investment_Page() {
		Reporter.logEvent(Status.INFO, "Tap Investment  Button ",
				"Investment name should be displayed as per order", true);
		if (INVESTMENT_BUT.isDisplayed()) {
			Reporter.logEvent(
					Status.PASS,
					"List of investment names per the order should be displayed",
					" Investement fund are displayed ", false);
		} else {
			Reporter.logEvent(
					Status.FAIL,
					"List of investment names per the order should be displayed",
					"Fund are not displayed more then once", true);

		}
	}
	
	
	/*
	 * verify_DIM_CIF_Build_Your_Own_Portfolio_With_Models
	 */
	public void verify_DIM_CIF_Build_Your_Own_Portfolio_With_Models() throws InterruptedException{
	
System.out.println("");
		go_To_Change_MyInvestment_Option(radioChangeFutureInvestmentOption,
				HELP_ME_DO_IT);
		Reporter.logEvent(Status.INFO,
				"Tap BASED ON A MODEL PORTFOLIO  button",
				"Verify Change Your Investement Page is displayed", false);
		Common.waitForProgressBar();	
		Mobile.clickElement(BASED_ON_A_MODEL_PORTFOLIO_BUT);
		Common.waitForProgressBar();	
		
		List<IOSElement> eleList = Mobile.getListOfElements_By_Class("XCUIElementTypeImage");
		for (IOSElement iosElement : eleList) {
			System.out.println(iosElement.getAttribute("name"));
			if(iosElement.getAttribute("name").equalsIgnoreCase(
						"tick-mark_gray")){
					sFundSelected =  Mobile
							.getText("//XCUIElementTypeImage[@name='tick-mark_gray']/following-sibling::XCUIElementTypeStaticText");
				Mobile.clickElement(butBack);	
				  Mobile.clickElement(DO_IT_MYSELF);	
				break;
				}
			else{
				iosElement.click();
				sFundSelected =  Mobile
						.getText("//XCUIElementTypeImage[@name='select-on']/following-sibling::XCUIElementTypeStaticText");
				Mobile.clickElement(CONTINUE_BUT);
				Common.waitForProgressBar();	
				Mobile.clickElement(CONFIRM_CHANGE_BUT);
				Common.waitTillElementNotDisplay("CONFIRMING CHANGE");
				Mobile.clickElement(RETURN_TO_MY_INVESTMENTS_BUT);
				Common.waitForProgressBar();	
				go_To_Change_MyInvestment_Option(radioChangeFutureInvestmentOption,
						DO_IT_MYSELF);
				break;
			}	
			
		}		

		Reporter.logEvent(Status.INFO,
				"Modle Portfolio selected  for Future Investment ",
				sFundSelected, false);			
	 	
				
		Mobile.clickElement(butChoooseIndividualFund);	
		Common.waitForProgressBar();	
		Reporter.logEvent(Status.INFO,
				"Tap DO IT MYSELF -> CHOOSE INDIVIDUAL FUNDS  button",
				"Build Your Own Portifolio Page is displayed", true);
		String  Asset_Allocation_Disclosure_Link_Warning_Msg="Warning! Your plan account is currently allocated among funds associated with a model portfolio, specifically "+sFundSelected+". To view other investment strategies before building your own portfolio, go back. The fund allocations below may be rounded and may not total 100%.";
		Mobile.verifyText(Asset_allocation_disclosure_Link, Asset_Allocation_Disclosure_Link_Warning_Msg, true);
	
		// Verify Remove fund by clicking Delete Button DDTC-5286 
    	Mobile.clickElement(butRemoveFunds);
		removeAllIvestments();		
	    Mobile.verifyElement_Is_Not_Displayed("Tap Remove Fund button and delete all the funds and verify  All the funds should not be display",By.name("Delete") , "All the Funds ");    
     	String[] percentage={"100"};
 		Mobile.clickElement(butaddViewAllFunds); 		

		 String[] asset_Disclosure_1 = {"Return information as of the most recent month-end. Please consider the investment objectives,"
		 		+ "			risks, fees and expenses carefully before investing. "
		 		+ "			The prospectus contains this and other information about the investment options."
		 		+ "			Depending on the investment options offered in your Plan, your registered representative can provide you with"
		 		+ " prospectuses for any mutual funds; any applicable annuity contracts and the annuity’s underlying funds; and/or disclosure documents"
		 		+ "	for investment options exempt from SEC registration. Please read them carefully "
		 		+ "	before investing. The 10 year/inception column represents the return of the "
		 		+ "	investment option for the period that is the lesser of the inception of"
		 		+ "	the investment option or the prior ten year. If your investment is part of "
		 		+ "	an annuity contract, the 10 year/inception column represents the return of "
		 		+ "	the fund for the period that is the lesser of the separate account's inception date or the prior ten years. "
		 		+ "For details about the investment's inception, "
		 		+ "click on the fund name and review the information in the Investment Overview"
		 		+ "document. Current performance may be lower or higher than performance data shown."
		 		+ "Performance data quoted represents past performance and is not a guarantee or"
		 		+ "prediction of future results. When redeemed, units/shares may be worth more or "
		 		+ "less than their original cost. Performance returns reflect deduction for fund "
		 		+ "operating expenses. Your Plan may assess a plan administrative fee that was not"
		 		+ "deducted in the returns shown above. The returns shown would be reduced if this"
		 		+ "	charge was applied. For investments offered through a group annuity, returns also "
		 		+ "reflect a mortality and expense risk charge of up to 0.00% , an average Contract"
		 		+ "Maintenance Charge (CMC) of 0.02%, and a Contingent Deferred Sales Charge (CDSC) "
		 		+ "of up to 0.00%. Your Plan may have higher, lower or no CMC or CDSC charges. "
		 		+ "For investments offered through a group annuity, returns prior to the separate "
		 		+ "account's inception date or the investment option's addition to the separate"
		 		+ "account, if later, are hypothetical. Please note performance figures shown do"
		 		+ "not reflect any applicable taxes. For performance data current to the most "
		 		+ "recent month-end, including fees and expenses, please click here. "
		 		+ "Regarding variable life and annuity products,"
		 		+ "while some of the funds offered have similar names and investment objectives "
		 		+ "	and/or may be modeled after publicly traded mutual funds, they are different "
		 		+ "from the publicly traded funds. Some of the investment options referenced"
		 		+ "herein may have names and investment objectives that are similar to certain "
		 		+ "	retail mutual funds. They are not, however, directly related to those mutual"
		 		+ "	funds and their investment performance may differ substantially. Investment "
		 		+ "decisions should not be made on performance information alone. "
		 		+ "Investors should carefully consider other factors as well such as risk,"
		 		+ "fund expenses, fund management and more. For important information about"
		 		+ "the available investment options please see the prospectus for mutual funds, "
		 		+ "any applicable annuity contract and the annuity's underlying funds, and/or "
		 		+ "	disclosure documents."};
		 
		 
		
		// String[] exp1= {asset_Disclosure_1}; 
			Common.verify_Value_InList_Contain(STATIC_TEXT_FIELD, asset_Disclosure_1, "Asser Disclosure should be displayed");
		 
	//	 Mobile.verifyElementPresent("Asser Disclosure should be displayed", asset_Disclosure_1, "Asser Disclosure content"); 		
 		
 		
 		addFundsInvestments(1); 		
     	sFundSelected =mapInvestmentOptions.get("investmentFundName1"); 
    	Reporter.logEvent(Status.INFO,
				"Tap  Add All FundsF and select One Fund",
				sFundSelected, false);
    	addFundPercentage(1, percentage);
     	Mobile.clickElement(butReviewChange);  
     	String sExpText = "Build your own portfolio 100% " + sFundSelected ;
     	verify_Review_Your_change_Page(sExpText);
    	verifyConfirmationPage(investment_From_Option, sExpText);	
		
	}
	
	/**
	 * DO IT MYSELF (DIM)- CHOOSE INDIVIDUAL FUNDS - No default investments
	 */
	public void verify_DIM_CIF_No_Default_Investement(){		

		//Step 4
		Mobile.verifyElementPresent("DO IT MYSELF  Button should be display in change my investement page",DO_IT_MYSELF,"DO IT MYSELF button");
		Mobile.verifyElementNotPresent("Verify Current Flag is not displayed", ALLOCATION_RIBBON, "Current Flag");
		//Step 5 
		Mobile.clickElement(DO_IT_MYSELF);
		//Step 6
		Mobile.clickElement(butChoooseIndividualFund);	
		
		//Step 7	
		Mobile.verifyElementPresent("Tap DO IT MYSELF-> CHOOSE INDIVIDUAL FUND button", VIEW_ALL_FUNDS_PAGE, "View All Funds Page ");
	    //Step 8
		Mobile.verifyElementNotPresent("All the Funds radio options should not be pre-selected or mark grey.", radioTick_Mark_Gray, "Radio option for funds are not grey mark");	     
		//Step 9
		verifyShowFiltersFunds("ASSET CLASS", "Bond");
		
		 // get first fund list name 
		WebElement sFund = first_inpInvestmentOptionFutureAllocation;			
	    sFundSelected = sFund.findElement(By.className("XCUIElementTypeStaticText")).getText();  	
	    //Step 10 
		verifySafariBrowserOpen(sFundSelected);	
		
		//Step 11 Select Fund
        Mobile.clickElement(first_inpInvestmentOptionFutureAllocation);     
	    Mobile.clickElement(butAdd);	     		
	    
	    //Step 12 Verify warning message
		Mobile.verifyText(Asset_allocation_disclosure_Link, WithOut_default_Model_Protfolio_Warning_Msg, true);
		
		//Step 13 verify Locked Image and default Total Allocation Percentage  
    	Mobile.verifyElementPresent("Default : \n Locked Image in  Build your Protfolio Page should be displayed . \n Total Allocation percentage should be 0%", butSlideLock, "Locked Image ");
       	verifyTotal_Allocation_Percentage("0%");
    	
    	//Step 14  : Default Reset Button and Review Change button                
    	Mobile.verifyElementEnable(butReset, "RESET Button "); 		
    	Mobile.verifyElementISDisable(butReviewChange, "REVIEW CHANGE Button ");    
    	
    	//Step 15 Change slider value  and verify  Reset Button and Review Change button
    	Mobile.setSliderValue(TEXT_FIELD, "50");    	
    	Mobile.verifyElementEnable(butReset, "RESET Button ");    	  
        Mobile.verifyElementISDisable(butReviewChange, "REVIEW CHANGE Button "); 
        verifyTotal_Allocation_Percentage("50%");
        
        //Step 16 Change slider value  and verify  Reset Button and Review Change button
        Mobile.setSliderValue(TEXT_FIELD, "100");
        Mobile.verifyElementEnable(butReset, "RESET Button ");    	  
        Mobile.verifyElementEnable(butReviewChange, "REVIEW CHANGE Button ");   
        verifyTotal_Allocation_Percentage("100%");   
        //Step 17 Verify Review Change Page 
        veifyReviewChangePage();
					
	}
	
	private void verifyShowFiltersFunds(String sFilterOption,String sFilterValue){		
		
		Mobile.clickElement(butShowFilters);
		if(sFilterOption.equals("ASSET CLASS")){
		Mobile.clickElement(listOfTextFields.get(0));
		}
		else if(sFilterOption.equals("RATE OF RETURN")){
			Mobile.clickElement(listOfTextFields.get(1));	
		}
		Mobile.selectPickerValue(sFilterValue, "next");
		Mobile.clickElement("CLOSE");
		Reporter.logEvent(Status.INFO," Tap Show Filter Option with  "+sFilterOption ,"Select value : "+sFilterValue, false);
		//Mobile.verifyElementISDisable(butAdd, "Add button");
	}
	
	private void veifyReviewChangePage(){
		   Mobile.clickElement(butReviewChange);  
	        Common.waitForProgressBar();
	    	String sExpText = "Build your own portfolio 100% " + sFundSelected ;
	    	ArrayList<String> sActListText = Common
					.get_Element_Lists(STATIC_TEXT_FIELD,"Tap Review Change button and verify Review Page");
	      	String Allocation_Text = sExpText;
			Common.verify_Value_For_FollowingSibling(sActListText, "ALLOCATIONS",
					1, 3, Allocation_Text, " Investment Fund should contain : \n "
							+ Allocation_Text);
			Mobile.verifyElement_Is_Not_Displayed(
					"From : Card is not displayed in Review change Page",
					By.name(FROM_TEXT), "FROM :  Card ");
			Mobile.verifyElement_Is_Not_Displayed(
					"To : Card is not displayed in Review change Page",
					By.name(TO_TEXT), "TO :  Card ");			
			verifySafariBrowserOpen(sFundSelected);				
			Mobile.clickElement("SAVE");
			Mobile.scroll_Down();
			Mobile.verifyElementPresent(
					"Selected fund should be present in Enrollement Page :\n"
							+ sFundSelected, sFundSelected, sFundSelected
							+ " \n Fund in Enrollement Page");   	
	}
	
	private void verifyReviewChangePageForMoreThenOneFunds(){
		   Mobile.clickElement(butReviewChange);  
	        Common.waitForProgressBar();
	        
	    	String sExpText = "Build your own portfolio";
	    	
	    	ArrayList<String> sActListText = Common
					.get_Element_Lists(STATIC_TEXT_FIELD,"Tap Review Change button and verify Review Page");
	    	
	    	if(sActListText == null)
	    		sActListText = Common
				.get_Element_Lists(STATIC_TEXT_FIELD,"Tap Review Change button and verify Review Page");
	    	
	    	//[Review Your Changes, The investment allocation(s) you have selected, will apply only to your future contributions., ALLOCATIONS, Build your own portfolio, 50%, DFA Emerging Markets Value I, 50%, DFA International Small Cap Value I]
	      	String Allocation_Text = sExpText;
			Common.verify_Value_For_FollowingSibling(sActListText, "ALLOCATIONS",
					1, 1, Allocation_Text, " Investment Fund should contain : \n "
							+ Allocation_Text);
			
			for(int i = 1; i <= mapCurrentInvestmentOptionsPecentage.size();i++){
				
				 String sFund = mapInvestmentOptions.get("investmentFundName"+i);
				 String percentage = mapCurrentInvestmentOptionsPecentage.get(sFund)+"%";
				 sExpText =  percentage+" "+sFund;				 
					Common.verify_Value_For_FollowingSibling(sActListText, percentage,
							1, 1, sFund, " Investment Fund should contain : \n "
									+ sExpText);
				
			}
			  
			
			
			Mobile.verifyElement_Is_Not_Displayed(
					"From : Card is not displayed in Review change Page",
					By.name(FROM_TEXT), "FROM :  Card ");
			Mobile.verifyElement_Is_Not_Displayed(
					"To : Card is not displayed in Review change Page",
					By.name(TO_TEXT), "TO :  Card ");			
			verifySafariBrowserOpen(sFundSelected);				
			Mobile.clickElement("SAVE");
			Mobile.scroll_Down();
			Mobile.verifyElementPresent(
					"Selected fund should be present in Enrollement Page :\n"
							+ sFundSelected, sFundSelected, sFundSelected
							+ " \n Fund in Enrollement Page");   	
	}
	
	private void verifySafariBrowserOpen(String sFundSelected){
		   Mobile.clickElement(sFundSelected);	
		   Common.waitTillElement_Is_Display(URL, 10);
		     Mobile.verifyElementPresent("Tap "+sFundSelected+"  fund link name", URL, "Safari browser should be ");
		     Common.waitTillElement_Is_Display(webButDone, 10);
		     Mobile.clickElement(webButDone);  
		     Common.waitForProgressBar();
	}
	
	

	private void verifySafariBrowserOpen(MobileElement sFund){
		   Mobile.clickElement(sFund);	
		   Mobile.wait(3000);
		   Common.waitTillElement_Is_Display(URL, 10);
		     Mobile.verifyElementPresent("Tap "+sFundSelected+"  fund link name", URL, "Safari browser should be ");
		     Common.waitTillElement_Is_Display(webButDone, 10);
		     Mobile.clickElement(webButDone);  
		     Common.waitForProgressBar();
	}
	

	
	
	/**
	 * DO IT MYSELF (DIM)- CHOOSE INDIVIDUAL FUNDS - No default investments
	 */
	public void verify_DIM_CIF_Default_Investement_Is_Model_Portfolio(){
		
		//Step 4
		Mobile.verifyElementPresent("DO IT MYSELF  Button should be display ",DO_IT_MYSELF,"DO IT MYSELF button");
		Mobile.verifyElementNotPresent("Verify Current Flag is not displayed", ALLOCATION_RIBBON, "Current Flag");
		//Step 5 
		Mobile.clickElement(DO_IT_MYSELF);
		//Step 6
		Mobile.clickElement(butChoooseIndividualFund);			

	    //Step 12 Verify warning message
		Mobile.verifyElementPresent("Tap DO IT MYSELF-> CHOOSE INDIVIDUAL FUND button", pageBuildYourOwnPortfolio,"Build Your Own Portfolio Page" );
		
		Mobile.verifyText(Asset_allocation_disclosure_Link, With_Default_Model_Protfolio_Warning_Msg, true);
	    Mobile.clickElement(butRemoveFunds);	
		removeAllIvestments();		
		Mobile.clickElement(butaddViewAllFunds);			
	//	Mobile.verifyElementPresent("One Model Portfolio Funds radio options should  be pre-selected or mark grey.", radioTick_Mark_Gray, "Radio option for funds is grey mark");	     
		//Step 9
		verifyShowFiltersFunds("ASSET CLASS", "International Funds");		
		addFundsInvestments(2);	
		//Verify Total Allcoation should be  0%
		verifyTotal_Allocation_Percentage("0%");  
		
		//Step 13 Set value for First slider to 50 
		List<IOSElement> ele3 = Mobile.getListOfElements_By_Class("XCUIElementTypeTextField"); 		
		Mobile.setSliderValue(ele3.get(0), "50");
		
		// Step 13Verify Total Allocation Should  be  auto adjust to 100%
//	    verifyTotal_Allocation_Percentage("100%");  
	    
	    //Step 14 -15 Add Value more then 100 % in slider 2 
//	    Mobile.setSliderValue(ele3.get(1), "55");
	    String sSlider2Value = ele3.get(1).getText();
	    if(sSlider2Value.equals("50%")){
	    	Reporter.logEvent(Status.PASS,"Second slider should be auto adjust to  50%." ,"Second slider is Auto Adjust to 50%" ,false);
		}else{
		     Reporter.logEvent(Status.FAIL,"Second slider should be auto adjust to  50%.","Expected :50% But was :"+sSlider2Value,true);
		}
	   
		String[] percent = {"60","40"};
	    addFundPercentage(2, percent);	
 		 
		 // get first fund list name 
			
	    sFundSelected = mapInvestmentOptions.get("investmentFundName1");  	
	    //Step 10 	   
	  
	    verifyReviewChangePageForMoreThenOneFunds();
							
	}
	
	
	
	
	public void verify_DIM_CIF_Model_Portfolio_Is_Not_default_Investment(){
		//Step 4
		Mobile.verifyElementPresent("DO IT MYSELF  Button should be display in change my investement page",DO_IT_MYSELF,"DO IT MYSELF button");
		Mobile.verifyElementNotPresent("Verify Current Flag is not displayed", ALLOCATION_RIBBON, "Current Flag");
		//Step 5 
		Mobile.clickElement(DO_IT_MYSELF);
		//Step 6
		Mobile.clickElement(butChoooseIndividualFund);	
	
    	Mobile.verifyElementPresent("Tap DO IT MYSELF-> CHOOSE INDIVIDUAL FUND button", pageBuildYourOwnPortfolio,"Build Your Own Portfolio Page" );
		
		Mobile.verifyText(Asset_allocation_disclosure_Link, With_Default_Model_Protfolio_Warning_Msg, true);
	    Mobile.clickElement(butRemoveFunds);	
		removeAllIvestments();		
		Mobile.clickElement(butaddViewAllFunds);			
	//	Mobile.verifyElementPresent("One Model Portfolio Funds radio options should  be pre-selected or mark grey.", radioTick_Mark_Gray, "Radio option for funds is grey mark");	     
		//Step 9
		verifyShowFiltersFunds("ASSET CLASS", "International Funds");		
		addFundsInvestments(1);	
		
		//Step 13 Set value for First slider to 50    
	
		List<IOSElement> ele3 = Mobile.getListOfElements_By_Class("XCUIElementTypeTextField"); 		
		Mobile.setSliderValue(ele3.get(0), "100");	
	       //Step 17 Verify Review Change Page 
		   sFundSelected = mapInvestmentOptions.get("investmentFundName1");  	
        veifyReviewChangePage();
	    
//		String[] percent = {"60","40"};
//	    addFundPercentage(2, percent);	 		 
//		 // get first fund list name 
//			
//	    sFundSelected = mapInvestmentOptions.get("investmentFundName1");  	
//	    //Step 10 	   	  
//	    verifyReviewChangePageForMoreThenOneFunds();		
	
	}
	
	
	
	/**
	 * verify Asset_allocation_disclosure_Link
	 */
	
	public void verify_DIM_CIF_Verify_Assest_allocation_Link(){
	
			Reporter.logEvent(
					Status.INFO,
					"Go to Change My Investement Page  and select Change Future Radio Option -> Tap Continue button",
					"Verify DO IT MYSELF button Persent", false);
			if(UserBaseTest.getParaValue("radioButtonPage").equalsIgnoreCase("Future Contributions"))
			go_To_Change_MyInvestment_Option(radioChangeFutureInvestmentOption,
					DO_IT_MYSELF);
			
			Reporter.logEvent(Status.INFO,
					"Tap CHOOSE INDIVIDUAL FUNDS  button",
					"Verify Build Your Own Portifolio Page is displayed", false);
			
			Mobile.clickElement(butChoooseIndividualFund);
			Common.waitForProgressBar();
			Mobile.verifyText(Asset_allocation_disclosure_Link, Asset_Allocation_Disclosure_Link_Warning_Msg, true);
			Mobile.clickElement(butaddViewAllFunds);
	
		 String asset_Disclosure_1 ="Return information as of the most recent month-end. Please consider the investment objectives,"
		 		+ "			risks, fees and expenses carefully before investing. "
		 		+ "			The prospectus contains this and other information about the investment options."
		 		+ "			Depending on the investment options offered in your Plan, your registered representative can provide you with"
		 		+ " prospectuses for any mutual funds; any applicable annuity contracts and the annuity’s underlying funds; and/or disclosure documents"
		 		+ "	for investment options exempt from SEC registration. Please read them carefully "
		 		+ "	before investing. The 10 year/inception column represents the return of the "
		 		+ "	investment option for the period that is the lesser of the inception of"
		 		+ "	the investment option or the prior ten year. If your investment is part of "
		 		+ "	an annuity contract, the 10 year/inception column represents the return of "
		 		+ "	the fund for the period that is the lesser of the separate account's inception date or the prior ten years. "
		 		+ "For details about the investment's inception, "
		 		+ "click on the fund name and review the information in the Investment Overview"
		 		+ "document. Current performance may be lower or higher than performance data shown."
		 		+ "Performance data quoted represents past performance and is not a guarantee or"
		 		+ "prediction of future results. When redeemed, units/shares may be worth more or "
		 		+ "less than their original cost. Performance returns reflect deduction for fund "
		 		+ "operating expenses. Your Plan may assess a plan administrative fee that was not"
		 		+ "deducted in the returns shown above. The returns shown would be reduced if this"
		 		+ "	charge was applied. For investments offered through a group annuity, returns also "
		 		+ "reflect a mortality and expense risk charge of up to 0.00% , an average Contract"
		 		+ "Maintenance Charge (CMC) of 0.02%, and a Contingent Deferred Sales Charge (CDSC) "
		 		+ "of up to 0.00%. Your Plan may have higher, lower or no CMC or CDSC charges. "
		 		+ "For investments offered through a group annuity, returns prior to the separate "
		 		+ "account's inception date or the investment option's addition to the separate"
		 		+ "account, if later, are hypothetical. Please note performance figures shown do"
		 		+ "not reflect any applicable taxes. For performance data current to the most "
		 		+ "recent month-end, including fees and expenses, please click here. "
		 		+ "Regarding variable life and annuity products,"
		 		+ "while some of the funds offered have similar names and investment objectives "
		 		+ "	and/or may be modeled after publicly traded mutual funds, they are different "
		 		+ "from the publicly traded funds. Some of the investment options referenced"
		 		+ "herein may have names and investment objectives that are similar to certain "
		 		+ "	retail mutual funds. They are not, however, directly related to those mutual"
		 		+ "	funds and their investment performance may differ substantially. Investment "
		 		+ "decisions should not be made on performance information alone. "
		 		+ "Investors should carefully consider other factors as well such as risk,"
		 		+ "fund expenses, fund management and more. For important information about"
		 		+ "the available investment options please see the prospectus for mutual funds, "
		 		+ "any applicable annuity contract and the annuity's underlying funds, and/or "
		 		+ "	disclosure documents.";
		 
		 Mobile.verifyElementPresent("Asser Disclosure should be displayed", asset_Disclosure_1, "Asser Disclosure content");
											
	}

	
	
	
	/**
	 * This Method to select the investment options and enter the percentage
	 * @author sidprd
	 *@param noOfInvestmentoptions
	 *@param percent
	 *
	 */
	
	public void addFundsInvestments(int noOfInvestmentoptions)   {
		try{			
			   mapInvestmentOptions.clear();
			   mapCurrentInvestmentOptionsPecentage.clear();
				int noOfRows = inpInvestmentOptionFutureAllocation.size();		   
			  
					
				int j =1;
				
				    for (MobileElement fund : inpInvestmentOptionFutureAllocation) {
				    	String investmentOption = fund.findElement(By.className("XCUIElementTypeStaticText")).getText();
				    	
				    	if(!investmentOption.equalsIgnoreCase(mapdeleteInvestmentOptions.get(0))){
							mapInvestmentOptions.put("investmentFundName"+j,investmentOption );
							Mobile.clickElement(fund);
							j++;
							if(j > noOfInvestmentoptions){
								break;
							}
				    	}
						
					}	
				    if (noOfRows >= noOfInvestmentoptions) {
						Reporter.logEvent(Status.PASS,
								"Verify Investment options are available and select",
								"Investment options :\n "+mapInvestmentOptions.get("investmentFundName1"), false);
					} else{
						Reporter.logEvent(Status.FAIL,
								"Verify Investment options are available",
								noOfInvestmentoptions+"Investment options are not available ", true);
					}	
				
				    for(int i=0;i<2;i++){
				    if(!Mobile.is_Element_Displayed(By.name(butAdd))){
				    	Mobile.scroll_Down();
				    }
				    }
				Mobile.clickElement(butAdd);
					
			
				
	}	catch(Exception e){
	    e.printStackTrace();
	
		}
			}
	
	/**
	 * This method will  update the Slider Value with given percentage 
	 */
	
	public void addFundPercentage(int noOfInvestmentoptions,String[] percent){
		List<IOSElement> ele3 = Mobile.getListOfElements_By_Class("XCUIElementTypeTextField"); 		
		for(int i=0;i<noOfInvestmentoptions;i++){	
			   Mobile.setSliderValue(ele3.get(i), percent[i]);
			   int j =i+1;
			   String sFund = mapInvestmentOptions.get("investmentFundName"+j);
		 	mapCurrentInvestmentOptionsPecentage.put(sFund,percent[i]);
		}
	}
	
	
	/**
	 * Method to remove Investment options from Build Your Own Portfolio Page
	 */
	private void removeAllIvestments(){
	
		List<IOSElement> btnRemoveInvestments = (List<IOSElement>) Mobile.getDriver().findElements(MobileBy.iOSNsPredicateString("label CONTAINS 'Delete'"));
		for (MobileElement iosElement : btnRemoveInvestments) {
			Mobile.clickElement(btnRemoveInvestments.get(0));
			Mobile.wait(500);
			//mapdeleteInvestmentOptions.put(i, inpInvestmentOptionFutureAllocationText.get(0).getText());		
			Mobile.clickElement(butDelete);			
	    }
		List<IOSElement> btnRemoveInvestments2 = (List<IOSElement>) Mobile.getDriver().findElements(MobileBy.iOSNsPredicateString("label CONTAINS 'Delete'"));
		for (MobileElement iosElement : btnRemoveInvestments2) {
			Mobile.clickElement(btnRemoveInvestments2.get(0));
			Mobile.wait(500);
		    Mobile.clickElement(butDelete);			
	    }
		
	}
	
	/**
	 * Verify Total Investment Percentage in Add Module Portfolio Page
	 */
	 public void  verifyTotal_Allocation_Percentage(String percentage){
		 if(Mobile.getText(txttotalInvestmentPercent).contains(percentage)){
				Reporter.logEvent(Status.PASS,
						"Total allocation percentage should be  "+percentage,
						"Total allocation Percentage is  "+percentage, false);

			}
			else 
				{
				Reporter.logEvent(Status.FAIL,
								" Total allocation percentage should be  "+percentage,
					"Total allocation Percentage is not Matching", true);
				}
	 }
	

     /**
  	 * <pre>
  	 * Method to Verify the Confirmation Message for Smart Restriction Flow
  	 *
  	 * </pre>
  	 */
  	public void verifyConfirmationMessageForSmartRestriction(ArrayList<String> sActListText, List<String> dates) {
  		
  		String expectedConfirmationMsg1 =null;
		String expectedConfirmationMsg2 =null;
		
  	
  	
  		 expectedConfirmationMsg1="Your investment allocation request for current account balance, and future contributions, has been received as of "+dates.get(0)+", and will be processed as soon as administratively feasible.";
  		 expectedConfirmationMsg2="Your investment allocation request for current account balance, and future contributions, has been received as of "+dates.get(1)+", and will be processed as soon as administratively feasible.";
  	   		
  		String sActMsg = Common.get_Value_ArrayList(sActListText,
				"CONFIRMATION NUMBER", 2);
		if (sActMsg.trim().contains(expectedConfirmationMsg1)) {
			Reporter.logEvent(Status.PASS,
					"Confirmation Message should be displayed ", sActMsg, false);

		} else {
			if (sActMsg.trim().contains(expectedConfirmationMsg2.trim())) {
				Reporter.logEvent(Status.PASS,
						"Confirmation Message should be displayed ", sActMsg,
						false);
			} else {
				Reporter.logEvent(Status.FAIL,
						"Confirmation Message should be displayed : \n Expected  = : "
								+ expectedConfirmationMsg1, " But was : "
								+ sActMsg, true);

			}
			
		}
  		}  
	 
	 
	 
	 

	/**
	 * <pre>
	 * Method to Verify the Confirmation Message for Change Future Investments Flow
	 *
	 * </pre>
	 * 
	 *
	 */
	private void verifyConfirmationMessageForChangeFutureFlow(
			ArrayList<String> sActListText, List<String> dates) {

		String expectedConfirmationMsg1 =null;
		String expectedConfirmationMsg2 =null;
		
		if(isSmartRestriction){
			
			if(UserBaseTest.getParaValue("isFundRestricted").contains("Yes")){

			 expectedConfirmationMsg1 = "Your investment allocation request for future contributions, has been received as of "
					+ dates.get(0)
					+ ", and will be processed as soon as administratively feasible.";
			 expectedConfirmationMsg2 = "Your investment allocation request for future contributions, has been received as of "
					+ dates.get(1)
					+ ", and will be processed as soon as administratively feasible.";
		
			}
			 else{
				 expectedConfirmationMsg1 = "Your investment allocation request for current account balance, and future contributions, has been received as of "+dates.get(0)+", and will be processed as soon as administratively feasible.";
				 expectedConfirmationMsg2 = "Your investment allocation request for current account balance, and future contributions, has been received as of "+dates.get(1)+", and will be processed as soon as administratively feasible.";
				 
				 
			 }
			 
			 isSmartRestriction= false;
		}
		
		
		else if(!UserBaseTest.getParaValue("changeInvestmentOption").contains("Rebalance")){
			

			 expectedConfirmationMsg1 = "Your investment allocation request for future contributions, has been received as of "
					+ dates.get(0)
					+ ", and will be processed as soon as administratively feasible.";
			 expectedConfirmationMsg2 = "Your investment allocation request for future contributions, has been received as of "
					+ dates.get(1)
					+ ", and will be processed as soon as administratively feasible.";
		
		}else {	
		
			String frequencyType = UserBaseTest.getParaValue("RebalFrequency").toLowerCase();
		
		if(UserBaseTest.getParaValue("selectFutureInvestmentCheckBox").equalsIgnoreCase("NO")){			
				expectedConfirmationMsg1="Your investment allocation request for current account balance, has been received as of "+dates.get(0)+", and will be processed as soon as administratively feasible. Your account will automatically rebalance "+frequencyType+".";
				expectedConfirmationMsg2="Your investment allocation request for current account balance, has been received as of "+dates.get(1)+", and will be processed as soon as administratively feasible. Your account will automatically rebalance "+frequencyType+".";
			
		}else{
				expectedConfirmationMsg1="Your investment allocation request for current account balance, and future contributions, has been received as of "+dates.get(0)+", and will be processed as soon as administratively feasible.Your account will automatically rebalance "+frequencyType+".";
				expectedConfirmationMsg2="Your investment allocation request for current account balance, and future contributions, has been received as of "+dates.get(1)+", and will be processed as soon as administratively feasible.Your account will automatically rebalance "+frequencyType+".";
				
		}

		}
		
		
		String sActMsg = Common.get_Value_ArrayList(sActListText,
				"Confirmation", 1);
		if (sActMsg.trim().equals(expectedConfirmationMsg1)) {
			Reporter.logEvent(Status.PASS,
					"Confirmation Message should be displayed ", sActMsg, false);

		} else {
			if (sActMsg.trim().equals(expectedConfirmationMsg2.trim())) {
				Reporter.logEvent(Status.PASS,
						"Confirmation Message should be displayed ", sActMsg,
						false);
			} else {
				Reporter.logEvent(Status.FAIL,
						"Confirmation Message should be displayed : \n Expected  = : "
								+ expectedConfirmationMsg1, " But was : "
								+ sActMsg, true);

			}

		}

	}
}

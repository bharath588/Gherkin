package com.greatWest.pageObject;

import java.util.ArrayList;

import lib.Reporter;
import lib.Stock;

import org.openqa.selenium.By;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.LoadableComponent;
import org.testng.Assert;

import com.aventstack.extentreports.Status;
import com.greatWest.login.UserBaseTest;
import com.greatWest.pageObject.investment.MyInvestmentPage;
import com.greatWest.utility.Common;
import com.greatWest.utility.Mobile;

public class EnrollmentPage extends LoadableComponent<LoginPage>{
	
	private LoadableComponent<?> parent;
	/** Empty args constructor
	 * 
	 */
	public EnrollmentPage() {
		this.parent = new MFAPage();
		PageFactory.initElements(Mobile.getDriver(), this);
	}
	
	/**
	 * Constructor taking parent as input
	 * 
	 * @param parent
	 */
	public EnrollmentPage(LoadableComponent<?> parent) {
		// this.driver = DriveSuite.webDriver;
		this.parent = parent;
		PageFactory.initElements(Mobile.getDriver(), this);
	}

	public String BACK_BUT = "Back";
	public static String ENROLL_HEADER ="Enrollment";
	public static String ENROLL_SWITCH ="//XCUIElementTypeSwitch";
	private String STATIC_TEXT_FIELD = "XCUIElementTypeStaticText";
	//XCUIElementTypeSwitch
	public static String ENROLL_EDIT_TEXTBOX ="YTDTextFieldIdentifier";
	public static String ENROLL_NOW_BUT= "I AGREE, ENROLL NOW";
	public static String DONE="Done";
	public static String ENROLLING_BUT ="ENROLLING";
	public static String CONTINUE_TO_YOUR_ACCOUNT_BUT="CONTINUE TO YOUR ACCOUNT";
	public static String ENROLL_ERROR_MSG= "An error has occurred. Please contact a Participant Services Representative.";
	public static String COMPANY_MATCH="//XCUIElementTypeStaticText[@name='COMPANY MATCH']/following-sibling::XCUIElementTypeStaticText[1]";
	public static String Company_Match="//XCUIElementTypeStaticText[@name='Company match:']/following-sibling::XCUIElementTypeStaticText[1]";
	
	public static String CONTINUE_BUT ="CONTINUE";

	public  void enter_PPC_In_Enrollemnt_Page(String sValue){	
		Common.waitForProgressBar();
	
//		Mobile.scroll_Down();
//		Mobile.is_Element_Visible(ENROLL_NOW_BUT);
//		Mobile.scroll_UP();
		Mobile.switchButton(true);
		Reporter.logEvent(Status.INFO,"Enter Amount in Enrollement Page :",sValue,false);	
		Common.waitForProgressBar();
		Mobile.setEdit(ENROLL_EDIT_TEXTBOX, sValue);	
		Mobile.clickElement(DONE);
		Mobile.clickElement("SAVE");
		Common.waitForProgressBar();
		
	
		
	}
	
	
	
	
	public void clickEnrollNowButton(){
		Mobile.scroll_Down();
		Common.waitTillElementEnable(By.name(ENROLL_NOW_BUT));
		Mobile.clickElement(ENROLL_NOW_BUT);
		Common.waitTillElementNotDisplay(ENROLLING_BUT);
		
		if(Common.ifServerError()){
			Assert.assertTrue(false, "Enrollment Page is not Loaded. Error Message :"+ENROLL_ERROR_MSG);
		}
		clickContinueTo_Your_Account_Button();
		  
		  if(Common.ifServerError()){
			  Assert.fail(" Not able to Enroll due to Server Error Message");
	
			Reporter.logEvent(Status.INFO, "Enrollment is successful", "LIAT Page is displayed.", false);
		  }
			  
	}



	@Override
	protected void isLoaded() throws Error {
			Assert.assertTrue(Mobile.assertElementPresent(By.name(ENROLL_HEADER)),"Enrollment Page is not loaded");				
			Reporter.logEvent(Status.INFO, "Participant should be in  Enrollment Page", "Enrollment Page is displayed.", false);
	
	}


	@Override
	protected void load() {
		MFAPage mfa = (MFAPage) this.parent;
		this.parent.get();			
	    try {
			mfa.submitVerificationCode(Stock.getConfigParam("defaultActivationCode"),false,false);
	    	Common.waitForProgressBar();
	    	Common.waitTillElementEnable(By.name(ENROLL_NOW_BUT),10);	    	
		} catch (Exception e) {
			
			e.printStackTrace();
		}
		
	}
	
	
	public void verify_Company_Match_Update_In_Confirmation_Page(){
		Reporter.logEvent(Status.INFO, "Tap on the continue", "Verify company match information is displayed in confirmation page as per participant selection ", false);
		Mobile.clickElement(CONTINUE_BUT);	
		Mobile.clickElement(CONTINUE_BUT);			 	
		if(Mobile.is_Element_Displayed(By.name(DeferralsPage.ADD_AUTO_INCREASE_PAGE))){
			Mobile.clickElement(CONTINUE_BUT);	
		}		
	}
	
	/**
	 * click_Edit_Add_Button  Tap on edit/ add button for given input label
	 */
	
	public void click_Edit_Add_Button(String sLabel){
      	Common.waitForProgressBar();
//		 String  sObjToClick = "//XCUIElementTypeStaticText[@name='"+sLabel+"']/following-sibling::XCUIElementTypeStaticText[@name='EDIT / ADD']";
		 Mobile.clickElement(sLabel); 	
		Mobile.wait(1000);	
		Common.waitForProgressBar();
		}
	
	
	public void click_My_Investment_Option(){
		if(Common.ifServerError()){
			Assert.assertTrue(false, "Enrollment Page is not Loaded. Error Message :"+ENROLL_ERROR_MSG);
		}
		if(Mobile.is_Element_Displayed(By.name("INVESTMENT OPTIONS"))){
		click_Edit_Add_Button("INVESTMENT OPTIONS");
		}else{
			click_Edit_Add_Button("INVESTMENT OPTION");
		}
		
		Reporter.logEvent(Status.INFO," Tap Investment Edit/ Add button in Enrollment Page","Change my Investement page is displayed", false);
	}
	
	public void verify_Shopping_Cart_Rate_changed(){
		DeferralsPage deferralsPage = new DeferralsPage();
		deferralsPage.click_Edit_Add_Button("CONTRIBUTIONS");
		DeferralsPage.setElective_Deferral_Deleated(UserBaseTest.getParaValue("contribution_Rate_Type"),true);  		
		deferralsPage.verifyButton_Name_In_Deferral_Group(DeferralsPage.STANDARD);
		if(DeferralsPage.isApplePlan){
			deferralsPage.verifyEnter_Contribution_Rate(DeferralsPage.STANDARD,DeferralsPage.ENTER_CONTRIBUTION_RATE, "BEFORE-TAX");
		}else{
		deferralsPage.verifyEnter_Contribution_Rate(DeferralsPage.STANDARD,DeferralsPage.ENTER_CONTRIBUTION_RATE, DeferralsPage.BEFORE_TAX);
		}
		Mobile.clickElement(BACK_BUT);	
		
	}
	
	
	
	public void verify_Company_Match_Is_Not_Displayed(){
		
		//Step 2 Verify that the company match rules are displayed without the company match rate
		Mobile.verifyElementNotPresent("Company Match Rate in Erollement page  should not be displayed ", COMPANY_MATCH, "Company Match Rate");
		DeferralsPage deferralsPage = new DeferralsPage();
		deferralsPage.click_Edit_Add_Button("CONTRIBUTIONS");
		deferralsPage.click_ContributionType_Edit_Add_Button(DeferralsPage.STANDARD);
		//Step 4 Check that company match rules are displays without the company match rate.
		if(Mobile.getText(Company_Match).contains("on the first")){
			Reporter.logEvent(Status.PASS,"Company Match Rate in Contribution Page should not be displayed","Company match Rate is not displayed",true);
			}else{
			 Reporter.logEvent(Status.FAIL,"Company Match Rate in Contribution Page should not be displayed" ," Company Match Rate is displayed ",true);
			}
		
		Mobile.clickElement(BACK_BUT);	
		
	}
	
	public void verify_Already_Participant_With_MA(){
		Common.waitForProgressBar();
		String ENROLLED_MANAGEMENT_PROG= "Enrolled in Professional Management Program.";	
	  Mobile.verifyElementPresent("Enrolled in Professional Management Program Should be Displayed", ENROLLED_MANAGEMENT_PROG, ENROLLED_MANAGEMENT_PROG);
	  clickEnrollment_Button_Till_ConfiramtionPage();
		  Mobile.verifyElementNotPresent("Investment Option Should not be Displayed", "INVESTMENT OPTIONS", "INVESTMENT OPTIONS");
		  clickContinueTo_Your_Account_Button();
		
	}
	
	
	public void clickEnrollment_Button_Till_ConfiramtionPage(){
		  Mobile.scroll_Down();
			Common.waitTillElementEnable(By.name(ENROLL_NOW_BUT));
			Mobile.clickElement(ENROLL_NOW_BUT);	
			Common.waitTillElementNotDisplay(ENROLLING_BUT);
			if(Common.ifServerError()){
				Assert.assertTrue(false, "Enrollment Page is not Loaded. Error Message :"+ENROLL_ERROR_MSG);
			}else{
				Reporter.logEvent(Status.INFO,"Tap I AGREE, ENROLL NOW  button","Confirmation Page is displayed",true);
			}
		
	}
	
	
	
	
	
	
public void verifyMyInvestementConfirmationPage_percentage(){
		
		if (Mobile.assertElementPresent(By.name("Congratulations!"))) {
		//[Here's what happens next in the Managed Account service:, You are now enrolled in your plan., CONFIRMATION NUMBER, 1040470826, PLAN, Pensionmark Retirement Group 401(k) Profit Sharing Plan, INVESTMENT OPTION, 100.00%, American Funds EuroPacific Gr R5, Congratulations!, Communication preference, Pensionmark Retirement Group 401(k) Profit Sharing Plan, You have chosen to receive all documents by mail.]
		ArrayList<String> sActListText = Common
				.get_Element_Lists(STATIC_TEXT_FIELD,"Tap Confirmation Change Button");
			
		
		String confirmation_Num = Common.get_Value_ArrayList(sActListText,
				"CONFIRMATION NUMBER", 1);
		if (confirmation_Num != "") {
			Reporter.logEvent(Status.PASS,
					"Confirmation page should be displayed",
					"Confirmation page is displayed and Number is :" + confirmation_Num, false);
		} else {
			Reporter.logEvent(Status.FAIL,
					"Confirmation number should be displayed",
					"Confirmation Number is not displayed", true);
		}
		
		String sExpText =  MyInvestmentPage.sFundSelected ;

		
		Common.verify_Value_For_FollowingSibling(sActListText, "INVESTMENT OPTION",
				1, 2, sExpText, " Investment Fund should contain : \n "
						+ sExpText);
			
		clickContinueTo_Your_Account_Button();
		
		}else{
			Assert.fail("Confirmation Page is not displayed");
		}
		
	}
	
	
	public void verifyMyInvestementConfirmationPage(){
		
		if (Mobile.assertElementPresent(By.name("Congratulations!"))) {
		//[Here's what happens next in the Managed Account service:, You are now enrolled in your plan., CONFIRMATION NUMBER, 1040470826, PLAN, Pensionmark Retirement Group 401(k) Profit Sharing Plan, INVESTMENT OPTION, 100.00%, American Funds EuroPacific Gr R5, Congratulations!, Communication preference, Pensionmark Retirement Group 401(k) Profit Sharing Plan, You have chosen to receive all documents by mail.]
		ArrayList<String> sActListText = Common
				.get_Element_Lists(STATIC_TEXT_FIELD,"Tap Confirmation Change Button");
			
		
		String confirmation_Num = Common.get_Value_ArrayList(sActListText,
				"CONFIRMATION NUMBER", 1);
		if (confirmation_Num != "") {
			Reporter.logEvent(Status.PASS,
					"Confirmation page should be displayed",
					"Confirmation page is displayed and Number is :" + confirmation_Num, false);
		} else {
			Reporter.logEvent(Status.FAIL,
					"Confirmation number should be displayed",
					"Confirmation Number is not displayed", true);
		}
		
		String sExpText = "100.00% " + MyInvestmentPage.sFundSelected ;
		Common.verify_Value_For_FollowingSibling(sActListText, "INVESTMENT OPTION",
				1, 2, sExpText, " Investment Fund should contain : \n "
						+ sExpText);
			
		clickContinueTo_Your_Account_Button();
		
		}else{
			Assert.fail("Confirmation Page is not displayed");
		}
		
	}
	
	public void verifyMyInvestementConfirmationPage_ForMoreTanOneFund(){
		
		if (Mobile.assertElementPresent(By.name("Congratulations!"))) {
		//[Here's what happens next in the Managed Account service:, You are now enrolled in your plan., CONFIRMATION NUMBER, 1040470826, PLAN, Pensionmark Retirement Group 401(k) Profit Sharing Plan, INVESTMENT OPTION, 100.00%, American Funds EuroPacific Gr R5, Congratulations!, Communication preference, Pensionmark Retirement Group 401(k) Profit Sharing Plan, You have chosen to receive all documents by mail.]
		ArrayList<String> sActListText = Common
				.get_Element_Lists(STATIC_TEXT_FIELD,"Tap Confirmation Change Button");
			
		
		String confirmation_Num = Common.get_Value_ArrayList(sActListText,
				"CONFIRMATION NUMBER", 1);
		if (confirmation_Num != "") {
			Reporter.logEvent(Status.PASS,
					"Confirmation page should be displayed",
					"Confirmation page is displayed and Number is :" + confirmation_Num, false);
		} else {
			Reporter.logEvent(Status.FAIL,
					"Confirmation number should be displayed",
					"Confirmation Number is not displayed", true);
		}
	
		for(int i = 0; i <= MyInvestmentPage.mapCurrentInvestmentOptionsPecentage.size();i++){
			 String sFund = MyInvestmentPage.mapInvestmentOptions.get("investmentFundName"+i+1);
			 String percentage = MyInvestmentPage.mapCurrentInvestmentOptionsPecentage.get(sFund)+"%";
				String  sExpText =  percentage+"%"+" "+sFund;				 
				Common.verify_Value_For_FollowingSibling(sActListText, percentage,
						1, 1, sFund, " Investment Fund should contain : \n "
								+ sExpText);
			
		}
	
		clickContinueTo_Your_Account_Button();
	
		
		}else{
			Assert.fail("Confirmation Page is not displayed");
		}
		
		
		
	}
	
	
	private void clickContinueTo_Your_Account_Button(){
		//  Assert.fail("Not able to Enroll Successfully due to bug DEFC-17685 ");
		Common.waitForProgressBar();
		Mobile.clickElement(CONTINUE_TO_YOUR_ACCOUNT_BUT);			
		Common.waitForProgressBar();
		Mobile.wait(5000);
		  if(Mobile.assertElementPresent(By.name(MFAPage.SKIP_TOUR))){
				Mobile.clickElement(MFAPage.SKIP_TOUR_BUT);
				Common.waitForProgressBar();
				Mobile.clickElement(MFAPage.BUT_CANCEL);
			}
//		  else if(Mobile.isElementPresent(CONTINUE_TO_YOUR_ACCOUNT_BUT)){
//			  Mobile.clickElement("ADD OR EDIT BENEFICIARIES");
//			  Common.waitForProgressBar();
//			  Assert.fail("Not able to Enroll Successfully");
//		  }
	}

	/*
	 * This method will verify the rate for Base Pay TaxType
	 * Rate should be in percentage and Tax Type can be Before Tax and Roth type
	 */
	public String  get_MyContribution_Rate_Percentage(String sTaxType){	
	
		String sObj ="//XCUIElementTypeStaticText[contains(@name,'"+sTaxType+"')]/../*/XCUIElementTypeStaticText";
		return Mobile.getElementValue(By.xpath(sObj)) ;
				
	}	
	
	/**
	 * 
	 * Future DErerral Option should not be display in Enrollment Page for Contribution.
	 */
	public void verifyFDDIsNotPresentInEnrollmentPage( DeferralsPage deferralsPage) {
		
		click_Edit_Add_Button("CONTRIBUTIONS");
		
		deferralsPage.click_ContributionType_Edit_Add_Button(DeferralsPage.STANDARD);
		Mobile.verifyElementNotPresent("Fdd select  Option is not display in Enrollment Page",
				deferralsPage.getWebElement("FDD_SELECT_OPTION"), "Fdd Select Option ");	
		
		Common.clickBackArrow();
		Common.waitForProgressBar();
		Common.clickBackArrow();
		clickEnrollNowButton();
		
	}
}

   package com.greatWest.pageObject;

import io.appium.java_client.pagefactory.AppiumFieldDecorator;

import java.util.ArrayList;

import org.openqa.selenium.By;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.LoadableComponent;
import org.testng.Assert;

import com.greatWest.login.UserBaseTest;
import com.greatWest.utility.Common;
import com.greatWest.utility.DateUtility;
import com.greatWest.utility.Mobile;


public class AccountSummaryPage  extends LoadableComponent<LoginPage>{
	
	private LoadableComponent<?> parent;
	
	
//	@iOSFindBy(id ="My Accounts")
	private String  MY_ACCOUNT ="My Accounts";

	public static String ESTIMATED_BENEFIT ="ESTIMATED BENEFIT";	
	public static String ESTIMATED_BENEFIT_VALUE ="$";
	public static String PLAN_LIST ="PLAN LIST";
	private static String  BALANCE_BENEFIT="BALANCE";
	public static String DB_CONTENT_2 ="†† Your estimated benefit is based on your plan rules, service and compensation earned, payable at Normal Retirement Date and the plan's normal form of payment for a single participant.";
    public static String CONTENT_1 = "Total balance is the value of your plan account(s) vested and non-vested balances as of the date shown.";
    public static String STATIC_TEXT_FIELD= "XCUIElementTypeStaticText";
    
    public static String PAYOUT_STATUS = "(in payout status)";
    
    public static String PLUS_SIGN ="grey-plus";
    public static String TRS_PLAN_CONTENT2 = "† This plan is administered by a third party. More details are available on the website.";
	
    public static String TOTAL_BALANCE = "TOTAL BALANCE AS OF "+DateUtility.getCurrentDate();
	
	/** Empty args constructor
	 * 
	 */
	public AccountSummaryPage() {
		this.parent = new  HomePage();
		PageFactory.initElements(new AppiumFieldDecorator(Mobile.getDriver()), this);
	}
	

	
	/**
	 * Constructor taking parent as input
	 * 
	 * @param parent
	 */
	public AccountSummaryPage(LoadableComponent<?> parent) {
		// this.driver = DriveSuite.webDriver;
		this.parent = parent;
		PageFactory.initElements(new AppiumFieldDecorator(Mobile.getDriver()), this);
	}

	

	@Override
	protected void isLoaded() throws Error {
		Assert.assertTrue(Mobile.assertElementPresent(By.name(MY_ACCOUNT)),"My Account Page is not loaded");		
		
	}

	@Override
	protected void load() {		
		 this.parent.get();		
	   
			if(!Mobile.assertElementPresent(By.name(MY_ACCOUNT))){
				HomePage.selectMenuOption("MY ACCOUNT","ACCOUNT SUMMARY");	
				
			}			
	
	}
	
	
	public void verify_DB_Plan_With_PayOutStatus(){
		
     	ArrayList<String > sActListText = Common.get_Element_Lists(STATIC_TEXT_FIELD,"Verify Account Summary Page");
		String plan = UserBaseTest.getParaValue("planType");
		Mobile.verifyElement_Is_Not_Displayed(TOTAL_BALANCE +" should not be displayed for plan "+plan, By.name(TOTAL_BALANCE), TOTAL_BALANCE);
		Mobile.verifyElement_Is_Not_Displayed(ESTIMATED_BENEFIT +" should not be displayed for plan "+plan, By.name(ESTIMATED_BENEFIT), ESTIMATED_BENEFIT);
		//Mobile.verifyElementNotPresent("Plus sign should not be display", PLUS_SIGN, "Plus Sign");
		Mobile.verifyElement_Is_Not_Displayed(PLUS_SIGN +" should not be displayed for plan "+plan, By.name(PLUS_SIGN), PLUS_SIGN);

		String[] contain_list= {PLAN_LIST,BALANCE_BENEFIT,PAYOUT_STATUS,CONTENT_1,getContent2(plan)}; 		
		Common.verify_Value_InList_Contain(sActListText, contain_list,plan+" Plan with PayOut Status  should contain");	
		
		
	}
	

	public void verifyDbTrsPlanOnly(){		
		String plan = UserBaseTest.getParaValue("planType");
		ArrayList<String > sActListText = Common.get_Element_Lists(STATIC_TEXT_FIELD,"Verify Account Summary Page");
		
		Common.verify_Value_For_FollowingSibling(sActListText,ESTIMATED_BENEFIT,1,2,"$","Estimated Benefit Amount Should be displayed");

		String[] containList= {PLAN_LIST,BALANCE_BENEFIT,CONTENT_1,getContent2(plan)}; 		
		Common.verify_Value_InList_Contain(sActListText, containList,plan+" Plan Only should contain");			
	
		Mobile.verifyElement_Is_Not_Displayed(TOTAL_BALANCE +" should not be displayed for plan "+plan, By.name(TOTAL_BALANCE), TOTAL_BALANCE);
	
	}
	
	
	
	public void verify_DB_TRS_Plan_With_DC_Plan(){	
		String plan = UserBaseTest.getParaValue("planType");
		Mobile.wait(5000);
		ArrayList<String > sActListText = Common.get_Element_Lists(STATIC_TEXT_FIELD,"Verify Account Summary Page");
		Common.verify_Value_For_FollowingSibling(sActListText,TOTAL_BALANCE,1,1,"$","Total Balance Amount Should be displayed");
	//	Mobile.verifyElementPresent("Plus sign should be display", PLUS_SIGN, "Plus Sign");	
		Common.verify_Value_For_FollowingSibling(sActListText,ESTIMATED_BENEFIT,1,2,"$","Estimated Benifit Amount Should be displayed");
		
		String[] contain_list= {PLAN_LIST,BALANCE_BENEFIT,CONTENT_1,getContent2(plan)}; 		
		Common.verify_Value_InList_Contain(sActListText, contain_list,plan+" Plan Only should contain");	
		
	}
	
	//[My Accounts, ESTIMATED BENEFIT, TOTAL BALANCE AS OF 7/14/2017, $334,303.58, PLAN LIST, BALANCE, Pearson TRS Test Plan †, n/a, Southwest Airlines Pilots Retirement Savings Plan, $334,303.58, Total balance is the value of your plan account(s) vested and non-vested balances as of the date shown., † This plan is administered by a third party. More details are available on the website.]
	
	public void verify_DB_TRS_Plan_With_DC_Plan_With_PayOutStatus(){
		String plan = UserBaseTest.getParaValue("planType");
		ArrayList<String > sActListText = Common.get_Element_Lists(STATIC_TEXT_FIELD,"Verify Account Summary Page");
		
		String[] contain_list= {TOTAL_BALANCE,PLAN_LIST,BALANCE_BENEFIT,CONTENT_1,getContent2(plan)}; 		
		Common.verify_Value_InList_Contain(sActListText, contain_list,plan+" Plan and DC with Payout  should contain");	
		
		Mobile.verifyElementNotPresent("Plus sign should not be display", PLUS_SIGN, "Plus Sign");	
		

		Mobile.verifyElement_Is_Not_Displayed(ESTIMATED_BENEFIT +" should not be displayed for plan "+plan, By.name(ESTIMATED_BENEFIT), ESTIMATED_BENEFIT);

	}
	
	public void verify_DB_TRS_Plan_Estimated_Benefit(){	
		String plan = UserBaseTest.getParaValue("planType");
		ArrayList<String > sActListText = Common.get_Element_Lists(STATIC_TEXT_FIELD,"Verify Account Summary Page");	
	//	Mobile.verifyElementPresent("Plus sign should be display", PLUS_SIGN, "Plus Sign");	
		Common.verify_Value_For_FollowingSibling(sActListText,ESTIMATED_BENEFIT,1,2,"semi-annual","Estimated Benifit Amount Should be displayed with frequency");
		
		String[] contain_list= {PLAN_LIST,BALANCE_BENEFIT,CONTENT_1,getContent2(plan)}; 		
		Common.verify_Value_InList_Contain(sActListText, contain_list,plan+" Plan Only should contain");		
			
		
	}
	
	
	public  void verify_Value_For_FollowingSibling(String sObj, String parent, String expected ,String sMsg){
		
	}
	
	private String getContent2(String sPlan){
	
		if(sPlan.equalsIgnoreCase("DB")){
			return DB_CONTENT_2;
		}
		else{
			return TRS_PLAN_CONTENT2;
		}
	}
}

package com.greatWest.pageObject;

import io.appium.java_client.MobileElement;
import io.appium.java_client.ios.IOSElement;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.pagefactory.iOSFindBy;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

import lib.Reporter;
import lib.Web;

import com.greatWest.utility.Mobile;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.LoadableComponent;
import org.testng.Assert;

import com.aventstack.extentreports.Status;
import com.greatWest.login.UserBaseTest;
import com.greatWest.utility.Common;
import com.greatWest.utility.DateUtility;

public class DeferralsPage extends LoadableComponent<LoginPage>{
	
	private LoadableComponent<?> parent;
	DeferralsPage	deferralsPage = null;
	
	@iOSXCUITFindBy(className = "XCUIElementTypeTextField")
	@CacheLookup
    private  MobileElement ENTER_CONTRIBUTION_TEXTFILED;
	
	
	@iOSXCUITFindBy(className = "XCUIElementTypeTextView")
	@CacheLookup
    private  MobileElement PPC_TOOLTIP_MSG_XPATH;
	
	@iOSXCUITFindBy(className = "XCUIElementTypeSwitch")
	@CacheLookup
    private  MobileElement MAXIMIZE_SWITCH;

	
	
//	@iOSFindBy(id = "Continue")
    private  String ALERT_CONTINUE_BUT= "Continue";
	
	@iOSFindBy(id = "check")	
    private  MobileElement CHECK;
	
	
	
	//FDD
	@iOSXCUITFindBy(accessibility = "Select other date")	
     MobileElement fddSelectOption;
	
	@iOSXCUITFindBy( iOSNsPredicate= "label contains 'Select other date'")	
    private  MobileElement fddTileSelectOption;
	
	
	
	@iOSXCUITFindBy( className= "XCUIElementTypeSwitch")	
    private  MobileElement switchButton;
	
	@iOSXCUITFindBy( accessibility = "SAVE")	
    private  MobileElement butSave;
	
	@iOSXCUITFindBy( accessibility = "Done")	
    private  MobileElement butDone;
	
	@iOSXCUITFindBy( className = "XCUIElementTypeTextField")	
    private  MobileElement textField;
	
	
	
	
	
	@iOSFindBy(id = "BACK")
	@CacheLookup
    private  MobileElement BACK_BUT;
	
	
	@iOSFindBy(id = "CANCEL")
	@CacheLookup
    private  MobileElement CANCEL_BUT;
	
	@iOSFindBy(id = "RESET")
	@CacheLookup
    private  MobileElement RESET_BUT;
	
	@iOSFindBy(id = "UPDATE")
	@CacheLookup
    private  MobileElement UPDATE_BUT;
	
	@iOSFindBy(id = "CONFIRMING")
	@CacheLookup
    private  MobileElement CONFIRMING_BUT;
	

	

	public static String CONTINUE_BUT = "CONTINUE";
	public static String ENTER_CONTRIBUTION_RATE ="ENTER YOUR CONTRIBUTION RATE";
	
	
	
	/** Empty args constructor
	 * 
	 */
	public DeferralsPage() {
		this.parent = new HomePage();
		PageFactory.initElements(new AppiumFieldDecorator(Mobile.getDriver()), this);
	}
	
	/**
	 * Constructor taking parent as input
	 * 
	 * @param parent
	 */
	public DeferralsPage(LoadableComponent<?> parent) {
		// this.driver = DriveSuite.webDriver;
		this.parent = parent;
		PageFactory.initElements(new AppiumFieldDecorator(Mobile.getDriver()), this);
	}

	
									  
	public static String TEXT_FIELD ="XCUIElementTypeTextField";
	public static String STATIC_TEXT_FIELD="XCUIElementTypeStaticText";

	public static String MY_CONTRIBUTION = "My contributions";

	public static String STANDARD_MAXIMIZE_ME_ALWAYS ="Maximize Me Always";
	public static String EDIT_BUT = "//XCUIElementTypeTextField[@name='PRIOR PLAN CONTRIBUTIONS']/following-sibling::*[@name='EDIT']";
	

	public static String currentYear = DateUtility.getCurrentYear();
	
	
	//------Base Pay contributions  Page 

	public static String BASE_PAY_BEFORE_TAX_MSG ="Base Pay contributions are deducted from your paycheck. Contributions in the Base Pay group include: Before Tax, Roth.";
	public static String CONFIRM_AND_CONTINUE_BUT ="CONFIRM & CONTINUE";
	

	public static String ALERT_MSG= "XCUIElementTypeAlert";

	
	
	//public static String CONTRIBUTION_COMPANY ="THE COMPANY";
	public static String CONTRIBUTION_COMPANY ="APPLE";
	
	public static String APPLE_PLAN ="Apple 401(k) Plan";
	public static String CONFIRM_PLAN_TEXT ="//XCUIElementTypeStaticText[@name='PLAN']/following-sibling::XCUIElementTypeStaticText";
	public static String CONFIRM_CONTRIBUTIONS_TEXT ="//XCUIElementTypeStaticText[@name='CONTRIBUTIONS']/following-sibling::XCUIElementTypeStaticText";
	
	
	public static String ERROR_MESSAGE_XPATH1 = "//XCUIElementTypeTextField/following-sibling::XCUIElementTypeStaticText[2]";
	
	public static String INPUT_TEXT_FIELD="XCUIElementTypeTextField";
	
	//Standard contributions Page 
	public static String  STANDARD_CONTRIBUTIONS_HEADER= "Standard contributions";
	public static String MAXIMIZE_COMPANY_MATCH = "MAXIMIZE TO "+CONTRIBUTION_COMPANY+" MATCH";	
		//public static String MAXIMIZE_COMPANY_MATCH = "MAXIMIZE TO APPLE MATCH";
	

	


	public static String MAXIMIZE_LIMIT = "MAXIMIZE TO THE "+currentYear+" IRS LIMIT";	
	
	//MAXIMIZE TO THE 2017 IRS LIMIT

	public static String MAXIMIZE_RATE_VALUE  = "//XCUIElementTypeStaticText[@name='MAXIMIZE TO THE "+currentYear+" IRS LIMIT']/following-sibling::*/XCUIElementTypeStaticText[1]";
	public static String MAXIMIZE_PER_PAY_PERIOD_VALUE = "//XCUIElementTypeStaticText[@name='MAXIMIZE TO THE "+currentYear+" IRS LIMIT']/following-sibling::*/XCUIElementTypeStaticText[2]";
  
	public static String AUTO_INCREASE_BEFORE_TAX ="AUTO INCREASE BEFORE TAX";
	
	public static String ADD_AUTO_INCREASE_PAGE ="Add auto increase";
	
	//ENTER YOUR CONTRIBUTION RATE
	public static String ENTER_CONTRIBUTION_AUTO_ADD_PAGE ="Add auto increase";

	//Message
	 
	public static String  WARNING_MESSGE_VIEW ="XCUIElementTypeTextView";
	public static String  EDIT_ANNUAL_COMPENSATION_MODEL = "Edit annual compensation";
	public static String  ANNUAL_COMPENSATION_TEXTBOX = "//XCUIElementTypeStaticText[@name='My annual compensation:']/following-sibling::XCUIElementTypeTextField";
	
    
	
	//Confirmation Page 	
	public static String CONFIRM_NUMBER ="//XCUIElementTypeStaticText[@name='CONFIRMATION NUMBER']/following-sibling::XCUIElementTypeStaticText";
	
	
	
	//Maximize Company Match 
	
	
	
	public static String MAXIMIZE_COMPANY_RATE = "//XCUIElementTypeStaticText[@name='"+MAXIMIZE_COMPANY_MATCH+"']/following-sibling::*/XCUIElementTypeStaticText[1]"; //   for 6%

	
	public static String MAXIMIZE_COMPANY_TOOLTIP ="//*[@name='"+MAXIMIZE_COMPANY_MATCH+"']/following-sibling::*/XCUIElementTypeStaticText[2]"; //  $0.00 per pay period
	
	public static String TOOLTIP_MSG_TEXT ="//*[@name='PopoverDismissRegion']/following-sibling::*//XCUIElementTypeStaticText";
	
	public static String SELECT_CONTRIBUTION_HEADER = "Select contribution";
	public static String SELECT_CONTRIBUTION_HEADER_XAPTH ="//XCUIElementTypeNavigationBar/XCUIElementTypeStaticText[@name='Select contribution']";
	public static String SELECT_CONTRIBUTION_QUESTION_LABEL ="What type of contribution would you like to make?";	 
	public static String SELECT_CONTRIBUTION_COMPARE_THEM ="Compare them";
	public static String SELECT_CONTRIBUTION_PLAN_RULES = "Plan rules";
	public static String APPLE_BEFORE_TAX ="BASE PAY TRADITIONAL";
	//public static String APPLE_BEFORE_TAX ="BEFORE-TAX";
	public static String APPLE_BEFORE_TAX_LABEL ="Traditional";
	//public static String APPLE_BEFORE_TAX_LABEL ="Before";
	public static String BEFORE_TAX ="BEFORE";
	public static String ROTH ="ROTH";
	
	public static String SELECT_CONTRIBUTION_BEFORE_TAX_MSG ="Base Pay Traditional 401(k) contributions are made from before-tax money.";

											
	 
	public static String SPLIT ="SPLIT YOUR CONTRIBUTION";	 
	
	
	
	
	public static String RETURN_TO_MY_CONTRIBUTIONS_BUT = "RETURN TO MY CONTRIBUTIONS";	
	

	 //  "BASE PAY"
	
	public static String BASE_PAY_MSG ="Base Pay contributions are deducted from your paycheck. Contributions in the Base Pay group include: Before Tax, Roth.";
	
	
	
	//My Contribution Page	
	
	
	public static String BASE_PAY ="BASE PAY";
	@FindBy(xpath ="//XCUIElementTypeStaticText[@value='BASE PAY']/following-sibling::XCUIElementTypeStaticText[@value='EDIT / ADD']")
	@CacheLookup
	private MobileElement BASE_PAY_EDIT_BUTTON;
			
	public static String  STANDARD ="STANDARD";
	@FindBy(xpath ="//XCUIElementTypeStaticText[@value='STANDARD']/following-sibling::XCUIElementTypeStaticText[@value='EDIT / ADD']")
	@CacheLookup
	private MobileElement STANDARD_EDIT_BUTTON;	
	
	public static String CATCH_UP ="CATCH-UP";

	@FindBy(xpath ="//XCUIElementTypeStaticText[@value='CATCH-UP']/following-sibling::XCUIElementTypeStaticText[@value='EDIT / ADD']")
	@CacheLookup
	private MobileElement CATCH_UP_EDIT_BUTTON;
	
	public static String AFTER_TAX ="AFTER TAX";
	public static String APPLE_AFTER_TAX ="AFTER-TAX";
	
	public static String BONUS ="BONUS";
	public static String OTHER = "OTHER";
	public static String EDIT_ADD_BUT ="EDIT / ADD";
	public static String ADD_BUT ="Add";
	
	
	//Catch up
	
    //public static String APPLE_CATCH_UP_BEFORE ="CATCH-UP BEFORE";
    
    public static String APPLE_CATCH_UP_BEFORE ="CATCH UP TRADITIONAL";
	public static String CATCH_UP_BEFORE ="CATCH-UP BEFORE";
	public static String APPLE_CATCH_UP_ROTH ="CATCH-UP ROTH";
	public static String CATCH_UP_ROTH ="CATCH-UP ROTH";
	//public static String CATCH_UP_SPLIT ="CATCH-UP SPLIT";
	
	public static String CATCH_UP_SPLIT ="SPLIT YOUR CONTRIBUTION";
	
	//Bonus
	public static String BONUS_BEFORE ="BEFORE TAX BONUS";
	public static String BONUS_ROTH ="ROTH BONUS";
	public static String BONUS_SPLIT ="SPLIT YOUR CONTRIBUTION";
	
	//Other 
	public static String OTHER_BEFORE ="BEFORE TAX VARIABLE";
	public static String OTHER_ROTH ="ROTH VARIABLE";
	public static String OTHER_AFTER ="AFTER TAX VARIABLE";
	
	
	//CATCH-UP ROTH
	
	//Base Pay contributions
	public static String IRS_CONTRIBUTION_LABEL =  "The "+currentYear+" IRS contribution limit:";
	public static String IRS_CONTRIBUTION_AMOUNT ="//XCUIElementTypeStaticText[@name='The "+currentYear+" IRS contribution limit:']/following-sibling::XCUIElementTypeStaticText[1]";
	
	public static String MY_ANNUAL_LABEL = "My annual compensation:";	
	public static String MY_ANNUAL_AMOUNT =	"//XCUIElementTypeStaticText[@name='My annual compensation:']/following-sibling::XCUIElementTypeStaticText";
	
	public static String CONTRIBUTION_RATE_PAGE = "Provide the contribution to be deducted from your paycheck.";
	

	//Message 
	public static String MODIFY_MAXIMIZE_ME_ALWAYS_MSG =  "Modify my contribution as necessary to maximize my contributions and Apple Match up to the IRS limit every year. This election will remain effective until cancelled.";
  //	public static String MODIFY_MAXIMIZE_ME_ALWAYS_MSG =  "Modify my contribution as necessary to maximize my contribution to the IRS limit. My election will remain effective until cancelled.";
	public static String MODIFY_MAXIMIZE_ME_ALWAYS_XAPTH = "//XCUIElementTypeSwitch/following-sibling::XCUIElementTypeStaticText[2]";
	public static String APPLE_MAXIMIZE_TOOLTIP_MSG = "This contribution is based on an estimated bi-weekly paycheck utilizing your annual compensation multiplied by the contribution rate.";
	public static String MAXIMIZER_LIMT_TOOLTIP_MSG ="The estimated amount to be deducted from your paycheck is based on the salary provided times your contribution rate.";
	public static  String EDIT_ANNUAL_COMPENSATION_MSG ="You are solely responsible for the accuracy of the contribution information you provide and it may result in you over-contributing or under-contributing for the year.";
	
	//public static  String MAXIMIZE_ME_ALWAYS_NOTE_MSG ="Note: If you elected to contribute at the Maximizer rate for your regular contributions, and chose the Maximize Me Always feature to maximize your contributions and Apple Match up to the IRS limit every year, and you also elect to contribute at the Maximizer catch-up rate, your Maximizer catch-up election will automatically be included in the Maximize Me Always feature.";
	public static  String MAXIMIZE_ME_ALWAYS_NOTE_MSG =	"If you elected to contribute at the Maximizer rate for your regular contributions, and chose the Maximize Me Always feature to maximize your contributions and Apple Match up to the IRS limit every year, and you also elect to contribute at the Maximizer catch-up rate, your Maximizer catch-up election will automatically be included in the Maximize Me Always feature. If your compensation earned the last pay period of the year is less than your annual salary on file divided by the total number of pay periods for the year, it is possible you will not maximize your contributions to the IRS limit.";

	public static  String MAXIMIZE_LIMIT_MANUALLY_MSG ="Maximize Me Always is not available if you manually entered an annual compensation to model your contribution rate.";
	
//	public static  String MAXIMIZE_LIMIT_MANUALLY_MSG ="Maximize Me Always is not available if you manually entered an annual compensation to model your contribution rate. Also, your Maximize my Catch-up election may change if you manually entered an annual compensation.";
	
     public static String APPLE_MAXIMIZE_WARNING_MSG ="Maximize Me Always is only applicable for Base Pay contributions. Do not choose this feature if you are making contributions from Commission pay.Selecting an after-tax rate that is too high will prevent your Maximize Me Always rate from maximizing your contributions and Apple Match for the year.";
	//public static String APPLE_MAXIMIZE_WARNING_MSG ="Maximize Me Always is only applicable for Base Pay contributions. Do not choose this feature if you are making contributions from Commission pay. Selecting an after-tax rate that is too high will prevent your Maximize Me Always rate from maximizing your contributions and Apple Match for the year. Note: If you elect to contribute at the Maximizer rate for your catch-up contributions, your Maximizer Catch-Up election will automatically be included in the Maximize Me Always feature.";
	//public static String APPLE_MAXIMIZE_WARNING_MSG ="Maximize Me Always is only applicable for Base Pay contributions. Do not choose this feature if you are making contributions from Commission pay.Selecting an after-tax rate that is too high will prevent your Maximize Me Always rate from maximizing your contributions and Apple Match for the year.Note: If you elect to contribute at the Maximizer rate for your catch-up contributions, your Maximizer Catch-Up election will automatically be included in the Maximize Me Always feature.";

	
	
	//Prior Plan  COntribution	
	//public static String PPC_SECTION_CONTENT_XPATH1 ="//XCUIElementTypeTextView";
	//public static String PPC_SECTION_CONTENT_MSG ="Have you made contributions to any other retirement plans since one / one / two zero one seven ? Why is this important?";

	public static String PPC_SECTION_CONTENT_MSG ="Have you made contributions to any other retirement plans since";
	public static String PPC_SECTION_CONTENT_XPATH="//XCUIElementTypeButton[@name='Why is this important?']/preceding-sibling::XCUIElementTypeStaticText";
	public static String PPC_SWITCH ="//XCUIElementTypeSwitch";
	public static String PPC_HEADER ="Prior plan contributions";
	public static String CLOSE ="Close";
	
	public static String PPC_EDIT_LABEL_2="Year-to-date contributions";
	public static String PPC_EDIT_LABEL_1="Enter the amount you contributed to any other retirement plans since 1/1/2017.";
	public static String PPC_EDIT_LABEL_3 ="This includes 401(k) pre-tax, Roth 401(k), 403(b), SARSEP and Simple IRA contributions.";
	public static String PPC_EDIT_LABEL_4 ="This includes 401(k) before-tax, Roth 401(k), SARSEP and Simple IRA contributions.";

	
	
	public static String PPC_TEXTFIELD ="YTDTextFieldIdentifier";

	public static String PPC_CONTENT_MSG="You are solely responsible for the accuracy of the contribution information you provide and it may result in you overcontributing or undercontributing for the year.";

	public static String PPC_TOOLTIP_HEADER =   "Why is this important?";

	public static String PPC_TOOLTIP_MSG ="The Internal Revenue Code limits the amount you can contribute to your retirement plan(s) each year. Contributions you make in excess of such limits may be subject to applicable taxes and returned to you.";
	public static String OK_BUT = "OK";
	public static String PPC_SECTION= "PRIOR PLAN CONTRIBUTIONS";		
	public static String PPC_CONFIRMATION_NUM ="//XCUIElementTypeStaticText[contains(@name,'Confirmation Number')]";
	public static String PPC_YEAR_OF_DATE_MSG ="Year-to-date contributions since 1/1/"+currentYear;
	public static String SAVE_BUT ="SAVE";
	
	public static String PPC_AMOUNT_DISPLAY="//XCUIElementTypeStaticText[@name='PRIOR PLAN CONTRIBUTIONS']/following-sibling::XCUIElementTypeStaticText[2]";
	
	public static String PPC_CATCH_UP_LABEL ="Catch-up contributions";
	public static String PPC_CATCH_UP_EDIT="CatchUpTextFieldIdentifier";	
	
	private static String sContributionRate ;
	private static String sContributionSalary;
	private static String sPerPay_Period;
	private static Boolean bMaximize_Me_Always =false;
	private static float before_tax_split; 
	private static float roth_split;	
	private static String split_before_label; 
	private static String split_roth_label;
	private Boolean bViewOnlyDeferralType = false;
	private static  String  viewOnlyRate;
	
	
	private static Boolean elective_deferral_deleated = false;
	public static String AMOUNT_TYPE ="Amount";
	public static String PERCENT_TYPE ="%";
	public static String PERCENT_AMOUNT_TYPE ="$";
	private static String CONTRIBUTING_RATE_TYPE ="%";
	private static Boolean bVerifyConfirmation = true;	
	private  static String CONFIRMATION_DEFERAL_TYPE ="";
	public static String contrbution_rate;
	
	//Verify Appal Plan 
	public static Boolean isApplePlan = false;	
	public static Boolean isDuplicateApplePlan = false;	
	
	//AUTO INCREASE
	
	public static String  AUTO_INCREASE1 = "auto-increase-check";

	
    
	
	


	@Override
	protected void isLoaded() throws Error {	
		      
				Assert.assertTrue(Mobile.assertElementPresent(By.name(MY_CONTRIBUTION)),"Diferrals Page is not loaded");		
				CONFIRMATION_DEFERAL_TYPE ="";
				Reporter.logEvent(Status.INFO, "Navigate to Deferral Page", "Deferral Page is displayed", true);
	}


	@Override
	protected void load() {	
		
	//	HomePage homePage = (HomePage) this.parent;
		this.parent.get();			
		try {			
			selectDeferralsHomePage();
		} catch (Exception e) {			
		e.printStackTrace();
		}    
	}
	
	
	public   MobileElement getWebElement(String webElement){
	
		MobileElement ele = null;
		switch (webElement) {
		case "TEXTFILED":
			return ENTER_CONTRIBUTION_TEXTFILED;
		
		case "FDD_SELECT_OPTION":
			return fddSelectOption;
		
		case "ONETIME_SWITCH":
			return MAXIMIZE_SWITCH;
		case "butcancel":
			return CANCEL_BUT;
			
			

		default:
			break;
		} 
		
		return ele;
}
	
	
	
	
	
	public static String getContributionRate(){
		return sContributionRate;
	}
	

	public static String getContributionPerPayPeriod(){
		return sPerPay_Period;
	}
	
	public static Boolean getVerifyConfirmation(){
		return bVerifyConfirmation;
	}
	

	public static void setbVerifyConfirmation(Boolean status){
		bVerifyConfirmation =status;
		if(!status){
			CONFIRMATION_DEFERAL_TYPE ="";
		}
	}
	
	public  Boolean isViewOnlyDeferralType(){
		return bViewOnlyDeferralType;
	}
	

	public  void setViewOnlyDeferralType(Boolean status,String rate){
		bViewOnlyDeferralType = status;
	   viewOnlyRate = rate;
	}
	
	
	
	public static void setContributionPerPayPeriod(String sPerPay){
		sPerPay_Period = sPerPay;
	}
	
	public static String getContributionSalary(){
		return sContributionSalary;
	}
	
	public static void setContributionRate(String sRate){
		sContributionRate = sRate;
	}
	public static void  setContributionSalary(String sSalary){
		sContributionSalary =sSalary;
	}
	public static void setMaximize_Me_Always(Boolean Maximize_Me_Always){
		bMaximize_Me_Always = Maximize_Me_Always;
	}
	
	public static Boolean getbMaximize_Me_Always(){
		return bMaximize_Me_Always;
	}
	
	
	public static void setApplePlan(Boolean status){
		isApplePlan = status;
	}
	
	
	public static void setDuplicateApplePlan(Boolean status){
		isDuplicateApplePlan = status;
		
	}
	
	public static Boolean getDuplicateApplePlan(){
		return isDuplicateApplePlan;
	}
	
	
	public static Boolean getApplePlan(){
		return isApplePlan;
	}
	
	
	public static   void setElective_Deferral_Deleated(String sContributingRateType, Boolean isElective_DeferralDelected){
		 elective_deferral_deleated = isElective_DeferralDelected;		
	    CONTRIBUTING_RATE_TYPE =sContributingRateType;
					
	}
	
	public String getContributionRateType() {
		return CONTRIBUTING_RATE_TYPE;
	}
	
	
	public static Boolean getElective_Deferral_Deleated(){
		return elective_deferral_deleated;
	}
	
	
	

	public  void selectDeferralsHomePage(){	
		if(HomePage.isMultiplePlan()){
			HomePage.selectMenuOption("MY ACCOUNT",HomePage.sPlanName,"MY CONTRIBUTIONS");	
			HomePage.setMultiplePlan(false,"");
			
		}else if(getApplePlan()) {
			HomePage.selectMenuOption("MY ACCOUNT","APPLE 401(K) PLAN","MY CONTRIBUTIONS");	
		}
		else
		{
		HomePage.selectMenuOption("MY ACCOUNT","MY CONTRIBUTIONS");	
		}	 	   		
	}
	
	public  void verifyWarningMessage(){	
		String sTestData = UserBaseTest.getParaValue("Warning_Msg");
		String sMsg = "";
	  try{	
		switch(sTestData){
			case "NO_LONGER_SUPPORTS_PERCENTAGE":
			{
				 sMsg = "Warning! Your plan no longer supports contributions by percent. Please enter a number for the dollar amount you would like to contribute to your retirement plan.";
				break;	
		     }
			case "NO_LONGER_SUPPORTS_DOLLOR":
			{
				 sMsg = "Warning! Your plan no longer supports contributions by dollar amount. Please enter a number for the percent of salary you would like to contribute to your retirement plan."; 
			   break;
			}
		
			case "CHANGE_ALL_APPLICABLE_TO_PERCENTAGE": 
			{				
				 sMsg = "Warning! Your plan no longer supports contributions by dollar amount. If you make any changes, you must change all applicable contribution rates.";
				 break;
			} 
			case "UNABLE_TO_COMPLETE_TRANS_ONE_DEFERRAL":
			{			
			Mobile.verifyElementPresent("Unable to complete transaction page should be display", "Unable to complete transaction", "Unable to complete transaction page");
			sMsg ="Due to plan setup changes, you are unable to modify your Before Tax contribution rate(s) through this process. Please go to My contributions to make this change.";
				break;
			} 
			case "UNABLE_TO_COMPLETE_TRANS_TWO_DEFERRAL":
			{			
			Mobile.verifyElementPresent("Unable to complete transaction page should be display", "Unable to complete transaction", "Unable to complete transaction page");
			sMsg ="Due to plan setup changes, you are unable to modify your Before Tax and After tax contribution rate(s) through this process. Please go to My contributions to make this change.";
		    break;	
			}
			case "UNABLE_TO_COMPLETE_TRANS_WITH_AGE":
			{			
				Mobile.verifyElementPresent("Review Your Changes should be display","Review Your Changes", "Review Your Changes");
				sMsg ="Due to plan setup changes, you are unable to modify your Before Tax contribution rate(s) through this process. Please go to My contributions to make this change.Tap the button below to process the other change(s) requested.";
			break;	
			}
			case "DEF_REST_ERROR_3020_MSG":
			{
				Mobile.verifyElementPresent("My contribution page should be display","My contributions", "My contributions");
				sMsg ="The Open deferral change window does not start until 02/15/2019.. You may, however, elect to stop all contributions.";
			 break;
			}
			case "DEF_REST_ERROR_3050_MSG":
			{
				Mobile.verifyElementPresent("My contribution page should be display","My contributions", "My contributions");
				sMsg ="Change not allowed, unless changing your deferral to zero. Plan allows 2 change every 1 Day(s). Next change allowed:";
			 break;
			}
			case "DEF_REST_ERROR_3021_MSG":
			{
				Mobile.verifyElementPresent("My contribution page should be display","My contributions", "My contributions");
				sMsg ="Deferral changes, other than setting deferrals to zero, are allowed between 02/15/2019 AND 03/01/2019 based on plan AND eligibility.. You may, however, elect to stop all contributions.";
			 break;
			}
			case "DEF_REST_ERROR_3016_MSG":
			{
				Mobile.verifyElementPresent("My contribution page should be display","My contributions", "My contributions");
				sMsg ="Enrollment may be completed between 02/15/2019 AND 03/01/2019 based on plan AND eligibility..";
			 break;
			}
			case "DEF_REST_ERROR_3044_MSG":
			{
				Mobile.verifyElementPresent("My contribution page should be display","My contributions", "My contributions");
				sMsg ="The Open enrollment window does not start until 02/28/2019..";
			 break;
			}
			case "DEF_REST_ERROR_3050_PF_MSG":
			{
				Mobile.verifyElementPresent("My contribution page should be display","My contributions", "My contributions");
				sMsg ="Change not allowed, unless changing your deferral to zero. Plan allows 2 deferral change(s) every 2 Week(s).. You may, however, elect to stop all contributions.";
			   break;
			}
			
				
			
			default:
			{
				Reporter.logEvent(Status.FAIL,sTestData," Warning_Msg is not listed",true);
			}
				break;
			}
			
			Mobile.verify_Element_Value(PPC_TOOLTIP_MSG_XPATH, sMsg, "Message displayed :\n"+sMsg );
		
	  }catch(Exception e){
			Reporter.logEvent(Status.FAIL,sTestData," Warning_Msg is not listed",false);
		  Assert.fail();
		  
	  }
		
	}
	
	
	
	/*
	 * This method will verify the Home page 
	 */

	public void verifyHomePage(String sExpText){
	     Mobile.wait(1000);
		IOSElement ele = Mobile.findElementBy(By.name(sExpText));
		if (ele != null) {
					Reporter.logEvent(Status.INFO,sExpText +" Page should be Displayed ",sExpText +"  Page is displayed", true);
				}
			    else{
				     Assert.assertTrue(false, "Expected Page should be : "+sExpText + "  But was not displayed " );  
				}
			
	}
	
	

	
	

	
	/*
	 * This method will verify the My Contribution Home page 
	 */

	public void verify_My_Contribution_HomePage(){	
		Mobile.wait(2000);
		if(Mobile.isElementPresent(MY_CONTRIBUTION)){
			Reporter.logEvent(Status.PASS," Display ", "MY Contribution Shopping Cart Page",true);
		}else{

		     Assert.assertTrue(false, " MY Contribution Shopping Cart Page not displayed");          
		}
		
		 	
		}
	
	
		
		
	/*
	 * This method will verify the PPC Home page 
	 */

	public void verify_PPC_HomePage(){	
		Mobile.wait(2000);
		if(Mobile.isElementPresent(PPC_HEADER)){
			Reporter.logEvent(Status.PASS,"Prior Plan Contributions Page   Display ", "Prior Plan Contributions Page is displayed",true);
		}else{
		   //  Reporter.logEvent(Status.FAIL,"  Not Display  ","Prior Plan Contributions Page is displayed",true);
		     Assert.assertTrue(false, " Prior Plan Contributions Page is not displayed ");         
		}
	}
	
		
	
	/*
	 * This method will verify the PPC Home page 
	 */

	public void verify_Contribution_Rate_Page(){
		Common.waitForProgressBar();
		if(Mobile.isElementPresent(CONTRIBUTION_RATE_PAGE)){
			Reporter.logEvent(Status.PASS,"Contributions Rate Page is  Display ", "",false);
		}else{
		   //  Reporter.logEvent(Status.FAIL,"  Not Display  ","Contributions Rate Page",true);
		     Assert.assertTrue(false, " Contributions Rate Page is not displayed ");         
		}
	}
	
	
	public void enterAnnualCompensationAmount(String sAmount){	
	Mobile.setEdit(ANNUAL_COMPENSATION_TEXTBOX, sAmount);
	Mobile.clickElement("Done");
	Reporter.logEvent(Status.INFO, "Amount entered in Annual Compensation text box" ,sAmount, false);
	}
	
	public void verify_Annual_Compensation_Amount_IsUpdated(String sAmount_onFile,Boolean sUpdated){		
		String sActAmount = Mobile.getText(MY_ANNUAL_AMOUNT);
			 
		if(sUpdated){
//			float fActAmount =Web.getIntegerCurrency(sActAmount);
//			sActAmount = String.valueOf(fActAmount);
			if(!sAmount_onFile.equals(sActAmount))
				Reporter.logEvent(Status.PASS, "Annual Compensation Amount Salary should be updated " ,sActAmount, false);
				else
			    Reporter.logEvent(Status.FAIL, "Annual Compensation Amount Salary should be updated " ,"Expected : "+ sAmount_onFile+" But Actual was:  "+sActAmount, true);
			}
			else{
				if(sAmount_onFile.equals(sActAmount))
				Reporter.logEvent(Status.PASS, "Annual Compensation Amount is same as On File:" ,sAmount_onFile, false);
				else
			    Reporter.logEvent(Status.FAIL, "Annual Compensation Amount is same as On File","Expected : "+ sAmount_onFile+" But Actual was:  "+sActAmount, true);

				
			}
		}
	public void verifyAnnualCompensationAmount(String sAmount){	
		sAmount = "$"+sAmount;		
		Mobile.verifyText(MY_ANNUAL_AMOUNT,sAmount, false);
		
		}
	
	
	
	
	/*
	 * This methos will click Edit/Add button  for respective label Type
	 */
	public void click_ContributionType_Edit_Add_Button(String sContributingType){
		 String  sObjToClick = "";		
		
		String sLabel ="";
		if(sContributingType.isEmpty() ||sContributingType.equals("")){
			sContributingType =UserBaseTest.getParaValue("contribution_Type");
		}		
		if(sContributingType.equalsIgnoreCase(STANDARD) || sContributingType.equalsIgnoreCase(BASE_PAY)){	
			if(getApplePlan() || getDuplicateApplePlan()){
				sLabel=BASE_PAY;				
					
			}else{
			sLabel=STANDARD;	
			
			}		
			Mobile.scroll_UP();
			}
		else if(sContributingType.equalsIgnoreCase("catch-up")){
			sLabel= CATCH_UP;
			
		}
		else if(sContributingType.equalsIgnoreCase("AFTER TAX")){
			if(getApplePlan()){
				sLabel=APPLE_AFTER_TAX;
			}else{
			sLabel=AFTER_TAX;	
			}			
			
		}
		else if(sContributingType.equalsIgnoreCase("BONUS")){	
			if(getApplePlan()){
				sLabel= "BONUS PAY";					
			}else{
				sLabel= BONUS;	
			}			
			}
		
		else if(sContributingType.equalsIgnoreCase("Other")){
			sLabel= "OTHER";
		}
		else {
			sLabel= sContributingType;
		}	

		    sObjToClick=sLabel;	
		 	 IOSElement ele =  Mobile.findElement(sLabel);  
	
	    	 if(Mobile.assertElementPresent(ele))		
	    	 {	
	    		 Mobile.clickElement(ele); 	 
	    		 Common.waitForProgressBar();
			  }	    	
	    	    	 
	    	 if(Mobile.isElementPresent(CONTRIBUTION_RATE_PAGE)){
				Reporter.logEvent(Status.INFO,"Tap  \"Edit / Add\" button  for "+sContributingType+" in Shoping Cart Page","Contribution Rate page is displayed",false);	
				
			}else{
				sObjToClick ="//XCUIElementTypeStaticText[contains(@name,'"+sLabel+"')]/preceding-sibling::XCUIElementTypeButton[contains(@name,'Add')]";
				 Mobile.clickElement(sObjToClick);  
				 Common.waitForProgressBar();
				 if(!Mobile.isElementPresent(CONTRIBUTION_RATE_PAGE)){
				     Assert.assertTrue(false, sContributingType +" Deferral Group is not present in Shopping Cart Page");         
				 }else{
						Reporter.logEvent(Status.INFO,"Tap  \" Add\" button  for "+sContributingType+" in Shoping Cart Page","Contribution Rate page is displayed",false);	
						
				 }
				 }
		 
	
		}

	
	public void click_ContributionType_Edit_Add_Button(String sContributingType,String sContributionType){
	 click_ContributionType_Edit_Add_Button(sContributingType);	
	 if(!sContributionType.isEmpty()){
		 Mobile.clickElement(sContributionType);		
	 }
		 
	}
	
	/**
	 * click_Edit_Add_Button  Tap on edit/ add button for given input label
	 */
	
	public void click_Edit_Add_Button(String sLabel){
      	Common.waitForProgressBar();
      	Reporter.logEvent(Status.INFO, "Tap  "+sLabel +" ", "", false);
		 Mobile.clickElement(sLabel);
		 Common.waitForProgressBar();	
		}
	
	/**
	 * 
	 * 
	 
	 */
	
	
	public String  isOneTimeEnableForFDD(Boolean isOneTime){
		
		Mobile.clickElement(fddSelectOption);
	
		Mobile.clickElement(textField);
		Mobile.scrollElement("XCUIElementTypePicker", "next", 30);
		Mobile.clickElement(butDone);
		Mobile.switchButton(isOneTime);
		 String date = Mobile.getElementValue(textField);
		Reporter.logEvent(Status.INFO, " Select FDD option and Save details :", "Submisssion Date : "+ date +"\n OneTime switch option is set :"+isOneTime, true);

		Mobile.clickElement(butSave);
		
	
		return date;
		
	}
	
	/**
	 * Verify FDD details are save
	 * @param date
	 * @param isOneTime
	 */
	public void verify_FDD_Details_Are_Save(String date, Boolean isOneTime) {
		Mobile.clickElement(fddSelectOption);
		Mobile.verify_Element_Value(textField, date, "Verify FDD submission option selected should be saved as "+date);  
		if(isOneTime) {
		Mobile.verify_Element_Is_Selected(switchButton, "One Time  button should be selected" );
		}
		else {
			Mobile.verify_Element_Is_Not_Selected(switchButton, "One Time  button should not be selected" );
		}
		Mobile.clickElement(butSave);
		
	}
	
	
	/* This function is used to verify Functionality for Enter Contribution Type with different Differal Type
	 * 
	 */
	public void verifyEnter_Contribution_Rate(String defferalGroupType, String Contributing_type,String Contribution_type){	
	//	verifyButton_Name_In_Deferral_Group(defferalGroupType);
    	click_ContributionType_Edit_Add_Button(defferalGroupType);    
    	
    	select_Standard_Contribution_Page(Contributing_type, Contribution_type, UserBaseTest.getParaValue("contribution_Rate"));
    	
	}
	
	
	/* This function will verify Company match value when Rate is update
	 *   if the deferral rate is 3% and the company match rule is "50% on the first 6%", then we display a company match rate of 1.5% (which is 50% of 3%)
	 * 
	 */
	
	
	public void verifyCompanyMatchRate(int percentage ,int contribution_Rate ){
		DecimalFormat format = new DecimalFormat();
	       format.setDecimalSeparatorAlwaysShown(false);
	       Double rate = 6.0;
	       Double value = 0.0;	     	       
	       if(contribution_Rate < 6){
	    	   value = (double) (contribution_Rate * percentage/100);
	          }else{
	        	  value  = rate* percentage/100;
	          }  	
		String sValue = 	format.format(value) +"%";		
		System.out.println(format.format(value));
		  String COMAPNY_MATCH_RATE = "//XCUIElementTypeStaticText[@name='Apple Match:']/following-sibling::XCUIElementTypeStaticText[1]";       
	   Mobile.verifyElementPresent("Company match rate value should be  displayed", sValue, sValue);
	//	  Mobile.verify_Element_Value(COMAPNY_MATCH_RATE, sValue+"%", "Company match rate value displayed");
	      
		
	}
	
	
	public void verifyAdding_Company_Match(String contribution_Rate){
	 // String contribution_Rate = UserBaseTest.getParaValue("contribution_Rate") ;  
	  int rate = Integer.parseInt(contribution_Rate);	   
      enter_Contribution_Rate_PerCentage(contribution_Rate);      
 	
      String perCentage  = UserBaseTest.getParaValue("percentage");
   
      if(perCentage.equalsIgnoreCase("50")){
    	  String sMsg1 ="50% on the first 6% for 0-2 years of service";
    	  Mobile.verifyElementPresent(sMsg1+"\n should be displayed", sMsg1, sMsg1 +" \n");
    	  verifyCompanyMatchRate(50, rate);
    	  
      }
      else if(perCentage.equalsIgnoreCase("75")){
    	//  Mobile.verifyText(sObj, "75% on the first 6% for 2-5 years of service", true);
    	  String sMsg2 ="75% on the first 6% for 2-5 years of service";
    	  Mobile.verifyElementPresent(sMsg2+"\n should be displayed", sMsg2, sMsg2 +" \n");
    	  verifyCompanyMatchRate(75, rate);
      }
      else if (perCentage.equalsIgnoreCase("100")){
    	//  Mobile.verifyText(sObj, "100% on the first 6% for 5 years of service or more", true);
       	  String sMsg2 ="100% on the first 6% for 5 years of service or more";
    	  Mobile.verifyElementPresent(sMsg2+"\n should be displayed", sMsg2, sMsg2 +" \n");
    	  verifyCompanyMatchRate(100, rate);
      }
   
       
      
    
       
   //    "50% on the first 6% for 0-2 years of service"
         
	}
	
	
	public void verifyButton_Name_In_Deferral_Group(String defferalGroupType){	
		
		  String sObj ="";
		  String sButtonType ="";
		  if(isApplePlan){
			  if(defferalGroupType.equals(STANDARD)){
				  defferalGroupType =BASE_PAY; 
			  }
		  }
		  
	//	  if(elective_deferral_deleated){
		   sButtonType = ADD_BUT;   
		   sObj = "//XCUIElementTypeStaticText[@name='"+defferalGroupType+"']/preceding-sibling::XCUIElementTypeButton[contains(@name,'"+sButtonType+"')]";
//		   if(defferalGroupType.equals(BONUS)){
//			   Mobile.scroll_Down();
//		   }
		   
//		   
//		   if(!Mobile.assertElementPresent(By.xpath(sObj))){	
//		   //  	Reporter.logEvent(Status.INFO,"Pre Condition :",defferalGroupType + "  should contain Add button",false);	
//				click_ContributionType_Edit_Add_Button(defferalGroupType);  
//				String Contributing_RateType ="//XCUIElementTypeButton[@name='"+CONTRIBUTING_RATE_TYPE+"']";
//				MobileElement contriBut = Mobile.findElement(Contributing_RateType);
//	        //     Common.waitTillElementDisplay(By.xpath(Contributing_RateType))  ;
//	             String value = Mobile.getElementValue(contriBut);
//	             System.out.println("Value   ====="+value);
//	             if(value != null){
//	            	 if(!value.equals("true")){
//	            			Mobile.clickElement(contriBut);	
//	            	 }
//	             }else{
//	            	 Mobile.clickElement(contriBut);	 
//	             }			
//	            Reporter.logEvent(Status.INFO,"Enter Value 0 in Enter Contribution Rate and click continue"," Add button is displayed for " +defferalGroupType,false);	
//	    		Mobile.setEdit(ENTER_CONTRIBUTION_TEXTFILED,"0");			
//				Mobile.clickElement(CHECK);
//				Mobile.wait(1000);
//				if(Mobile.assertElementPresent(By.className(ALERT_MSG))){
//					Mobile.clickElement("Confirm");
//				}
//			    Mobile.clickElement(CONTINUE_BUT);	
//				
//		   }		   
//		  }else{
//			     sButtonType =EDIT_ADD_BUT;
//				 sObj = "//XCUIElementTypeStaticText[@name='"+defferalGroupType+"']/following-sibling::XCUIElementTypeStaticText[@name='EDIT / ADD']"; 
//		  }	 	   	  
		Mobile.verifyElementPresent(sButtonType +"  Button  for "+defferalGroupType+" is should be display." , sObj, sButtonType +"  Button name for "+defferalGroupType);
	}
	
	
	
	
	
	public void update_MyAnnual_Compensation_Salary(String sContributingType,String Contribution_type){		
		getContributing_Salary_and_Rate_Value_OnFile(sContributingType,MAXIMIZE_LIMIT);			
		Mobile.clickElement(MY_ANNUAL_AMOUNT);
		String sExpAmount =UserBaseTest.getParaValue("UpdateSalary");
		enterAnnualCompensationAmount(sExpAmount);
		Mobile.clickElement(UPDATE_BUT);		
		Common.waitForProgressBar();	
		verify_Annual_Compensation_Amount_IsUpdated(getContributionSalary(),true);		
		verify_Maximizer_perPay_Period_Value_Updated(MAXIMIZE_LIMIT, getContributionPerPayPeriod(),true);
		Mobile.verify_Element_Is_Not_Selected(MAXIMIZE_SWITCH, "Maximize switch should be  OFF");		
		//Mobile.verify_Element_Value(PPC_TOOLTIP_MSG_XPATH, MAXIMIZE_LIMIT_MANUALLY_MSG, "Maximizer Me Always  Message displayed");
		Mobile.verifyText(PPC_TOOLTIP_MSG_XPATH, MAXIMIZE_LIMIT_MANUALLY_MSG, false);		
		Mobile.scroll_Down();		
		
		Mobile.clickElement(CONTINUE_BUT);
		Common.waitForProgressBar();
		selectRadioButton(Contribution_type);
		Mobile.clickElement(CONTINUE_BUT);
		Common.waitForProgressBar();
		
	}
	
	
	private static void selectRadioButton(String Contribution_type){
		
		 if(Contribution_type.equalsIgnoreCase(CATCH_UP_BEFORE)){			   
			   if(getApplePlan()){
				   Contribution_type =APPLE_CATCH_UP_BEFORE;
			   }
			 
		   }
		   else if(Contribution_type.equalsIgnoreCase(CATCH_UP_ROTH)){			   
			   if(getApplePlan()){
				   Contribution_type =APPLE_CATCH_UP_ROTH;
			   }
		   }
		   else if(Contribution_type.equalsIgnoreCase(BEFORE_TAX)){			   
			   if(getApplePlan()){
				   Contribution_type =APPLE_BEFORE_TAX;
			   }
		   }
		 
		 Mobile.selectRadioButton(Contribution_type);
	}
	
	
	
	public void verify_Maximizer_perPay_Period_Value_Updated(String sContributingType,String sValueOnFile,Boolean sUpdated){	
		String sCatch_perPay_Update = get_MyContribution_PerPay_Period(sContributingType);
		if(sUpdated){
		if(!sValueOnFile.equals(sCatch_perPay_Update))
			Reporter.logEvent(Status.PASS, "Maximizer Per Pay Period should be updated :","Updated : Per Pay Period "+sCatch_perPay_Update +" \n On File  was :"+sValueOnFile, false);
			else
		    Reporter.logEvent(Status.FAIL, "Expected Updated Maximizer Per Pay Period  " ,"But it was not updated and  was :  "+sValueOnFile, true);
		}
		else{
			if(sValueOnFile.equals(sCatch_perPay_Update))
			Reporter.logEvent(Status.PASS, "Per Pay Period should be same as On File: ",sCatch_perPay_Update, false);
			else
		    Reporter.logEvent(Status.FAIL, "Expected Per Pay Period Value to be  :  "+sValueOnFile ,"But Actual was:  "+sCatch_perPay_Update, true);

			
		}
	}
	
	public void verify_MyContributions_Rate_Percentage_Update(String sContributingType,String sValueOnFile,Boolean bUpdated){	
	       if(getApplePlan()){
	    	  if(sContributingType.equals(STANDARD)){
	    		  sContributingType= BASE_PAY;
	    	  }
	       }
		
		String rate = get_MyContribution_Rate(sContributingType);
		if(!rate.equals("")){
		if(bUpdated ){
			if(!sValueOnFile.equals(rate))
				Reporter.logEvent(Status.PASS, "Contributing Rate in Shopping cart page for "+sContributingType+" should be updated" ,"Updated Contribution Rate :  "+rate +"\n On File Rate was :"+sValueOnFile, true);
				else
			    Reporter.logEvent(Status.FAIL, "Expected My Contributng Rate for "+ sContributingType+" to be updated","But it was not updated and  was :  "+sValueOnFile, true);
			}
			else{
				if(sValueOnFile.equals(rate))
				Reporter.logEvent(Status.PASS, "My Contributing Rate for "+sContributingType+" is same as On File:"+sValueOnFile ,"", true);
				else
			    Reporter.logEvent(Status.FAIL, "Expected My Contributing Rate  Value :  "+sValueOnFile ,"But Actual was:  "+rate, true);

				
			}
		}else{
			  Reporter.logEvent(Status.FAIL, "My Contributing Rate  Value  for  : "+sContributingType + " is not present","" , true);

		}
	}
	
	public void verify_Maximizer_Rate_Value_Updated(String sContributingType,String sValueOnFile,Boolean sUpdated){	
		String sCatch_rate_Update = get_MyContribution_Rate(sContributingType);
		  setContributionRate(sCatch_rate_Update);
		if(sUpdated){
		if(!sValueOnFile.equals(sCatch_rate_Update))
			Reporter.logEvent(Status.PASS, " Maximizer Rate  should be updated for :"+sContributingType ,"Maximizer Rate updated :" +sCatch_rate_Update+ "\n On File Rate was  :"+sValueOnFile, false);
			else
		    Reporter.logEvent(Status.FAIL, "Maximizer Rate  should be updated for :"+sContributingType ,"Expected was not to have  :"+sValueOnFile+ "But Actual was :  "+sCatch_rate_Update, true);
		}else{
			if(sValueOnFile.equals(sCatch_rate_Update))
				Reporter.logEvent(Status.PASS, "Maximizer rate value should be  same as On File :" ,sValueOnFile, false);
				else
			    Reporter.logEvent(Status.FAIL, "Maximizer rate value  should be same as On File :  "+sValueOnFile ,"But Actual was:  "+sCatch_rate_Update, true);

		}
		
	}
	
	
	
	
	
	
	/*
	 * This method will get Salary and Rate details 
	 */
	public void getContributing_Salary_and_Rate_Value_OnFile(String sContributingType,String sContributionType ){	
		if(sContributingType.equals(STANDARD)){
		click_ContributionType_Edit_Add_Button(sContributingType,sContributionType);
	
	    setContributionSalary(getMy_Annual_Compensation_Amount());	 	
	    setContributionRate(get_MyContribution_Rate(sContributionType));   
	    setContributionPerPayPeriod(get_MyContribution_PerPay_Period(sContributionType));
	    Reporter.logEvent(Status.INFO, "Standard Rate and Salary on File ", "Contribution Rate : " +getContributionRate()+ "\n Per Pay Period : "+ getContributionPerPayPeriod() +"\n My Annual Compensation : "+getContributionSalary(), false); 
		
		}
		else if(sContributingType.equals(CATCH_UP)){
			click_ContributionType_Edit_Add_Button(CATCH_UP,sContributionType);	
			setContributionRate(get_MyContribution_Rate(sContributionType));   
		    setContributionPerPayPeriod(get_MyContribution_PerPay_Period(sContributionType));
			Reporter.logEvent(Status.INFO, "Catch Up Rate and Salary on File ", "Contribution Rate :  " +getContributionRate()+ "\n Per Pay Period :  "+ getContributionPerPayPeriod(), false); 
			Mobile.clickElement(CONTINUE_BUT);
			selectRadioButton(CATCH_UP_BEFORE);
			Mobile.clickElement(CONTINUE_BUT);
		}
		if(Mobile.assertElementPresent(By.name(ADD_AUTO_INCREASE_PAGE))){
			Mobile.clickElement(CONTINUE_BUT);
		}
	 
	}
	/*
	 * This method will verify 
	 */
	
	public void verify_My_Contribution_Salary_and_Rate_Value(String sContributionType,String sContributingType ){			
		click_ContributionType_Edit_Add_Button(sContributionType,sContributingType);
	    setContributionSalary(get_MyContribution_PerPay_Period(sContributingType));	 	
	    setContributionRate(get_MyContribution_Rate(sContributingType));   
	    if(sContributingType.equals(MAXIMIZE_LIMIT))
	         Mobile.scroll_Down();
		
	}
	
	public String getMy_Annual_Compensation_Amount(){
		return Mobile.getElementValue(MY_ANNUAL_AMOUNT);
	}
	
	  public String  get_MyContribution_PerPay_Period(String sContributingType){
		  try{
		  String sSalary  ="";
		  String sObj="per pay period";
		//  String sObj_salary = "//XCUIElementTypeStaticText[@name='"+sContributingType+"']/following-sibling::*/XCUIElementTypeStaticText[2]"; 	
		   // sSalary = Mobile.getElementValue(sObj_salary) ;
		    MobileElement ele =  Mobile.findElementWithPredicate(sObj);
		    	if(ele != null)	{
		    		sSalary = ele.getAttribute("value") ;
		    	}	    		
		    
		    if(sSalary != null){
		    	 return sSalary;
		    }
		  }catch(NoSuchElementException e){
			  Reporter.logEvent(Status.FAIL," Pay Period label should be present.", "Not able to find Per Pay Period label", true);
		  }
		 return "";
	  }
	

	
	
	
	
	public void verify_Maximizer_Limit_Option_Display(){
		
		
	}
	
	
	public void verify_Catch_Up_Option_Display_In_SelectionPage(){		

		String[] radioOptions={MAXIMIZE_LIMIT,ENTER_CONTRIBUTION_RATE};
		Common.verify_Value_InList_Contain(STATIC_TEXT_FIELD, radioOptions, "Catch -UP Contributing Type  should be  display");
			
	}
	public void verify_Maximize_Limit_Rate_Display(){
		Mobile.verifyText(MAXIMIZE_RATE_VALUE, "%", " Maximize Limit Rate Value should be displayed in percentage ",false);
	}
	
	/*
	 * This method will click the toolTp and verify message and close toolTip
	 */
		
	public void verifyToolTip(String locator,String sMsg) throws InterruptedException{
		
		IOSElement ele = Mobile.findElement(locator);
		if (ele != null) {
			ele.click();
			
		//Mobile.verifyText(TOOLTIP_MSG_TEXT, sMsg, true);
		Mobile.verifyElementPresent("Verify ToolTip message should be displayed", sMsg, sMsg);	
		Mobile.clickElement("PopoverDismissRegion");	
		}else{
			Reporter.logEvent(Status.FAIL,"  Not Display Tool Tip   ","Not able to find Tool Tip Element",true);
		}		
		}
	
	/*
	 * This method will verify the Edit Content of PPC
	 */
	
	public void verify_PPC_Edit_Content_Display(){	
		String[] radioOptions={PPC_EDIT_LABEL_1,PPC_EDIT_LABEL_2,PPC_EDIT_LABEL_3};
		Common.verify_Value_InList_Contain(STATIC_TEXT_FIELD, radioOptions, "PPC Page Content  should  display");	
	}
	
	/*
	 * verify_PPC_EditTextBox_Default_Value
	 */
	public void verify_PPC_EditTextBox_Value(String sExpValue) {
		String sActValue = Mobile.getElementValue(PPC_TEXTFIELD);
		if (sExpValue.equals("")){
			if(sActValue == null || sActValue.equals("0.00")) 
			 {
				Reporter.logEvent(
						Status.PASS,
						"Default Value in Year to date Contribution textBox",
						"Year to date Contribution textBox is empty for first time", false);
			} else {
				Reporter.logEvent(Status.FAIL,
						" Expected Default value to be empty ", "But was"
								+ sActValue, true);

			}

		}
		else {
			sExpValue=sExpValue+".00";
			sActValue = sActValue.replace(",", "");
			if (sActValue != null && sExpValue.equals(sActValue)) {
				Reporter.logEvent(Status.PASS,
						"Value in  PPC Edit Box is same", sExpValue +" Value is displayed in Year to date Contribution textBox", false);
			} else {
				Reporter.logEvent(Status.FAIL, " Expected Value :" + sExpValue,
						"But was :" + sActValue, true);
			}

		}
	}
	
	
	/*
	 * verify_PPC_EditTextBox_Default_Value
	 */
	public void verify_PPC_Catch_UP_EditTextBox_Value(String sExpValue) {
		String sActValue = Mobile.getElementValue(PPC_CATCH_UP_EDIT);
		if (sExpValue.equals("")) {
			if (sActValue == null || sActValue.equals("0.00")) {
				Reporter.logEvent(
						Status.PASS,
						"Default Value in Catch Up Contribution textBox",
						"Catch Up Contribution textBox is empty for first time", false);
			} else {
				Reporter.logEvent(Status.FAIL,
						" Expected Default value to be empty ", "But was"
								+ sActValue, true);

			}

		} else {
			sExpValue=sExpValue+".00";
			if (sActValue != null && sExpValue.equals(sActValue)) {
				Reporter.logEvent(Status.PASS,
						"Catch Up Contribution textBox is same", sExpValue +" Value is displayed in Catch Up Contribution textBox", false);
			} else {
				Reporter.logEvent(Status.FAIL, " Expecte Value :" + sExpValue,
						"But was :" + sActValue, true);
			}

		}
	}
	
	
	



	/*
	 * This method will verify the rate in MAXIMIZE TO COMPANY  TaxRAte
	 * Rate should be in percentage and Tax Type can be Before Tax and Roth type
	 */
	public void verify_Maximize_To_Company_Rate(String sCompany,String sExpRate){	
		sExpRate=sExpRate+"%";
		String sObj ="//XCUIElementTypeStaticText[@name='MAXIMIZE TO "+sCompany+" MATCH']/following-sibling::*/XCUIElementTypeStaticText[1]"; //   for 6%
		Mobile.verifyText(sObj, sExpRate,"Rate to be displayed in", false);
				
	}
	
	/*
	 * This method will verify the rate in MAXIMIZE TO COMPANY  TaxRAte
	 * Rate should be in percentage and Tax Type can be Before Tax and Roth type
	 */
	public String get_Maximize_To_Company_Rate(String sCompany){		
		String sObj ="//XCUIElementTypeStaticText[@name='MAXIMIZE TO "+sCompany+" MATCH']/following-sibling::*/XCUIElementTypeStaticText[1]"; //   for 6%
		
		String sValue ="";
		
		sValue =Mobile.getElementValue(sObj) ;
		
		if(sValue != null){
			sValue =sValue.replace("%","");
		}
		else{
			sValue ="";
		}		
	return sValue;	
				
	}
	
	
	/*
	 * This method will return Rate from My Contribution Page for Contibution Type
	 *
	 */
	public String get_MyContribution_Rate(String Contribution_type){	
		String sValue ="";
		String sObj ="";		
		      
		if(getApplePlan()){
			if(Contribution_type.equals(STANDARD))
			Contribution_type =BASE_PAY;
			 sObj ="//XCUIElementTypeStaticText[@name ='"+Contribution_type+"']/following-sibling::*//XCUIElementTypeStaticText[contains(@name,'%')]";					
				
		}	
		if(sObj.equals(""))	
			 sObj ="//XCUIElementTypeStaticText[contains(@name,'"+Contribution_type+"')]/following-sibling::*//XCUIElementTypeStaticText[contains(@name,'%')]";					
			 sValue = Mobile.getElementValue(sObj) ;
			 if(sValue == null){
				 sValue = Mobile.getElementValue(sObj) ;
			 }
			 
			if(sValue != null){
				sValue =sValue.replace("%","");
			}
			else{
				sValue ="";
			}		
		return sValue;				
	}
	
	
	public String getMyContributionsType1(String sContributingType){
		
		String sObj = "//XCUIElementTypeStaticText[@name='"+sContributingType+"']/following-sibling::*//*[contains(@name,'"+sContributingType+"')]";	
		return Mobile.getElementValue(sObj);
	}
	
	
	
	
	
	
	
	/*
	 * This method will verify the rate for Base Pay TaxType
	 * Rate should be in percentage and Tax Type can be Before Tax and Roth type
	 */
	public void verify_MyContributions_Rate_Percentage(String sTaxType,String sExpRate){	
		if(CONTRIBUTING_RATE_TYPE.equals("$")){
			sExpRate ="$"+sExpRate;
		}else{
		sExpRate =sExpRate+"%";
		}
	//	String sObj ="";
		MobileElement ele = Mobile.findElementWithPredicate(sTaxType);				
		//sObj ="//XCUIElementTypeStaticText[contains(@name,'"+sTaxType+"')]";
		Mobile.verifyElementPresent("Deferral Type : "+sTaxType+" should be display in Shopping Cart Page", ele, "Deferra Type "+sTaxType );
		Mobile.verifyElementPresent("Deferral Rate  : "+sExpRate+" should be displayed for "+sTaxType +" in Shopping Cart Page.", sExpRate, sExpRate+ " Deferra Rate  for Type "+sTaxType );
		
						
	}
	
	/*
	 * This method will verify the rate for Base Pay TaxType
	 * Rate should be in percentage and Tax Type can be Before Tax and Roth type
	 */
	public String  get_MyContribution_Rate_Percentage(String sTaxType){	
		String sObj ="//XCUIElementTypeStaticText[contains(@name,'"+sTaxType+"')]/following-sibling::*/XCUIElementTypeStaticText";
		return Mobile.getElementValue(By.xpath(sObj)) ;
				
	}
	
	
	/*
	 * This method will verify The Rate for  Selection Contribution Tax Type
	 * Rate should be in percentage and Tax Type can be Before Tax and Roth type
	 */
	public void verify_Select_Contribution_Rate(String sTaxType,String sExpRate){	
		String sObj = null;
		if(CONTRIBUTING_RATE_TYPE.equals("$")){
			sExpRate ="$"+sExpRate;
		}else{
		sExpRate =sExpRate+"%";
		}
		if(sTaxType.contains("SPLIT")){
			 sObj ="//XCUIElementTypeStaticText[contains(@name,'"+sTaxType+"')]/following-sibling::*/XCUIElementTypeStaticText";
			 Mobile.verifyText(sObj, sExpRate,sTaxType+ " Rate in split page should be displayed  "+sExpRate, false);
		}
		else {
			sObj ="//XCUIElementTypeStaticText[contains(@name,'"+sTaxType+"')]/following-sibling::*/XCUIElementTypeStaticText";			
			 Mobile.verifyText(sObj, sExpRate,sTaxType+ " Rate in split page should be displayed  "+sExpRate, false);
		}
				
	}
	
	
	/*
	 * This method will enter  Rate value in Split your Contribution section  for  Selection Contribution Tax Type
	 * Rate should be in number  and Tax Type can be Before Tax and Roth type
	 */
	
	public void enter_Split_Your_Contribution_Rate(String deferralType,String sTextValue) {			
		
			List<IOSElement> testBoxList =Mobile.getListOfElements_By_Class(TEXT_FIELD);	
			
		if(testBoxList.size() > 2){
		Mobile.setEdit(testBoxList.get(1), sTextValue);
		}else{
		Mobile.setEdit(testBoxList.get(0), sTextValue);
		}
		Mobile.clickElement(CHECK);	
	    Reporter.logEvent(Status.INFO, "Enter the value in  Split Option  for Deferral Type : "+deferralType, sTextValue +" is entered for deferral Type "+deferralType, false);
	
		
		String sBeforeLabel ="";
		String sRothLabel  ="";
		if(getApplePlan()){
			
			 sBeforeLabel  = Mobile.getElementValueByPredicate(APPLE_BEFORE_TAX_LABEL);
			sRothLabel  = Mobile.getElementValueByPredicate("Roth");	
			
		}else{
		 sBeforeLabel  = Mobile.getElementValueByPredicate("Before");	//Mobile.getElementValue("//XCUIElementTypeStaticText[contains(@name,'Before')]");
		sRothLabel  =  Mobile.getElementValueByPredicate("Roth");//Mobile.getElementValue("//XCUIElementTypeStaticText[contains(@name,'Roth')]");// Mobile.getElementValue("//*[@name='SPLIT YOUR CONTRIBUTION']/following-sibling::*//*[contains(@name,'Roth')]");
		}
	
		setLabelSplitContribution(sBeforeLabel,sRothLabel);		
		   String before_split_rate =Integer.toString((int)before_tax_split);		         
		   String roth_split_Rate =	Integer.toString((int)roth_split);
		
		   if(CONTRIBUTING_RATE_TYPE.equals("%")){
				if(getbMaximize_Me_Always()){
			//	CONFIRMATION_DEFERAL_TYPE =  CONFIRMATION_DEFERAL_TYPE +before_split_rate+" "+CONTRIBUTING_RATE_TYPE+ " " +sBeforeLabel+"(Maximize Me Always) "+roth_split_Rate+" "+ CONTRIBUTING_RATE_TYPE+" "+sRothLabel+" (Maximize Me Always)=";
				CONFIRMATION_DEFERAL_TYPE =  CONFIRMATION_DEFERAL_TYPE +before_split_rate+" "+CONTRIBUTING_RATE_TYPE+ " " +sBeforeLabel+"(Maximize Me Always)";
				
				}else
				CONFIRMATION_DEFERAL_TYPE =  CONFIRMATION_DEFERAL_TYPE +before_split_rate+" "+CONTRIBUTING_RATE_TYPE+ " " +sBeforeLabel+" "+roth_split_Rate+" "+ CONTRIBUTING_RATE_TYPE+" "+sRothLabel+"=";
		   }   else{
		        CONFIRMATION_DEFERAL_TYPE =  CONFIRMATION_DEFERAL_TYPE +CONTRIBUTING_RATE_TYPE+before_split_rate+" "+sBeforeLabel+" "+CONTRIBUTING_RATE_TYPE+" "+roth_split_Rate+ " "+sRothLabel+"=";
		 
			    }
	 
		
	}
	
	
	
	/*
	 * 
	 */
	
	public void verify_Shopping_Cart_Confirmation_Number(){
		String sObj = "//XCUIElementTypeStaticText[contains(@name,'Confirmation Number')]";
		String sNumber = Mobile.getText(sObj);
		if(sNumber != "" || sNumber != null ){
			if(!sNumber.isEmpty()){
				Reporter.logEvent(Status.PASS, "CONFIRMATION NUMBER is dsiplayed  ", sNumber, false);
		
			}else {
				Reporter.logEvent(Status.FAIL, "CONFIRMATION NUMBER  is empty", "CONFIRMATION NUMBER should not be empty", true);
			}
	
		}else {
			Reporter.logEvent(Status.FAIL, "CONFIRMATION NUMBER  is empty", "CONFIRMATION NUMBER should not be empty", true);
		}
		
		
		
	}

	public void clickConfirm_And_Continue(String sDeferralType){
		
		if(Mobile.assertElementPresent(By.name(CONFIRM_AND_CONTINUE_BUT))){
     		Mobile.scroll_Down();
     		Reporter.logEvent(Status.INFO, "Click CONTINUE and CONFIRMATION Button", " Verify Confirmation Page", true);
     		 
     		Mobile.clickElement(CONFIRM_AND_CONTINUE_BUT);
         	verify_Confirmation_Page("",sDeferralType);    		
 		    }else{
 		    	Reporter.logEvent(Status.WARNING, "Deferral Change Type was same as previous value", "CONTINUE and CONFIRMATION Button was not displayed", true);
 		    }
     	   
	}
	
	
	/*
	 * This method will verify Confirmation Number for Tax reate
	 * Will print confirmation number in report reuslt
	 * 6% Before Tax
	 * 6% Before Tax
	 */
	
	
	public void verify_Confirmation_Page(String sExpPlanLabel,String sConfirmation_DeferraTypes){	
				
		clickAlertMessage();			
		Common.waitTillElementNotDisplay(CONFIRMING_BUT);
		String error_Msg="An error has occurred. Please contact a Participant Services Representative.";
		if(!Mobile.assertElementPresentByAccessibilityId(error_Msg) || Mobile.assertElementsPresent(RETURN_TO_MY_CONTRIBUTIONS_BUT) )
		{	
			
	    Reporter.logEvent(Status.INFO, "Confirmation Page is displayed","", true);						
		String[] deferralTypeInConfirmation =  sConfirmation_DeferraTypes.split("=");
		
		 IOSElement ele = Mobile.findElement(CONFIRM_CONTRIBUTIONS_TEXT);
		 String sActText =null;
		if (ele != null) {
		 sActText = ele.getText();
		}
				
		for (String type : deferralTypeInConfirmation) {
			
			if(sActText.replaceAll("\\n", "").replaceAll(" ","").trim().toLowerCase().contains(type.replaceAll(" ","").trim().toLowerCase()))
					Reporter.logEvent(Status.PASS, "Contribution confirmation Page  should display",type, false);
				else
					Reporter.logEvent(Status.FAIL, "Expected in Confirmation Page was  :" +type ,"But Actual was :"+sActText, false);
		      
		
//				 Common.verify_Value_InList_Contain("XCUIElementTypeStaticText", deferralTypeInConfirmation, "Contribution confirmation page contain");
	//		Mobile.verifyText(CONFIRM_CONTRIBUTIONS_TEXT,type,"Contribution detail contain", false);
			
		}
		CONFIRMATION_DEFERAL_TYPE ="";
			
			if(getbMaximize_Me_Always()){
				 Mobile.verifyText(CONFIRM_CONTRIBUTIONS_TEXT, "Maximize Me Always"," Maximize Me Always text content should be displayed in Cntribution Details", false);
					
			 }else{
				 Mobile.verify_Text_Is_Not_Displayed(CONFIRM_CONTRIBUTIONS_TEXT, "Maximize Me Always is not displayed","Maximize Me Always should not be displayed in Contribution Detail", false);
				 
			 }					
			String sNumber = Mobile.getText(CONFIRM_NUMBER);
			String sPlan = Mobile.getText(CONFIRM_PLAN_TEXT);
			
			if(sPlan != null){
			if(!sPlan.equals("")){
				Reporter.logEvent(Status.PASS, "Confirmation Page should display Plan details  ", sPlan, false);
			}else{
				Reporter.logEvent(Status.FAIL, "Confirmation Page should display Plan details  ", "Plan in Confirmation page is empty", false);
				
			}
			}else{
				Reporter.logEvent(Status.FAIL, "Confirmation Page should display Plan details  ", "Plan in Confirmation page is empty", false);
				
			}
			
			
			if(sNumber != "" || sNumber != null ){
				if(!sNumber.isEmpty()){
					Reporter.logEvent(Status.PASS, "CONFIRMATION NUMBER is  ", sNumber, false);
			
				}else {
					Reporter.logEvent(Status.FAIL, "Confirmation Number not generated", "Confirmation Number should be generated", true);
				}
		
			}else {
				Reporter.logEvent(Status.FAIL, "Confirmation Number not generated", "CONFIRMATION NUMBER should not be empty", true);
			}
		
			Reporter.logEvent(Status.INFO,"Click RETURN TO MY CONTRIBUTIONS Button  ","Shopping cart page is displayed",false);
			Mobile.clickElement(RETURN_TO_MY_CONTRIBUTIONS_BUT);
		Common.waitForProgressBar();	
		}
		else{
			Reporter.logEvent(Status.FAIL, "Confirmation Page is not displyed","" , true);
			CONFIRMATION_DEFERAL_TYPE ="";
			Mobile.scroll_UP();
		}
	}
	
	
	/*
	 * 
	 */
	
	public void regular_Maximizer_Me_Always(Boolean status ){		
		
		Boolean  present = false;
		if(Mobile.assertElementPresent(By.name(STANDARD_MAXIMIZE_ME_ALWAYS))){
			present = true;
		}
		
		
		
		if(status){
			if(!present){
				click_ContributionType_Edit_Add_Button(STANDARD, MAXIMIZE_LIMIT);
				Mobile.clickElement(MY_ANNUAL_AMOUNT);
				if(Mobile.is_Element_Enable(RESET_BUT)){
				Mobile.clickElement(RESET_BUT);						
				Common.waitForProgressBar();	
				}else{
					Mobile.clickElement(CLOSE);
				}
				Mobile.switchButton( status);
				Common.clickContinueButon();
				if(!Mobile.is_Element_Enable(CONTINUE_BUT))
					selectDeferralType();
				Mobile.clickElement(CONTINUE_BUT);
			}
			
		}else{
			if(present){
				click_ContributionType_Edit_Add_Button(STANDARD, MAXIMIZE_LIMIT);
				Mobile.switchButton(status);
				Common.clickContinueButon();
				if(!Mobile.is_Element_Enable(CONTINUE_BUT))
					selectDeferralType();
				
				Mobile.clickElement(CONTINUE_BUT);
				
			}
			
		}
		if(status){
		Reporter.logEvent(Status.INFO,"Pre Set up : ","Participant has selected Maximize Me Always from standard contributions.",false);
		}
		
		setMaximize_Me_Always(status);
		
	}
	

	/*
	 * Method to add Fund from Review Change Page Return String
	 */

	private void selectDeferralType() {
		List<IOSElement> eleList = Mobile
				.getListOfElements_By_Class("XCUIElementTypeImage");
		for (IOSElement iosElement : eleList) {
			System.out.println(iosElement.getAttribute("name"));
			if (!iosElement.getAttribute("name").equalsIgnoreCase(
					"tick-mark_gray")) {
				iosElement.click();
				break;
			}
		}
	
	}
	
	public void verifyMaximize_Me_Always_Diplayed(String sContributingType, Boolean bFlag){
		if(isApplePlan){
			sContributingType =BASE_PAY;
		}
		String sObj = "Maximize Me Always";	
		if(bFlag)
		Mobile.verifyElementPresent(sContributingType +" contain " , sObj, "Maximizer Me  Always text is displayed");
		else
		Mobile.verifyElementNotPresent(sContributingType +" contain " , sObj, "Maximizer Me  Always text is not displayed");	
	}
	
	
	
	public void verify_IRS_Contribution_Limit_Displayed(){		
		String sObj = "//XCUIElementTypeStaticText[@name='The "+currentYear+" IRS contribution limit:']/following-sibling::XCUIElementTypeStaticText";	
		 String sValue =Mobile.getElementValue(sObj);
		 if(sValue != null ){
			 if(!sValue.isEmpty())
				 Reporter.logEvent(Status.PASS,"IRS Contribution Limit should be displayed  ", sValue,false);		 
		 }
		 else{
			 Reporter.logEvent(Status.FAIL,"IRS Contribution Limit should be displayed", "IRS Contribution Limit Value is not displayed",false); 
		 }
	
	}
	
	public void setSplitContributionValue( String contributionRate){		
		if(contributionRate != null){
			if(isViewOnlyDeferralType()){
				contributionRate = Integer.toString(Integer.parseInt(UserBaseTest.getParaValue("contribution_Rate")) -Integer.parseInt(viewOnlyRate));	
			}
		float irs_limit=(float) Float.parseFloat(contributionRate);
		before_tax_split =Float.parseFloat(UserBaseTest.getParaValue("before_tax_ratio"))*irs_limit;
		roth_split =Float.parseFloat(UserBaseTest.getParaValue("roth_ratio"))*irs_limit; 
		}
	}
	
	private void setLabelSplitContribution(String split_before_labelValue,String split_roth_labelValue ){
		if(split_before_labelValue != null || split_roth_labelValue != null){
		split_before_label = split_before_labelValue.toUpperCase();
		split_roth_label =split_roth_labelValue.toUpperCase();
		}
	
	}
	
		
	public void  select_Contribution_Details(String shoppingCartType, String Contributing_type,String Contribution_type){
		click_ContributionType_Edit_Add_Button(shoppingCartType);		
	 	Reporter.logEvent(Status.INFO,"Select  "+Contributing_type+"  ->  "+Contribution_type,"Click  Continue button to return Shopping cart page",false);
		Assert.assertTrue(Mobile.assertElementPresent(By.name(Contributing_type)), Contributing_type +"  : Contribution Type Option is not displayed");			 
		String contribution_Rate = null;			
		Mobile.clickElement(Contributing_type);	
		Mobile.wait(2000);
		if(Contribution_type.equals(SPLIT)){
		     contribution_Rate = get_MyContribution_Rate_Percentage(MAXIMIZE_LIMIT);
		 	Reporter.logEvent(Status.INFO,"Contribution Rate when Deferral is split option",contribution_Rate,false);
		 	  contribution_Rate = contribution_Rate.replace("%", "");
		     contribution_Rate = contribution_Rate.split("\\.")[0];
		  	     
			}
		if(Contributing_type.equals(MAXIMIZE_LIMIT) && shoppingCartType.equals(CATCH_UP)){		
		if(getbMaximize_Me_Always()){
			Mobile.switchButton(true);
		}
		else{
			Mobile.switchButton(false);
		}
		}
		  
		 Common.clickContinueButon();	
		 if(!Contribution_type.equals("")){
		 
		 if(Contribution_type.equalsIgnoreCase(CATCH_UP_BEFORE)){			   
			   if(getApplePlan()){
				   Contribution_type =APPLE_CATCH_UP_BEFORE;
			   }
			 
		   }
		   else if(Contribution_type.equalsIgnoreCase(CATCH_UP_ROTH)){			   
			   if(getApplePlan()){
				   Contribution_type =APPLE_CATCH_UP_ROTH;
			   }
		   }
		   else if(Contribution_type.equalsIgnoreCase(BEFORE_TAX)){			   
			   if(getApplePlan()){
				   Contribution_type =APPLE_BEFORE_TAX;
			   }
		   }
		 
		 
		 
		 Mobile.selectRadioButton(Contribution_type);	
		 
		 if(Contribution_type.equals(SPLIT)){		 
		
			 setSplitContributionValue(contribution_Rate);	
		    	
	        String  before_split_rate =Integer.toString((int)before_tax_split);		         
	    	String roth_split_Rate =	Integer.toString((int)roth_split);     
	      	      	  
	       	if(getApplePlan()){
	       	    
	    		List<IOSElement> testBoxList =Mobile.getListOfElements_By_Class(TEXT_FIELD);
	    		Mobile.setEdit(testBoxList.get(0), "1000");	
	    		//DDTC-27902 QA-Contributions - Maximizer-Split rate page - Enter value more than deferral rate
	    		String sWarMessage = null;
	    		 IOSElement ele = Mobile.findElementWithPredicate("Your split contributions must add up to");
	    		  if(ele != null){
	    			  sWarMessage ="Your split contributions must add up to ";
	    			  Reporter.logEvent(Status.PASS,"Enter  value more than maximizer Rate : 1000" ,sWarMessage +" is Displayed " ,false);
	    		  }
	    	    			  
	    		  else if(shoppingCartType.equals(CATCH_UP)){	    			
	    		sWarMessage = "Contributions for Catch Up Traditional 401(k) must be no more than 75%.";
	    		Mobile.verifyElementPresent("Enter  value more than maximizer Rate : 1000" , sWarMessage, "validation should be performed with message:\n"+sWarMessage);
		    	
	    			    		    	
	    		}else{
	    		 sWarMessage = "Contributions for Base Pay Traditional 401(k) must be no more than 75%.";
	    			Mobile.verifyElementPresent("Enter  value more than maximizer Rate : 1000" , sWarMessage, "validation should be performed with message:\n"+sWarMessage);
	    	    	
	    		}
	    		Mobile.clickElement(CHECK);		
	       		
	       	enter_Split_Your_Contribution_Rate("Traditional",before_split_rate );
	    	// enter_Split_Your_Contribution_Rate(APPLE_BEFORE_TAX_LABEL,before_split_rate );
	    	 
	       	}
	       	else{
	    	 enter_Split_Your_Contribution_Rate("Before",before_split_rate );
	       	}
	    	    	
		 }
		 
		 Mobile.clickElement(CONTINUE_BUT);		 
		 Common.waitForProgressBar();
		 
		 if(Contributing_type.equals(ENTER_CONTRIBUTION_RATE)){
			 Mobile.clickElement(CONTINUE_BUT);	
		 }	 
		 
		 }
		 
		
	}	
	
	
	/*
	 * This method willselct Contribution Details and verify  
	 */
	
	public void select_Standard_Contribution_Page(String Contributing_type,String Contribution_type,String contribution_Rate){
	  	String before_split_rate  = "";
    	String roth_split_Rate  ="";    	
		Boolean bEnter_Conter_Rate =false;
		
		Assert.assertTrue(Mobile.assertElementPresent(By.name(Contributing_type)), Contributing_type +"  : Contribution Type Option is not displayed");			 
		if(Contributing_type.equalsIgnoreCase(ENTER_CONTRIBUTION_RATE)){
			bEnter_Conter_Rate =true;
		}				
		 String sTaxLabel = null;
	 
	
	    	Mobile.clickElement(Contributing_type);		
	    	Reporter.logEvent(Status.INFO,"Contributing Type Selected ",Contributing_type,false);
	    	
	    	if(bEnter_Conter_Rate){
				enter_Contribution_Rate_PerCentage(contribution_Rate);
				contribution_Rate = contrbution_rate;
			}	
	    		    			
		   if(Contribution_type.equalsIgnoreCase(BEFORE_TAX)){	
			   if(getApplePlan()){
				   Contribution_type =APPLE_BEFORE_TAX;
			   }
			   
			   if(getbMaximize_Me_Always()){
				   sTaxLabel ="Before Tax(Maximize Me Always)";  
			   }else{
				   sTaxLabel ="Before Tax";
			   }			  
		   }
		   else if (Contribution_type.equalsIgnoreCase(ROTH)){	
			   if(getbMaximize_Me_Always()){
				   sTaxLabel ="Roth(Maximize Me Always)";  
			   }else{
				   sTaxLabel ="Roth";
			   }
			   sTaxLabel ="Roth";			   
		   }else if (Contribution_type.equalsIgnoreCase(SPLIT)){	

			   setSplitContributionValue(contribution_Rate);
			   sTaxLabel =  before_tax_split+"% Before Tax "+roth_split+"% Roth";	   
			 
				   
		   }else if(Contribution_type.equalsIgnoreCase(CATCH_UP_BEFORE)){
			   
			   if(getApplePlan()){
				   Contribution_type =APPLE_CATCH_UP_BEFORE;
			   }
			   if(getbMaximize_Me_Always()){
				   sTaxLabel ="Catch-Up Before(Maximize Me Always)";  
			   }else{
			   sTaxLabel ="Catch-Up Before";
			   }
			   
		   }
		   else if(Contribution_type.equalsIgnoreCase(CATCH_UP_ROTH)){
			   
			   if(getApplePlan()){
				   Contribution_type =APPLE_CATCH_UP_ROTH;
			   }
			   if(getbMaximize_Me_Always()){
				   sTaxLabel ="Catch-Up Roth(Maximize Me Always)";  
			   }else{
				   sTaxLabel ="Catch-Up Roth";
			   }
			   
		   }else if(Contribution_type.equalsIgnoreCase(CATCH_UP_SPLIT)){
			   setSplitContributionValue(contribution_Rate);		
			   if(getbMaximize_Me_Always()){
				   sTaxLabel =  before_tax_split+"% Catch-Up Before(Maximize Me Always)"+roth_split+"% Catch-Up Roth(Maximize Me Always)";
			   }else{
				   sTaxLabel =  before_tax_split+"% Before Tax "+roth_split+"% Roth";				
			   }		   
		   }	  
		   
		 

				 
			
			if(Contributing_type.equals(MAXIMIZE_LIMIT)){
				 Common.clickContinueButon();
			}
			else{
				Mobile.clickElement(CONTINUE_BUT);
			}
			
			
		   if(!Contribution_type.equals("")){
		 	
		    Mobile.selectRadioButton(Contribution_type);
			
		  
		    if(Contribution_type.equalsIgnoreCase(SPLIT) || Contribution_type.equalsIgnoreCase(CATCH_UP_SPLIT)){
		    			    	
		         before_split_rate =Integer.toString((int)before_tax_split);		         
		    	 roth_split_Rate =	Integer.toString((int)roth_split);
		     
		       	if(isViewOnlyDeferralType()){		       		
		    		Mobile.verifyElementISDisable(CONTINUE_BUT, "Continue Button is disable");
		    		String sObj ="//XCUIElementTypeStaticText[@name='SPLIT YOUR CONTRIBUTION']/following-sibling::*//*[contains(@name,'Roth')]/preceding-sibling::XCUIElementTypeTextField";
		    	    Mobile.verify_Element_Value(sObj, "0", "Default rate value should be 0");		    		
		    		Mobile.setEdit(sObj, roth_split_Rate);
		    	    Reporter.logEvent(Status.INFO, "Value entered in Split Option  for Deferral Type : Roth", roth_split_Rate, false);
		    		Mobile.clickElement(CHECK);
		    	
		    	}		       	
		  
		       	if(getApplePlan()){
		       	 enter_Split_Your_Contribution_Rate("Traditional",before_split_rate );
		    	 //enter_Split_Your_Contribution_Rate(APPLE_BEFORE_TAX_LABEL,before_split_rate );
		       	}
		       	else{
		    	 enter_Split_Your_Contribution_Rate("Before",before_split_rate );
		       	}
		    	    	
		    }
		    else{
		 //   verify_Select_Contribution_Rate(Contribution_type, contribution_Rate);	
		    if(CONTRIBUTING_RATE_TYPE.equals("%"))
		    CONFIRMATION_DEFERAL_TYPE = CONFIRMATION_DEFERAL_TYPE +contribution_Rate+ " "+CONTRIBUTING_RATE_TYPE+ " "+Mobile.getElementValue("//*[contains(@name,'"+Contribution_type+"')]")+"=";
		    else{
		    CONFIRMATION_DEFERAL_TYPE = CONFIRMATION_DEFERAL_TYPE +CONTRIBUTING_RATE_TYPE+contribution_Rate+ " " +Mobile.getElementValue("//*[contains(@name,'"+Contribution_type+"')]")+"=";
		 		 
		    }		    
		    } 
		   }
		   
		   if(Mobile.is_Element_Displayed(By.name(CONTINUE_BUT))){			
		    Mobile.clickElement(CONTINUE_BUT);
			 Common.waitForProgressBar();
		   }
	
		 	if(Mobile.is_Element_Displayed(By.name(ADD_AUTO_INCREASE_PAGE))){
		 		Mobile.clickElement(CONTINUE_BUT);	
		 		 Common.waitForProgressBar();
		 	}	
		 	
		  //  verifyHomePage(MY_CONTRIBUTION);
		    
		    if(!Contribution_type.equals("")){
		    if(Contribution_type.equalsIgnoreCase(SPLIT)){		    	
		    	verify_MyContributions_Rate_Percentage(split_before_label,before_split_rate);   
		    	//Uncomment : Change int to double
		    	//verify_MyContributions_Rate_Percentage(split_roth_label, roth_split_Rate);		    
		    }		    
		    else{
		    	verify_MyContributions_Rate_Percentage(Contribution_type, contribution_Rate);   
		    //	CONFIRMATION_DEFERAL_TYPE = contribution_Rate+"% "+sTaxLabel;
		    }   
		    }   	   
		    
		    if(bVerifyConfirmation){
		    Reporter.logEvent(Status.INFO,"Click CONFIRM & CONTINUE Button  ","Confirmation Page is display with expected Value",false);
		    Mobile.scroll_Down();
		    if(Mobile.assertElementPresent(By.name(CONFIRM_AND_CONTINUE_BUT))){
		        Mobile.clickElement(CONFIRM_AND_CONTINUE_BUT);			    
			verify_Confirmation_Page(APPLE_PLAN,CONFIRMATION_DEFERAL_TYPE);	
		    }else{
		    	Reporter.logEvent(Status.FAIL, "Deferral Change Type was same as previous value", "CONTINUE and CONFIRMATION Button was not displayed", true);
		    	CONFIRMATION_DEFERAL_TYPE ="";
		    
		    }
		    
		    }			
	}
	
	
	
	
	
	/* This method will click Continue mesage for Alert Text Box */
	
	
	public void clickAlertMessage(){
		if(Mobile.assertElementPresent(By.className(ALERT_MSG))){
			Mobile.clickElement(ALERT_CONTINUE_BUT);			
		}		
	}
	
	
	public void exit_UnSaves_Contribution(){
		 Common.clickBackArrow(); 
				
	}

	
	public void enter_Contribution_Rate_PerCentage(String rate){
  
	Mobile.clickElement(CONTRIBUTING_RATE_TYPE);
	if(elective_deferral_deleated){		
		verify_Default_Elective_Deferral_Value();
	}
	IOSElement enterContribution_TextField = Mobile.getIOSElement(By.className(INPUT_TEXT_FIELD));
	String sRateValue = enterContribution_TextField.getAttribute("value"); 
	if(rate.equals(sRateValue)){
		contrbution_rate= Integer.toString(Integer.parseInt(rate)+2);
	}else{
	contrbution_rate = rate;
	}
	
	Mobile.setEdit(enterContribution_TextField, contrbution_rate);
	Mobile.clickElement(CHECK);
	//Mobile.hideKeyboard();
	Reporter.logEvent(Status.INFO," Value entered in Contribution Rate  "+ CONTRIBUTING_RATE_TYPE+ " Type.",contrbution_rate +" "+CONTRIBUTING_RATE_TYPE,false);	

	}
	
	
	
	
	/* This function will verify default value for Effective Deferral RAte"*/
	
	
	private void verify_Default_Elective_Deferral_Value(){
		String sRateValue     =    Mobile.getElementValue(By.className(INPUT_TEXT_FIELD));		
	  //	String sRateValue = Mobile.getElementValue(ENTER_CONTRIBUTION_TEXTFILED);	
		
		if(CONTRIBUTING_RATE_TYPE.equals("$")){
			if(sRateValue ==null)
				Reporter.logEvent(Status.PASS, "Default value for enter contribution rate should be empty", "Default value for Rate is empty", false);
			
		}
		else{		
		String sPerPayPeriod = get_MyContribution_PerPay_Period(ENTER_CONTRIBUTION_RATE);		
		if(sPerPayPeriod.contains("$0.00") && sRateValue.contains("0")){
			Reporter.logEvent(Status.PASS, "Default value for Pay Per Period is $0.00", "Default value for Rate is 0", false);
		}else{
			Reporter.logEvent(Status.INFO, "Expected Rate value to be 0", "But Actual was :"+sRateValue, false);	
		}
		}
		
	}
	
	
	/* This method will verify the content of Select Contribution PAge */
	
	public void verify_Select_Contribution_Page_Content(){
		verifyHomePage(SELECT_CONTRIBUTION_HEADER);
	    Mobile.verifyElementPresent("label ", SELECT_CONTRIBUTION_QUESTION_LABEL, "What type of contribution would you like to make? is Display");
	    Mobile.verifyElementPresent("Plan Rule ", SELECT_CONTRIBUTION_PLAN_RULES, "Plan Rule link should be displayed");
	    Mobile.verifyElementPresent("Compare Them ", SELECT_CONTRIBUTION_COMPARE_THEM, "Compare Them  link should be displayed");
	
	}
	
	/*This method will verify Why is this important?"  link in PPC page and verify the content
	*/
	public void verify_PPC_ToolTip_Link() {
		
		Mobile.clickElement(PPC_TOOLTIP_HEADER);
		Mobile.wait(2000);
		Mobile.verify_Element_Value(PPC_TOOLTIP_MSG_XPATH, PPC_TOOLTIP_MSG, "PPC tool tip Message should be displayed");
		Mobile.clickElement(OK_BUT);
		
	}
	/*
	 * verify_Data_Not_On_File
	 * This method will verify if precondition  for PPC user is satisfied.
	 * if data is not on file "Have you made contributions to any other retirement plans since" section should be displayed with Switch option to enter value
	 */
	public void verify_PPC_Is_Enable() {
		if(!Mobile.assertElementPresentByPageFactor(MAXIMIZE_SWITCH)){			
			Assert.assertTrue(false, " Participant  should  have Prior Plan Contribution enable. Please delete PPC record from DB first for User");			
		}
		
	}
	
	
	/*
	 * This method will enter amount value in PPC text box
	 * 	  
	 */
	public void enter_amount_in_PPC(String amount){	
		Mobile.setEdit(PPC_TEXTFIELD, amount);
	    Reporter.logEvent(Status.INFO,"Enter Value in PPC Edit Box  ",amount,false);		
		Mobile.clickElement("Done");
	}
	
	/*
	 * This method will enter amount value in PPC text box
	 * 	  
	 */
	public void enter_Amount_in_PPC_CatchUp(String amount){	
		Mobile.setEdit(PPC_CATCH_UP_EDIT, amount);
	    Reporter.logEvent(Status.INFO,"Enter Value in PPC Edit Box  ",amount,false);		
		Mobile.clickElement("Done");
	}
	
	/*
	 * Verify PPC Content display 
	 */
	public void verify_PPC_Content_Page(String sAmount){	
		String sexpValue = null;
		
		if(sAmount.equals("10000")){
			sexpValue ="$10,000";
		}
		else{		
			sexpValue ="$"+sAmount;
		}
		Mobile.verifyText(PPC_AMOUNT_DISPLAY, sexpValue, true);
		Mobile.verifyElementPresent("PPC page Content ", PPC_YEAR_OF_DATE_MSG, PPC_YEAR_OF_DATE_MSG);
		Mobile.verifyElementPresent("PPC page Content", PPC_EDIT_LABEL_4,  PPC_EDIT_LABEL_4);
		
		
	}
	
	/*
	 * This will verify TTK message 
	 */
	
	public void validate_TTK_message_inContribution_Page(){
		String[] sExpText = {"You cannot make contribution rate changes at this time.","THINGS TO KNOW"}; 
		Common.verify_Value_InList_Contain(STATIC_TEXT_FIELD, sExpText, "My Contribution Page should contain ");
		Mobile.verifyElementPresent("light-bulb image should be present", "light-bulb", "light-bulb" );
		String sValue = Mobile.getElementValue("//XCUIElementTypeStaticText[contains(@name,'Test Apple')]");
		System.out.println(sValue);
		if(sValue.length() <= 210)
		{
			Reporter.logEvent(Status.PASS,"TTK message should be less than 200 char" ,sValue ,false);
		}else{			
		     Reporter.logEvent(Status.FAIL,"TTK message should be less than 200 char " ,sValue,false);
					          
		}
		
		Mobile.clickElement("Expand");
		sValue = Mobile.getElementValue("//XCUIElementTypeStaticText[contains(@name,'Test Apple')]");
		System.out.println(sValue);
		if(sValue.length() >= 210)
		{
			Reporter.logEvent(Status.PASS,"TTK message should be more than 200 char" ,"TTK message is more than 200 char" ,false);
		}else{			
		     Reporter.logEvent(Status.FAIL,"TTK message should be more than 200 char" ,"TTK message is less than 200 char",false);
					          
		}
		
		Mobile.verifyElementNotPresent("Tap Expand Button and it should not be display", "Expand", "Expand Button");
	}
	
	
	
	
	
	
	 
	public void verify_Add_Auto_PopUp_Message(){
		System.out.println("test");
		String sAutoPopMsg = null;	
		String defferalType = UserBaseTest.getParaValue("deferralType");
		CONTRIBUTING_RATE_TYPE =UserBaseTest.getParaValue("contribution_Rate_Type");		
	
		click_ContributionType_Edit_Add_Button(defferalType);
		Mobile.clickElement(ENTER_CONTRIBUTION_RATE);
		if(CONTRIBUTING_RATE_TYPE.equalsIgnoreCase("%") ){
		enter_Contribution_Rate_PerCentage("10"); 
		sAutoPopMsg = "A 0% contribution rate will cancel your auto increase election.";	
		}else{
	    enter_Contribution_Rate_PerCentage("100"); 
	    sAutoPopMsg = "A $0 contribution rate will cancel your auto increase election.";	
		}
		Mobile.clickElement(CONTINUE_BUT);
		if(!Mobile.assertElementPresent(By.name(ADD_AUTO_INCREASE_PAGE))){
		selectRadioButton(BEFORE_TAX); 	
		Mobile.clickElement(CONTINUE_BUT);
		}
		
	    Mobile.switchButton(true);
	    String Auto_Increase = "";
	    List<IOSElement> message_List = Mobile.getListOfElements_By_Class(INPUT_TEXT_FIELD);
		if(CONTRIBUTING_RATE_TYPE.equalsIgnoreCase("%") ){	
	    enter_Value_In_Add_Auto_Increase(message_List,"2", "15", "Current Date");
	     Auto_Increase = "Auto increase: 2% per year up to 15%";
		}else{
	    enter_Value_In_Add_Auto_Increase(message_List,"2", "105", "Current Date");
	     Auto_Increase = "Auto increase: $2 per year up to $105";
		}
	    Mobile.clickElement(CONTINUE_BUT);
	  
		
		Mobile.verifyElementPresent("Auto Increase value should be displayed in Shopping Cart page", Auto_Increase, Auto_Increase);
	    click_ContributionType_Edit_Add_Button(defferalType);      
	    enter_Contribution_Rate_PerCentage("0");
	   Common.waitTillElement_Is_Display(By.className("XCUIElementTypeAlert"), 10);
	    Mobile.verifyElementPresent("Auto Increase pop up should be displayed", "Cancel Auto Increase", "Auto Increase Pop");
	    Mobile.verifyElementPresent("Message should be displayed", sAutoPopMsg, sAutoPopMsg);
		Reporter.logEvent(Status.INFO,"Tap Cancel button Pop up" ,"Contribution rate value to set default to original state" ,false);
	    
	    Mobile.clickElement("Cancel");  
	     String sValue =  Mobile.getElementValue(By.className(INPUT_TEXT_FIELD));
	     if( sValue != "0"){	    	 
	 		Reporter.logEvent(Status.PASS,"Contributionate  rate value should not be zero " ,sValue +" Rate was displayed" ,false);
			}else{
		    Reporter.logEvent(Status.FAIL,"Contributionate  rate value should not be zero",sValue +" Rate was displayed",true);
	     	}
			  
	    enter_Contribution_Rate_PerCentage("0"); 	
	    Mobile.clickElement("Confirm");
		Mobile.clickElement(CONTINUE_BUT);	
		Mobile.verifyElementPresent("Tap Confirm and Continue button and My Contribution Page should be displayed", MY_CONTRIBUTION, "My Contribution Page");
		Mobile.verifyElement_Is_Not_Displayed("Auto Increase in shoppoing cart page  should not  be displayed", By.name(Auto_Increase), Auto_Increase);
		}
	
	
	
	public void verify_Auto_Increase_Percentage(){	
		  String contribution_Type = UserBaseTest.getParaValue("contribution_Type");
		   enterContributionRate_For_Auto_Increase(contribution_Type,"10", "5");   
		   List<IOSElement> message_List = Mobile.getListOfElements_By_Class(INPUT_TEXT_FIELD);
		   int per_max = 0;		 
		   if(contribution_Type.contains(ROTH)){
			   per_max=75;
			 
		   }else{
			   per_max=75;			   
		   }
		   if(getApplePlan()){
			   if(contribution_Type.contains("BEFORE")){
				   contribution_Type="BASE PAY TRADITIONAL 401(K)";
			   }else if (contribution_Type.contains("ROTH")){
				   contribution_Type = "BASE PAY ROTH 401(K)";
				  // contribution_Type="ROTH";
			   }
			   
		   }
		   
		   
		   int  sValue = per_max -5; 
		   String autoIncreaseValue = Integer.toString(sValue);
		   String maxIncreaseValue = Integer.toString(per_max);
		   
		   enter_Value_In_Add_Auto_Increase(message_List,"1", "4", "");  
	    	Mobile.clickElement(CHECK);
      	    Mobile.verifyElementPresent("Verify validation message for when  auto increase Percentage is less than current rate", "Auto increase for "+contribution_Type+" must be at least 6%.", "Validation Message : Auto increase for "+contribution_Type+" must be at least 6%.");
    	    enter_Value_In_Add_Auto_Increase(message_List,"100", "", "");    
    	    Mobile.verifyElementPresent("Verify validation message for when  auto increase  Percentage is greater than plan maximum", "Auto increase for "+contribution_Type+" must be no more than "+autoIncreaseValue+"%.", "Validation Message : Auto increase for "+contribution_Type+" must be no more than "+autoIncreaseValue+"%.");
    	    enter_Value_In_Add_Auto_Increase(message_List,"", "1000", ""); 	 
    	    Mobile.verifyElementPresent("Verify validation message for when  Auto increase maximum Percentage is less than current rate", "Auto increase for "+contribution_Type+" must be no more than "+maxIncreaseValue+"%.", "Validation Message : Auto increase for "+contribution_Type+" must be no more than "+maxIncreaseValue+"%.");
    	    enter_Value_In_Add_Auto_Increase(message_List,"1", "6", "current date"); 	
    		Mobile.clickElement(CONTINUE_BUT);	
    		Mobile.verifyElementPresent(" Enter valid rate and click continue  and Auto Increase should be displayed in Shopping Cart page", "Auto increase: 1% per year up to 6%", "Auto increase: 1% per year up to 6%");
       		
    		
	}

	private void  enterContributionRate_For_Auto_Increase(String contribution_Type,String sContributionRate,String deferralRate){
		 String[] autoIncreaseText = null;
		 
		 if(getApplePlan()){
			 autoIncreaseText = new String[]   {"Add auto increase",
		               // "AUTO INCREASE BEFORE-TAX",
					    "AUTO INCREASE BASE PAY TRADITIONAL 401(K)",
		                "You must choose a rate of increase.",
		                "You must choose a maximum contribution rate.",
		                "You must choose a start date",
		                //"AUTO INCREASE ROTH"
		                "BASE PAY ROTH 401(K)"};
			 
		 }else{
			 autoIncreaseText =  new String[] {"Add auto increase",
	                "AUTO INCREASE BEFORE TAX",	               
	                "You must choose a rate of increase.",
	                "You must choose a maximum contribution rate.",
	                "You must choose a start date",
	                "AUTO INCREASE ROTH"
	                };
		 }
		
	    CONTRIBUTING_RATE_TYPE =UserBaseTest.getParaValue("contribution_Rate_Type");
	    click_ContributionType_Edit_Add_Button(STANDARD);  
	    Mobile.clickElement(ENTER_CONTRIBUTION_RATE);
	    enter_Contribution_Rate_PerCentage(sContributionRate); 
		Mobile.clickElement(CONTINUE_BUT);		
			
	    Mobile.selectRadioButton(SPLIT);    
		List<IOSElement> testBoxList =Mobile.getListOfElements_By_Class(TEXT_FIELD);
		Mobile.setEdit(testBoxList.get(0), "1000");
		 if(getApplePlan()){
		//DDTC-27897 QA- Contributions -Split rate page - Enter value more than deferral rate
		String sWarMessage = "Contributions for Base Pay Traditional 401(k) must be no more than 75%.";
		Mobile.verifyElementPresent("Enter  value more than maximizer Rate : 1000" , sWarMessage, "validation should be performed with message:\n"+sWarMessage);
		 }
		Mobile.setEdit(testBoxList.get(0), deferralRate);
  		Mobile.clickElement(CHECK);
  	         	
		Mobile.clickElement(CONTINUE_BUT);	
		Common.waitForProgressBar();
		if(contribution_Type.contains(ROTH)){
			List<IOSElement> elements  = Mobile.getListOfElements_By_Class("XCUIElementTypeSwitch");
			  Mobile.switchButton(elements.get(0),false);
			  Mobile.switchButton(elements.get(1),true);
		
		}else{		
	    Mobile.switchButton(true);
		}
		Mobile.clickElement(CONTINUE_BUT);
		Reporter.logEvent(Status.INFO,"Click Continue button without entering values in Auto Increase","Verify error message displayed ",false);
	 		
	    Common.verify_Value_InList_Contain(STATIC_TEXT_FIELD, autoIncreaseText, " text should be  display");	
	}
	
	
	
	public void verify_Auto_Increase_Dollor(){		
		String contribution_Type = UserBaseTest.getParaValue("contribution_Type");	   
		   
		enterContributionRate_For_Auto_Increase(contribution_Type,"200", "100");
		 List<IOSElement> message_List = Mobile.getListOfElements_By_Class(INPUT_TEXT_FIELD);
		enter_Value_In_Add_Auto_Increase(message_List,"0", "", ""); 
	 	Mobile.clickElement(CHECK);
	   String minAutoInc = "$0.01.";
	    Mobile.verifyElementPresent("Verify validation message for when zero value is enter in automatically  increase  my contribution rate", "Auto increase for "+contribution_Type+" must be at least "+minAutoInc, "Validation Message : Auto increase for "+contribution_Type+" must be at least "+minAutoInc);
	 
	    enter_Value_In_Add_Auto_Increase(message_List,"", "0", "");   
	 	Mobile.clickElement(CHECK);
	 	String minContRate= "$100.";
	    Mobile.verifyElementPresent("Verify validation message for when zero in  maximium Contribution Rate", "Auto increase for "+contribution_Type+" must be at least "+minContRate, "Validation Message : Auto increase for "+contribution_Type+" must be at least "+minContRate);
	    String maxAutoInc = "$900.";
	    enter_Value_In_Add_Auto_Increase(message_List,"18000", "", ""); 	    
	    Mobile.verifyElementPresent("Verify validation message for when more then current rate in automatically  increase  my contribution rate", "Auto increase for "+contribution_Type+" must be no more than "+maxAutoInc, "Validation Message : Auto increase for "+contribution_Type+" must be no more than "+maxAutoInc);
		String maxContRate= "$1,000.";
	    enter_Value_In_Add_Auto_Increase(message_List,"", "180000", ""); 	    
	    Mobile.verifyElementPresent("Verify validation message for when more then current rate in maximium Contribution Rate", "Auto increase for "+contribution_Type+" must be no more than "+maxContRate, "Validation Message : Auto increase for "+contribution_Type+" must be no more than "+maxContRate);
	 
        enter_Value_In_Add_Auto_Increase(message_List,"100", "100", ""); 
    	Mobile.clickElement(CHECK);
		Mobile.verifyElementPresent("Verify validation message for when increase maximum amount less than current rate.", "Auto increase for "+contribution_Type+" must be at least $200.", "Validation Message : Auto increase for "+contribution_Type+" must be at least $200.");
	 
		enter_Value_In_Add_Auto_Increase(message_List,"100", "200", "current date"); 	
		Mobile.clickElement(CONTINUE_BUT);	
		Mobile.verifyElementPresent(" Enter valid rate and click continue  and Auto Increase should be displayed in Shopping Cart page", "Auto increase: $100 per year up to $200", "Auto increase: $100 per year up to $200");
   	
		
}
	
	public void verify_Auto_Increase_Dollor_With_Roth(){		
		System.out.println("Test");
		String contribution_Type = UserBaseTest.getParaValue("contribution_Type");
		enterContributionRate_For_Auto_Increase(contribution_Type,"200", "100");
		 List<IOSElement> message_List = Mobile.getListOfElements_By_Class(INPUT_TEXT_FIELD);
		enter_Value_In_Add_Auto_Increase(message_List,"0", "", ""); 
	 	Mobile.clickElement(CHECK);
	   String minAutoInc = "$0.01.";
	    Mobile.verifyElementPresent("Verify validation message for when zero value is enter in automatically  increase  my contribution rate", "Auto increase for "+contribution_Type+" must be at least "+minAutoInc, "Validation Message : Auto increase for "+contribution_Type+" must be at least "+minAutoInc);
	 
	    enter_Value_In_Add_Auto_Increase(message_List,"", "0", "");   
	 	Mobile.clickElement(CHECK);
	 	String minContRate= "$100.";
	    Mobile.verifyElementPresent("Verify validation message for when zero in  maximium Contribution Rate", "Auto increase for "+contribution_Type+" must be at least "+minContRate, "Validation Message : Auto increase for "+contribution_Type+" must be at least "+minContRate);
	    String maxAutoInc = "$900.";
	    enter_Value_In_Add_Auto_Increase(message_List,"18000", "", ""); 	    
	    Mobile.verifyElementPresent("Verify validation message for when more then current rate in automatically  increase  my contribution rate", "Auto increase for "+contribution_Type+" must be no more than "+maxAutoInc, "Validation Message : Auto increase for "+contribution_Type+" must be no more than "+maxAutoInc);
		String maxContRate= "$1,000.";
	    enter_Value_In_Add_Auto_Increase(message_List,"", "180000", ""); 	    
	    Mobile.verifyElementPresent("Verify validation message for when more then current rate in maximium Contribution Rate", "Auto increase for "+contribution_Type+" must be no more than "+maxContRate, "Validation Message : Auto increase for "+contribution_Type+" must be no more than "+maxContRate);
	 
        enter_Value_In_Add_Auto_Increase(message_List,"100", "100", ""); 
    	Mobile.clickElement(CHECK);
		Mobile.verifyElementPresent("Verify validation message for when increase maximum amount less than current rate.", "Auto increase for "+contribution_Type+" must be at least $200.", "Validation Message : Auto increase for "+contribution_Type+" must be at least $200.");
	 
		enter_Value_In_Add_Auto_Increase(message_List,"100", "200", "current date"); 	
		Mobile.clickElement(CONTINUE_BUT);	
		Mobile.verifyElementPresent(" Enter valid rate and click continue  and Auto Increase should be displayed in Shopping Cart page", "Auto increase: $100 per year up to $200", "Auto increase: $100 per year up to $200");
   	
		
}

	
	
	private void enter_Value_In_Add_Auto_Increase(List<IOSElement> message_List,String value1,String sValue2,String sDate){
		
		if(message_List.size() != 3){
			 message_List = Mobile.getListOfElements_By_Class(INPUT_TEXT_FIELD);
		}
		if(value1 != ""){
		Mobile.setEdit(message_List.get(0), value1);
		Reporter.logEvent(Status.INFO, "Entered value for Automatically increase contribution"  , value1 + CONTRIBUTING_RATE_TYPE +" has been entered", false);
  	}
		
		if(sValue2 != ""){
	 	Mobile.setEdit(message_List.get(1), sValue2);	
	 	Reporter.logEvent(Status.INFO, "Entered value for maximium contribution"  , sValue2+  CONTRIBUTING_RATE_TYPE +" has been entered", false);
		}
		
		if(sDate != ""){
	 	message_List.get(2).click();
	    Mobile.clickElement("Done");
		}
		
	
	  }	  
		
	public void verify_Contributions_Maximize_to_the_company_match(){
	
		Reporter.logEvent(Status.INFO,"Step 1:  Go to My Contributions page and tap on Standard Add/edit button ","  Following options display 1) MAXIMIZE TO THE IRS LIMIT 2) MAXIMIZE TO COMPANY MATCH 3) ENTER YOUR CONTRIBUTION RATE",false);
	   
		click_ContributionType_Edit_Add_Button(STANDARD);	
		
		
		Reporter.logEvent(Status.INFO,"Step 2-3: Select the radio button MAXIMIZE TO COMPANY MATCH ","Verify the value of maximizer rate with %.",false);
	    
		Mobile.selectRadioButton(MAXIMIZE_COMPANY_MATCH); 
		String contribution_Rate = get_MyContribution_Rate(MAXIMIZE_COMPANY_MATCH);
		
		
	    verify_Maximize_To_Company_Rate(CONTRIBUTION_COMPANY, contribution_Rate);    
//	    
		Reporter.logEvent(Status.INFO,"Step 8: Click Continue Button ","Verify Split Page is display. ",false);
	    Mobile.clickElement(CONTINUE_BUT);	 
	    verify_Select_Contribution_Page_Content();
	    
	    if(Mobile.is_Element_Enable(CONTINUE_BUT)){	    
	    Mobile.clickElement(CONTINUE_BUT);
	    }
	    else{
	          Mobile.selectRadioButton(ROTH); 
	          Mobile.clickElement(CONTINUE_BUT);
	    	  
	    }  
	    
	    
		if(Mobile.is_Element_Displayed(By.name(ADD_AUTO_INCREASE_PAGE))){
	 		Mobile.clickElement(CONTINUE_BUT);	
	 	}	
		 
	    
	    Reporter.logEvent(Status.INFO,"Step 9: Select Before Tax Deferral Type  ","Verify Before Tax IRA rate is dsipaly in % and message is display below ",false);
	   
	    click_ContributionType_Edit_Add_Button(STANDARD);
	    setbVerifyConfirmation(false);
	    select_Standard_Contribution_Page(MAXIMIZE_COMPANY_MATCH,APPLE_BEFORE_TAX, contribution_Rate);
	    setbVerifyConfirmation(false);
	    
	 	Reporter.logEvent(Status.INFO,"Step 12: Repeat the above steps 9 - 11 with different deferral types : Roth ","",false);	 	  
		click_ContributionType_Edit_Add_Button(STANDARD);
		setbVerifyConfirmation(true);
	 	select_Standard_Contribution_Page(MAXIMIZE_COMPANY_MATCH,ROTH, contribution_Rate);
	 
	 	
	 	Reporter.logEvent(Status.INFO,"Step 12.2: Repeat the above steps 9 - 11 with different deferral types : Split","",false);	
		click_ContributionType_Edit_Add_Button(STANDARD);
	 	select_Standard_Contribution_Page(MAXIMIZE_COMPANY_MATCH,SPLIT, contribution_Rate);    
			

	}
	
	public void verify_DDTC_7292_QA_Contributions_Maximize_to_the_IRS_Limit() throws InterruptedException{
		Reporter.logEvent(Status.INFO,"Step 1: Go to My Contribution Shoping Cart Page and tap on Standard Add/edit button ","  Following options should be displayed  1) MAXIMIZE TO THE IRS LIMIT 2) MAXIMIZE TO COMPANY MATCH 3) ENTER YOUR CONTRIBUTION RATE",false);
		click_ContributionType_Edit_Add_Button(STANDARD);	
		
		Mobile.selectRadioButton(MAXIMIZE_LIMIT);	
		
		String[] radioOptions={MAXIMIZE_LIMIT,MAXIMIZE_COMPANY_MATCH,ENTER_CONTRIBUTION_RATE,IRS_CONTRIBUTION_LABEL,MY_ANNUAL_LABEL,MODIFY_MAXIMIZE_ME_ALWAYS_MSG};
		 ArrayList<String> sActText = Common.get_Element_Lists(STATIC_TEXT_FIELD,"Tap Maximimize Limit");
		 Common.verify_Value_InList_Contain(sActText, radioOptions, "Contributing Type  should be  display");
		 				
	  
	  Common.verify_Value_For_FollowingSibling(sActText, MAXIMIZE_LIMIT, 1, 1, "%", "Step 2-3: Maximizer Rate Should should contain % value"); 
  
	  Common.verify_Value_For_FollowingSibling(sActText, MAXIMIZE_LIMIT, 2, 2, "$", "Step 4: Per pay period should contain  dollar amount"); 

		
	    //Verified in TC 001_DDTC_7292 
		Reporter.logEvent(Status.INFO,"Step 5 : Tap on the pay per period amount ","Verify Tool Tip display",true);
		verifyToolTip(MAXIMIZE_PER_PAY_PERIOD_VALUE,APPLE_MAXIMIZE_TOOLTIP_MSG);

				
	//	Reporter.logEvent(Status.INFO,"Step  6: Check that tooltip is getting closed if participant taps anywhere on the screen."," Tool tip is closed",false);
		Mobile.verifyElement_Is_Not_Displayed("Step 6 :Tooltip is should be closed if taps anywhere on the screen. ", By.name(APPLE_MAXIMIZE_TOOLTIP_MSG), "Tool Tip ");

		
	//	Reporter.logEvent(Status.INFO,"Step 9-13 : IRS contribution limit and  My annual compensation  label is displayed "," Verify IRS contribution limit is displayed with dollar amount ",false);		

	   Common.verify_Value_For_FollowingSibling(sActText, IRS_CONTRIBUTION_LABEL, 1, 1, "$", "Step 10  IRS contribution should  contain dollar amount"); 
	   Common.verify_Value_For_FollowingSibling(sActText, MY_ANNUAL_LABEL, 1, 1, "$", "Step 11  My Annual Compensation should  contain dollar amount"); 
		
	   
		Reporter.logEvent(Status.INFO,"Step 14-15: Option to automatically Maximize the participant to the IRS limit. "," Verify Maximizer Switch should default to OFF",false);
		//Mobile.verify_Element_Is_Not_Selected(MAXIMIZE_SWITCH, "Maximize switch should be  OFF");		
		
		
		Reporter.logEvent(Status.INFO,"Step 16 :Turn ON the switch  ","Verify Message under Maximizer Switch Option",false);
		Mobile.switchButton( true);  
		Mobile.verifyText(PPC_TOOLTIP_MSG_XPATH, APPLE_MAXIMIZE_WARNING_MSG, false);
			
		Reporter.logEvent(Status.INFO,"Step 17-19:  Tap on the compensation amount"," Verify  Edit annual compensation  model open.",false);
		Mobile.clickElement(MY_ANNUAL_AMOUNT);				
		verifyHomePage(EDIT_ANNUAL_COMPENSATION_MODEL);		
				
		//Reporter.logEvent(Status.INFO,"Step 20:  Check that following content is displaying under the my annual compensation field", EDIT_ANNUAL_COMPENSATION_MSG,false);
		Mobile.verifyElementPresent("Step 20 :  Verify content  : "+EDIT_ANNUAL_COMPENSATION_MSG , EDIT_ANNUAL_COMPENSATION_MSG, "Content");
				
	//	Reporter.logEvent(Status.INFO,"Step 21- 22: Enter different amount in annual compensation input field and tap on update button:  ","App will update maximizer rate and per pay period amount with updated salary in shopping cart page ",false);
		
		Mobile.verifyElementPresent("Step 21 : Update Button should be display", UPDATE_BUT, "Update Button");
		Mobile.verifyElementPresent("Step 21 Reset Button should be display", RESET_BUT, "Reset Button");
		
		enterAnnualCompensationAmount(UserBaseTest.getParaValue("amount"));
		Mobile.clickElement(UPDATE_BUT);
		Common.waitForProgressBar();
		
		Reporter.logEvent(Status.INFO,"Step 23 :  Update annual compensation  ","Verify Amount is updated ",false);		     
		verifyAnnualCompensationAmount(UserBaseTest.getParaValue("amount"));	
		
	//	Reporter.logEvent(Status.INFO,"Step 24 :Check that maximize me always switch will be disabled and greyed. "," ",false);
		Mobile.verify_Element_Is_Not_Selected(MAXIMIZE_SWITCH, "Maximize switch should be  OFF");		
				
		Mobile.verifyText(PPC_TOOLTIP_MSG_XPATH, MAXIMIZE_LIMIT_MANUALLY_MSG, false);
		
		Reporter.logEvent(Status.INFO,"Step 26 : Enter different amount in annual compensation input box and tap on 'Reset' button "," Shopping cart page with previous values",false);
		Mobile.clickElement(MY_ANNUAL_AMOUNT);
		enterAnnualCompensationAmount(UserBaseTest.getParaValue("updateAmount"));	
		Mobile.clickElement(RESET_BUT);	
			
		Reporter.logEvent(Status.INFO,"Step 28 -30: Turn OFF the switch and Click Continue  ","Participant is no longer eligible for auto-increase.App will not provide Auto Increase option ",false);
		Mobile.switchButton(false);	
		Mobile.scroll_Down();
		Mobile.clickElement(CONTINUE_BUT);	
		
		Mobile.selectRadioButton(SPLIT);    
		List<IOSElement> testBoxList =Mobile.getListOfElements_By_Class(TEXT_FIELD);
		Mobile.setEdit(testBoxList.get(0), "1000");	
		//DDTC-27902 QA-Contributions - Maximizer-Split rate page - Enter value more than deferral rate
		String sWarMessage = "Contributions for Base Pay Traditional 401(k) must be no more than 75%.";
		Mobile.verifyElementPresent("Enter  value more than maximizer Rate : 1000" , sWarMessage, "validation should be performed with message:\n"+sWarMessage);
		Mobile.clickElement(CHECK);		
		
		Mobile.clickElement(CONTINUE_BUT);
		Mobile.verifyElement_Is_Not_Displayed("Add Auto Increase Page Not displayed", By.name(ADD_AUTO_INCREASE_PAGE), "Add Auto Increase Page should  not be displayed");
		
		
	}
	
	public void DDTC_8187_Contributions_Maximizer_Catch_Up_Onetime_Salary_Update(){

		getContributing_Salary_and_Rate_Value_OnFile(CATCH_UP,MAXIMIZE_LIMIT);
		String sCatch_Up_Rate_OnFile =   getContributionRate();	
		String sCatch_Up_PerPay_Period_OnFile =   getContributionPerPayPeriod();
		
		
		Reporter.logEvent(Status.INFO,"Step 2: Select Standard ->Maximizer Limit Option and enter new salary and click UPDATE button","Verify updates participant salary and  percentage as per the new salary",false);
		 update_MyAnnual_Compensation_Salary(STANDARD,BEFORE_TAX);		
		String sStd_Salary_On_File =   getContributionSalary();
		String sStd_PerPay_On_File =   getContributionPerPayPeriod();
		String sStandard_Rate_per_OnFile  =   getContributionRate();
		
		Reporter.logEvent(Status.INFO,"Step 3  Click Catch -Up option  ","Validate Catch up maximizer value also got updated as per the new salary. ",false);
		 verify_MyContributions_Rate_Percentage_Update(CATCH_UP, sCatch_Up_Rate_OnFile,true);
		 click_ContributionType_Edit_Add_Button(CATCH_UP);	
		 verify_Maximizer_Rate_Value_Updated(MAXIMIZE_LIMIT,sCatch_Up_Rate_OnFile,true);	
		 verify_Maximizer_perPay_Period_Value_Updated(MAXIMIZE_LIMIT,sCatch_Up_PerPay_Period_OnFile,true);	
		Mobile.clickElement(BACK_BUT);
		
		Reporter.logEvent(Status.INFO,"Step 4 -6 : Select AFTER TAX and click Continue and confirmation ","Shoping cart page with new Value for Base Pay and Catch Up as per the salary update",false);
			
		 click_ContributionType_Edit_Add_Button(AFTER_TAX);	
		 select_Standard_Contribution_Page(ENTER_CONTRIBUTION_RATE, "", "2");
//		 verify_MyContributions_Rate_Percentage_Update(STANDARD, sStandard_Rate_per_OnFile,false);
//		 verify_MyContributions_Rate_Percentage_Update(CATCH_UP, sCatch_Up_Rate_OnFile,false);	
		
//		
	//	Reporter.logEvent(Status.INFO,"Step 6: Return to shopping cart page","Verify Catch Up contribution rates as per the new salary. ( Saved values in previous step) ",false);
		
	//	Reporter.logEvent(Status.INFO,"Step 7: Select Standard type and select Maximize to IRS option ","Verify app displays maximizer card with salary on file ( Not the salary -updated in previous steps) and the contribution percentage based on the existing salary on file ",false);
		 click_ContributionType_Edit_Add_Button(STANDARD,MAXIMIZE_LIMIT);			
		 verify_Annual_Compensation_Amount_IsUpdated(getContributionSalary(),false);	
		 verify_Maximizer_perPay_Period_Value_Updated(MAXIMIZE_LIMIT, sStd_PerPay_On_File,false);
		Common.clickBackArrow();		
		
		Reporter.logEvent(Status.INFO,"Step 8: Go back to shopping cart page, Select Catch up card and select Maximize to IRS option","Verify contribution percentage based on the existing salary on file and not as per the new salary.(Contribution rate should be different than shopping cart page value) ",false);
		 click_ContributionType_Edit_Add_Button(CATCH_UP,MAXIMIZE_LIMIT);		
		 verify_MyContributions_Rate_Percentage_Update(MAXIMIZE_LIMIT, sCatch_Up_Rate_OnFile,false);	
		
		Common.clickBackArrow();
		
	}
	
	public void DDTC_7197_Maximizer_Catchup_Maximize_me_Always_selected_for_Standard_type(){
		
		//	Reporter.logEvent(Status.INFO,"Step 2:  Select Catch -Up Type  ","Verify following options displayed.- MAXIMIZE TO THE 2016 IRS LIMIT- ENTER YOUR CONTRIBUTION RATE",false);
			 click_ContributionType_Edit_Add_Button(CATCH_UP);		
			Mobile.clickElement(MAXIMIZE_LIMIT);
			Reporter.logEvent(Status.INFO,"Step 4 -9 : Select the radio button MAXIMIZE TO THE 2016 IRS LIMIT","App displays the value of maximizer rate with % below the title. ",true);
			// verify_Maximize_Limit_Rate_Display();
			 verify_IRS_Contribution_Limit_Displayed();	
			
		//	Reporter.logEvent(Status.INFO,"Step 10 : message in catch-up card if participant selected maximize me always for their standard deferrals."," ",false);
		    Mobile.verifyElementPresent("Step 10 : Note for Maximize me Always should be displayed Content",   MAXIMIZE_ME_ALWAYS_NOTE_MSG, MAXIMIZE_ME_ALWAYS_NOTE_MSG);
	      	Common.clickContinueButon();
	      	selectRadioButton(CATCH_UP_BEFORE);		
			Mobile.clickElement(CONTINUE_BUT);
			
			Reporter.logEvent(Status.INFO,"Step 11-13 : Tap Continue button and select Before Tax and Tap Continue","Shoping cart page is displayed ",true);
		//	Reporter.logEvent(Status.INFO,"Step 13: Check that maximize me always text is displayed under catch-up deferral group."," As expected.",false);
			 verifyMaximize_Me_Always_Diplayed(CATCH_UP,true);
			String contribution_Rate =  get_MyContribution_Rate(CATCH_UP);
			
			Reporter.logEvent(Status.INFO,"Step 14-15 Tap on Confirm and Continue ","Application returns to contributions confirmation page. ",false);
			Mobile.clickElement(CONFIRM_AND_CONTINUE_BUT);	
		//	String sLabel = contribution_Rate+"% Age catch-up Before(Maximize Me Always)";
			String sLabel = contribution_Rate+"% catch up Traditional 401(K)(Maximize Me Always)";
			 verify_Confirmation_Page("",sLabel);		
				
//			Reporter.logEvent(Status.INFO,"Step 16: Repeat the above steps with multiple catch-up deferral types and make sure it is working as expected","As expected. ",false);
//			 click_ContributionType_Edit_Add_Button(  CATCH_UP);
//		 	 select_Standard_Contribution_Page(  MAXIMIZE_LIMIT,  CATCH_UP_ROTH, contribution_Rate);
//		 
		 	
		 	Reporter.logEvent(Status.INFO,"Step 16: Repeat the above stepswith multiple catch-up deferral types : Split","",false);	
			 click_ContributionType_Edit_Add_Button(CATCH_UP);
		 	 select_Standard_Contribution_Page(MAXIMIZE_LIMIT,CATCH_UP_SPLIT, contribution_Rate);    
		 
	}
	
	
	public void DDTC_12339_Bonus_One_View_Only_And_One_Non_View_Deferral()
	{
	

		String ViewOnlyDeferralRate =   get_MyContribution_Rate(UserBaseTest.getParaValue("ViewOnlyDeferralType"));
		
		 verify_MyContributions_Rate_Percentage(UserBaseTest.getParaValue("ViewOnlyDeferralType"), ViewOnlyDeferralRate);   

		Reporter.logEvent(Status.INFO,"Step 3 Tap on the Edit/Add button to change the values.","Application returns to contribution rate selection page.",false);	
		 click_ContributionType_Edit_Add_Button(  BONUS);

		Reporter.logEvent(Status.INFO,"Step 4 Enter the contributions rate and tap on the continue "," Verify Application returns to contribution list by allocating remaining amount minus the amount to view only deferrals to non-view only deferrals",false);	
		 enter_Contribution_Rate_PerCentage(UserBaseTest.getParaValue("contribution_Rate"));
		

		Reporter.logEvent(Status.INFO,"Step 5 Click on Continue Button ","Split option is not displayed",false);	
		Mobile.clickElement(CONTINUE_BUT); 
		Mobile.verifyElement_Is_Not_Displayed("Split Contribution Page ", By.name(SPLIT), "Split option should not be displayed");
		Mobile.clickElement(CONTINUE_BUT); 	
		if(Mobile.is_Element_Displayed(By.name(ADD_AUTO_INCREASE_PAGE))){
	 		Mobile.clickElement(CONTINUE_BUT);	
	 	}		 	
	  	
		Reporter.logEvent(Status.INFO,"Step 6 Submit the contribution rate "," The view only deferrals are displaying under deferrals group correctly.",false);	
	   
		 verify_MyContributions_Rate_Percentage(UserBaseTest.getParaValue("ViewOnlyDeferralType"), ViewOnlyDeferralRate);   
		 verify_MyContributions_Rate_Percentage(UserBaseTest.getParaValue("NonViewDeferralType"), UserBaseTest.getParaValue("NonViewDeferralRate"));   
			

	}
	
	public void DDTC_DTC_12334_View_Only_Other_with_split_contributions(){

		//String sViewOnlyRate = UserBaseTest.getParaValue("ViewOnlyDeferralRate");
		String sViewOnlyType =  UserBaseTest.getParaValue("viewOnlyDeferralType");
	 	String NonViewDeferralType =UserBaseTest.getParaValue("NonViewDeferralType");
	 	String sContributionRate = UserBaseTest.getParaValue("contribution_Rate");
	 	String sViewOnlyRate =   get_MyContribution_Rate(UserBaseTest.getParaValue("ViewOnlyDeferralType"));
		 verify_MyContributions_Rate_Percentage(sViewOnlyType, sViewOnlyRate); 
		

		Reporter.logEvent(Status.INFO,"Step 3 Tap on Other  Edit/Add button  deferral group.","Contribution rate selection page is displayed.",false);	
		
		 click_ContributionType_Edit_Add_Button(  OTHER);

		Reporter.logEvent(Status.INFO,"Step 4 -5 Enter the rate equal to view only deferrals contribution rate"," Verify split rate page is not displayed and return to My Contribution page",false);	
		 enter_Contribution_Rate_PerCentage(sViewOnlyRate);
		Mobile.clickElement(CONTINUE_BUT);
		 Mobile.verifyElement_Is_Not_Displayed(SELECT_CONTRIBUTION_HEADER+" should not be display.", By.name(SELECT_CONTRIBUTION_HEADER), SELECT_CONTRIBUTION_HEADER);
		 verifyHomePage(MY_CONTRIBUTION);	
		 verify_MyContributions_Rate_Percentage(sViewOnlyType, sViewOnlyRate);   
		

		Reporter.logEvent(Status.INFO,"Step 6 Tap on Other deferral Edit/Add button ","Contribution rate selection page.",false);	
		 click_ContributionType_Edit_Add_Button(OTHER);
		
		Reporter.logEvent(Status.INFO,"Step 7 Enter the contributions rate and click Continue","Split Page is displayed",false);	
	  
		 enter_Contribution_Rate_PerCentage(sContributionRate);
		Mobile.clickElement(CONTINUE_BUT);
		 verifyHomePage(SELECT_CONTRIBUTION_HEADER);
		
		String NonViewDEferralRate = Integer.toString(Integer.parseInt(sContributionRate) -Integer.parseInt(sViewOnlyRate));
		String sValue = NonViewDEferralRate+"% "+NonViewDeferralType+" WITH "+sViewOnlyRate+"% "+sViewOnlyType;

		Reporter.logEvent(Status.INFO,"Step 8   Verify  non-view only deferrals panel should displayed :.",NonViewDEferralRate +"%",false);	
	  
	   	Mobile.verifyElementPresent("Non View Only Deferral Panal", sValue, sValue + " is displayed ");
		
		Reporter.logEvent(Status.INFO,"Step 9 Tap on the split rate contribution","Verify view only deferrals value is displaying as static text and not editable.",false);	
	    Mobile.clickElement(  SPLIT);
	    
	    String sObj = "//XCUIElementTypeStaticText[contains(@name,'"+Common.upperCaseAllFirst(sViewOnlyType)+"')]/preceding-sibling::XCUIElementTypeTextField";  
	       
	    Mobile.verify_Element_Value(sObj, sViewOnlyRate, sViewOnlyType +"  View only should contain static value in Split Page");
	    selectRadioButton(UserBaseTest.getParaValue("NonViewDeferralType")); 
	         
		Reporter.logEvent(Status.INFO,"Step 10 Click Continue button ","Verify view only deferrals are displaying under deferrals group correctly.",false);	
	    Mobile.clickElement(CONTINUE_BUT);	
		 verify_MyContributions_Rate_Percentage(sViewOnlyType, sViewOnlyRate);   
		 verify_MyContributions_Rate_Percentage(NonViewDeferralType, NonViewDEferralRate);   
		
		
	}
	
	public void DDTC_12342_Maximizer_Catch_Up_View_Only_Deferral_Group(){
		String sViewOnlyType =  UserBaseTest.getParaValue("viewOnlyDeferralType");
	 	String NonViewDeferralType =UserBaseTest.getParaValue("NonViewDeferralType");
	 	String sContributionRate = UserBaseTest.getParaValue("contribution_Rate");
		
		
		Reporter.logEvent(Status.INFO,"Step 1-2  User click My Contributions link","",false);	
		Reporter.logEvent(Status.INFO,"Step 3-4 Select Standard  Edit/Add -> Maximizer Limit"," Maximizer Option is selected",false);	
		String sViewOnlyRate =   get_MyContribution_Rate(sViewOnlyType);
		 select_Contribution_Details(STANDARD,  MAXIMIZE_LIMIT,  BEFORE_TAX);
	 	
		Reporter.logEvent(Status.INFO,"Step 5-6 Select Catc-Up ","Verify maximizer section is not displayed ",false);
		 click_ContributionType_Edit_Add_Button(  CATCH_UP);
		Mobile.verifyElementNotPresent("Maximizer Limit section ",   MAXIMIZE_LIMIT, "Maximizer section should not be displayed");
		
		Reporter.logEvent(Status.INFO,"Step 7-9 Enter the contribution and save the value. "," The view only deferrals are displaying under deferrals group correctly.",false);	
		 enter_Contribution_Rate_PerCentage(sContributionRate);
		 Mobile.clickElement(CONTINUE_BUT);
		String NonViewDeferralRate = Integer.toString(Integer.parseInt(sContributionRate) -Integer.parseInt(sViewOnlyRate));
	    Mobile.clickElement(CONTINUE_BUT);
		if(Mobile.is_Element_Displayed(By.name(ADD_AUTO_INCREASE_PAGE))){
	 		Mobile.clickElement(CONTINUE_BUT);	
	 	}		
	     verify_MyContributions_Rate_Percentage(sViewOnlyType, sViewOnlyRate);   
		 verify_MyContributions_Rate_Percentage(NonViewDeferralType, NonViewDeferralRate);     

		
	}
	
	public void DDTC_12341_Maximizer_Standard_View_Only_Deferral_Group(){
		String sViewOnlyType =  UserBaseTest.getParaValue("viewOnlyDeferralType");
	 	String NonViewDeferralType =UserBaseTest.getParaValue("NonViewDeferralType");
	 	String sContributionRate = UserBaseTest.getParaValue("contribution_Rate");
		
		Reporter.logEvent(Status.INFO,"Step 1-2  User click My Contributions link","",false);	
		Reporter.logEvent(Status.INFO,"Step 3-4 Select Standard  Edit/Add -> Maximizer Limit","Verify maximizer section is not displayed ",false);
	
		String sViewOnlyRate =   get_MyContribution_Rate(sViewOnlyType);

		 click_ContributionType_Edit_Add_Button(STANDARD);
		Mobile.verifyElementNotPresent("Maximizer Limit section ", MAXIMIZE_LIMIT, "Maximizer section should not be displayed");
			

		Reporter.logEvent(Status.INFO,"Step 5 Enter the contribution and save the value. "," The view only deferrals are displaying under deferrals group correctly.",false);	
		 enter_Contribution_Rate_PerCentage(sContributionRate);
		Mobile.clickElement(CONTINUE_BUT);
		String NonViewDeferralRate = Integer.toString(Integer.parseInt(sContributionRate) -Integer.parseInt(sViewOnlyRate));
		String sValue = NonViewDeferralRate+"% "+NonViewDeferralType+" WITH "+sViewOnlyRate+"% "+sViewOnlyType;

		Reporter.logEvent(Status.INFO,"Step 6-7   Verify  non-view only deferrals panel should displayed .",NonViewDeferralRate +"%",false);	
	   	Mobile.verifyElementPresent("Non View Only Deferral Panal", sValue, sValue );
	   
	   	Mobile.clickElement(CONTINUE_BUT);
		if(Mobile.is_Element_Displayed(By.name(ADD_AUTO_INCREASE_PAGE))){
	 		Mobile.clickElement(CONTINUE_BUT);	
	 	}		
				
		Reporter.logEvent(Status.INFO,"Step 7-8 Select Catch-Up ","Verify maximizer section is not displayed ",false);
		 click_ContributionType_Edit_Add_Button(CATCH_UP);
		Mobile.verifyElementNotPresent("Maximizer Limit section ", MAXIMIZE_LIMIT, "Maximizer section should not be displayed");
		Mobile.clickElement(CONTINUE_BUT);
		Mobile.clickElement(CONTINUE_BUT);
		if(Mobile.is_Element_Displayed(By.name(ADD_AUTO_INCREASE_PAGE))){
	 		Mobile.clickElement(CONTINUE_BUT);	
	 	}		
		Reporter.logEvent(Status.INFO,"Step 9 Submit Contribution Rate ","Verify view only deferrals are displaying under deferrals group correctly.",false);	
	     verify_MyContributions_Rate_Percentage(sViewOnlyType, sViewOnlyRate);   
		 verify_MyContributions_Rate_Percentage(NonViewDeferralType, NonViewDeferralRate);   
	
	}
	
	
	public void DDTC_12353_Split_Rate_Page_View_Only_Deferral(){
		Reporter.logEvent(Status.INFO,"Step 1-2: Navigate to My Accounts -> Plan -> My contributions. ","  System returns to My contributions page.",false);
     	String sViewOnlyRate =   get_MyContribution_Rate(UserBaseTest.getParaValue("ViewOnlyDeferralType"));	
		 setViewOnlyDeferralType(true,sViewOnlyRate);
		
		String sContributionRate = UserBaseTest.getParaValue("contribution_Rate");
	    
	 	
		Reporter.logEvent(Status.INFO,"Step 3 Select  Other deferral group.","Contribution rate selection page is displayed.",false);	
	     click_ContributionType_Edit_Add_Button(OTHER);
	   
	    
	    Reporter.logEvent(Status.INFO,"Step 4 -5 Enter the contribution rate  and click Continue "," Verify  in split rate page  non view deferral type are available with '0' contribution ",false);	
	     enter_Contribution_Rate_PerCentage(sViewOnlyRate);
	    Mobile.clickElement(CONTINUE_BUT);	
	     click_ContributionType_Edit_Add_Button(OTHER);
	    
	    Reporter.logEvent(Status.INFO,"Step 6 Enter split the value to available deferrals.","Participant is able to split the value to available deferrals.",false);	
		Reporter.logEvent(Status.INFO,"Step 7 Check that continue button is disabled until the total split rate contribution equals to contributions rate.","Verify Continue button is disable",false);	
		  setbVerifyConfirmation(false);
		 select_Standard_Contribution_Page(ENTER_CONTRIBUTION_RATE, SPLIT, sContributionRate);
		
	}
	
	public void DDTC_12354_Split_Page_One_Deferral_Enter_Rate_Less_Than_Minimum(){
		String sDeferralType = UserBaseTest.getParaValue("ViewOnlyDeferralType");
		String contribution_Rate  =  get_MyContribution_Rate(sDeferralType);	
		
		Reporter.logEvent(Status.INFO,"Step 3 -4 Select Standard-> Enter the value  ","Application returns to contribution rate selection page.",false);	
		 click_ContributionType_Edit_Add_Button(STANDARD);
		String MimRateValue = Common.subStringValue(contribution_Rate, 2);
		 enter_Contribution_Rate_PerCentage(MimRateValue);
		Mobile.clickElement(CONTINUE_BUT);	
		
//		Reporter.logEvent(Status.INFO,"Step 5 check that split rate section is defaulted to Roth deferral type "," In split rate page roth bonus is defaulted in split rate page.",false);	
//	    Mobile.verifyElement_Is_Not_Displayed("Deferral Type : "+sDeferralType, By.name(sDeferralType), sDeferralType +" should not be displayed.");
//		Mobile.clickElement(SPLIT);
//		String sObj ="//XCUIElementTypeStaticText[@name='SPLIT YOUR CONTRIBUTION']/following-sibling::*//*[contains(@name,'Roth')]/preceding-sibling::XCUIElementTypeTextField";
//	    Mobile.verify_Element_Value(sObj,MimRateValue, "Default rate value should be "+MimRateValue);		
//		
//		Reporter.logEvent(Status.INFO,"Step 6  Tap on continue and check that validation message is getting displayed ","Verify Error Message.",false);	
//		Mobile.clickElement(CONTINUE_BUT);
		String sErrormsg = "Contributions for "+UserBaseTest.getParaValue("contribution_Type")+" must be at least "+contribution_Rate+"%.";
		Mobile.verifyElementPresent("Message " , sErrormsg, sErrormsg);

		Reporter.logEvent(Status.INFO,"Step 7 Change the contributions and Submit the contribution "," Verify contribution values are displayed correctly.",false);	
	//	Mobile.clickElement(BACK_BUT);	
		 enter_Contribution_Rate_PerCentage(contribution_Rate);
		Mobile.clickElement(CONTINUE_BUT);
		Mobile.verifyElementPresent("Deferral Type  : "+sDeferralType , sDeferralType, sDeferralType + "  should be present");
		Mobile.clickElement(CONTINUE_BUT);
		if(Mobile.is_Element_Displayed(By.name(ADD_AUTO_INCREASE_PAGE))){
	 		Mobile.clickElement(CONTINUE_BUT);	
	 	}		 	
		 verifyHomePage(MY_CONTRIBUTION);
		
	}
	
	public void DDTC_5294_Adding_Company_Match_In_Contribution_Page(){
		

		Reporter.logEvent(Status.INFO,"Step 1-2: Navigate to My Accounts -> Plan -> My contributions. ","  System returns to My contributions page.",false);
		 click_ContributionType_Edit_Add_Button(STANDARD);	
		Reporter.logEvent(Status.INFO,"Step 3: Tap Standard->Enter Contribution Rate ","Participant is able to view the company match contribution ",false);
		
		
		Reporter.logEvent(Status.INFO,"Step 4- 5: Update the participant contribution  ","Verify company match is getting calculated based on the participant contribution and plan tier rule ",false);
	    Mobile.selectRadioButton(ENTER_CONTRIBUTION_RATE);
	    String contribution_Rate =UserBaseTest.getParaValue("contribution_Rate");
	     verifyAdding_Company_Match(contribution_Rate);
	     verifyAdding_Company_Match(Common.subStringValue(contribution_Rate, 2));
	     verifyAdding_Company_Match(Common.addStringValue(contribution_Rate, 2));  
	     
		Reporter.logEvent(Status.INFO,"Step 6: Tap on the continue . ","Verify that participant is navigated to split contribution page ",false);
		Mobile.clickElement(CONTINUE_BUT);
//		 verifyHomePage(  SELECT_CONTRIBUTION_HEADER);
			
		Reporter.logEvent(Status.INFO,"Step 7 -8 :Tap on confirm and continue to complete the contribution changes.","Check that company match information is not displayed in confirmation page as per participant selection.  ",false);
		Mobile.clickElement(CONTINUE_BUT);			 	
		if(Mobile.is_Element_Displayed(By.name(ADD_AUTO_INCREASE_PAGE))){
			Mobile.clickElement(CONTINUE_BUT);	
		}
		
		 if(Mobile.assertElementPresent(By.name(CONFIRM_AND_CONTINUE_BUT))){ 
		  Mobile.clickElement(CONFIRM_AND_CONTINUE_BUT);			    
		 //  clickAlertMessage();			
		  Common.waitTillElementNotDisplay(CONFIRMING_BUT);
		Mobile.verify_Text_Is_Not_Displayed(CONFIRM_CONTRIBUTIONS_TEXT, "Apple Match","Company match information is not displayed in confirmation page", false);
		 }else{
			 
		 }
	}
		 
		 public void DDTC_6302_Prior_plan_contributions_data_not_on_file_and_catch_up_allowed(){			 
				
				Mobile.verifyText(DeferralsPage.PPC_SECTION_CONTENT_XPATH, DeferralsPage.PPC_SECTION_CONTENT_MSG, false);
				Mobile.verify_Element_Is_Not_Selected(MAXIMIZE_SWITCH, "PPC  switch is OFF");		
						
				Reporter.logEvent(Status.INFO,"Step 8-11 Verify tooltip \"Why is this important?\" hiperlink and content in PCC page."," ",false);
				
			     setMaximize_Me_Always(true);
					
				//Split Option should be displayed
			     select_Contribution_Details(DeferralsPage.STANDARD, DeferralsPage.MAXIMIZE_LIMIT, DeferralsPage.SPLIT);
			     select_Contribution_Details(DeferralsPage.CATCH_UP, DeferralsPage.MAXIMIZE_LIMIT, DeferralsPage.CATCH_UP_BEFORE);
			  
				 String beforeTax = get_MyContribution_Rate_Percentage(APPLE_BEFORE_TAX);
				 String RothTax = get_MyContribution_Rate_Percentage(ROTH);
				 Reporter.logEvent(Status.INFO,"Standard Rate at Shopping cart on File"," Before Tax : "+beforeTax+" \n Roth Tax :"+RothTax,true);
					
				 String catchUpBeforeRate = get_MyContribution_Rate_Percentage(CATCH_UP_BEFORE);
				
				 Reporter.logEvent(Status.INFO,"CatchUp Rate at Shopping cart on File","CatchUp Before Tax : "+catchUpBeforeRate,false);
								 				 
							 	 
				
				Reporter.logEvent(Status.INFO,"Step 12 :Turn  PPC switch to ON ","Verify page  \"Prior Plan Contributions\" ",false);
			    Mobile.switchButton(true);			     
			    verify_PPC_HomePage();
			  
				Reporter.logEvent(Status.INFO,"Step 13 -15:  Verify Year to date Contribution default value "," Check that entry field for Year to date  contribution is not default to any value at the first time.",false);
			    verify_PPC_EditTextBox_Value("");		
				
				
				Reporter.logEvent(Status.INFO,"Step 16   Check that catch-up PPC contributions field is  displaying","Catch up edit box is display empty for first time ",false);
				Mobile.verifyElementPresent(" Catch Up Contribution Label",DeferralsPage.PPC_CATCH_UP_LABEL, "Catch-up PPC contributions field is  displaying if participant age is above than 50");
				verify_PPC_Catch_UP_EditTextBox_Value("");
				  
				Reporter.logEvent(Status.INFO,"Step 17 : Click Cancel Button "," My Contribution shopping cart page is displayed ",false);
				Mobile.clickElement(CANCEL_BUT);
			     verify_My_Contribution_HomePage();
				
				Reporter.logEvent(Status.INFO,"Step 18 -19 : Turn PPC switch to ON ","Verify the content is displayed in PPC page ",false);
				Mobile.switchButton(true);	
		     	
				Mobile.verifyElementPresent("PPC Content Page ", DeferralsPage.PPC_CONTENT_MSG, DeferralsPage.PPC_CONTENT_MSG);
				
		     	Reporter.logEvent(Status.INFO,"Step 20   Verify Save button is disable "," ",false);
				Mobile.verifyElementISDisable(DeferralsPage.SAVE_BUT, "Save button is disable");
				
				Reporter.logEvent(Status.INFO,"Step 21:  Enter value in the data for Year to date  and Catch Up contributions  text field"," Save button is enable",false);
				String sYearToDateAmount = UserBaseTest.getParaValue("year_to_date_amount");
				String catch_up_amount = UserBaseTest.getParaValue("catch_up_amount");
				enter_amount_in_PPC(sYearToDateAmount);
				enter_Amount_in_PPC_CatchUp(catch_up_amount);
				Mobile.verifyElementEnable(DeferralsPage.SAVE_BUT, "Save button is enable");
				
				Reporter.logEvent(Status.INFO,"Step 23: Click Save button  ","Shopping Cart Page is displayed ",false);
				Mobile.clickElement(DeferralsPage.SAVE_BUT);
				Common.waitForProgressBar();
				verify_My_Contribution_HomePage();
				
				 String beforeTax_After_Update = get_MyContribution_Rate_Percentage(APPLE_BEFORE_TAX);
				 String RothTax_after_Update = get_MyContribution_Rate_Percentage(ROTH);
				 
				 String catchUp_After_Update = get_MyContribution_Rate_Percentage(CATCH_UP_BEFORE);			 
			    if(beforeTax_After_Update.equals(beforeTax)){
			    	Reporter.logEvent(Status.PASS," Before Tax for Standard Should not change ","Before Tax for Standard Deferral is :"+beforeTax_After_Update,false);
			    	
			    }else{
			    	Reporter.logEvent(Status.FAIL," Before Tax for Standard Should not change ","On File was  :"+beforeTax+  " \n  Actual is : "+beforeTax_After_Update,true);
				  }
			    
			    if(RothTax_after_Update.equals(RothTax)){
			    	Reporter.logEvent(Status.PASS," Roth Tax for Standard Should not change ","Roth Tax for Standard Deferral is :"+RothTax_after_Update,false);
			    	
			    }else{
			    	Reporter.logEvent(Status.FAIL," Roth Tax for Standard Should not change ","On File was  :"+RothTax+  " \n  Actual is : "+RothTax_after_Update,true);
				        }
			    if(!catchUp_After_Update.equals(catchUpBeforeRate)){
			    	Reporter.logEvent(Status.PASS," Catch up Before Tax for Catch Up Should change ","Before Tax for Standard Deferral is :"+beforeTax_After_Update,false);
			    	
			    }else{
			    	Reporter.logEvent(Status.FAIL," CAtch Up Before Tax for Catch Up Should change ","On File was  :"+beforeTax+  " \n  Actual is : "+beforeTax_After_Update,true);
				     }
			
		
				Reporter.logEvent(Status.INFO,"Step 24-25: Verify Confirmation Number and Contribution Amount is displayed","",false);
				 Mobile.scroll_UP();
				String total_amount = UserBaseTest.getParaValue("total_amount");
				 verify_PPC_Content_Page(total_amount);	
		         verify_Shopping_Cart_Confirmation_Number();  
				
				Reporter.logEvent(Status.INFO,"Step 26-28: Tap on the Edit link  and Click Cancel Button.","Confirmation number is not getting displayed in shopping Cart Page",false);
				Common.clickEditLink(DeferralsPage.PPC_SECTION);	
				Mobile.clickElement(CANCEL_BUT);		
				Mobile.verifyElement_Is_Not_Displayed("Step 26", By.xpath(DeferralsPage.PPC_CONFIRMATION_NUM), "Confirmation should not be displayed");
				 verify_PPC_Content_Page(total_amount);	
					
					
				Reporter.logEvent(Status.INFO,"Step 29-30 :Tap on the edit link ","PPC page and displayed previously entered values for standard & catch-up.",false);
		    
				Common.clickEditLink(DeferralsPage.PPC_SECTION);
				 verify_PPC_EditTextBox_Value(sYearToDateAmount);
			     verify_PPC_Catch_UP_EditTextBox_Value(catch_up_amount);
				Mobile.clickElement(CANCEL_BUT);      
		          
			 
		 }
		 
		 public void DDTC_6289_Prior_plan_contributions_data_not_on_file_and_catch_up_not_allowed(){
			 

				Reporter.logEvent(Status.INFO,"Check that under PPC section following content is displaying with switch default to off position. ","Have you made contributions to any other retirement plans since 1/1/[current year]?",false);
				verify_PPC_Is_Enable();
				Mobile.verify_Element_Is_Not_Selected(MAXIMIZE_SWITCH, "PPC  switch should be OFF");		
				
				update_MyAnnual_Compensation_Salary(DeferralsPage.STANDARD,DeferralsPage.BEFORE_TAX);		
			    String sStandard_Rate_per_OnFile =DeferralsPage.getContributionRate();
			    
			    String beforeTax_Before_PPC_Update = get_MyContribution_Rate_Percentage(APPLE_BEFORE_TAX);		
				
				Reporter.logEvent(Status.INFO,"Step 12-15  :Turn  PPC switch to ON and  ","Entry field should be  not default to any value for the first time. ",false);
			    Mobile.switchButton(true);	
				
				Reporter.logEvent(Status.INFO,"Step 16   Check that catch-up PPC contributions field","Catch-up PPC contributions field should not be displyed for participant age is less than 50. ",false);
				Mobile.verifyElementNotPresent("Catch-up contributions Label",DeferralsPage.PPC_CATCH_UP_LABEL, "Catch-up PPC contributions field is not displaying if participant age is less than 50");

				Reporter.logEvent(Status.INFO,"Step 21:  Enter value in the data in  PPC contributions text field "," Save button should be enable",false);
				String sValueToEnter = UserBaseTest.getParaValue("year_to_date_amount");
				enter_amount_in_PPC(sValueToEnter);
				Mobile.verifyElementEnable(DeferralsPage.SAVE_BUT, "Save button shoukd be enabled");
				
				Reporter.logEvent(Status.INFO,"Step 23: Click Save button  ","Ppc page is getting closed and returns to Shopping Cart confirmation page ",false);
				Mobile.clickElement(DeferralsPage.SAVE_BUT);	
				Common.waitForProgressBar();
				 verify_My_Contribution_HomePage();
				 
				  String beforeTax_After_PPC_Update = get_MyContribution_Rate_Percentage(APPLE_BEFORE_TAX);
					 
				    if(!beforeTax_Before_PPC_Update.equals(beforeTax_After_PPC_Update)){
				    	Reporter.logEvent(Status.PASS," Before Tax for Standard Should  change ","Before Tax for Standard Deferral before update was  :"+beforeTax_Before_PPC_Update +" \n Before Tax after update PPC update :"+beforeTax_After_PPC_Update,false);
				    	
				    }else{
				    	Reporter.logEvent(Status.FAIL," Before Tax for Standard Should  change ","On File was  :"+beforeTax_Before_PPC_Update+  " \n After PPC update  is : "+beforeTax_After_PPC_Update,true);
					 }
				    
				
				Reporter.logEvent(Status.INFO,"PPC switch is displaying as ON/YES ","Verify PPC page content and  Confirmation Number is displayed",false);
				verify_PPC_Content_Page(sValueToEnter);
				Mobile.verifyElementPresent("Step 24", DeferralsPage.PPC_CONFIRMATION_NUM, "Confirmation number should be displayed");
				
				
				Reporter.logEvent(Status.INFO,"Step 25 -26: Tap on the Edit link for any other deferral group and click cancel button  without making any changes.","Confirmation number is not getting displayed in Prior plan contributions section",false);
				Common.clickEditLink(DeferralsPage.PPC_SECTION);	
				Mobile.clickElement(CANCEL_BUT);
				 verify_My_Contribution_HomePage();			
				Mobile.verifyElement_Is_Not_Displayed("Step 26", By.xpath(DeferralsPage.PPC_CONFIRMATION_NUM), "Confirmation should not be displayed");
				
				Reporter.logEvent(Status.INFO,"Step 27- 28 :Check that card title is displaying  ","Verify  \"Prior Plan Contributions\" page content.",false);
				 verify_PPC_Content_Page(sValueToEnter);		
					
				Reporter.logEvent(Status.INFO,"Step 29-30 :Tap on the edit link ","Application returns to PPC page and displayed previously entered values for standard & catch-up. ",false);
		   		Common.clickEditLink(DeferralsPage.PPC_SECTION);
				verify_PPC_EditTextBox_Value(sValueToEnter);
				Mobile.clickElement(CANCEL_BUT);   
				clickConfirm_And_Continue(APPLE_BEFORE_TAX);
				
		          
		 }
		 
		 public void DDTC_6309_Prior_plan_contributions_data_entered_during_session(){
				Reporter.logEvent(Status.INFO,"Step 1 -10: Tap on the Edit PPC link.","Verify previous entered value",false);
				Common.clickEditLink(DeferralsPage.PPC_SECTION);
			
				Reporter.logEvent(Status.INFO,"Step 11 :Enter PPC contribution values to \"0\" and save the values.  ","Verify  \"Prior Plan Contributions\" page content.",false);
				 enter_amount_in_PPC("0");
				Mobile.clickElement(DeferralsPage.SAVE_BUT);	
				Common.waitForProgressBar();
				 verify_PPC_Content_Page("0");			
				Reporter.logEvent(Status.INFO,"Step 12:Navigate to different page and come back to contribution page","Verify PPC switch default to 'Off' position.. ",false);
				HomePage.selectMenuOption("OVERVIEW");	
				HomePage.selectMenuOption("MY CONTRIBUTIONS");	
				Mobile.verify_Element_Is_Not_Selected(MAXIMIZE_SWITCH, "PPC  switch should be OFF");		
			      
		 }
	
		 
		 
		 /*
			 * This method willselct Contribution Details and verify  
			 */
			
		 public enum IsAutoIncreaseDisplay {
			 True,
			 False
		 }
			public void VerifyContributionDetailsWithFDD(String Contributing_type,String Contribution_type,String contribution_Rate,IsAutoIncreaseDisplay isAutoIncreaseDisplay,String fddMessageOnConfrimation){
			  	String before_split_rate  = "";
		    	String roth_split_Rate  ="";    	
				Boolean bEnter_Conter_Rate =false;
				
				Assert.assertTrue(Mobile.assertElementPresent(By.name(Contributing_type)), Contributing_type +"  : Contribution Type Option is not displayed");			 
				if(Contributing_type.equalsIgnoreCase(ENTER_CONTRIBUTION_RATE)){
					bEnter_Conter_Rate =true;
				}				
				 String sTaxLabel = null;
			 
			
			    	Mobile.clickElement(Contributing_type);		
			    	Reporter.logEvent(Status.INFO,"Contributing Type Selected :" ,Contributing_type,false);
			    	
			    	if(bEnter_Conter_Rate){
						enter_Contribution_Rate_PerCentage(contribution_Rate);
						contribution_Rate = contrbution_rate;
					}	
			    		    			
				   if(Contribution_type.equalsIgnoreCase(BEFORE_TAX)){	
					   if(getApplePlan()){
						   Contribution_type =APPLE_BEFORE_TAX;
					   }
					   
					   if(getbMaximize_Me_Always()){
						   sTaxLabel ="Before Tax(Maximize Me Always)";  
					   }else{
						   sTaxLabel ="Before Tax";
					   }			  
				   }
				   else if (Contribution_type.equalsIgnoreCase(ROTH)){	
					   if(getbMaximize_Me_Always()){
						   sTaxLabel ="Roth(Maximize Me Always)";  
					   }else{
						   sTaxLabel ="Roth";
					   }
					   sTaxLabel ="Roth";			   
				   }else if (Contribution_type.equalsIgnoreCase(SPLIT)){	

					   setSplitContributionValue(contribution_Rate);
					   sTaxLabel =  before_tax_split+"% Before Tax "+roth_split+"% Roth";	   
					 
						   
				   }
				   
				 

						 
					
					if(Contributing_type.equals(MAXIMIZE_LIMIT)){
						 Common.clickContinueButon();
					}
					else{
						Mobile.clickElement(CONTINUE_BUT);
					}
					
					
				   if(!Contribution_type.equals("")){
				 	
				    Mobile.selectRadioButton(Contribution_type);
					
				  
				    if(Contribution_type.equalsIgnoreCase(SPLIT) || Contribution_type.equalsIgnoreCase(CATCH_UP_SPLIT)){
				    			    	
				         before_split_rate =Integer.toString((int)before_tax_split);		         
				    	 roth_split_Rate =	Integer.toString((int)roth_split);
				     
				      		       	
				  
				       	if(getApplePlan()){
				       	 enter_Split_Your_Contribution_Rate("Traditional",before_split_rate );
				    	 //enter_Split_Your_Contribution_Rate(APPLE_BEFORE_TAX_LABEL,before_split_rate );
				       	}
				       	else{
				    	 enter_Split_Your_Contribution_Rate("Before",before_split_rate );
				       	}
				    	    	
				    }
				    else{
				    	
				    	
				    	CONFIRMATION_DEFERAL_TYPE ="";
				 //   verify_Select_Contribution_Rate(Contribution_type, contribution_Rate);	
				    if(CONTRIBUTING_RATE_TYPE.equals("%"))
				    	
				    CONFIRMATION_DEFERAL_TYPE = CONFIRMATION_DEFERAL_TYPE +contribution_Rate+ " "+CONTRIBUTING_RATE_TYPE+ " "+Mobile.getElementValue("//*[contains(@name,'"+Contribution_type+"')]");
				    else{
				    CONFIRMATION_DEFERAL_TYPE = CONFIRMATION_DEFERAL_TYPE +CONTRIBUTING_RATE_TYPE+contribution_Rate+ " " +Mobile.getElementValue("//*[contains(@name,'"+Contribution_type+"')]");
				 		 
				    }		    
				    } 
				   }
				   
				   CONFIRMATION_DEFERAL_TYPE = CONFIRMATION_DEFERAL_TYPE +" "+fddMessageOnConfrimation;
				   if(Mobile.is_Element_Displayed(By.name(CONTINUE_BUT))){			
				    Mobile.clickElement(CONTINUE_BUT);
					 Common.waitForProgressBar();
				   }
			
				   
				   if(isAutoIncreaseDisplay == IsAutoIncreaseDisplay.True) {
				 	Mobile.verifyElementPresent("Add Auto Increase Page should be display", ADD_AUTO_INCREASE_PAGE, "Add Auto Increase Page ");
				 		Mobile.clickElement(CONTINUE_BUT);	
				 		 Common.waitForProgressBar();
				 	}else {
				 		Mobile.verifyElementNotPresent("Add Auto Increase Page should not be dipslay", ADD_AUTO_INCREASE_PAGE, "Add Auto Increase Page ");
				 	}
				 	
				
				   
				    
				    if(bVerifyConfirmation){
				    Reporter.logEvent(Status.INFO,"Click CONFIRM & CONTINUE Button  ","Confirmation Page is display with expected Value",false);
				    Mobile.scroll_Down();
				    if(Mobile.assertElementPresent(By.name(CONFIRM_AND_CONTINUE_BUT))){
				        Mobile.clickElement(CONFIRM_AND_CONTINUE_BUT);			    
				      
					verify_Confirmation_Page(APPLE_PLAN,CONFIRMATION_DEFERAL_TYPE);	
				    }else{
				    	Reporter.logEvent(Status.FAIL, "Deferral Change Type was same as previous value", "CONTINUE and CONFIRMATION Button was not displayed", true);
				    	CONFIRMATION_DEFERAL_TYPE ="";
				    
				    }
				    
				    }			
			}
			
			
	
}

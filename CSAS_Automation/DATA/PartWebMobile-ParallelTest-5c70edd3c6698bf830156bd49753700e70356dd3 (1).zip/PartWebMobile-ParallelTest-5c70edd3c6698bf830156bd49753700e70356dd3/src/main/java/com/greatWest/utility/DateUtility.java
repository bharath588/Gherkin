package com.greatWest.utility;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;

public class DateUtility {
	
	public static void main(String a[]){
		List<String> si = getInvestmentsSubmissionTime();
	}

	public static String getCurrentYear(){	
	return Integer.toString(Calendar.getInstance().get(Calendar.YEAR));
	}
	
	
	public static String getCurrentDate(){	
		        
        TimeZone.setDefault(TimeZone.getTimeZone("EST"));         
		DateFormat dateFormat = new SimpleDateFormat("M/d/yyyy");
		Date date = new Date();
		return dateFormat.format(date);
	
		}
	
	
	
	public static List<String> getInvestmentsSubmissionTime(){
		List<String> timeStamp=new ArrayList<String>();
		String time =null;
		String time1 =null;
		String minute=null;
		String minute1=null;
		String hour=null;
		
		TimeZone timeZone1 = TimeZone.getTimeZone("Asia/Calcutta");
		
		Calendar cal = Calendar.getInstance();
		cal.setTimeZone(timeZone1);
		if(cal.get(Calendar.HOUR)==0){
			hour="12";
		}
		else{
			hour=Integer.toString(cal.get(Calendar.HOUR));
		}
		if(cal.get(Calendar.MINUTE)<=9){
			 minute="0"+Integer.toString(cal.get(Calendar.MINUTE));
			 minute1="0"+Integer.toString(cal.get(Calendar.MINUTE)-1);
		}
		else{
			 minute=Integer.toString(cal.get(Calendar.MINUTE));
			 minute1=Integer.toString(cal.get(Calendar.MINUTE)-1);
		}
		 time=cal.getDisplayName(Calendar.DAY_OF_WEEK, Calendar.LONG, Locale.getDefault())+","+" "+
					cal.getDisplayName(Calendar.MONTH, Calendar.LONG, Locale.getDefault())+" "
					+Integer.toString(cal.get(Calendar.DAY_OF_MONTH))+","+" "+
					Integer.toString(cal.get(Calendar.YEAR))+","+" "+
					hour+":"+minute+" "+cal.getDisplayName(Calendar.AM_PM, Calendar.LONG, Locale.getDefault());
		 
		 time1=cal.getDisplayName(Calendar.DAY_OF_WEEK, Calendar.LONG, Locale.getDefault())+","+" "+
				cal.getDisplayName(Calendar.MONTH, Calendar.LONG, Locale.getDefault())+" "
				+Integer.toString(cal.get(Calendar.DAY_OF_MONTH))+","+" "+
				Integer.toString(cal.get(Calendar.YEAR))+","+" "+
				hour+":"+minute1+" "+cal.getDisplayName(Calendar.AM_PM, Calendar.LONG, Locale.getDefault());
		
		 timeStamp.add(time);
		 timeStamp.add(time1);
		 
		 System.out.println("TIME STAMP1"+time);
		 System.out.println("TIME STAMP2"+time1);
		 
		return timeStamp;
		
	}
}

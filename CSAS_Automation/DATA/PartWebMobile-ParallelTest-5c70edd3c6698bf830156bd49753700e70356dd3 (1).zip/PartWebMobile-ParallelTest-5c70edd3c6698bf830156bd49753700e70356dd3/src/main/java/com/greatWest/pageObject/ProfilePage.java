package com.greatWest.pageObject;

import io.appium.java_client.MobileElement;
import io.appium.java_client.ios.IOSElement;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.pagefactory.iOSFindBy;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;

import java.util.List;

import lib.Reporter;
import lib.Stock;

import org.openqa.selenium.By;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.LoadableComponent;
import org.testng.Assert;

import appium.utils.Reader;

import com.aventstack.extentreports.Status;
import com.greatWest.login.UserBaseTest;
import com.greatWest.utility.Common;
import com.greatWest.utility.Mobile;

public class ProfilePage extends LoadableComponent<ProfilePage>{
	private LoadableComponent<?> parent;	
	

	private static String HEADER_PAGE = "Profile";
	
	@iOSFindBy(id ="Password")
	@CacheLookup
	private MobileElement PASSWORD_LINK;
	
	@iOSFindBy(id ="Username")
	@CacheLookup
	private MobileElement USERNAME_LINK;
	

	@iOSXCUITFindBy(className = "XCUIElementTypeTextField")
	@CacheLookup
    private MobileElement USERNAME_TEXTBOX;
	
	@iOSFindBy(id = "Back")
    private MobileElement BACK_BUT;
	
	
//	public String BACK_BUT = "Back";

	
	/** Empty args constructor
	 * 
	 */
	public ProfilePage() {
		this.parent = new HomePage();
		PageFactory.initElements(new AppiumFieldDecorator(Mobile.getDriver()), this);
	}
	
	/**
	 * Constructor taking parent as input
	 * 
	 * @param parent
	 */
	public ProfilePage(LoadableComponent<?> parent) {
		// this.driver = DriveSuite.webDriver;
		this.parent = parent;
		PageFactory.initElements(new AppiumFieldDecorator(Mobile.getDriver()), this);
	}
	

//	public static String HEADER_PAGE = "Profile";
	public String  PERSONAL_CONTACT_INFORMATION = "Personal contact information";
	
	public static String CLOSE_IMG = "Close";

	
	
	
//Pasword Page
//	public String PASSWORD_LINK ="Password";
	public String EDIT_PASSWORD_BUTTON ="EDIT PASSWORD";	
	public String   EDIT_PASSWORD_PAGE="Edit password";
	public String   VALID_PASSWORD="Valid password";
	public String  PASSWORD_TEXTBOX_LIST= "XCUIElementTypeSecureTextField";
	public String  PASSWORD_BUTTON_LIST= "XCUIElementTypeButton";
	
	public String  MESSAGE_LABEL_TEXT = "XCUIElementTypeStaticText";
	public String PASSWORD_MUST_BE_BETWEEN_8_16_CHAR_MSG ="• Password must be between 8-16 characters";
	public String MUST_INCLUDE3_OFTHESE_4_MSG ="• Must include 3 of these 4";
	public String MUST_INCLUDE2_OFTHESE_3_MSG ="• Must include 2 of these 3";
	public String MUST_INCLUDE1_OFTHESE_2_MSG ="• Must include 1 of these 2";
	public String  UPPER_CASE_MSG ="• Uppercase letter";
	public String   LOWERCASE_MSG ="• Lowercase letter";
	public String   SPECIAL_CHAR_MSG ="• Special character";
	public String   NUMBER_MSG ="• Number";

	

	//UserName Page
//	public String USERNAME_LINK = "Username";	
	public String   EDIT_USERNAME_PAGE="Edit username";
	public String AT_LEAST_6_CHAR_MSG  ="• Must be at least 6 characters";
	public String  AT_LEAST_3_LETTER_MSG ="• Must include at least 3 letters";
	public String  AT_LEAST_1_NUMBER_MSG ="• Must include at least 1 number";
	public String  EDIT_USERNAME_BUT ="EDIT USERNAME";	

	public String   VALID_USERNAME="Valid username";	//
	public String CANCEL_BUT = "CANCEL";
	public String SAVE_BUT = "SAVE";
	public String CLOSE_BUT = "Close";

	
	
	public String NEXT_BUT = "Next";
	public String DONE_BUT = "Done";
	
	

	public String   ENTER_CURRENT_PASSWORD = "ENTER CURRENT PASSWORD";	
	public String	CREATE_NEW_PASSWORD ="CREATE NEW PASSWORD";
	public String	CONFIRM_NEW_PASSWORD  ="CONFIRM NEW PASSWORD";

  //Personal Contact Information

	public String PERSONAL_EMAIL_ADD_LABEL = "Personal email address";
	public String PERSONAL_CONTACT_LABEL = "Personal contact information";
	public String PHONE_LABEL = "Phone number";
	 
	public String EDIT_CONTACT_INFO_BUT = "EDIT CONTACT INFORMATION";
	 
	public String EDIT_PERSONAL_PAGE = "Edit personal contact information";
	 
	public String EMAIL_INVALID_MSG = "Email address is invalid.";
	public String PHONE_INVALID_MSG ="Phone number must be 10 digits.";
	 
	//Communication preference
	
	public String COMMUNICATION_PREFERENCE = "Communication preference";	

	
	//public String ELECTRONIC_CONTENT ="You have not chosen a communication preference. Your plan sponsor has elected you to receive confirmations and prospectuses electronically.";
	public String ELECTRONIC_CONTENT ="You have chosen to receive confirmations";
	public String ELECTRONIC_CONTENT_2 ="You have chosen to receive confirmations, statements, notices and prospectuses electronically.";
	
	public String EDIT_PREFERENCE_BUT= "EDIT PREFERENCE";
	
	public String ELECTRONIC_DELIVERY ="Electronic Delivery";
	
	public String MAIL_CONTENT = "You have chosen to receive all documents by mail.";
	public String PREF_EMAIL_ADDRESS = "Preferred email address";
//	public String SWITCH_BUTTON1 = "//XCUIElementTypeSwitch";
	
	
	//XCUIElementTypeStaticText
	
	
//			
//			Password entries must match.
	
	
	
	
	

	@Override
	protected void isLoaded() throws Error {
		// TODO Auto-generated method stub		
		Assert.assertTrue(Mobile.assertElementPresent(By.name(HEADER_PAGE)),"Profile Page is not loaded");	
			
	}
	
	

	@Override
	protected void load() {
		// TODO Auto-generated method stub
		HomePage homePage = (HomePage) this.parent;
		this.parent.get();			
		try {			
			HomePage.selectMenuOption("PROFILE");			
		
		} catch (Exception e) {
			// TODO Auto-generated catch block
		e.printStackTrace();
		}    
	}
	
	/*
	 * This method will verify the Home page 
	 */

	public void verify_Profile_HomePage(){		
			if(Mobile.assertElementPresent(By.name(HEADER_PAGE)))
					Reporter.logEvent(Status.PASS, "Verify Profile Page is displayed "," Profile Page is diplayed", true);
				else{
				     Assert.assertTrue(false, " Profile page  is not displyed");  
				}
			
		}
	
	
	public void verify_Password_Page(){		
		Mobile.clickElement(PASSWORD_LINK);
		verify_Profile_HomePage();
		Mobile.verifyElementPresent("Password  should be encrypted", "●●●●●●●●●●●", "Password is  displayed  ●●●●●●●●●●●");
	
		
	}
	
	public void verify_UserName_Page(){		
		Mobile.clickElement(USERNAME_LINK);
		verify_Profile_HomePage();
		Mobile.verifyElementPresent("User name  should be displayed ",LoginPage.getUserLogIN(), " User Name displayed :"+LoginPage.getUserLogIN() );
	
		
	}
	
	public void update_UserName(String sUserName){		
		Mobile.clickElement(USERNAME_LINK);
		Mobile.clickElement(EDIT_USERNAME_BUT);
		Mobile.setEdit(USERNAME_TEXTBOX, sUserName);
//		IOSElement userTextBox =  Mobile.findElement(USERNAME_TEXTBOX);
//		userTextBox.clear();
//		userTextBox.clear();
//		userTextBox.sendKeys(sUserName);
		Mobile.clickElement(DONE_BUT);
		Mobile.clickElement(SAVE_BUT);
		Common.waitForProgressBar();
		if(Common.ifServerError()){
		   Assert.fail("Not able to update  UserName in Profile Page");	
		}		
		//verify_Profile_HomePage();
		Mobile.verifyElementPresent("Username  should be updated and  displayed as :  ",sUserName, " User Name :"+ sUserName );
		Mobile.clickElement(BACK_BUT);	
	    Common.waitForProgressBar();
	}
	
	
	public void update_Password(String sPassWord,Boolean isNew){	
		Mobile.clickElement(PASSWORD_LINK);
		 Common.waitForProgressBar();
		if(!Mobile.is_Element_Displayed(By.name(EDIT_PASSWORD_BUTTON))){
			Mobile.clickElement(PASSWORD_LINK);
		}
		Mobile.clickElement(EDIT_PASSWORD_BUTTON);
		Mobile.wait(1000);
		List<IOSElement> testBoxList = (List<IOSElement>) Mobile.getDriver().findElements(By.className(PASSWORD_TEXTBOX_LIST));	
	     String sActPassWord = Reader.getUserNameParam("passWord");
		
		if(isNew){
	 		testBoxList.get(0).sendKeys(sActPassWord);
	 		testBoxList.get(1).sendKeys(sPassWord);
			testBoxList.get(2).sendKeys(sPassWord);		
			Reporter.logEvent(Status.PASS,"Updated Password in Profile Page ", sPassWord,false);
	 	}else{	 	
			testBoxList.get(0).sendKeys(sPassWord);
	 		testBoxList.get(1).sendKeys(sActPassWord);
			testBoxList.get(2).sendKeys(sActPassWord);
			Reporter.logEvent(Status.PASS,"Updated Password in Profile Page ", sActPassWord,false);
	 	}
	 	
	 	Mobile.clickElement(DONE_BUT);
		Mobile.clickElement(SAVE_BUT);
		Common.waitForProgressBar();
		if(Common.ifServerError()){
			   Assert.fail("Not able to update  Password in Profile Page");	
		}	
	//	Mobile.verifyElementPresent("Password  should be encrypted", "●●●●●●●●●●●●●●●●", "Password is  displayed  ●●●●●●●●●●●●●●●●");
		Mobile.clickElement(BACK_BUT);	
		
		
	}
	
	public void verify_User_Password_Updated() throws Exception{
		update_UserName(UserBaseTest.getParaValue("updateUserName"));
	
		update_Password(UserBaseTest.getParaValue("updatePassWord"), true);
		HomePage.selectMenuOption("BACK","LOG OUT");
	    submitLogin(UserBaseTest.getParaValue("updateUserName"),UserBaseTest.getParaValue("updatePassWord"));
		new MFAPage().submitVerificationCode(Stock.getConfigParam("defaultActivationCode"),false,false);
		HomePage.selectMenuOption("PROFILE");	
		update_UserName(LoginPage.getUserLogIN());
		update_Password(UserBaseTest.getParaValue("updatePassWord"), false);
	}
	
	
	
	public void verify_Communication_Perf_Page(){
		String sOption = UserBaseTest.getParaValue("Communication_Perf");
		Mobile.clickElement(COMMUNICATION_PREFERENCE);
		Mobile.clickElement(EDIT_PREFERENCE_BUT);
	    String[] expLabel = null;	
				
		if(sOption.equals("mail")){
			Mobile.switchButton(true);		
		  expLabel = new String[] {ELECTRONIC_DELIVERY,ELECTRONIC_CONTENT,PREF_EMAIL_ADDRESS};			
		}
		else{
			Mobile.switchButton(false);		
		   expLabel =  new String[] {ELECTRONIC_DELIVERY,MAIL_CONTENT};	  			
		}
		
		Reporter.logEvent(Status.INFO,"In Communication Pereference select option :"+sOption+ " delivery ","Click Save button and verify label displayed in Communication Perf page ",false);
	   if(Mobile.is_Element_Enable(SAVE_BUT)){
			Mobile.clickElement(SAVE_BUT);
		    Common.waitForProgressBar();	
	   }else{
		Mobile.clickElement(CANCEL_BUT);
	   }
	  	Common.verify_Value_InList_Contain(MESSAGE_LABEL_TEXT, expLabel, sOption+" delivery option should  displayed");		
	//	verify_Value_InList_Contain(MESSAGE_LABEL_TEXT,expLabel," "+sOption+" delivery option should be displayed");
		Mobile.clickElement(BACK_BUT);
		
		
	}
	
	public void submitLogin(String user,String Password){
	Reporter.logEvent(Status.INFO,"Login with USER ID :",user,false);
	Mobile.setEdit("GWMUsernameTextField",user.trim());
	Mobile.setEdit("GWMPasswordTextField",Password.trim());	
	Mobile.hideKeyboard();			
	Mobile.clickElement("GWMLoginButton");			
	Common.waitTillElementNotDisplay("GWMLoginButton");	
	Mobile.wait(2000);
	Assert.assertFalse(Mobile.assertElementPresent(By.name("GWMUsernameTextField")),"User is not able to Login");
	}
	
	public void verify_UserName_Edit_Page_Details(){
		
		Mobile.clickElement(EDIT_USERNAME_BUT);
	//	IOSElement userTextBox =  Mobile.findElement(USERNAME_TEXTBOX);
		 Mobile.verifyElementISDisable(SAVE_BUT, "Save Button should be  disable");
		 USERNAME_TEXTBOX.clear();
		 String[] expMsg = {EDIT_USERNAME_PAGE,AT_LEAST_6_CHAR_MSG,AT_LEAST_3_LETTER_MSG,AT_LEAST_1_NUMBER_MSG};
		 verify_Value_InList_Contain(MESSAGE_LABEL_TEXT,expMsg,"Clear UserName  Text Box and verify the message is displayed");
		  
		  String[] expMsg2 = {EDIT_USERNAME_PAGE,AT_LEAST_6_CHAR_MSG,AT_LEAST_1_NUMBER_MSG};
		  USERNAME_TEXTBOX.sendKeys("Abc");
		  verify_Value_InList_Contain(MESSAGE_LABEL_TEXT,expMsg2,"Enter Three Letter  UserName  Text Box and verify the message is displayed");
		 
		  String[] expMsg3 = {EDIT_USERNAME_PAGE,AT_LEAST_6_CHAR_MSG};	  
		  USERNAME_TEXTBOX.sendKeys("1");
		  verify_Value_InList_Contain(MESSAGE_LABEL_TEXT,expMsg3,"Enter One Number in  UserName  Text Box and verify the message is displayed");
		
		  String[] expMsg4 = {EDIT_USERNAME_PAGE,VALID_USERNAME};	  
		  USERNAME_TEXTBOX.clear();
		  USERNAME_TEXTBOX.sendKeys("Test@1234");
		  Mobile.clickElement(DONE_BUT);
		  verify_Value_InList_Contain(MESSAGE_LABEL_TEXT,expMsg4,"Enter Valid  UserName  Text Box and verify the message is displayed");
			 
		 		  
		  Mobile.verifyElementEnable(SAVE_BUT, "Save Button is enable");	
		  Mobile.clickElement(CANCEL_BUT);
		  Mobile.clickElement(BACK_BUT);
		  
		  
	
		
	}
	
	public void verifyElementList(String sObj, String[] expList,String sMsg ){
	
	Mobile.wait(2000);
	List<IOSElement> message_List = (List<IOSElement>) Mobile.getDriver().findElements(By.className(sObj));	
    	String sActResult = "";
	   String sExpResult = "";
	   Boolean sStatus = true;
		int i =0;
		
		if(message_List.size() != expList.length){
			sStatus = false;
		}
		
		for (IOSElement iosElement : message_List) {
			String value = iosElement.getText().trim();
			sActResult = sActResult+ "\n "+ value;
			
			while(i < expList.length){
				sExpResult =sExpResult +"\n "+expList[i];
				if(!value.trim().contains(expList[i])){
					sStatus = false;
					break;
				}else{
				i++;
				break;
				}
			}
			if(!sStatus){
				break;
			}
			
			
		}		
		if(sStatus){
			Reporter.logEvent(Status.PASS,sMsg, sActResult,false);
	}else{
	     Reporter.logEvent(Status.FAIL,"sMsg"," Expected :  "+sExpResult +"  But Actual was :"+sActResult,true);		
	}
	
}
	
	
	public void verify_Value_InList_Contain(String sObj, String[] expected ,String sMsg){
		Boolean bStatus = false;
		Mobile.wait(500);
		List<IOSElement> message_List = (List<IOSElement>) Mobile.getDriver().findElements(By.className(sObj));		
		 
		
		   for (int i = 0; i < expected.length; i++) {
			   bStatus= false;
			   for (IOSElement ioSEle : message_List) {
				   String elementsValue = ioSEle.getText();
				    if(expected[i].equals(elementsValue)){
				    	bStatus= true;
				    	break;
				    }			    
			   }	
			   if(bStatus){
			    	  Reporter.logEvent(Status.PASS,sMsg  ,expected[i] + " \n is Displayed",false);	
			    }else{
			    	Reporter.logEvent(Status.FAIL, sMsg ,"Not Displayed \n"+expected[i] ,true);	
			    }
	
	}
	
	}
	
	

	
	
	public void Verify_Password_Validation_Message(){
		   String[] expMsg = {EDIT_PASSWORD_PAGE,PASSWORD_MUST_BE_BETWEEN_8_16_CHAR_MSG,MUST_INCLUDE3_OFTHESE_4_MSG,UPPER_CASE_MSG,LOWERCASE_MSG,NUMBER_MSG,SPECIAL_CHAR_MSG};
		List<IOSElement> textBoxList = (List<IOSElement>) Mobile.getDriver().findElements(By.className(PASSWORD_TEXTBOX_LIST));	
		IOSElement CurrentPassword = 	textBoxList.get(1);
		CurrentPassword.click();	
		verify_Value_InList_Contain(MESSAGE_LABEL_TEXT,expMsg,"Click Current Password Text Box and verify the message is displayed");	
		
	//	Reporter.logEvent(Status.INFO ,"Enter Upper Cases Letter in Current Password ", "Verify Message  displayed",false);
		CurrentPassword.sendKeys("T");
		 String[] expMsg2 = {EDIT_PASSWORD_PAGE,PASSWORD_MUST_BE_BETWEEN_8_16_CHAR_MSG,MUST_INCLUDE2_OFTHESE_3_MSG,LOWERCASE_MSG,NUMBER_MSG,SPECIAL_CHAR_MSG};
		 verify_Value_InList_Contain(MESSAGE_LABEL_TEXT,expMsg2,"Enter Upper Cases Letter in Current Password and verify the message is displayed");		
		
		//Reporter.logEvent(Status.INFO ,"Enter Upper Cases and lower cases Letter in Current Password ", "Verify Message  displayed",false);
		CurrentPassword.sendKeys("e");
		 String[] expMsg3 = {EDIT_PASSWORD_PAGE,PASSWORD_MUST_BE_BETWEEN_8_16_CHAR_MSG,MUST_INCLUDE1_OFTHESE_2_MSG,NUMBER_MSG,SPECIAL_CHAR_MSG};
		 verify_Value_InList_Contain(MESSAGE_LABEL_TEXT,expMsg3,"Enter Upper Cases and lower cases Letter in Current Password and verify the message is displayed");		
		
	//	Reporter.logEvent(Status.INFO ,"Enter Upper Cases and lower cases and Number  in Current Password ", "Verify Message  displayed",false);
		
		CurrentPassword.sendKeys("1");
	    String[] expMsg4 = {EDIT_PASSWORD_PAGE,PASSWORD_MUST_BE_BETWEEN_8_16_CHAR_MSG};
	    verify_Value_InList_Contain(MESSAGE_LABEL_TEXT,expMsg4,"Enter Upper Cases and lower cases and Number  in Current Password and verify the message is displayed");		
		
		//Reporter.logEvent(Status.INFO ,"Enter more than 16 char in Current Password ", "Verify Message  displayed",false);
		
		CurrentPassword.sendKeys("Test@123456789101112");	  
		verify_Value_InList_Contain(MESSAGE_LABEL_TEXT,expMsg4,"Enter more than 16 char in Current Password and verify the message is displayed");	
		
		//Reporter.logEvent(Status.INFO ,"Enter more than valid 8 -16 char in Current Password ", "Verify Message  displayed",false);
	
		CurrentPassword.clear();
		CurrentPassword.sendKeys("Test@12345678");	
		String[] expMsg5 = {EDIT_PASSWORD_PAGE,VALID_PASSWORD};
		verify_Value_InList_Contain(MESSAGE_LABEL_TEXT,expMsg5,"Enter more than valid 8 -16 char in Current Password and verify the message is displayed");	
		Mobile.clickElement(NEXT_BUT);
		Mobile.clickElement(DONE_BUT);
		Mobile.clickElement(CANCEL_BUT);
		Mobile.clickElement(BACK_BUT);	   
		
	}
	
	
	
	public void verify_Element_InList_By_Value1(String sObj,String[] expected,String sOption ,String sMsg){
		List<IOSElement> textBoxList = (List<IOSElement>) Mobile.getDriver().findElements(By.className(sObj));	
				
	    for (int i = 0; i < expected.length; i++) {
		    String elementsValue = textBoxList.get(i).getAttribute(sOption);
		    if (elementsValue.equals(expected[i])) {
		    	Reporter.logEvent(Status.PASS,sMsg +": \n "+ expected[i],  expected[i]+ " is Displayed.",false);
		    } else {
		    	Reporter.logEvent(Status.FAIL,sMsg +" "+expected[i], "But Acutal was "+elementsValue,false);
		}	
	
		    }
		
	}
	
	

	
	
	
	
	public void  verify_Password_Edit_Page_Details(){
		Mobile.clickElement(EDIT_PASSWORD_BUTTON);
		String[] expected_Button = {CLOSE_BUT,CANCEL_BUT,SAVE_BUT}; 
		Common.verify_Value_InList_Contain(PASSWORD_BUTTON_LIST, expected_Button, "Verify Edit Password Page should contain Button");
	//    verify_Element_InList_By_Value(PASSWORD_BUTTON_LIST, expected_Button,"label","Verify Edit Password Page should contain Button");
	      String[] expected = {ENTER_CURRENT_PASSWORD,CREATE_NEW_PASSWORD,CONFIRM_NEW_PASSWORD}; 	  
	  	Common.verify_Value_InList_Contain(PASSWORD_TEXTBOX_LIST, expected, "Verify Edit Password Page should contain Text box");	
	  //  verify_Element_InList_By_Value(PASSWORD_TEXTBOX_LIST, expected,"value","Verify Edit Password Page should contain Text box");	    
	      Mobile.verifyElementISDisable(SAVE_BUT, "Save Button is disable");
	
		 }
		    	    
	
	
	public void verify_Personal_Contact_Info_Page(){
		Mobile.clickElement(PERSONAL_CONTACT_INFORMATION);	
		 String[] expLabel = {PERSONAL_CONTACT_LABEL};
		 verify_Value_InList_Contain(MESSAGE_LABEL_TEXT, expLabel, " Personal Contact Information Page  should contain label");
		 Mobile.clickElement(EDIT_CONTACT_INFO_BUT);	
		  String[] expected_Button = {CLOSE_BUT,CANCEL_BUT,SAVE_BUT}; 
		  
		  	Common.verify_Value_InList_Contain(PASSWORD_BUTTON_LIST, expected_Button, "Verify Personal Contact Info Page should contain Button");

		//   verify_Element_InList_By_Value(PASSWORD_BUTTON_LIST, expected_Button,"label","Verify Personal Contact Info Page should contain Button");
		 		 
			List<IOSElement> textBoxList = (List<IOSElement>) Mobile.getDriver().findElements(By.className("XCUIElementTypeTextField"));	
			//For email 
			
			IOSElement emailTextBox = textBoxList.get(0);
			IOSElement PhoneTextBox = textBoxList.get(1);
			
			String sActEmail = emailTextBox.getText();
			String sActPhone = PhoneTextBox.getText();
			String sExpEmail = "Test@gmail.com";
			String sExpPhone ="1234567891";
			if(sActEmail.equals(sExpEmail)){
				sExpEmail ="Test12@gmail.com";
			}
			if(sActPhone.equals(sExpPhone)){
				sExpPhone ="1987654321";
			}
			
			
			emailTextBox.clear();
			Mobile.clickElement(NEXT_BUT);
			Mobile.verifyElementPresent("Clear Email text Box and verify Email Invalid message", EMAIL_INVALID_MSG, EMAIL_INVALID_MSG);
			emailTextBox.sendKeys("Invalid Email");
			Mobile.clickElement(NEXT_BUT);
			Mobile.verifyElementPresent(" Enter Invalid  email and verify invalid email message", EMAIL_INVALID_MSG, EMAIL_INVALID_MSG);
			emailTextBox.clear();
			emailTextBox.sendKeys(sExpEmail);
			Mobile.clickElement(NEXT_BUT);
			// clear Phone number 
			PhoneTextBox.clear();
			Mobile.clickElement(DONE_BUT);
			Mobile.verifyElementPresent("Clear Phone number  and verify validation message for Phone number", PHONE_INVALID_MSG, PHONE_INVALID_MSG);
			PhoneTextBox.sendKeys("123456");
			Mobile.clickElement(DONE_BUT);
			Mobile.verifyElementPresent(" Enter Invalid  Phone Number  and verify validation message for Phone number", PHONE_INVALID_MSG, PHONE_INVALID_MSG);
			PhoneTextBox.clear();
			PhoneTextBox.sendKeys(sExpPhone);
			Mobile.clickElement(DONE_BUT);			
			Mobile.clickElement(SAVE_BUT);
			if(!Common.ifServerError())	{		
			Common.waitForProgressBar();
			String[] expLabel2 = {sExpEmail};
			verify_Value_InList_Contain(MESSAGE_LABEL_TEXT, expLabel2, "Email should be updated");
		    Mobile.clickElement(BACK_BUT);
			}else{
			Reporter.logEvent(Status.FAIL, "Not able to save Contact information","" , true);
			Mobile.clickElement(CLOSE_IMG);
			 Mobile.clickElement(BACK_BUT);
			
			}
			
	}
		    
	
		
		

	
	
}

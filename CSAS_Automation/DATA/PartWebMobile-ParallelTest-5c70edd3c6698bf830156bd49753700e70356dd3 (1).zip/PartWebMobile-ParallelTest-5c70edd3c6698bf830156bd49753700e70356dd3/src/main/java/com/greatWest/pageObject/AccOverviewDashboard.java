package com.greatWest.pageObject;

import io.appium.java_client.MobileElement;
import io.appium.java_client.ios.IOSElement;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.pagefactory.iOSFindBy;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;

import java.util.List;

import lib.Reporter;

import org.openqa.selenium.By;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.LoadableComponent;
import org.testng.Assert;

import com.aventstack.extentreports.Status;
import com.greatWest.login.UserBaseTest;
import com.greatWest.utility.Common;
import com.greatWest.utility.DateUtility;
import com.greatWest.utility.Mobile;

public class AccOverviewDashboard extends LoadableComponent<LoginPage>{
	
	private LoadableComponent<?> parent;
	
	
	private String  accountOverView ="Account overview";
	public static String currentYear = DateUtility.getCurrentYear();
	
	
    @iOSXCUITFindBy(iOSNsPredicate = "label CONTAINS 'As of'")
	 private MobileElement asOfDate;
    
 
  
     @iOSFindBy(accessibility = "BALANCE")
	private MobileElement balanceCard;
    
    @iOSFindBy(accessibility = "RATE OF RETURN")
  	private MobileElement rateOfReturnCard;
    
    @iOSFindBy(accessibility = "YTD contributions")
  	private MobileElement YTDContributions;
    @iOSFindBy(accessibility = "Est. on track to contribute")
  	private MobileElement trackToContribution;
   
  	public String IRS_Limit = currentYear+" IRS limit";  
   
    
//    @iOSFindBy(accessibility = "2018 CONTRIBUTIONS")
//  	private MobileElement contributionCard;    

    public String beneficiariesCard = "BENEFICIARIES";
    public String contributionCard = currentYear+" CONTRIBUTIONS";
    

    private String loanBalanceCard = "LOAN BALANCE";    

    private String transactionHistoryCard = "TRANSACTION HISTORY";
    
    @iOSFindBy(xpath = "//XCUIElementTypeStaticText[contians(@name,'CONFIRMATION NUMBER')]")  
  	private MobileElement confNumberCol;
    
    @iOSFindBy(accessibility = "AMOUNT")
  	private MobileElement amountCol;
    
    @iOSFindBy(accessibility = "None on file.")
  	public MobileElement NoneOnFile;    
    
    
    @iOSFindBy(xpath = "//XCUIElementTypeOther[@name='TOTAL ACCOUNT BALANCE']")
  	private MobileElement totalCurrentAmount;
    
    @iOSFindBy(accessibility = "ESTIMATED RETIREMENT INCOME")
   	private MobileElement liatPage; 
    
    @iOSFindBy(xpath = "//XCUIElementTypeStaticText[@name='Asset allocation']")
  	private MobileElement assetAllocationPage;
    
    
    @iOSFindBy(xpath = "//XCUIElementTypeStaticText[@name='Rate of return']")
  	private MobileElement rateOfReturnPage;
    
    @iOSFindBy(xpath = "//XCUIElementTypeStaticText[@name='Beneficiaries']")
  	public MobileElement beneficiariesPage;
    
    
 
		
  
    
  private static Boolean liatAmountToVerify = false;
  
  public void setLiatAmountToVerify(Boolean flag){
	  liatAmountToVerify = true;
  }
    
  public Boolean getLiatAmountToVerify(){
	  return liatAmountToVerify;
  }
    

	@Override
	protected void isLoaded() throws Error {
		Assert.assertTrue(Mobile.assertElementPresent(By.name(accountOverView)),"Account Overview Dashboard Page is not loaded");		
		 Reporter.logEvent(Status.INFO,"Navigate to Account Overview Page." ,"Account Overview page is displayed." ,true); 
	}
	
	static String currentAmount = null;

	@Override
	protected void load() {		
		 this.parent.get();		
		 if(getLiatAmountToVerify()){
		 if(Mobile.is_Element_Displayed(liatPage)){
			 currentAmount = Mobile.getElementValue(totalCurrentAmount);
			Reporter.logEvent(Status.INFO,"Total amount in LIAT Page is : " ,currentAmount ,true); 
		 }
		 }
		 HomePage.selectMenuOption("MY ACCOUNT","OVERVIEW");		
		
	}
	
	
	/** Empty args constructor
	 * 
	 */
	public AccOverviewDashboard() {
		this.parent = new  HomePage();
		PageFactory.initElements(new AppiumFieldDecorator(Mobile.getDriver()), this);
	}
	
	

	public String getWebElement(String fieldName) {
		
		if (fieldName.trim().equalsIgnoreCase(beneficiariesCard)) {
			return this.beneficiariesCard;
		} 
		return null;
	}
	
	

	
	
	public  void verifyAODCard(){			
		Mobile.verifyElementPresent("Balance card should be display.", balanceCard, "Balance Card");
		Mobile.verifyElementPresent("Rate of Return card should be display.", rateOfReturnCard, "Rate of Return Card");
		verifyCardDetails("BALANCE");
		verifyCardDetails("RATE OF RETURN");
		Mobile.clickElement(balanceCard);
		Common.waitForProgressBar();
		Mobile.verifyElementPresent("Tap Business card and Asset Allocation Page should be display",assetAllocationPage,"Asset Allocation Page ");
		HomePage.selectMenuOption("OVERVIEW");
		Mobile.clickElement(rateOfReturnCard);
		Common.waitForProgressBar();
		Mobile.verifyElementPresent("Tap Rate of Retirn card and Rate of return Page should be display",rateOfReturnPage,"Rate of return Page ");
			
	}
	
	//XCUIElementTypeStaticText[@name='AFTER-TAX']/../XCUIElementTypeOther//XCUIElementTypeStaticText[@name="YTD contributions"]
	
	
	
	/**
	 * 
	 * 	CONFIRMATION NUMBER / TYPE
		TRANSACTION HISTORY
		AMOUNT
		BENEFICIARIES
		(1 Primary, 3 Contingent)
		Last updated: 8/30/2016
		LOAN BALANCE
	 * @param cardName
	 */
	public void verifyTransactionHistoryCard(){		
//	Mobile.verifyElementPresent("Transcation History Card should be display.", transactionHistoryCard, "TRANSACTION HISTORY Card");
//	//Mobile.verifyElementPresent("Transcation History Card should  display CONFIRMATION NUMBER / TYPE Column.", confNumberCol, "Confirmation Number column");
//	
//	Mobile.verifyElementPresent("Transcation History Card should  display AMOUNT Column.", amountCol, "Amount column");
	System.out.println("Test");
		List<IOSElement> listOfTransaction =   Mobile.getListOfElementsByXpath("//XCUIElementTypeStaticText[@name='TRANSACTION HISTORY']/../XCUIElementTypeOther[2]/XCUIElementTypeOther");
	if(listOfTransaction.size() == 5){
		Reporter.logEvent(Status.PASS,"Number of Transaction History list should be 5" , " Transaction History list is total 5" ,false);
	}else{
	     Reporter.logEvent(Status.FAIL,"Number of Transaction History list should be 5"," Transaction History list is not total 5",true);
	}
	 
	}
	
	
	public void verifyBeneficiariesCard(){
		verifyCardDetails(beneficiariesCard);
		Mobile.clickElement(beneficiariesCard);
		Common.waitForProgressBar();
		Mobile.verifyElementPresent("Tap Beneficiaries card and Beneficiaries Page should be display",beneficiariesPage,"Beneficiaries Page ");
			
	}
	
	private void verifyCardDetails(String cardName){		
		String xpathofCard = "//XCUIElementTypeStaticText[@name='"+cardName+"']/../XCUIElementTypeStaticText";
		List<MobileElement> eleList =  (List<MobileElement>) Mobile.getDriver().findElements(By.xpath(xpathofCard));
		 String rate = null;
		 String contentOfROR = null;
		 String date = null;	
			
			 if(cardName.equals("RATE OF RETURN")){
				  rate = Mobile.getElementValue(eleList.get(2));
				  contentOfROR = Mobile.getElementValue(eleList.get(3));
				   date =  Mobile.getElementValue(eleList.get(4));
				   String expROR = UserBaseTest.getParaValue("RORContent");
				   if(contentOfROR.equals(expROR)){
					   Reporter.logEvent(Status.PASS,expROR + " rate in ROR card content should be display" ,rate +" : "+contentOfROR ,false);  
				   }else{
					   Reporter.logEvent(Status.FAIL,expROR +"rate in ROR card content should be display" ,rate +" : "+contentOfROR  ,false);  
				   }
				   
				   if(date != null){
					   Reporter.logEvent(Status.PASS," ROR Date content should be display" ,date ,false);  
				   }else{
					   Reporter.logEvent(Status.FAIL,"ROR Date content should be display" ,date ,false);  
				   }
				   
				   
				 
			 } else if(cardName.equals("BALANCE")){
				 rate = Mobile.getElementValue(eleList.get(2));
				 date = Mobile.getElementValue(eleList.get(3));
				 if(currentAmount != null){
					 if(rate.equals(currentAmount)){
					   Reporter.logEvent(Status.PASS,"Amount in  Business Card should be same as LIAT Page" ,rate ,false);  
				   }else{
					   Reporter.logEvent(Status.FAIL,"Amount in  Business Card should be same as LIAT Page" ,rate,false);  
				   }
				 }
				 if(date != null){
					   Reporter.logEvent(Status.PASS,"As of Date should be display in Business Card." ,date ,false);  
				   }else{
					   Reporter.logEvent(Status.FAIL,"As of Date should be display in Business Card." ,date,false);  
				   }
				 
			 }	
			 else if(cardName.equals(beneficiariesCard)){
		
				 rate = Mobile.getElementValue(eleList.get(2));
				 String benf_details = Mobile.getElementValue(eleList.get(3));
				 date = Mobile.getElementValue(eleList.get(4));
				 if(benf_details != null){
					   Reporter.logEvent(Status.PASS,"Beneficiaries details should be display in Beneficiaries Card." ,benf_details ,false);  
				   }else{
					   Reporter.logEvent(Status.FAIL,"Beneficiaries details should be display in Beneficiaries Card." ,benf_details,false);  
				   }
				
				 if(date != null){
					   Reporter.logEvent(Status.PASS,"Last update Date should be display in Beneficiaries Card." ,date ,false);  
				   }else{
					   Reporter.logEvent(Status.FAIL,"Last update Date  should be display in Beneficiaries Card." ,date,false);  
				   }
	}
	}
	
	private void verifyAODCardDetailsLink(String sCardName,String sPageName){
		String eleLocator = "//XCUIElementTypeStaticText[@name='"+sCardName+"']/../XCUIElementTypeOther/XCUIElementTypeOther[1]";
	    Mobile.clickElement(eleLocator);
		Common.waitForProgressBar();
		Mobile.verifyElementPresent("Tap "+sCardName+" and "+sPageName+" Page should display", sPageName, sPageName+" page");
		}
	
	public void verifyContributionCardPage(){	
	
		Mobile.verifyElementPresent("Contribution card  should be display", contributionCard, contributionCard +" card");
		Mobile.verifyElementPresent("BASE PAY card  should be display", "BASE PAY", "BASE PAY card");
		Mobile.verifyElementPresent("YTD contributions should be display", YTDContributions, "YTD contributions ");
		Mobile.verifyElementPresent("Est. on track to contribute  should be display", trackToContribution, "Est. on track to contribute card");
		Mobile.verifyElementPresent("IRS Limit card  should be display", IRS_Limit, "IRS Limit ");
		
		 //YTD contributions,Est. on track to contribute,2018 IRS limit,$18,500 
		 List<IOSElement> elelist = Mobile.getListOfEleByAccessibility("donut-shadow");
		 if(elelist.size() != 0){
				Reporter.logEvent(Status.PASS,"Donut Shadow should be display in Contribution Card" ,"Donut Shodow is Displayed " ,false);
	 
		 }else{
				Reporter.logEvent(Status.FAIL,"Donut Shadow should be display in Contribution Card","Donut Shodow is Displayed " ,false);
		 }	
		 verifyAODCardDetailsLink("BASE PAY", "Base Pay contributions");
		 Common.clickBackArrow();        
		 verifyAODCardDetailsLink("CATCH-UP", "Catch-up contributions");
	     Common.clickBackArrow();		   
	     Mobile.clickElement("//XCUIElementTypeStaticText[@name='"+contributionCard+"']/following-sibling::XCUIElementTypeStaticText");
		 Common.waitForProgressBar();
	     Mobile.verifyElementPresent("Tap Details in Contribution card and Contribution Page should  display", "My contributions", "My contributions page");
		
		
	}
	
	
	
	public void verifyFDDDetailsInContributionCard() {
		
		
	}
	
	
	
	

}

package com.greatWest.utility;

import io.appium.java_client.MobileElement;
import io.appium.java_client.ios.IOSElement;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import lib.Reporter;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriverException;
import org.testng.Assert;

import com.aventstack.extentreports.Status;

public class Common {
	public static String PAGEHEADER_TEXT = "//XCUIElementTypeNavigationBar/XCUIElementTypeStaticText";
	public static String KEYBOARD = "XCUIElementTypeKeyboard";
	public static String RETURN_TO_EMPOWSER = "Return to Empower";
	public static String ALERT = "XCUIElementTypeAlert";
		
	
	/*
	 * 
	 */
	
	public static String subStringValue(String s,int intValue){
		return Integer.toString(Integer.parseInt(s) - intValue);
	}
	
	
	public static String addStringValue(String s,int intValue){
		return Integer.toString(Integer.parseInt(s) + intValue);
	}
	
	public static void verifyAlertMessage(String sMsg,String sButton){
		
		MobileElement eleAlert =  (MobileElement) Mobile.findElement_By_Class(ALERT);
		Mobile.verify_Element_Label(eleAlert, sMsg,"Alert Message should be display." );
	      Mobile.clickElement(sButton);	
	}
	
	
	
	
	public static void verifyWarningMessage(String sMsg){		
		MobileElement eleAlert =  (MobileElement) Mobile.findElementWithPredicate("Warning!");
		Mobile.verify_Element_Label(eleAlert, sMsg,"Warning Message should be display." );	   	
	}
	
	
	public static Boolean isWarningMsgDisplayed(){
		Boolean flag = false;
		MobileElement eleAlert =  (MobileElement) Mobile.findElementWithPredicate("Warning!");
		if(eleAlert != null ){
			return true;
		}
		return flag;
	}

	public static String covertDoubletoInterger(int value){
		String result;
		 DecimalFormat format = new DecimalFormat();
	     format.setDecimalSeparatorAlwaysShown(false);
		result =  format.format(value);		
		return result;
	}
	
	
	public static void setSliderValue( String sFundName,String sValue){
		
		
		List<IOSElement> sFundList =  Mobile.getListOfElements_By_Class("XCUIElementTypeCell");
		List<IOSElement> sTextFieldsList = Mobile.getListOfElements_By_Class("XCUIElementTypeTextField");
		int i =0;	
		for (MobileElement sFundElement : sFundList) {
			 MobileElement ele = sFundElement.findElement(By.className("XCUIElementTypeStaticText"));
			 String name = ele.getText();  
				System.out.println(name);
				if (sFundName.equals(name)){					
					break;
				}
			i++;
		}	 
				
		Mobile.setSliderValue(sTextFieldsList.get(i), sValue);
		
		
	}
	
	
	public static Boolean ifServerError(){
		Boolean status = false;
		String error_Msg="An error has occurred. Please contact a Participant Services Representative.";
		if(Mobile.assertElementPresentByAccessibilityId(error_Msg)){
			status = true;
			Reporter.logEvent(Status.FAIL," Server Error Message ", "An error has occurred. Please contact a Participant Services Representative.",false);
		}
		return status;
	
		
	}
	
	public static void verifyElementList(String sObj, String[] expList,String sMsg ){
		
	List<IOSElement> message_List = (List<IOSElement>) Mobile.getDriver().findElementsByClassName(sObj);	
    	String sActResult = "";
	   String sExpResult = "";
	   Boolean sStatus = true;
		int i =0;
		
		if(message_List.size() != expList.length){
			sStatus = false;
		}
		
		for (IOSElement iosElement : message_List) {
			String value = iosElement.getText().trim();
			sActResult = sActResult+ "\n "+ value;
			
			while(i < expList.length){
				sExpResult =sExpResult +"\n "+expList[i];
				if(!value.trim().contains(expList[i])){
					sStatus = false;
					break;
				}else{
				i++;
				break;
				}
			}
			if(!sStatus){
				break;
			}
			
			
		}		
		if(sStatus){
			Reporter.logEvent(Status.PASS,sMsg, sActResult,false);
	}else{
	     Reporter.logEvent(Status.FAIL,"sMsg"," Expected :  "+sExpResult +"  But Actual was :"+sActResult,true);		
	}
	
}
	
	public static void verify_Value_InList_Contain(ArrayList<String > listText, String[] expected ,String sMsg){
		Boolean bStatus = false;		
		String result = null;		
		String sExpText = "";
		   for (int i = 0; i < expected.length; i++) {
			   sExpText = expected[i];
			   bStatus= false;
			   for (String ioSEle : listText) {
				       if(ioSEle != null){
				       result =ioSEle.replaceAll("\\n", "");				  
				        if(result.contains(expected[i])){
				    	bStatus= true;
				    	result =ioSEle;
				    	break;
				        }
				    }			    
			   }	
			   if(bStatus){
			    	  Reporter.logEvent(Status.PASS,"Expected  : "+ sExpText   ,result + " is displayed",false);	
			    }else{
			    	Reporter.logEvent(Status.FAIL, "Expected :"+sExpText ," Not displayed",false);	
			    }
	}
		 
	}
	
	public static void verify_Value_InList_Contain(String sObj,String[] expected ,String sMsg){
		 ArrayList<String> sActText = Common.get_Element_Lists(sObj,sMsg);         
		 verify_Value_InList_Contain(sActText, expected, "");
	}
	
		public static void verify_Is_element_Displayed(MobileElement ele,String sElementName){
		try{
			if(ele != null){
		if(ele.isDisplayed()){
			 Reporter.logEvent(Status.PASS,sElementName +" Should be displayed" ,sElementName + " is displayed",false);	
		}
		else{
			 Reporter.logEvent(Status.FAIL,sElementName  +" Should be displayed",sElementName + " is not displayed",true);	
		}
		}else{
			 Reporter.logEvent(Status.FAIL,sElementName  +" Should be displayed",sElementName + " is not displayed",true);	
		}
		}catch(NoSuchElementException e){
			 Reporter.logEvent(Status.FAIL,sElementName  +" Should be displayed",sElementName + " is not displayed",true);	
		}
	}
	
	public static void verify_element_Is_Not_Displayed(MobileElement ele,String sElementName){
		if(ele != null){			
	try{
		if(!ele.isDisplayed()){
			 Reporter.logEvent(Status.PASS,sElementName +" Should not be displayed" ,sElementName + " is not displayed",false);	
		}
		else{
			 Reporter.logEvent(Status.FAIL,sElementName  +" Should not be displayed",sElementName + " is  displayed",true);	
		}
		}catch(NoSuchElementException e){
			 Reporter.logEvent(Status.PASS,sElementName +" Should not be displayed" ,sElementName + " is not displayed",false);	

		}
		}
	}
	
	
	public static ArrayList<String > get_Element_Lists(String sObj,String sMsg ){		
		Reporter.logEvent(Status.INFO,sMsg,"Screen Shot is display below" ,true);
		List<IOSElement> message_List =  Mobile.getListOfElements_By_Class(sObj);
		ArrayList<String > listText = new ArrayList<>();
		   for (IOSElement ioSEle : message_List) {
			     listText.add(ioSEle.getText());
		}		   
		   return listText;
	}
	
	
	
	public static void verify_Value_InList_isNotContain(ArrayList<String> listText, String[] expected ,String sMsg){
		Boolean bStatus = false;	   	 
		
		   for (int i = 0; i < expected.length; i++) {
			   bStatus= false;
			   for (String ioSEle : listText) {
				     if(ioSEle.contains(expected[i])){
				    	bStatus= true;
				    	break;
				    }			    
			   }	
			   if(bStatus){
			    	  Reporter.logEvent(Status.FAIL,sMsg  ,expected[i],true);	
			    }else{
			    	Reporter.logEvent(Status.PASS, sMsg ,expected[i],false);	
			    }
	
	}
	
	}
	
	
	//[Confirmation, Your investment allocation request for future contributions, has been received as of Thursday, July 13, 2017, 4:40 PM, and will be processed as soon as administratively feasible., CONFIRMATION NUMBER, 1012926631, Please refer to this number for inquiries regarding this transaction., FROM:, Build your own portfolio, 40%, Dodge & Cox International Stock, 60%, LifePath Index 2060 Account A, TO:, Target Date fund, 100%, LifePath Index 2060 Account A]
	// Build your own portfolio 40% Dodge & Cox International Stock 60% LifePath Index 2060 Account A
	public static void verify_Value_For_FollowingSibling(ArrayList<String> listText, String parent,int indexfrom,int indexTo, String expected ,String sMsg){
		Boolean bStatus = false;			
		String result = "";
		int j =1;
		   for (String ioSEle : listText) {
			    if(bStatus){
			    	if(j <= indexTo){
			    	 result = result + " " +ioSEle;
			    	 if(j == indexTo)
			    	break;
			    	}
			    	j++;
			    }else{
			      String parentText = ioSEle;
			      if(parentText.equalsIgnoreCase(parent)){			    	  
			    	  bStatus =true;  
			      }
			    }
		}		     
		   
		
		      if(result.trim().contains(expected.trim()))	    	
		    		  Reporter.logEvent(Status.PASS,sMsg  ,result + " is displayed.",false);	
			         else
			          Reporter.logEvent(Status.FAIL, sMsg,"Expected :"+ expected +" \n But Actual was :"+result,false);	 
		}
	
	
	public static void verify_Value_Between_List(ArrayList<String> listText,String expected, String parent,String toObj,String sMsg){
		
		
		Boolean bStatus = false;			
		String result = "";
		for (String ioSEle : listText) {
			    if(bStatus){
			    	if(toObj.equalsIgnoreCase("last")){
			    		result = result + "\n" +ioSEle;	
			    	}			    	
			    	else if(!ioSEle.trim().equals(toObj.trim())){
			    		result = result + "\n" +ioSEle;	
			    	}else
			    	break;
			    				    	
			    }else{
			      String parentText = ioSEle;
			      if(parentText.equalsIgnoreCase(parent)){			    	  
			    	  bStatus =true;  
			      }
			    }
		}		    		   
		
		      if(result.replaceAll("\n", " ").replaceAll(" ", "").contains(expected.replaceAll("\n", " ").replaceAll(" ", "")))	    	
		    		  Reporter.logEvent(Status.PASS,sMsg  ,result + " is displayed.",false);	
			         else
			          Reporter.logEvent(Status.FAIL, sMsg,"Expected :"+ expected +" \n But Actual was :"+result,true);	
		
	}
	
	
	
		public static void verify_Label_Text(String sLabel,String sExpected,String sMsg){
		String sActText ="";
		try{	
			IOSElement eleRadioOption =	Mobile.findElementWithPredicate(sLabel);
		if(eleRadioOption != null){
			 sActText = eleRadioOption.getText();		
	
	    if(sExpected.replaceAll(" ","").trim().equalsIgnoreCase(sActText.replaceAll("\n", " ").replaceAll(" ", "")))	    	
  		  Reporter.logEvent(Status.PASS,sMsg  ,sActText + " is displayed.",false);	
	         else
	          Reporter.logEvent(Status.FAIL, sMsg,"Expected :"+ sExpected +" \n But Actual was :"+sActText,true);	
		}else{
	        Reporter.logEvent(Status.FAIL, sMsg,"Expected :"+ sExpected +" \n But Actual was :"+sActText,true);	

		}
		
		}
		catch(Exception e){
			System.out.println("Not able to select Radio Button");
		}	
	}
	
	public static String get_Value_Between_FollowingSibling(ArrayList<String> listText, String parent,String toObj){
		
		Boolean bStatus = false;			
		String result = "";
		for (String ioSEle : listText) {
			    if(bStatus){
			    	if(!ioSEle.trim().equals(toObj.trim())){
			    		result = result + " " +ioSEle;	
			    	}else
			    	break;
			    				    	
			    }else{
			      String parentText = ioSEle;
			      if(parentText.equalsIgnoreCase(parent)){			    	  
			    	  bStatus =true;  
			      }
			    }
		}		     
		  
		   return result;
		 
		}
	
	
	public static String get_Value_ArrayList(ArrayList<String> listText, String parent,int indexTo){
		
		Boolean bStatus = false;			
		String result = "";
		int  j =1;
		for (String ioSEle : listText) {
			  if(bStatus){
			    	if(j <= indexTo){
			    	 result = result + " " +ioSEle;
			    	 if(j == indexTo)
			    	break;
			    	}
			    	j++;
			    }else{
			      String parentText = ioSEle;
			      if(parentText.equalsIgnoreCase(parent)){			    	  
			    	  bStatus =true;  
			      }
			    }
		}		       
		  
		   return result;
		 
		}
	
public static String get_Value_ArrayList_TillLast(ArrayList<String> listText, String parent){
	//[Review Your Changes, FROM:, Target Date fund, 100%, LifePath Index 2055 Account A, TO:, Model Portfolio, 100%, AGGRESSIVE STRATEGY, 50%, Loomis Sayles Core Plus Bond Y, 50%, Vanguard Windsor II Fund - Admiral]
		
		Boolean bStatus = false;			
		String result = "";
		
		for (String ioSEle : listText) {
			  if(bStatus){				 
				  result = result + "\n " +ioSEle;	
			    
			    	}
			 	 else{
			      String parentText = ioSEle;
			      if(parentText.equalsIgnoreCase(parent)){			    	  
			    	  bStatus =true;  
			      }
			    }
		}		       
		  
		   return result;
		 
		}
	
	

	public static String get_Value_ArrayList(ArrayList<String> listText, String parent,int indexFrom,int indexTo){
		
		Boolean bStatus = false;			
		String result = "";
		int  j =1;
		for (String ioSEle : listText) {
			  if(bStatus){
			    	if(j >= indexFrom){
			    	 result = result + " " +ioSEle;
			    	 if(j == indexTo)
			    	break;
			    	}
			    	j++;
			    }else{
			      String parentText = ioSEle;
			      if(parentText.equalsIgnoreCase(parent)){			    	  
			    	  bStatus =true;  
			      }
			    }
		}		       
		  
		   return result;
		 
		}
	
	
	
	
	
	
	/* 
	 * @Author :- Siddartha 
	 * @Date :- 24/April/2017
	 * Method:- This method will click ellipse  for given label
	 */
	public static  void clickEllipses(String sLabel){	

		String sObj = "//*[contains(@name,'"+sLabel+"')]/following-sibling::*[@name='View details']";
		if(Mobile.assertElementPresent(By.xpath(sObj))){
		Mobile.clickElement(sObj);
		}
		
	}
	
	/* 
	 * @Author :- Siddartha 
	 * @Date :- 24/April/2017
	 * Method:- This method will click ellipse  for given label
	 */
	public static  void clickEllipses_WithValue(String sLabel){	

		String sObj = "//*[contains(@value,'"+sLabel+"')]/following-sibling::*[@name='View details']";
		if(Mobile.assertElementPresent(By.xpath(sObj))){
		Mobile.clickElement(sObj);
		}
		
	}
	
	
	public static  void closeEllipses(String sLabel){			
		String sObj = "//*[@name='"+sLabel+"']/following-sibling::*[@name='details close']";
		Mobile.clickElement(sObj);
		
	}
	
	/*
	    * @Author :- Siddartha 
	     * @Date  :- 2 - Feb -2017
	    * @ Method:- This will wait till element is not display
	     */
	    
	      public static void waitTillElementNotDisplay(String sElement){
	    	  int iTimeInSecond=80;
	           try{
	                  int iCount = 0;
	                  while (FindElement_Acc_ID(sElement).isDisplayed()){
	                         if(iCount ==iTimeInSecond){
	                               break;
	                         }   	                         
	                         System.out.println("Element is still diplaying...");
	                         Thread.sleep(1000);                       
	                         iCount++;
	                  }
	                  
	           }catch(Exception e){
	                  
	           }
	           
	        }
	      
	      /*
		    * @Author :- Siddartha 
		     * @Date  :- 2 - Feb -2017
		    * @ Method:- This will wait till element is not display
		     */
		    
		      public static void waitTillElementNotDisplay_InLoginPage(String sElement){
		    	  int iTimeInSecond=50;
		           try{
		                  int iCount = 0;    	                  
		                    
		                 System.out.println(Mobile.getElementLabel(FindElement_Acc_ID(sElement))+"Test");
		                  while(Mobile.getElementLabel(FindElement_Acc_ID(sElement)).equals("LOGGING IN")){
		                         if(iCount ==iTimeInSecond){
		                               break;
		                         }   	                         
		                         System.out.println("Element is still diplaying...");
		                         Thread.sleep(1000);                       
		                         iCount++;
		                         if(FindElement_Acc_ID("GWMLoginErrorLabel").isDisplayed()){
		                        	 Assert.fail("User is not able to login .");
		                         }
		                  }
		                  
		           }catch(Exception e){
		                  
		           }
		           
		        }
		      
	      
	      /*
		    * @Author :- Siddartha 
		     * @Date  :- 2 - Feb -2017
		    * @ Method:- This will wait till element is not display
		     */
		    
		      public static void waitTillElementNotDisplay(MobileElement sElement){
		    	  int iTimeInSecond=80;
		           try{
		                  int iCount = 0;
		                  if(sElement != null)
		                  while (sElement.isDisplayed()){
		                         if(iCount ==iTimeInSecond){
		                               break;
		                         }   	                         
		                         System.out.println("Element is still diplaying...");
		                         Thread.sleep(1000);                       
		                         iCount++;
		                  }
		                  
		           }catch(Exception e){
		                  
		           }
		           
		        }
		      
		      
	      
	      
	      
	      
	      public static String upperCaseAllFirst(String value) {

	          char[] array = value.toCharArray();
	          // Uppercase first letter.
	          array[0] = Character.toUpperCase(array[0]);

	          // Uppercase all letters that follow a whitespace character.
	          for (int i = 1; i < array.length; i++) {
	              if (Character.isWhitespace(array[i - 1])) {
	                  array[i] = Character.toUpperCase(array[i]);
	              }
	              else {
	            	  array[i] = Character.toLowerCase(array[i]);
	              }
	          }

	          // Result.
	          return new String(array);
	      }
	  	
	  	/*
	  	    * @Author :- Siddartha 
	  	     * @Date  :- 2 - Feb -2017
	  	    * @ Method:- This will wait till element is not display
	  	     */
	  	    
	  	      public static void waitTillElementDisplay(By link){
	  	    	  int iTimeInSecond=30;
	  	           try{
	  	                  int iCount = 0;
	  	                  IOSElement ele = Mobile.findElementBy(link);
	  	                  if(ele != null){
	  	                  while (!ele.isDisplayed()){
	  	                         if(iCount ==iTimeInSecond){
	  	                               break;
	  	                         }   	                         
	  	                         System.out.println("Element is still diplaying...");
	  	                         Thread.sleep(1000);                       
	  	                         iCount++;
	  	                  }
	  	                  }
	  	                  
	  	           }catch(Exception e){
	  	              System.out.println("##### Element is ");    
	  	           }
	  	           
	  	        }
	  	      
	  	      
	  	    public static void waitTillElement_Is_Display(By link){
	  	    	  int iTimeInSecond=30;
	  	           try{
	  	                  int iCount = 0;
	  	                  IOSElement ele = Mobile.findElementBy(link);
	  	        
	  	                  while (ele == null){	  	                	   
	  	                         if(iCount ==iTimeInSecond){
	  	                               break;
	  	                         }   	                         
	  	                         System.out.println("Element is still not diplaying...");
	  	                         Thread.sleep(1000);                       
	  	                         iCount++;
	  	                       ele = Mobile.findElementBy(link);
	  	                  }	  	               
	  	                  
	  	           }catch(Exception e){
	  	              System.out.println("##### Element is not found ");    
	  	           }
	  	           
	  	        }
	  	   public static void waitTillElement_Is_Display(By link, int iTimeInSecond){
	  	    	
	  	           try{
	  	                  int iCount = 0;
	  	                  IOSElement ele = Mobile.findElementBy(link);
	  	        
	  	                  while (ele == null){	  	                	   
	  	                         if(iCount ==iTimeInSecond){
	  	                               break;
	  	                         }   	                         
	  	                         System.out.println("Element is still not diplaying...");
	  	                         Thread.sleep(1000);                       
	  	                         iCount++;
	  	                       ele = Mobile.findElementBy(link);
	  	                  }	  	               
	  	                  
	  	           }catch(Exception e){
	  	              System.out.println("##### Element is not found ");    
	  	           }
	  	           
	  	        }
	  	   
		   public static void waitTillElement_Is_Display(MobileElement ele, int iTimeInSecond){
	  	    	
  	           try{
  	                  int iCount = 0;
  	                  //IOSElement ele = Mobile.findElementBy(link);
  	                while (ele == null){	  	                	   
	                         if(iCount ==iTimeInSecond){
	                               break;
	                         }   
	                         if(!ele.isDisplayed()){
	                         System.out.println("Element is still not diplaying...");
	                         Thread.sleep(1000);                       
	                         iCount++;
	                         }else{
	                        	 break;
	                         }
	                      
	                  }	               
  	                  
  	           }catch(Exception e){
  	              System.out.println("##### Element is not found ");    
  	           }
  	           
  	        }
  	      
	  	      

	  	      public static void waitTillElementEnable(By link){
	  	    	  int iTimeInSecond=50;
	  	           try{
	  	                  int iCount = 0;
	  	                  IOSElement ele = Mobile.findElementBy(link);
	  	                  if(ele != null){
	  	                  while (!ele.isEnabled()){
	  	                         if(iCount ==iTimeInSecond){
	  	                               break;
	  	                         }   	                         
	  	                         System.out.println("Element is still diplaying...");
	  	                         Thread.sleep(1000);                       
	  	                         iCount++;
	  	                  }
	  	                  }
	  	                  
	  	           }catch(Exception e){
	  	                  
	  	           }
	  	           
	  	        }
	  	      
	  	    public static void waitTillElementEnable(By link ,int iTimeInSecond){	  	    
	  	           try{
	  	                  int iCount = 0;
	  	                  IOSElement ele = Mobile.findElementBy(link);
	  	                  if(ele != null){
	  	                  while (!ele.isEnabled()){
	  	                         if(iCount ==iTimeInSecond){
	  	                               break;
	  	                         }   	                         
	  	                         System.out.println("Element is still diplaying...");
	  	                         Thread.sleep(1000);                       
	  	                         iCount++;
	  	                  }
	  	                  }
	  	                  
	  	           }catch(Exception e){
	  	                  
	  	           }
	  	           
	  	        }
	
	
	
	  	public static void clickEmpowerButton(){
			Mobile.clickElement(RETURN_TO_EMPOWSER);
		}
	      
	
	/*
	    * @Author :- Siddartha 
	     * @Date  :- 17 - Oct -2016
	    * @ Method:- This will wait till Progress is display
	     */
	    
	      public static void waitForProgressBar(){
	    	  int iTimeInSecond=100;
	           try{
	                  int iCount = 0;
	                  while (FindElement_Acc_ID("In progress").isDisplayed()){
	                         if(iCount ==iTimeInSecond){
	                               break;
	                         }   
	                         
	                         System.out.println("Progress Bar displaying..");
	                         Thread.sleep(1000);                       
	                         iCount++;
	                  }
	                  
	           }catch(Exception e){
	                  
	           }
	           
	        }
	      public static MobileElement FindElement_Acc_ID(String sElement){
	    		Mobile.getDriver().manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
	           return (IOSElement) Mobile.getDriver().findElement(By.name(sElement));
	        }
		

	      public static void verify_RadioButton_IsSelected(String sLabel ,Boolean bIsSelected){
	    	String sObj = "//*[@name='"+sLabel+"']/preceding-sibling::XCUIElementTypeButton";
	    	  String sSelected = Mobile.getElementValue(sObj);
	    	  if(bIsSelected){
	    		  
	    	  }
	    	  else {
	    		  
	    	  }
	    	  
	      }
	    
	  
	  	public  static void verifyPageIsDisplayed(String sStep,String sExpected){			
			
	  		if(Mobile.isElementPresent(sExpected)){
				Reporter.logEvent(Status.PASS,sStep, sExpected+" Page is Displayed " ,false);
			}else{			
			     Reporter.logEvent(Status.FAIL,sStep,sExpected+" Page is not Displayed",true);
			     Assert.fail();
						          
			}	
		
		}
	  	
	  	
		public static void clickBackArrow() {		
//			String BACK_ARROW = "Back";
//			MobileElement ele =  (MobileElement) Mobile.getDriver().findElement(By.name(BACK_ARROW));
//			Mobile.clickElement(ele);
			clickBackButton();
		}
		
		public static void clickContinueButon() {			
		    Mobile.scroll_Down();
			Mobile.clickElement("CONTINUE");

		}		
		
		
		public static  void clickEditLink(String sLabel) {
			String sObj ="//*[@name='"+sLabel+"']/following-sibling::*[@name='EDIT']";	
			Mobile.clickElement(sObj);
		}
		
		public static void clickBackButton() {
			String BACK_BUT = "Back";
			Mobile.clickElement(BACK_BUT);


		}
		
		public static void assertTrue(By link,String sMsg) throws Exception{
			Assert.assertTrue(Mobile.assertElementPresent(link),sMsg);
			

		}
		
		
		public static  void verifyKeyBoardIsOpen(){
			Mobile.verifyElementPresent("Keyboard  should be open to Type", Mobile.findElement_By_Class(KEYBOARD), "KeyBoard");
		}
		
		
		public static void switchButton(String sObj,Boolean bStatus){
			
		}
		
		/**
		 * Set value in slider in TextField using MobileElement
		 * @param locator
		 * @param sText
		 */	
		
		public static void setSliderValueInLIATPage(MobileElement ele, String sText) {
			try {		
				if (ele != null) {
				    ele.clear();
					ele.sendKeys(sText);
					Mobile.clickElement("check");			
				} 
				
			Reporter.logEvent(Status.INFO," Value set in slider bar.",sText + " %",false);			
			} catch (WebDriverException e) {
				System.out.println(" Not able to slide the Value");
			}

		}
		
		/**
		 * Set value in slider in TextField using MobileElement
		 * @param locator
		 * @param sText
		 */	
		
		public static void setSliderValueInLIATPage(String label, String sText) {
			try {	
				String sObj = "//XCUIElementTypeTextField[@name='"+label+"']";
				IOSElement ele = Mobile.findElement(sObj);
				if (ele != null) {
				    ele.clear();
					ele.sendKeys(sText);
					Mobile.clickElement("check");	
					Mobile.wait(1000);
				} 
				
			Reporter.logEvent(Status.INFO," Value set in slider bar.",sText + " %",false);			
			} catch (WebDriverException e) {
				System.out.println(" Not able to slide the Value");
			}

		}
		
		public static String getSliderValueInLIATPage(String label) {
			String result ="";
			try {	
				String sObj = "//XCUIElementTypeTextField[@name='"+label+"']";
				IOSElement ele = Mobile.findElement(sObj);
				if (ele != null) {
					result = Mobile.getElementValue(ele);
				} 
			
			} catch (WebDriverException e) {
				System.out.println(" Not able to get slider Value");
			}

			return result;
		}
	  	
	  

}

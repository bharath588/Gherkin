package com.greatWest.pageObject;

import io.appium.java_client.MobileElement;
import io.appium.java_client.ios.IOSElement;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.pagefactory.iOSFindBy;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;

import java.util.List;

import lib.Reporter;
import lib.Stock;

import com.greatWest.utility.Mobile;

import org.openqa.selenium.By;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.LoadableComponent;
import org.testng.Assert;

import com.aventstack.extentreports.Status;
import com.greatWest.login.UserBaseTest;
import com.greatWest.utility.Common;

public class LookUpAccountPage extends LoadableComponent<LookUpAccountPage>{
	
	private LoadableComponent<?> parent;
	
	
	@iOSFindBy(id ="Let's look up your account")
	@CacheLookup
	private MobileElement pageRegisterLookUp;
	
	
	
	@iOSFindBy(id ="Done")
	@CacheLookup
	private MobileElement butDone;

	@iOSFindBy(id ="Next")
	@CacheLookup
	private MobileElement butNext;
	@iOSFindBy(id ="CONTACT US")
	@CacheLookup
	private MobileElement butContactUs;
	
	
	
	@iOSFindBy(id ="FIND ME")
	@CacheLookup
	private MobileElement butFindMe;
	
	@iOSXCUITFindBy(className = "XCUIElementTypeSecureTextField")
	@CacheLookup
	public MobileElement textBoxSSN;
	
	@iOSFindBy(id ="GWMBirthdateTextField")
	@CacheLookup
	private MobileElement textBoxDOB;
	
	String  MESSAGE_LABEL_TEXT = "XCUIElementTypeStaticText";

		
	@iOSXCUITFindBy(className = "XCUIElementTypeTextField")
	private List<MobileElement>  textListType;
	
	@iOSXCUITFindBy(className = "XCUIElementTypePickerWheel")
	@CacheLookup
	private List<MobileElement>  datePickerList;
	
	@iOSXCUITFindBy(className = "XCUIElementTypeTextField")
	@CacheLookup
	private MobileElement  textBoxUserName;
	
	@iOSXCUITFindBy(className = "XCUIElementTypeSecureTextField")
	@CacheLookup
	private List<MobileElement>  passwordList;
	
	@iOSFindBy(id ="REGISTER")
	@CacheLookup
	private MobileElement butRegister;
	
	@iOSFindBy(id ="down-arrow")
	private MobileElement butDownArrow;
	
	@iOSFindBy(id ="Register now")
	@CacheLookup
	private MobileElement linkRegisterNow;
	
	
	public static String pageNewLogin = "New login";
	
	@iOSFindBy(id ="NEXT")
	@CacheLookup
	private MobileElement butNEXT;
	public static String AGREE_BUT ="GWMTermsOfUseAgreeButton";
	 
	public static String TERM_OF_USE = "Terms of Use";
	
	//public static String REGISTER_LOOK_UP_PAGE= "Let's look up your account";
			
   // public static String FIND_ME_BUT= "FIND ME";
			
	// public static String SOCIAL_SECURITY_NUMBER =
	// "//XCUIElementTypeSecureTextField[@value='SOCIAL SECURITY NUMBER']";
	String ZIP_CODE = "//XCUIElementTypeTextField[@value='ZIP / POSTAL CODE']";
	String SKIP_TOUR_BUT = "skip";
	String LAST_NAME = "//XCUIElementTypeTextField[@value='LAST NAME']";

	String NUMERIC_STREET_ADDRESS = "//XCUIElementTypeTextField[@value='NUMERIC STREET ADDRESS']";

	String USER_CONTACT_LABEL = "To continue, provide your contact information. We will use this to send verification codes for enhanced account security.";
	String USER_CONTACT_PAGE = "We found you!";

	String REGISTRATION_ERROR_INVALID = "Error: The entries you provided do not match our records. Please try again. You have 2 attempt(s) remaining.";
	String REGISTRATION_ERROR_INVALID_REMAIN1 = "Error: The entries you provided do not match our records. Please try again. You have 1 attempt(s) remaining.";
	String AT_LEAST_6_CHAR_MSG = "• Must be at least 6 characters";
	String AT_LEAST_3_LETTER_MSG = "• Must include at least 3 letters";
	String AT_LEAST_1_NUMBER_MSG = "• Must include at least 1 number";
	String   VALID_USERNAME="Valid username";

	String PASSWORD_MUST_BE_BETWEEN_8_16_CHAR_MSG = "• Password must be between 8-16 characters";
	String MUST_INCLUDE3_OFTHESE_4_MSG = "• Must include 3 of these 4";
	String MUST_INCLUDE2_OFTHESE_3_MSG = "• Must include 2 of these 3";
	String MUST_INCLUDE1_OFTHESE_2_MSG = "• Must include 1 of these 2";
	String UPPER_CASE_MSG = "• Uppercase letter";
	String LOWERCASE_MSG = "• Lowercase letter";
	String SPECIAL_CHAR_MSG = "• Special character";
	String NUMBER_MSG = "• Number";
	String   VALID_PASSWORD="Valid password";
	String PASSWORD_VALIDATION = "Password entries must match.";
	String   PASSWORD_MATCH="Passwords match";
		 
	/** Empty args constructor
	 * 
	 */
	public LookUpAccountPage() {
		this.parent = new LoginPage();
		PageFactory.initElements(new AppiumFieldDecorator(Mobile.getDriver()), this);
	}
	
	/**
	 * Constructor taking parent as input
	 * 
	 * @param parent
	 */
	public LookUpAccountPage(LoadableComponent<?> parent) {
		// this.driver = DriveSuite.webDriver;
		PageFactory.initElements(new AppiumFieldDecorator(Mobile.getDriver()), this);
	}		

	
	
	@Override
	protected void load()
	{
		// TODO Auto-generated method stub		
	
		clickRegisterButton();
		
		
		
	}

	@Override
	protected void isLoaded() throws Error {
		// TODO Auto-generated method stub
		Assert.assertTrue(Mobile.assertElementPresentByPageFactor(pageRegisterLookUp),"Not able to open Look Up Page");
		
	}
	
	public  void clickRegisterButton(){			
		
		Mobile.clickElement(linkRegisterNow);
		
	}
	public void verifyUserContactInformationPage(){
	
		Mobile.verifyElementPresent("User Contact  Infromation page should be displayed", USER_CONTACT_PAGE, "User Contact Page");
		String sMsg_email1 = "Email address is invalid.";
		String sMsg_Phone1 = "Phone number must be 10 digits.";
	   Common.waitTillElement_Is_Display(By.className("XCUIElementTypeTextField"), 20);		
		MobileElement emailElement = textListType.get(0);
		MobileElement phoneElement = textListType.get(1);
		//invalid email id 	
		Mobile.setEdit(emailElement,"testautogmail.com");
		Mobile.clickElement(butNext);
		Mobile.verifyElementPresent("Entering blank value in email textBox should display error message.", sMsg_email1, sMsg_email1);
		//blank value  for email
		Mobile.setEdit(emailElement,"");
		Mobile.clickElement(butNext);
		Mobile.verifyElementPresent("Entering blank value in email textBox should display error message.", sMsg_email1, sMsg_email1);
		Mobile.clickElement(butDone);
		
		Mobile.verifyElementISDisable(butNEXT,"NEXT button should be disable");
		//blank value  for phone number
		Mobile.setEdit(phoneElement,"");
		Mobile.clickElement(butDone);
		Mobile.verifyElementPresent("Entering blank value in Phone textBox should display error message.", sMsg_Phone1, sMsg_Phone1);
	
		//Less than 10 digit for phone number
		Mobile.setEdit(phoneElement,"123456");
		Mobile.clickElement(butDone);
		Mobile.verifyElementPresent("Entering blank value in Phone textBox should display error message.", sMsg_Phone1, sMsg_Phone1);
	
		Mobile.setEdit(phoneElement,"1234567891011");
		Mobile.clickElement(butDone);
		Mobile.verifyText(phoneElement, "(123) 456-7891", true);	
		
	}
	
	public void verifyUserNameAndPassWordTextBox(){
		Mobile.verifyElementPresent("Tap Next button should display  New Login Page", pageNewLogin, "New Login Page");
		verify_UserName_TextBox();
		verify_PassWord_TextBox();
	}
	
	
	

	public void verifyLIATPageIsDisplayed(){
		if(new HomePage().isHomePageDisplayed()){
			Reporter.logEvent(Status.PASS,"LIAT Page should be display "," LIAT page is displayed" ,true);
			}else{
			     Reporter.logEvent(Status.FAIL,"LIAT Page should be display","LIAT page is not Displayed",true);
			}
	}
	
	
	public void verifyRegistrationPage(){		
		Mobile.setEdit(textBoxSSN,"1234567891011");	
		Mobile.verify_Element_Value(textBoxSSN, "•••••••••", "SSN field will not allow more then 9 value");
		String sSSN_Err_MSG = "SSN must be 9 digits.";
		Mobile.setEdit(textBoxSSN,"1234");	
		Mobile.clickElement(butNext);
		Mobile.verifyElementPresent("Entering less than 9 value in SSN field should displaye error message", sSSN_Err_MSG, sSSN_Err_MSG);
		Mobile.setEdit(textBoxSSN,UserBaseTest.getParaValue("ssn"));	
		Mobile.clickElement(butNext);
		
		//ZIP CODE text box  Validation
		Mobile.setEdit(textListType.get(0), "&&***");
		Mobile.verify_Element_Value(textListType.get(0), "ZIP / POSTAL CODE", "ZIP Code field should be blank while entering special character");
		Mobile.setEdit(textListType.get(0), "ABCDE1234567");
		Mobile.verify_Element_Value(textListType.get(0), "ABCDE12345", "ZIP Code will not allow more then 10 value");
		Mobile.setEdit(textListType.get(0), "");
		Mobile.clickElement(butNext);
		String sZIP_Code_Err_MSG = "ZIP code is required.";
		Mobile.verifyElementPresent("Entering blank value in Zip code should displaye error message", sZIP_Code_Err_MSG, sZIP_Code_Err_MSG);
		Mobile.setEdit(textListType.get(0), UserBaseTest.getParaValue("zipCode"));
		Mobile.clickElement(butNext);
		
		//Last Name text box  Validation
		Mobile.setEdit(textListType.get(1),  UserBaseTest.getParaValue("lastName"));
		
		//DOB  text box  Validation
		setDate(textListType.get(2),"12-August-2017");
		String sDOBValue = Mobile.getElementValue(textBoxDOB);
		if(sDOBValue.equals("08/12/2017")){
			Reporter.logEvent(Status.FAIL,"DOB field should not allow to select date within current date - 15 years" , "Entered Value : 08/12/2017 \n Actual DOB value: "+ sDOBValue,true);
		}else{
		     Reporter.logEvent(Status.PASS,"DOB field should not allow to select date within current date - 15 years"," Entered Value : 08/12/2017 \n Actual DOB value: "+ sDOBValue,false);
		}
		
		setDate(textListType.get(2),"12-August-1916");
		sDOBValue= Mobile.getElementValue(textBoxDOB);
		if(sDOBValue.equals("08/12/1916")){
			Reporter.logEvent(Status.FAIL,"DOB field should not allow to select date within current date +100 years" , "Entered Value : 08/12/1916 \n Actual DOB value: "+ sDOBValue ,true);
		}else{
		     Reporter.logEvent(Status.PASS,"DOB field should not allow to select date within current date +100 years","  Entered Value : 08/12/1916 \n Actual DOB value: "+ sDOBValue,false);
		}
	
		//Street Address 
		Mobile.setEdit(textListType.get(3), "");
		Mobile.clickElement(butDone);
		Mobile.verifyElementISDisable(butFindMe, "Entering  no value in Street address  will disable Find Me button");
		Mobile.setEdit(textListType.get(3),  UserBaseTest.getParaValue("address"));	
		Mobile.clickElement(butDone);
		Mobile.clickElement(butFindMe);
		Common.waitTillElementNotDisplay("SEARCHING");
		Mobile.verifyElementPresent("Entering invalid details  and Tapping Find Me button will display error message", REGISTRATION_ERROR_INVALID, REGISTRATION_ERROR_INVALID);
	
		Mobile.clickElement(butFindMe);
		Common.waitTillElementNotDisplay("SEARCHING");
		Mobile.verifyElementPresent("Entering Again invalid details  and Tapping Find Me button will display error message", REGISTRATION_ERROR_INVALID_REMAIN1, REGISTRATION_ERROR_INVALID_REMAIN1);
	
		
		
	}
	
	public void verifyContactUsButton(){
		Mobile.verifyElementPresent("CONTACT US button is present" ,butContactUs, "CONTACT US button");
		Mobile.clickElement(butContactUs);
		Common.waitForProgressBar();
		Common.verifyPageIsDisplayed("Contact Us Home Page is display", "Contact us");
		Mobile.clickElement("menu");
		Mobile.clickElement("LOG IN");
		
	}
	
	public void enterRegisterLookUpPage(){
		Mobile.setEdit(textBoxSSN, UserBaseTest.getParaValue("ssn"));		
		Mobile.setEdit(textListType.get(0), UserBaseTest.getParaValue("zipCode"));
		Mobile.setEdit(textListType.get(1), UserBaseTest.getParaValue("lastName"));
		setDate(textListType.get(2),UserBaseTest.getParaValue("dob"));
		Mobile.setEdit(textListType.get(3),  UserBaseTest.getParaValue("address"));
		Mobile.clickElement(butDone);
		Reporter.logEvent(Status.INFO,"Enter Details in Registration Page for User ", UserBaseTest.getParaValue("ssn") ,true);
		Mobile.clickElement(butFindMe);
	    Common.waitTillElementNotDisplay("SEARCHING");
	}
	
	public void enterUserContactPage(){
			if(!Mobile.assertElementPresentByAccessibilityId(USER_CONTACT_PAGE)){
			Assert.fail("Not display User Contact Information Page");			
		}
		else{
			Reporter.logEvent(Status.PASS,"Tap Find Me Button should display User Contact  Information page." , "User Contact Page  is Displayed " ,false);
		}
		Mobile.setEdit(textListType.get(0),"testauto@gmail.com");
		Mobile.setEdit(textListType.get(1),"1111111111");
		Mobile.clickElement(butDone);
		Mobile.wait(1000);
		Mobile.clickElement("NEXT");	
		Common.waitForProgressBar();
		if(Mobile.assertElementPresent(By.name("NEXT"))){
			Mobile.clickElement("NEXT");	
		}
		
	}
	
	public void enterNewLoginDetails(){
	
		if(!Mobile.assertElementPresentByAccessibilityId(pageNewLogin)){
			Assert.fail("Not display New Login Page");			
		}else{
			Reporter.logEvent(Status.PASS,"Tap Find Me Button should display New Login  Information page." , "New User Login Page  is Displayed " ,false);
		}
		
		Mobile.setEdit(textBoxUserName, UserBaseTest.getParaValue("ssn")+"ABC");
		Mobile.setEdit(passwordList.get(0), "Test@1234");
		Mobile.setEdit(passwordList.get(1), "Test@1234");
		Mobile.clickElement(butDone);
		Reporter.logEvent(Status.INFO,"Enter new UserName and Password in New Login Page ", UserBaseTest.getParaValue("ssn")+"ABC" ,true);
		Mobile.clickElement(butRegister);
		Common.waitTillElementNotDisplay("SAVING");
		if(Mobile.assertElementPresent(By.name(TERM_OF_USE))){
			Mobile.scroll_Down();
			Mobile.clickElement(AGREE_BUT);
			Common.waitForProgressBar();				
		    Mobile.wait(2000);
		}	
		
	}
	
	public void verifyNewLoginDetails(){
		Mobile.verifyElementPresent("Tap Next button should display New Login Page", "New login", "New login Page");
	
		
	}
	
	
	public void verify_UserName_TextBox(){		
		
	//	IOSElement userTextBox =  Mobile.findElement(USERNAME_TEXTBOX);
		 Mobile.verifyElementISDisable(butRegister, "Register Button should be  Disable");
		  Mobile.setEdit(textBoxUserName, "");	
		 String[] expMsg = {AT_LEAST_6_CHAR_MSG,AT_LEAST_3_LETTER_MSG,AT_LEAST_1_NUMBER_MSG};
		  Common.verify_Value_InList_Contain(MESSAGE_LABEL_TEXT,expMsg,"Tap on UserName Box");
		  
		//  String[] expMsg2 = {AT_LEAST_6_CHAR_MSG,AT_LEAST_1_NUMBER_MSG};
		  Mobile.setEdit(textBoxUserName, "Abc");		
		  //Common.verify_Value_InList_Contain(MESSAGE_LABEL_TEXT,expMsg2,"Enter Three Letter  UserName  Text Box and verify the message is displayed");
		  Mobile.verifyElementNotPresent("Enter less than 6 character", AT_LEAST_3_LETTER_MSG, AT_LEAST_3_LETTER_MSG);
			
		  Mobile.setEdit(textBoxUserName, "Abcdef");	
		  Mobile.verifyElementPresent("Enter 6 character in UserName textbox and verify the message is displayed", AT_LEAST_1_NUMBER_MSG, AT_LEAST_1_NUMBER_MSG);
		  Mobile.verifyElementNotPresent(AT_LEAST_6_CHAR_MSG +" should not be displayed", AT_LEAST_6_CHAR_MSG, AT_LEAST_6_CHAR_MSG);
		  Mobile.verifyElementNotPresent(AT_LEAST_3_LETTER_MSG +" should not be displayed", AT_LEAST_3_LETTER_MSG, AT_LEAST_3_LETTER_MSG);
			
		  Mobile.setEdit(textBoxUserName, "Abc1");		  
		  Mobile.verifyElementPresent("Enter One Number and more 3 char in  UserName  Text Box ", AT_LEAST_6_CHAR_MSG, AT_LEAST_6_CHAR_MSG );
		  Mobile.verifyElementNotPresent(AT_LEAST_1_NUMBER_MSG+" should not be displayed", AT_LEAST_1_NUMBER_MSG, AT_LEAST_1_NUMBER_MSG);
		  Mobile.verifyElementNotPresent(AT_LEAST_3_LETTER_MSG+" should not be displayed", AT_LEAST_3_LETTER_MSG, AT_LEAST_3_LETTER_MSG);
		 
		  String Char65_UserName = "ABCDE123456789012345678901234567890123456789012345678901234567890";
		  String Char64_UserName = "ABCDE12345678901234567890123456789012345678901234567890123456789";		  
		  Mobile.setEdit(textBoxUserName, Char65_UserName);	
		  Mobile.verifyText(textBoxUserName, Char64_UserName, true);
		  Mobile.verifyElementPresent("Enter 64 char Valid username and verify message valid username", VALID_USERNAME, VALID_USERNAME);
			
		  Mobile.setEdit(textBoxUserName, "Test@1234");	
		  Mobile.verifyElementPresent("Enter less than 64 valid username and verify message valid username", VALID_USERNAME, VALID_USERNAME);
	  
		
	}
	
	public void verify_PassWord_TextBox(){		
		   String[] expMsg = {PASSWORD_MUST_BE_BETWEEN_8_16_CHAR_MSG,MUST_INCLUDE3_OFTHESE_4_MSG,UPPER_CASE_MSG,LOWERCASE_MSG,NUMBER_MSG,SPECIAL_CHAR_MSG};
			MobileElement CurrentPassword = 	passwordList.get(0);
			MobileElement ConfirmPassword = 	passwordList.get(1);
			Mobile.setEdit(CurrentPassword, "");		
			Common.verify_Value_InList_Contain(MESSAGE_LABEL_TEXT,expMsg,"Tap Current Password textBox ");	
				
			Mobile.setEdit(CurrentPassword, "T");
	    	 Mobile.verifyElementNotPresent("Enter Upper case letter and Verify message \n"+UPPER_CASE_MSG+" should not be displayed", UPPER_CASE_MSG, UPPER_CASE_MSG);
				
			CurrentPassword.sendKeys("e");
			Mobile.verifyElementNotPresent("Enter lower case letter Verify message \n "+LOWERCASE_MSG+" should not be displayed", LOWERCASE_MSG, LOWERCASE_MSG);
		
			Mobile.setEdit(CurrentPassword, "Te1");
		    Mobile.verifyElementPresent("Enter Upper Cases and lower cases and Number  verify validation message.", PASSWORD_MUST_BE_BETWEEN_8_16_CHAR_MSG, PASSWORD_MUST_BE_BETWEEN_8_16_CHAR_MSG);
	    	Mobile.verifyElementNotPresent(MUST_INCLUDE1_OFTHESE_2_MSG+" should not be displayed", MUST_INCLUDE1_OFTHESE_2_MSG, MUST_INCLUDE1_OFTHESE_2_MSG);
			Mobile.verifyElementNotPresent(NUMBER_MSG+" should not be displayed", NUMBER_MSG, NUMBER_MSG);
			Mobile.verifyElementNotPresent(SPECIAL_CHAR_MSG+" should not be displayed", SPECIAL_CHAR_MSG, SPECIAL_CHAR_MSG);
					
			Mobile.setEdit(CurrentPassword, "Test@123456789101112");
			Mobile.verifyElementPresent("Enter password more then 16 char and verify validation message.", PASSWORD_MUST_BE_BETWEEN_8_16_CHAR_MSG, PASSWORD_MUST_BE_BETWEEN_8_16_CHAR_MSG);
				
			
			Mobile.setEdit(CurrentPassword, "Test@12345678");
			Mobile.verifyElementPresent("Enter Valid password  and verify message ", VALID_PASSWORD, VALID_PASSWORD);
			  
			Mobile.setEdit(ConfirmPassword, "invalid");
			Mobile.clickElement(butDone);
			Mobile.verifyElementPresent("Enter inValid password  in confirmation password and verify validation message ", PASSWORD_VALIDATION, PASSWORD_VALIDATION);
			Mobile.verifyElementISDisable(butRegister, "Register Button should be  Disable");	
			Mobile.setEdit(ConfirmPassword, "Test@12345678");
			Mobile.clickElement(butDone);
			Mobile.verifyElementPresent("Enter same password in confirmation textbox  and verify message ", PASSWORD_MATCH, PASSWORD_MATCH);
			Mobile.verifyElementEnable(butRegister, "Register Button should be  enable");  
			
		}
		
	
	
	
	
	
	public void submitVerificationCode(){
		
		try {
			new MFAPage().submitVerificationCode(Stock.getConfigParam("defaultActivationCode"),false,false);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void verifyRegistrationSummaryPage(){
		Mobile.verifyElementPresent("Registration summary Page should be display", "Registration summary", "Registration summary Page");
		Mobile.scroll_Down();
		Mobile.clickElement("CONTINUE TO YOUR ACCOUNT");
	   if(Mobile.assertElementPresent(By.name("CONTINUE TO YOUR ACCOUNT"))){
			Mobile.clickElement("CONTINUE TO YOUR ACCOUNT");
	   }
	
	 	Mobile.clickElement(SKIP_TOUR_BUT);
			Common.waitForProgressBar();
			Mobile.clickElement(MFAPage.BUT_CANCEL);
	}
	
	private void setDate(MobileElement ele, String cDate){	
		String[] dobList = cDate.split("-");
		Mobile.clickElement(textBoxDOB);		
      datePickerList.get(0).setValue(dobList[0]);
      datePickerList.get(1).sendKeys(dobList[1]);
      datePickerList.get(2).setValue(dobList[2]);
      Mobile.clickElement(butNext);
      

	}
	public void sendValue(IOSElement els, String value){
		try{
		els.sendKeys(value);
		}catch(Exception e){
			System.out.println("WebDriverException");
		}
	}
	
	   public static IOSElement FindElementByXpath(String sElement){
           return (IOSElement) Mobile.getDriver().findElement(By.xpath(sElement));
        }
	
	public static void clickBackArrow() {
		String BACK_ARROW = "back arrow";
		Mobile.clickElement(BACK_ARROW);

	}

}

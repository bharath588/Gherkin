package com.greatWest.pageObject;

import java.util.List;

import lib.Reporter;
import lib.Stock;
import io.appium.java_client.MobileElement;
import io.appium.java_client.ios.IOSElement;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.pagefactory.iOSFindBy;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;

import com.greatWest.utility.Mobile;

import org.openqa.selenium.By;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.LoadableComponent;
import org.testng.Assert;

import com.aventstack.extentreports.Status;
import com.greatWest.login.UserBaseTest;
import com.greatWest.pageObject.investment.MyInvestmentPage;
import com.greatWest.pageObject.investment.MyInvestmentPage.InvestmentOption;
import com.greatWest.pageObject.investment.MyInvestmentPage.fundAllocationType;
import com.greatWest.utility.Common;

public class HomePage extends LoadableComponent<LoginPage>{
	private LoadableComponent<?> parent;
	
	
	@iOSFindBy(accessibility ="Back")
	private MobileElement BACK_ARROW;
	
	@iOSFindBy(accessibility ="BACK")
	@CacheLookup
	private MobileElement BACK_BUTTON;
	
	@iOSFindBy(accessibility ="LOG OUT")
	@CacheLookup
	private MobileElement LOG_OUT_BUTTON;
	
	@iOSFindBy(accessibility ="LOG IN")
	@CacheLookup
	private MobileElement LOG_IN_BUTTON;
	

	@iOSFindBy(accessibility ="Next")

	private MobileElement NEXT;
	
	@iOSFindBy(accessibility ="menu")
	private static MobileElement HAMBURGER_MENU;
	
	@iOSFindBy(accessibility ="Done")
	@CacheLookup
	private static MobileElement DONE;
	
	@iOSFindBy(accessibility ="MY ACCOUNT")
	private static  MobileElement MY_ACCOUNT_MENU;
	
	@iOSFindBy(accessibility ="MY CONTRIBUTIONS")
	private static MobileElement MY_CONTRIBUTIONS_MENU;
	
	@iOSFindBy(accessibility ="BACK")
	@CacheLookup
	private static MobileElement BACK_MENU;
	
	@iOSFindBy(accessibility ="RETIREMENT INCOME")
	@CacheLookup
	private  static MobileElement RETIREMENT_INCOME_MENU;
	
	@iOSFindBy(accessibility ="TOUR")
	@CacheLookup
	private static  MobileElement TOUR_MENU;
	
	@iOSFindBy(accessibility ="PROFILE")
	@CacheLookup
	private static  MobileElement PROFILE_MENU;
	
	@iOSFindBy(accessibility ="FAQ")
	@CacheLookup
	private  static MobileElement FAQ_MENU;
	
	@iOSFindBy(accessibility ="ALLOCATION OVERVIEW")	
	private static  MobileElement ALLOCATION_OVERVIEW_MENU;
	
	@iOSFindBy(accessibility ="DISCLOSURES")
	@CacheLookup
	private static  MobileElement DISCLOSURES_MENU;
	
	@iOSFindBy(accessibility ="BENEFICIARIES")
	@CacheLookup
	private  static MobileElement BENEFICIARIES_MENU;
	
	
	private static String  APPLE_401_PLAN_MENU = "APPLE 401(K) PLAN";
		
	@iOSFindBy(accessibility ="OVERVIEW")	
	private  static MobileElement OVERVIEW_MENU;
	
	@iOSFindBy(accessibility ="ACCOUNT SUMMARY")
	@CacheLookup
	private  static MobileElement ACCOUNT_SUMMARY_MENU;
	
	@iOSFindBy(accessibility ="CONTACT US")
	@CacheLookup
	private  static MobileElement CONTACT_US_MENU;
	@iOSFindBy(accessibility ="LOG OUT")
	@CacheLookup
	private  static MobileElement LOG_OUT_MENU;
	
	@iOSFindBy(accessibility ="left arrow")
	@CacheLookup
	private  static MobileElement LEFT_ARROW;
	
	@iOSFindBy(accessibility ="right arrow")
	@CacheLookup
	private  static MobileElement RIGHT_ARROW;
	
	
	@iOSFindBy(accessibility = "EQUITIES")
	private MobileElement equities_Text_Field;
	
	@iOSXCUITFindBy(accessibility = "REVIEW CHANGES")
	private MobileElement butReviewChange;
	
	
	@iOSXCUITFindBy(accessibility = "CONTINUE")
	private MobileElement butContinue;
	
	public  String  reviewChangeBut = "REVIEW CHANGES";
	
	
	
	//Plan savings
	
	//Help Me Do It
	
	//Learn how you can further personalize your retirement strategy with additional investment information.
	
	//@iOSFindBy(id ="blue-down-arrow")
	@iOSFindBy(accessibility ="Investments View Options")	
	private  static MobileElement selectInvestmentOption;
	
	@iOSFindBy(id ="Get Started")
	@CacheLookup
	private  static MobileElement butGetStarted;
	@iOSFindBy(id ="Learn More")
	@CacheLookup
	private  static MobileElement butLearnMore;
	
	@iOSFindBy(id ="Plan savings")
	private  static MobileElement liat_Plan_Saving;	
	
	
	@iOSFindBy(id ="ALL CONTRIBUTIONS:")
	@CacheLookup
	private  static MobileElement Link_All_Contributions;
	
	
	@iOSXCUITFindBy(iOSNsPredicate = "label contains 'OF MY GOAL'")
	@CacheLookup
	private  static MobileElement OF_MY_GOAL;
	
	@iOSXCUITFindBy(iOSNsPredicate = "label contains 'Company match'")
	@CacheLookup
	private  static MobileElement APPLE_MATCH;
	
	
	
	@iOSXCUITFindBy(className = "XCUIElementTypeNavigationBar")
    private static MobileElement NAVIGATION_BAR;
	
	@iOSFindBy(id = "Edit")
	@CacheLookup
    private  MobileElement Edit;
	

	
	
	/** Empty args constructor
	 * 
	 */
	public HomePage() {
		this.parent = new MFAPage();
		PageFactory.initElements(new AppiumFieldDecorator(Mobile.getDriver()), this);
	}
	
	/**
	 * Constructor taking parent as input
	 * 
	 * @param parent
	 */
	public HomePage(LoadableComponent<?> parent) {
		// this.driver = DriveSuite.webDriver;
		this.parent = parent;
		PageFactory.initElements(new AppiumFieldDecorator(Mobile.getDriver()), this);
	}

	public static final String CLOSE_IMG = "Close";	
	public static final String ESTIMATED_RETIREMENT_INCOME= "ESTIMATED RETIREMENT INCOME";	
	public static final String RETIREMENT_PAGE= "Retirement income";
	public static final String ACCOUNT_PAGE= "Account overview";
	public static final String MY_ACCOUNT = "My Accounts";
	private static final String ASSETALLOCATIONPAGE = "Asset allocation";

	public static String  CURRENT_SALARY =  "CURRENT SALARY:";// "//XCUIElementTypeStaticText[@name='CURRENT BASE SALARY']/following-sibling::XCUIElementTypeTextField[1]";
	public static String  OTHER_VARIABLE_COMPENSATION =  "OTHER VARIABLE COMPENSATION:"; //"//XCUIElementTypeStaticText[@name='OTHER VARIABLE COMPENSATION']/following-sibling::XCUIElementTypeTextField[1]";

	
	private static String EMPLOYER_FUTURE_CONTRIBUTION ="_futureEmployerContributionsView";
	
	
	//public static String MENU_BACK="BACK";
	
	
	private static Boolean isMultiplePlan = false;
	public static String sPlanName;
	
	
	
	
	

	@Override
	protected void isLoaded() throws Error {
	  
		Assert.assertTrue(isHomePageDisplayed(),"Home Page is not loaded");
	
	}
	
	public Boolean isHomePageDisplayed(){
		Boolean status = false;
		if(Mobile.assertElementPresent(By.name("GWMUsernameTextField"))){
			return status;
		}
		else{
			
	   if(Mobile.assertElementsPresent(ESTIMATED_RETIREMENT_INCOME,RETIREMENT_PAGE,ACCOUNT_PAGE,MY_ACCOUNT,ASSETALLOCATIONPAGE)){
		  return true; 
	   }
	   else{
		   if(Mobile.assertElementsPresent("Enrollment")){
			   new EnrollmentPage().clickEnrollNowButton();
			   return Mobile.assertElementsPresent(ESTIMATED_RETIREMENT_INCOME,RETIREMENT_PAGE,ACCOUNT_PAGE,MY_ACCOUNT,ASSETALLOCATIONPAGE);
		   }
	   }
		
		return status;
	
		//	return isHomePageLoaded();
		}
	
	}
	
	
	private Boolean isHomePageLoaded(){
		Boolean b = false;
		String[] expPageTitleList = {ESTIMATED_RETIREMENT_INCOME,RETIREMENT_PAGE,ACCOUNT_PAGE,MY_ACCOUNT,ASSETALLOCATIONPAGE};
		try{
		String actTitle = Mobile.getElementName(NAVIGATION_BAR);
		for (String expTitle : expPageTitleList) {
			if(actTitle.equals(expTitle)){
				b= true;
				return b;
		}
		
	}
		}catch(Exception e){
			System.out.println("Not able to load home page");
		}
		
		
		return b;
	}

	@Override
	protected void load() {
		// TODO Auto-generated method stub
		
		MFAPage mfa = (MFAPage) this.parent;
		this.parent.get();			
	    try {
			mfa.submitVerificationCode(Stock.getConfigParam("defaultActivationCode"),false,false);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	   
	}
	
	public   MobileElement getWebElement(String webElement){
		
		MobileElement ele = null;
			 if (webElement.equalsIgnoreCase("Edit")){
				return Edit;
			}
			else if (webElement.equalsIgnoreCase("Collapse")){
				return Edit;
			}
				
			 
			
				
			
			return ele;
}
	
	
	
	
	
	
	public static void setMultiplePlan(Boolean status, String sPlan){
		 isMultiplePlan = status;		
		 if(sPlan.equalsIgnoreCase("PERSHING_PLAN TESTING")){		
			 sPlanName ="PERSHING_PLAN TESTING";
		 }else{
			 sPlanName = sPlan;
		 }
	}
	

	public static Boolean isMultiplePlan(){
		return isMultiplePlan;		
	}
	
	 
	
	public  void logout(){
		if(Mobile.assertElementPresentByPageFactor(BACK_ARROW)){
			Mobile.clickElement(BACK_ARROW);			
		}	
		Mobile.clickElement(HAMBURGER_MENU);
		if(Mobile.assertElementPresent(By.className(DeferralsPage.ALERT_MSG))){
			if(Mobile.assertElementPresent(By.name("Exit")))
				Mobile.clickElement("Exit");
			else if(Mobile.assertElementPresent(By.name("OK")))
				Mobile.clickElement("OK");
			else if(Mobile.assertElementPresent(By.name("Continue"))){
				Mobile.clickElement("Continue");			}
			else{	
				Mobile.clickElement("Cancel");
			}
		}
			
		if(Mobile.assertElementPresentByPageFactor(BACK_BUTTON)){
			Mobile.clickElement(BACK_BUTTON);
		}	
		if(Mobile.assertElementsPresent(CLOSE_IMG)){
			Mobile.clickElement(CLOSE_IMG);
		}  
		if(Mobile.assertElementPresentByPageFactor(BACK_BUTTON)){
			Mobile.clickElement(BACK_BUTTON);
		}	
		if(Mobile.assertElementPresentByPageFactor(LOG_OUT_BUTTON)){
			Mobile.clickElement(LOG_OUT_BUTTON);
		}
		else if(Mobile.assertElementPresentByPageFactor(LOG_IN_BUTTON)){
			Mobile.clickElement(LOG_IN_BUTTON);
		}
	//	Mobile.clickElement(LOGOUT);
		 Common.waitForProgressBar();  	
    	
    }
	public static void selectMenuOption(String... menulist) {

		Mobile.clickElement(HAMBURGER_MENU);	
		
		if(Mobile.assertElementPresent(By.name("Exit"))){
			Mobile.clickElement("Exit");
		}		
		
		for (int i = 0; i < menulist.length; i++) {
			
			switch (menulist[i]) {
			case "MY ACCOUNT":
				if(Mobile.assertElementPresent(MY_ACCOUNT_MENU)){
				Mobile.clickElement(MY_ACCOUNT_MENU);
				}else{
					 List<IOSElement> menulistselement =  Mobile.getListOfElements_By_Class("XCUIElementTypeCell");
					 if(menulistselement.size() >=3){
						 menulistselement.get(3).click();
						 Mobile.wait(3000);
						 Common.waitForProgressBar();
					 }
				}
				
				break;
				
	        case "BACK":				
	        	Mobile.clickElement(BACK_MENU);
				break;
	        case "MY CONTRIBUTIONS":
	        	
	        	  if(Mobile.is_Element_Displayed(MY_CONTRIBUTIONS_MENU)){
	  	        	Mobile.clickElement(MY_CONTRIBUTIONS_MENU);
	  	            }
	  	            else{
	  					 List<IOSElement> menulistselement =  Mobile.getListOfElements_By_Class("XCUIElementTypeCell");
	  					 if(menulistselement.size() >=3){
	  						 menulistselement.get(3).click();
	  					 }
	  					 Mobile.clickElement(MY_CONTRIBUTIONS_MENU);
	  	            }	        	
	        	
				break;
	        case "RETIREMENT INCOME":				
	        	Mobile.clickElement(RETIREMENT_INCOME_MENU);
				break;
	        case "TOUR":				
	        	Mobile.clickElement(TOUR_MENU);
				break;
	        case "PROFILE":				
	        	Mobile.clickElement(PROFILE_MENU);
				break;
	        case "FAQ":				
	        	Mobile.clickElement(FAQ_MENU);
				break;
				
	        case "ALLOCATION OVERVIEW":	
	            if(Mobile.is_Element_Displayed(ALLOCATION_OVERVIEW_MENU)){
	        	Mobile.clickElement(ALLOCATION_OVERVIEW_MENU);
	            }
	            else{
					 List<IOSElement> menulistselement =  Mobile.getListOfElements_By_Class("XCUIElementTypeCell");
					 if(menulistselement.size() >=3){
						 menulistselement.get(3).click();
					 }
					 Mobile.clickElement(ALLOCATION_OVERVIEW_MENU);
	            }
	        	break;
				
	        case "DISCLOSURES":				
	        	Mobile.clickElement(DISCLOSURES_MENU);
				break;
				
	        case "BENEFICIARIES":				
	        	Mobile.clickElement(BENEFICIARIES_MENU);
				break;
				
	        case "APPLE 401(K) PLAN":	
	           	Mobile.clickElement(APPLE_401_PLAN_MENU);
	           	Common.waitForProgressBar();
				break;
	        case "OVERVIEW":		
	        	
	        	Mobile.clickElement(OVERVIEW_MENU);
				break;	
	        case "ACCOUNT SUMMARY":				
	        	Mobile.clickElement(ACCOUNT_SUMMARY_MENU);
				break;	
	        case "CONTACT US":				
	        	Mobile.clickElement(CONTACT_US_MENU);
				break;	
	        case "LOG OUT":				
	        	Mobile.clickElement(LOG_OUT_MENU);
				break;

			default:				
			if(Mobile.is_Element_Displayed(MY_ACCOUNT_MENU)){
				Mobile.clickElement(MY_ACCOUNT_MENU);
			}
			    List<IOSElement> menulistselement =  Mobile.getListOfElements_By_Class("XCUIElementTypeCell");
			    for(int j = 1;j<menulistselement.size();j++){
			    	String sValue = menulistselement.get(j).getText();
			    	if(sValue.contains(menulist[i])){
			    		Mobile.clickElement(menulistselement.get(j));
			    		break;
			    	}
			    }
			    break;
				
			}		
			
			
		}
		 Common.waitForProgressBar();
	}
	
	public static void verifyHomePage(){
		Mobile.verifyElementPresent("", NAVIGATION_BAR, "Home Page is display");
	}
	
	/*
	 * This method will verify Company match in Liat Page
	 */
	
	
	public  void verify_Company_Match(){
		String sExpContent  = UserBaseTest.getParaValue("PlanRule"); 
	   	   Mobile.verifyText(APPLE_MATCH, sExpContent, false);
		}
	
	/* 
	 * This method will update Salary in My Gold 
	 */
	
	
	public  void update_Salary_In_My_Goal(String sSalaryType){
		
		if(Mobile.assertElementPresentByPageFactor(OF_MY_GOAL)){
		Mobile.clickElement(OF_MY_GOAL);
	//	Mobile.isElementPresent("My goal");	
		String sSalVal = null;
		
		
		 if(sSalaryType.equals(CURRENT_SALARY))
		 {
			 sSalVal =  UserBaseTest.getParaValue("base_salary");
			Mobile.setEdit(sSalaryType, sSalVal);
			Mobile.clickElement(NEXT);
			Mobile.setEdit(OTHER_VARIABLE_COMPENSATION, "000");
			Reporter.logEvent(Status.INFO, "Salary Update for Base Salary in My Goal Page ",sSalVal, false);	
		 }
		 else if(sSalaryType.equals(OTHER_VARIABLE_COMPENSATION)){
			 sSalVal =  UserBaseTest.getParaValue("Valariable_Salary");
			Mobile.setEdit(CURRENT_SALARY, "000");
			Mobile.clickElement(NEXT);
			Mobile.setEdit(OTHER_VARIABLE_COMPENSATION, sSalVal);	
			Reporter.logEvent(Status.INFO, "Salary Update for Variable Salary in My Goal Page ",sSalVal, false);	
		}	
		 else if(sSalaryType.equals("BOTH"))
		 {
			 sSalVal =  UserBaseTest.getParaValue("base_salary");
			 Mobile.setEdit(CURRENT_SALARY, sSalVal);
		     Reporter.logEvent(Status.INFO, "Salary Update for Base Salary in My Goal Page ",sSalVal, false);	
		     Mobile.clickElement(NEXT);
		     String sVarSalary =  UserBaseTest.getParaValue("Valariable_Salary");
			 Mobile.setEdit(OTHER_VARIABLE_COMPENSATION, sVarSalary);	
			 Reporter.logEvent(Status.INFO, "Salary Update for Variable Salary in My Goal Page ",sVarSalary, false);
		 }
	   
//		Mobile.clickElement(NEXT);
//		if(Mobile.assertElementPresentByPageFactor(NEXT)){
//			Mobile.clickElement(NEXT);
//		}
		Mobile.clickElement(DONE);
		Mobile.clickElement("SAVE");
		
		Common.waitForProgressBar();
		}else{
			Assert.fail("Not able to load LIAT Page");
		}
		}
	
	/*
	 * 
	 */
	
	public void verifyEmployer_Future_Contribution_Update(String empPastConfValue){
		String sEmpValue = Mobile.getElementValue(EMPLOYER_FUTURE_CONTRIBUTION);
		if(sEmpValue != null){
		if(empPastConfValue != "$0")
		 if(!sEmpValue.equals(empPastConfValue))
			Reporter.logEvent(Status.PASS, " Employer future contribution in paycheck is update from "+empPastConfValue , "To "+sEmpValue, false);
			else
			Reporter.logEvent(Status.FAIL, "Employer future contribution in paycheck is not update","But Actual was :  "+sEmpValue, true);
		}
		else
			Reporter.logEvent(Status.FAIL, "Employer future contribution in paycheck is not found","", true);
			
	}
	
	public void verify_Company_Match_Rule_From_Income_Goal(String SalaryType){
		update_Salary_In_My_Goal(SalaryType);	
	
		Reporter.logEvent(Status.INFO, "Step 6 Verify the Company match rule. ", "Company Match rule should be updated .", false);
	
		Mobile.clickElement(Link_All_Contributions);
		verify_Company_Match();		
	}
	
	/*
	 * 
	 * This method will select LIAT Page Option 
	 */
	
	public void selectLiatPage(String pageOption){
		for(int i =0;i< 5;i++){
	if(!Mobile.assertElementPresent(By.name(pageOption))){
		Mobile.clickElement(RIGHT_ARROW);
		
	 }else{
		 break;
	 }
		}
	
	}
	
	
	public void selectInvestmentOptionInLIAT_Page(String pageOption,InvestmentOption investmentOption,String pickerOption){
		
		   Reporter.logEvent(Status.INFO, "In LIAT Page select :"+pageOption, "select Investment Option :" +MyInvestmentPage.getInvestmentOption(investmentOption), false);	
		selectLiatPage(pageOption);
		Mobile.clickElement(selectInvestmentOption);
	    Mobile.selectPickerValue(MyInvestmentPage.getInvestmentOption(investmentOption),pickerOption);
	    if(investmentOption.equals(InvestmentOption.HMDI)){
	    	if(Mobile.is_Element_Displayed(butGetStarted))
	    		Mobile.clickElement(butGetStarted);	
	    	else
	    		Mobile.clickElement(butLearnMore);	     
	     
	    }else if(investmentOption.equals(InvestmentOption.DIM)){
	    	 Common.setSliderValueInLIATPage(equities_Text_Field,"60");	    	 
	    	 Mobile.clickElement(butReviewChange);	 	  
	    }	 
	    Common.waitForProgressBar();	
	}
	
	public void verify_Unable_To_Complete_Transaction_Message(){
		selectInvestmentOptionInLIAT_Page("Plan savings", InvestmentOption.DIM, MyInvestmentPage.NEXT_PICKER_VALUE);
	
	    Mobile.verifyElementPresent("Warning message should be display", "Unable to complete transaction", "Unable to complete transaction Page");
	   
	    String sWarMsg = "Warning! Because your plan offers certain investment or service options, your transaction cannot be completed. Please select \"Continue\" to make investment allocation changes to your current account balance or future contributions.";
	    Mobile.verifyElementPresent("Warning message should be display",sWarMsg, sWarMsg);
	    Mobile.clickElement(butContinue);
	    Common.waitForProgressBar();
	    
	}
	
	
	public void verify_Pending_Transfer_Exist_For_Smart_Restriction(){
		selectInvestmentOptionInLIAT_Page("Plan savings", InvestmentOption.DIM, MyInvestmentPage.NEXT_PICKER_VALUE);
		 
		
	}
	
	
	public void validate_TTK_message_inContribution_Page(){
		
	}
	
}

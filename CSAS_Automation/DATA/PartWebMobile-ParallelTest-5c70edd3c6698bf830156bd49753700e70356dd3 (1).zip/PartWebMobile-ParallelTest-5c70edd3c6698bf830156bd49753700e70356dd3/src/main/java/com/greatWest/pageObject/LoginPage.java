package com.greatWest.pageObject;

import lib.Reporter;
import lib.Stock;
import io.appium.java_client.MobileElement;
import io.appium.java_client.ios.IOSElement;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.pagefactory.iOSFindBy;

import org.openqa.selenium.By;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.LoadableComponent;
import org.testng.Assert;

import appium.utils.Reader;

import com.aventstack.extentreports.Status;
import com.greatWest.login.UserBaseTest;
import com.greatWest.utility.Common;
import com.greatWest.utility.Mobile;

import core.framework.Globals;




public class LoginPage  extends LoadableComponent<LoginPage>{
	
	private LoadableComponent<?> parent;
	
	
	@iOSFindBy(id ="GWMUsernameTextField")
	@AndroidFindBy(id = "username")
	@CacheLookup
	private MobileElement inputUserName;
	
	@iOSFindBy(id ="GWMPasswordTextField")
	@CacheLookup
	private MobileElement inputPassWord;
	

	@iOSFindBy(id ="GWMLoginButton")
	@CacheLookup
	private MobileElement butLogin;
	
	@iOSFindBy(id ="menu")
	@CacheLookup
	private MobileElement MENULABEL;

	
	public String ERROR_LABEL_ID="GWMLoginErrorLabel";
	
	@iOSFindBy(id ="LOG IN")
	@CacheLookup
	private MobileElement LOG_IN;
	
	@iOSFindBy(id ="Register now")
	@CacheLookup
	private MobileElement linkRegisterNow;
	
	@iOSFindBy(id ="forget username or password?")
	private MobileElement  forgotUserName;
	
	
	
	public static String CLOSE_IMG = "Close";
	
	@iOSFindBy(id ="back arrow")
	private MobileElement BACK_ARROW;
		
	

	
	
	/** Empty args constructor
	 * 
	 */
	public LoginPage() {

	PageFactory.initElements(new AppiumFieldDecorator(Mobile.getDriver()), this);
	}
	
	/**
	 * Constructor taking parent as input
	 * 
	 * @param parent
	 */
	public LoginPage(LoadableComponent<?> parent) {

		this.parent = parent;
		PageFactory.initElements(new AppiumFieldDecorator(Mobile.getDriver()), this);
	}

	public static String inputUserName_ID = "GWMUsernameTextField";
	public static String inputPassWord_ID = "GWMPasswordTextField";
	
	public static String butLogin_ID ="GWMLoginButton";
	

	public static String envlabel = "Environments"; 

	public static String DISCLOSURES ="DISCLOSURES";
	public static String CONTACT_US = "Contact us.";	
	public static String envVal = "Proj2";
	public static String logInLabel = "GWMLoginViewController";
	public static String menu = "UINavigationButton";		
	public static String BACK_ARROW1 = "back arrow";	
	
	
	
	public static String LOGO_IMG = "login-logo";
	public static String FIRST_TIME_TEXT ="First time user?";
	
	
	public static String HELPER_ICON ="//*[@name='GWMPasswordTextField']/XCUIElementTypeButton[@name='help icon']";
	public static String ERROR_LOGIN_INVALID_PASSWORD_MSG ="Error: The system was not able to log you on. Please verify your Username and Password before trying again.";
	public static String ERROR_LOGIN_EXCEEDED_MAX_TRIAL ="You have exceeded the maximum number of login attempts allowed. For security reasons, internet access to your account has been temporarily disabled. Your account will be reactivated";

	public static String SESSION_TIME_OUT_MSG ="Your session has timed out. Please log on again.";
	
	private static Boolean setEnv = true;	
	public static String USERLOGGIN ="";

	@Override
	protected void isLoaded() throws Error {
		if(setEnv){	
	//	selectEnv();
		readUserDetail();
		setEnv = false;
		}	
		//readUserDetail();
		Assert.assertTrue(Mobile.assertElementPresentByPageFactor(inputUserName),"Login Page is Not Loaded");
		
	}

	@Override
	protected void load() {
		try {
			setDefaultPageToLogin();		
	
		} catch (Exception e) {
			
		}
		}
	
	
      private void setDefaultPageToLogin(){
    	 int i =0; 

    	   do{
    		if(Mobile.assertElementPresent(By.name("menu"))){
				new HomePage().logout();
			}
    		else
			{
    		if(Mobile.assertElementsPresent("Back")){
    				Common.clickBackArrow();
    		}
    		if(Mobile.assertElementPresent(By.name("CANCEL"))){
				Mobile.clickElement("CANCEL");
			}    
    		if(Mobile.assertElementsPresent(CLOSE_IMG)){
				Mobile.clickElement(CLOSE_IMG);
			}  
    		if(Mobile.assertElementPresent(By.className(DeferralsPage.ALERT_MSG))){    			
    			if(Mobile.assertElementPresent(By.name("Exit"))){
    				Mobile.clickElement("Exit");
    			}
    			else if(Mobile.assertElementPresent(By.name("OK"))){
    				Mobile.clickElement("OK");
    			}
    			else if(Mobile.assertElementPresent(By.name("Continue"))){
    				Mobile.clickElement("Continue");
    				Mobile.clickElement("LOG OUT");
    			}
    			else{ 
    				Mobile.clickElement("Cancel");
    			}
    			
    		}	
//    		if(Mobile.assertElementPresent(By.name(DeferralsPage.BACK_BUT))){
//    			Mobile.clickElement(DeferralsPage.BACK_BUT);
//    		}	    		
			}
    		i++;
    	   }while(!Mobile.assertElementPresentByPageFactor(inputUserName) && i <3);
    		
    	
    		
      }
	
      public void clickForgotPasswordLink(){
    	  Mobile.clickElement(forgotUserName);
      }
      

      public void clickForgotUserLink(){
    	  Mobile.clickElement(forgotUserName);
      }
	
      /**
       * Submit Login : Enter login  details and submit
       * @param user : Username to llogin in app
       * @param Password : Password for username
       * @throws InterruptedException
       */
	
		public  void submitLogin(String user,String Password) throws InterruptedException{			

			Reporter.logEvent(Status.INFO,"Login with USER ID :",user,false);
			Mobile.setEdit(inputUserName, user.trim());
			Mobile.setEdit(inputPassWord,Password.trim());	
			Mobile.hideKeyboard();			
			Mobile.clickElement(butLogin);			
			Common.waitTillElementNotDisplay_InLoginPage("GWMLoginButton");	
			Common.waitTillElement_Is_Display(By.name("GWMAlreadyHaveCodeButton"),20);
			Common.waitForProgressBar();

			Assert.assertFalse(Mobile.assertElementPresentByPageFactor(inputUserName),"User is not able to Login");
			setUserLogIn(user);			
		}

		public  void enterLoginDetails(String user,String Password) throws InterruptedException{			

			Reporter.logEvent(Status.INFO,"Login with USER ID :",user,false);
			Mobile.setEdit(inputUserName,user);
			Reporter.logEvent(Status.INFO,"Login with PASSWORD  :",Password,false);
			Mobile.setEdit(inputPassWord,Password);	
			Mobile.hideKeyboard();			
			Mobile.clickElement(butLogin);	
			
		}
		
		private  void selectEnv(){
			Mobile.clickElement(MENULABEL);		
			Mobile.wait(2000);		
			Mobile.clickElement(envlabel);
		//	String env ="//*[@name='"+Stock.getConfigParam("APP_ENV").trim()+"']";
			Mobile.clickElement(Stock.getConfigParam("APP_ENV").trim());
			Mobile.clickElement(MENULABEL);
			Mobile.wait(2000);
			Mobile.clickElement(LOG_IN);
			
		}
		
		private void readUserDetail(){
			appium.utils.Reader.setUserNameParam(Globals.GC_TESTCONFIGLOC
					+ "UserConfig.properties");
			
			
		}
		
		public void verifyMenuOption(String... sMenuOptionList){
			Mobile.clickElement(MENULABEL);
			for (String menulist : sMenuOptionList) {
				Mobile.verifyElementPresent(menulist+ " should be displaye.", menulist, menulist);
				
			}
			Mobile.clickElement(LOG_IN);
		}
		
		
	
		
		
		
		public void verifyContactLink(){
			Mobile.clickElement(MENULABEL);
			Mobile.clickElement(CONTACT_US);
			Common.waitForProgressBar();
			Common.verifyPageIsDisplayed("Contact Us Home Page is display", "Contact us");
			Mobile.clickElement(MENULABEL);
		}
		
		public void verifyDisclosuresLink(){
			Mobile.clickElement(DISCLOSURES);
			Common.waitForProgressBar();
			Common.verifyPageIsDisplayed("DisClosure Home Page should be display.", "Disclosures");
			Mobile.clickElement(MENULABEL);
		}
		
		public void verifyLookUpAccountPage(){
			Mobile.clickElement(linkRegisterNow);
			Mobile.verifyElementPresent("Tap Registration button and verify Look Up Account page is displayed", "Let's look up your account", "look Up your Account Page");
			Common.clickBackArrow();
		}
		public void verifyErrorMessageForThreeTimeInValidLogin(String user,String Password,String sMsg){
			for(int i =0; i<3;i++){
				Reporter.logEvent(Status.INFO,"User Login with USER ID :",user,true);
				Mobile.setEdit(inputUserName,user);
				Mobile.setEdit(inputPassWord,Password);	
				Mobile.hideKeyboard();			
				Mobile.clickElement(butLogin);	
				
					Mobile.wait(4000);
			
			}
			Mobile.verifyText(ERROR_LABEL_ID, sMsg,false);
			
		}
		
		
		
		
		
		public void popUpWindow() throws InterruptedException{
			
			String VIEW ="//XCUIElementTypeStaticText[@name='LIAT Esothogotcm Emcuuhe Ucmcsh Fghgsscm 401(l) Nsshht Ugcshoi NmcoLIAT Esothogotcm Emcuuhe Ucmcsh F']/following-sibling::*[@name='VIEW']";
			String popTest ="We're working hard to update this app";
			String ALERT_POP ="//XCUIElementTypeAlert";
			String CANCEL_BUT = "Cancel";
			String CONTINUE_BUT = "Continue";
			String LOGOUT ="Logout";
			String verifyName ="NDHIOHGE";
			
			Mobile.clickElement(VIEW);
			if(Mobile.isElementPresent(ALERT_POP)){
				System.out.println("Alert Present");
			}
			Mobile.clickElement(CONTINUE_BUT);
			if(Mobile.isElementPresent(verifyName)){
				System.out.println("Name is verified");
			}
			Mobile.clickElement(LOGOUT);
			Mobile.wait(8000);
			
		}
		
	
		
		
		
		public void clickHelpIcon(String sLabel){
			String sObj = "//*[@value='"+sLabel+"']/XCUIElementTypeButton[@name='help icon']";
			Mobile.clickElement(sObj);
			
		}
		
		
		public static  void clickEllipses(String sLabel){			
			String sObj = "//*[@name='"+sLabel+"']/following-sibling::*[@name='ellipses']";
			Mobile.clickElement(sObj);
			
		}
		
		public static  void closeEllipses(String sLabel){			
			String sObj = "//*[@name='"+sLabel+"']/following-sibling::*[@name='details close']";
			Mobile.clickElement(sObj);
			
		}
		
		public static String getUserLogIN(){
			return USERLOGGIN;
		}
		
		public static void setUserLogIn(String sUserName){
			USERLOGGIN =sUserName;			
		}
		
		public  static void LIATPage() throws InterruptedException{
			String CANCLE_X= "cancel x";
			String CHECK = "check";
		
			 String  CURRENT_SALARY = "//*[@name='CURRENT SALARY']/following-sibling::XCUIElementTypeTextField[1]";
				
				String BUTTON_80 ="//XCUIElementTypeButton[@name='80%']";
				
				String BUTTON_90 = "//XCUIElementTypeButton[@name='90%']";		
				String message ="International phone number support is currently unavailable";
				
				String PERCENTAGE = "//*[@name='PERCENTAGE OF MY CURRENT SALARY I WILL NEED IN RETIREMENT']/following-sibling::XCUIElementTypeTextField";
				String CANCEL_BUT ="GWMEditGoalCancelButton";
				String OF_MY_GOAL = "OF MY GOAL";
				String CLOSE = "close x";		
				String ENROLL_BUT = "Enroll In Managed Accounts";
			
			
			
			Mobile.clickElement(OF_MY_GOAL);
			Mobile.isElementPresent("My goal");
			
			Mobile.setEdit(CURRENT_SALARY, "100000");
			Mobile.clickElement(BUTTON_80);
			Mobile.clickElement(BUTTON_90);		
			Mobile.clickElement(CANCEL_BUT);
			
			//Mobile.clickElement(CLOSE);		
			//Mobile.clickElement("REVIEW CHANGES");
			
			clickEllipses("ESTIMATED RETIREMENT INCOME");
			Mobile.wait(5000);
			closeEllipses("ESTIMATED RETIREMENT INCOME");
			Mobile.wait(5000);
			Mobile.setSliderValue("RETIREMENT AGE:" ,"50");			
			Mobile.clickElement(CHECK);
			Mobile.wait(5000);

		

		}
	
		public static void Beneficiary() throws InterruptedException {
			String ADD_BENEFICIARIES = "add bene";
			String PRIMARY_BUT = "Primary";
			String CONTINGENT_BUT = "Contingent";
			String CLOSE = "close x";
			String SELECT = "//*[@value='SELECT ONE']";

		
			HomePage.selectMenuOption("MY ACCOUNT", "BENEFICIARIES");
			Common.waitForProgressBar();

			Mobile.clickElement(ADD_BENEFICIARIES);

			Mobile.clickElement(PRIMARY_BUT);
			Mobile.clickElement(SELECT);
			Mobile.wait(3000);
//			Mobile.clickElement("Sibling");
//			Mobile.wait(3000);
	//		Mobile.clickElement(DONE_BUTTON);
			Mobile.clickElement(CONTINGENT_BUT);
			Mobile.clickElement(CLOSE);
			HomePage.selectMenuOption("BACK","RETIREMENT INCOME");
			 Common.waitForProgressBar();

		}
		public static void Profile(){
			HomePage.selectMenuOption("PROFILE","Communication preference");
			Mobile.clickElement("EDIT PREFERENCE");
			
		}
		
	
		

		public static void selectView(String sLabel) {
			String sObj = "//*[@name='VIEW:']/following-sibling::*[@name='"	+ sLabel + "']";
			 Mobile.clickElement(sObj);

		}
	  
		
		public static Boolean is_Same_User_Already_LogIN(){	
			try{
			if(Reader.getUserNameParam(UserBaseTest.getParaValue("userName")).equals(getUserLogIN())){
				Reporter.logEvent(Status.INFO, "User is already login to app", LoginPage.USERLOGGIN, false);
				return  true;
			}
			else {
				//Reporter.logEvent(Status.INFO, "User should login to app", LoginPage.USERLOGGIN, false);
				return false;
			}
			}catch(Exception e){
				return false;
			}
		}
		
		
		      
		      public static  MobileElement FindElement(By link){		    	
		    	return (IOSElement) Mobile.getDriver().findElement(link);	    		 
		    	  
		      }
		        
		        public static MobileElement FindElement(String sElement){
		           return (MobileElement) Mobile.getDriver().findElement(By.xpath(sElement));
		        }
		        
		     

		//*[@name='BEFORE-TAX DEFERRAL CONTRIBUTION:']/following-sibling::XCUIElementTypeSlider"
		//BEFORE-TAX DEFERRAL CONTRIBUTION:
//		        public static void waitForPageToLoad(String locator) {
//		    		try {
//		    			MobileElement id = FindElement(locator);
//		    			WebDriverWait wait = new WebDriverWait(Mobile.getDriver(),
//		    					Integer.parseInt(Stock.getConfigParam("objectSyncTimeout")));
//		    			wait.until(ExpectedConditions.elementToBeClickable(id));
//		    		} catch (Exception e) {
//		    			System.out.println("Not able to  load the Page waitForPageToLoad");
//		    		}
//		    	}
		
		        
		        public void verify_Login_Screen_Negative_Flow(){
		        	
		        	Reporter.logEvent(Status.INFO,"Step 2: Enter UserName in Login Page","Username typed is displayed ",false);
		    		String sUserName =Reader.getUserNameParam(UserBaseTest.getParaValue("userName"));
		    		Mobile.setEdit(inputUserName, sUserName);
		    		
		    		Reporter.logEvent(Status.INFO,"Step 3: Do not Input a Password","No Password entered",false);
		    		Mobile.setEdit(inputPassWord,"");
		    		Mobile.hideKeyboard();	
		    		
//		    		Reporter.logEvent(Status.INFO,"Step 4: Select the LOGIN link.","Login button enable",false);
//		    		Mobile.verifyElementISDisable(butLogin,"Login Button should be enable");
		    	
		    		
		    		Reporter.logEvent(Status.INFO,"Step 5-6: Enter User Name  and Password","The password is masked and not visable but is replaced with an * for each character typed",false);
		    		Mobile.setEdit(inputUserName,sUserName);		
		    		Mobile.setEdit(inputPassWord,"test");
		    		Mobile.verifyText(inputPassWord,"••••",true);
		    		
		    		
		    		Reporter.logEvent(Status.INFO,"Step 7:Click LOGIN button ","Error message should be displayed  "+ LoginPage.ERROR_LOGIN_INVALID_PASSWORD_MSG,false);
		    		Mobile.hideKeyboard();	
		    		Mobile.clickElement(butLogin);
		    		Mobile.wait(4000);
		    		Mobile.verifyText(ERROR_LABEL_ID, LoginPage.ERROR_LOGIN_INVALID_PASSWORD_MSG,true);
		    		
		    		
		    		Reporter.logEvent(Status.INFO,"Step 8-10: Leave the username blank and password"," Login button is enabled",false);
		    		Mobile.setEdit(inputUserName,"");
		    		Mobile.setEdit(inputPassWord,"");		
		    		Mobile.hideKeyboard();	
		    		Mobile.verifyElementEnable(butLogin,"Login Button ");
		    		
		    		Reporter.logEvent(Status.INFO,"Step 11:Enter User with invalid User and Valid password ","",false);
		    		Mobile.setEdit(LoginPage.inputUserName_ID,"12345");		
		    		Mobile.setEdit(LoginPage.inputPassWord_ID,"Test@1234");
		    		
		    		Reporter.logEvent(Status.INFO,"Step 13: Click  LOGIN button ","Verify Error message :\n   "+LoginPage.ERROR_LOGIN_INVALID_PASSWORD_MSG,false);
		    		Mobile.hideKeyboard();	
		    		Mobile.verifyElementEnable(butLogin,"Login Button");
		    		Mobile.clickElement(butLogin);
		    		Mobile.verifyText(ERROR_LABEL_ID, LoginPage.ERROR_LOGIN_INVALID_PASSWORD_MSG,true);	
		    		
		    	    HomePage.selectMenuOption(LoginPage.DISCLOSURES);
		    	    Mobile.clickElement(MENULABEL);
		    	    Mobile.wait(1000);
		    	    Mobile.clickElement(LOG_IN);
		    	   
		        }
		        
		        public void verify_Login_Scree_Login_Prevent_Lock_Account() throws InterruptedException{
		        	String sUserName =Reader.getUserNameParam(UserBaseTest.getParaValue("userName"));
		    		Reporter.logEvent(Status.INFO,"Step 2-4 Enter Valid User name and invalid Password and click login : ","Error Message :   Error: The system was not able to log you on. Please verify your username and password before trying again. ",false);
		    		
		    		enterLoginDetails(sUserName, UserBaseTest.getParaValue("invalidPassWord1"));
		    		Mobile.verifyText(ERROR_LABEL_ID, ERROR_LOGIN_INVALID_PASSWORD_MSG,true);
		    		
		    		Reporter.logEvent(Status.INFO,"Step 5 -7: Enter valid User name and invalid Password and click login "," Error message  display ",false);
		    		enterLoginDetails(sUserName,UserBaseTest.getParaValue("invalidPassWord2"));
		    		Mobile.verifyText(ERROR_LABEL_ID, ERROR_LOGIN_INVALID_PASSWORD_MSG,true);
		    				
		    		Reporter.logEvent(Status.INFO,"Step 8 -11: Enter Valid User name and valid Password and click login ","MFA Page is displayed ",false);
		    		enterLoginDetails(sUserName, UserBaseTest.getParaValue("passWord"));
		    		Common.waitTillElementNotDisplay(butLogin_ID);	
		    		Mobile.verifyElementPresent("Step 11","Already have a code?", "MFA page is displayed");		
		    		Common.clickBackArrow();
		        }
		        
		        public void verify_Login_Screen_Login_Lock_Account() throws InterruptedException{
		        	String sUserName =Reader.getUserNameParam(UserBaseTest.getParaValue("userName"));
		    		Reporter.logEvent(Status.INFO,"Step 2-4 Enter Valid  User name and invalid Password (123) and click login : ","Error Message is displayed ",false);
		    		enterLoginDetails(sUserName, UserBaseTest.getParaValue("invalidPassWord1"));
		    		Mobile.verifyText(ERROR_LABEL_ID, ERROR_LOGIN_INVALID_PASSWORD_MSG,true);
		    		
		    		Reporter.logEvent(Status.INFO,"Step 5 -7: Enter valid  User name and invalid Password(1686) and click login :   "," Error message  display ",false);
		    		enterLoginDetails(sUserName, UserBaseTest.getParaValue("invalidPassWord2"));
		    		Mobile.verifyText(ERROR_LABEL_ID, ERROR_LOGIN_INVALID_PASSWORD_MSG,true);
		    		
		    		Reporter.logEvent(Status.INFO,"Step 8 -10:  Enter valid User name and invalid Password and click login ","Error message  display :"+ LoginPage.ERROR_LOGIN_EXCEEDED_MAX_TRIAL,false);
		    		enterLoginDetails(sUserName, UserBaseTest.getParaValue("invalidPassWord3"));
		    		Mobile.verifyText(ERROR_LABEL_ID, ERROR_LOGIN_EXCEEDED_MAX_TRIAL,false);		
		    		
		    		Reporter.logEvent(Status.INFO,"Step 11 -13:  Enter valid User name and valid Password and click login ","Error message  display :"+ LoginPage.ERROR_LOGIN_EXCEEDED_MAX_TRIAL,false);
		    		enterLoginDetails(sUserName, UserBaseTest.getParaValue("passWord"));
		    		Mobile.verifyText(ERROR_LABEL_ID, ERROR_LOGIN_EXCEEDED_MAX_TRIAL,false);
		    		 HomePage.selectMenuOption(DISCLOSURES);
		    		 Mobile.clickElement(MENULABEL);
		    		    Mobile.wait(3000);
		    		    Mobile.clickElement(LOG_IN);
		    		    Mobile.wait(3000);
		        }
		        

		    	public static void clickDeleteImage(String sLabel) {
		    		String sObj = "//*[@name='" + sLabel
		    				+ "']/preceding-sibling::XCUIElementTypeButton";
		    		Mobile.clickElement(sObj);

		    	}
		    	
		    	public void verify_Registration_Page(){
		    		
		    	}

}

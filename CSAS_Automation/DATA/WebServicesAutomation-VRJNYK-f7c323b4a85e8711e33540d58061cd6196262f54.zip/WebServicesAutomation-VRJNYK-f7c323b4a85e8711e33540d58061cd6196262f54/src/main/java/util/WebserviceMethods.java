package util;

import lib.Reporter;
import lib.Stock;

import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpGet;

import webservices.util.WebserviceUtil;

import com.aventstack.extentreports.Status;

public class WebserviceMethods {
	
	private final static String remove = "REMOVE";
	private final static String blank = "BLANK";
	String jsonRequestStringAuth = null;
	String jsonRequestString = null;
	String jsonResponseString = null;
	static String authCode;
	WebserviceUtil web;
	
	public static String formRequestURL(String baseURL, String...params)
	{
		String requestURL = baseURL;
		try
		{
			if(params.length>0)
			{
				for(String param : params)
				{
					if(!(param.contains(remove)||param.contains(blank)||param.contains("?")))
					{
						if(requestURL.endsWith("/")){
							requestURL = requestURL+param;}
						else if(requestURL.endsWith("&")){
							requestURL=requestURL+param;
						}
						else{
							requestURL = requestURL+"/"+param;
						}
					}
					if(param.contains(blank))
					{
						param = param.replace(blank, "");
						requestURL = requestURL+"/"+param+"/";
					}
					if(param.contains("?"))
					{
						if(requestURL.endsWith("/")){
							requestURL = requestURL.substring(0,requestURL.length()-1).trim();
						}
						requestURL = requestURL+param;
					}
				}
				if(requestURL.endsWith("/")){
					requestURL = requestURL.substring(0,requestURL.length()-1).trim();
				}
			}
			
			Reporter.logEvent(Status.INFO, "Request URL", requestURL, false);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return requestURL;
	}
	
	public String runGetService(String requestUrl,String authCode) throws Exception {
		// TODO Auto-generated method stub

		web=new WebserviceUtil();
		
		HttpGet httpGetReq = new HttpGet(requestUrl);
		httpGetReq.addHeader("Authorization", "JWT "+authCode);
		
		HttpResponse httpGetResp = web.getResponseasJsonforGet(httpGetReq);
		
		System.out.println(httpGetResp.toString());
		jsonResponseString = web.getHttpResponseAsString(httpGetResp);
		System.out.println(jsonResponseString);
		Reporter.logEvent(Status.INFO, "Response form Services ", jsonResponseString, false);
		
		if(httpGetResp.getStatusLine().getStatusCode() == Integer.parseInt(Stock.GetParameterValue("status")))
			Reporter.logEvent(Status.PASS, "Verify the Response status", "Response Code: "+Stock.GetParameterValue("status"), false);
		else
			Reporter.logEvent(Status.FAIL, "Verify the Response status", "NOT correct Response: Code!="+Stock.GetParameterValue("status"), false);
		
		if(httpGetResp.getStatusLine().getStatusCode()!=200)
		
			Reporter.logEvent(Status.INFO, "Verify the Exception message", "Exception Message: "+httpGetResp.getFirstHeader("exceptionMessage").getValue(), false);
			

		
		return jsonResponseString;
	}
}

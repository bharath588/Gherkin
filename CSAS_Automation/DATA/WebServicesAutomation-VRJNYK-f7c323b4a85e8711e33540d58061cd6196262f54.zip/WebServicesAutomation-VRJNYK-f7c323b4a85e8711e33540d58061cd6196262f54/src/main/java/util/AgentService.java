package util;

public class AgentService {
	String username;
	String password;
	String accuCode;
	String accuAccessTypeCode;
	
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getAccuCode() {
		return accuCode;
	}
	public void setAccuCode(String accuCode) {
		this.accuCode = accuCode;
	}
	public String getAccuAccessTypeCode() {
		return accuAccessTypeCode;
	}
	public void setAccuAccessTypeCode(String accuAccessTypeCode) {
		this.accuAccessTypeCode = accuAccessTypeCode;
	}
	
}

package util;

import lib.Reporter;

import org.apache.http.HttpResponse;


import webservices.util.JsonUtil;
import webservices.util.WebserviceUtil;

import com.aventstack.extentreports.Status;

public class AuthService {
	
	AgentService agntserv;
	String jsonRequestStringAuth = null;
	String jsonRequestString = null;
	String jsonResponseString = null;
	static String authCode;
	WebserviceUtil web = null;
	public String runAuthWebservice() throws Exception{
		// TODO Auto-generated method stub
		web = new WebserviceUtil();
		agntserv= new AgentService();
		agntserv.setUsername("100071382ABC");
		agntserv.setPassword("Test@1234");
		agntserv.setAccuCode("Empower");
		agntserv.setAccuAccessTypeCode("PPT_WEB");
		jsonRequestStringAuth = JsonUtil.writeToJson(agntserv);
		
//		8516-Proj-1
//		8517-Proj-2
//		8615-Proj-10
		HttpResponse httpResponseForAuth = web.getResponseasJsonforPostRequest(web.getAuthURL(), jsonRequestStringAuth);
		
		System.out.println(httpResponseForAuth.toString());
		authCode = httpResponseForAuth.getFirstHeader("Authorization").getValue();
		System.out.println("AuthCode: " + authCode);
		Reporter.logEvent(Status.PASS, "Verify Authentication Code", "Authentication code has generated successfully\n"
				+ "Authentication Code : " + authCode, false);
		return authCode;
	}

}

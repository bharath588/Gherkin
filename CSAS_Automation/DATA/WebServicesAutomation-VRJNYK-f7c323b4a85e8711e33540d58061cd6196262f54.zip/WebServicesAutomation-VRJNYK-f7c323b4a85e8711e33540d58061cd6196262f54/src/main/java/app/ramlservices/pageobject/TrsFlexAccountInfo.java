package app.ramlservices.pageobject;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;

import lib.DB;
import lib.Reporter;
import lib.Stock;
import util.CommonLib;
import app.webservice.pageobjects.JsonReadWriteUtils;

import com.aventstack.extentreports.Status;

public class TrsFlexAccountInfo {
	CommonLib utilities;
	ResultSet queryResultSet;

	/**
	 * Validate InvestmentSevice Details.
	 * 
	 * @throws SQLException
	 * @throws ParseException
	 */
	public void validateTrsFlexAccountDetailsForInst() throws SQLException,
			ParseException {
		utilities = new CommonLib();
		String responseString = utilities.getHttpResponseAsString();
		System.out.println("res is    " + responseString);
		Reporter.logEvent(Status.INFO, "The response", responseString, false);
		String query = Stock.getTestQuery("getTrsAccountDetailsForInst")[1];
		queryResultSet = DB.executeQuery(
				Stock.getTestQuery("getTrsAccountDetailsForInst")[0], query);
		verifyTrsFlexACcountDetails(queryResultSet, responseString);
		String gaServiceQuerey = Stock.getTestQuery("getGAServiceVODetails")[1];
		String parameter = Stock.GetParameterValue("GAIDParam");
		String gaServiceUpdatedQuerey = gaServiceQuerey.replace("?", parameter);
		queryResultSet = DB.executeQuery("TARGETDB", gaServiceUpdatedQuerey);
		verifyGAServiceVODetails(queryResultSet, responseString);

	}

	/**
	 * Validate InvestmentSevice Details.
	 * 
	 * @throws SQLException
	 * @throws ParseException
	 */
	public void validateTrsFlexAccountDetails() throws SQLException,
			ParseException {
		utilities = new CommonLib();
		String responseString = utilities.getHttpResponseAsString();
		System.out.println("res is    " + responseString);
		Reporter.logEvent(Status.INFO, "The response", responseString, false);
		String query = Stock.getTestQuery("getTrsAccountDetails")[1];
		queryResultSet = DB.executeQuery("TARGETDB", query);
		verifyTrsFlexACcountDetails(queryResultSet, responseString);
		String gaServiceQuerey = Stock.getTestQuery("getGAServiceVODetails")[1];
		String parameter = Stock.GetParameterValue("GAIDParam");
		String gaServiceUpdatedQuerey = gaServiceQuerey.replace("?", parameter);
		queryResultSet = DB.executeQuery("TARGETDB", gaServiceUpdatedQuerey);
		verifyGAServiceVODetails(queryResultSet, responseString);

	}

	public void verifyTrsFlexACcountDetails(ResultSet queryResultSet,
			String responseString) throws SQLException, ParseException {
		if (queryResultSet != null) {
			while (queryResultSet.next()) {
				String expectedINDID = queryResultSet.getString("INDID");
				String ActualInID = JsonReadWriteUtils.getNodeValueUsingJpath(
						responseString, "$..indId");
				JsonReadWriteUtils.compareValueAndLogReport(ActualInID,
						expectedINDID, "INDID");

				String ActualPeriodBeginDate = JsonReadWriteUtils
						.getNodeValueUsingJpath(responseString,
								"$..periodBeginDate");
				JsonReadWriteUtils.compareDbWithDateInResponse(
						ActualPeriodBeginDate,
						queryResultSet.getDate("PERIODBEGINDATE"),
						"PeriodBeginDate");

				String ActualPeriodEndDate = JsonReadWriteUtils
						.getNodeValueUsingJpath(responseString,
								"$..periodEndDate");
				JsonReadWriteUtils.compareDbWithDateInResponse(
						ActualPeriodEndDate,
						queryResultSet.getDate("PERIODENDDATE"),
						"PeriodEndDate");

				String expectedPeriodBeginBalance = queryResultSet
						.getString("PERIODBEGINBALANCE");
				String ActualPeriodBeginBalance = JsonReadWriteUtils
						.getNodeValueUsingJpath(responseString,
								"$..periodBeginBalance");
				JsonReadWriteUtils.compareValueAndLogReport(
						expectedPeriodBeginBalance, ActualPeriodBeginBalance,
						"PeriodBeginBalance");

				String expectedPeriodEndBalance = queryResultSet
						.getString("PERIODENDBALANCE");
				String ActualPeriodEndBalance = JsonReadWriteUtils
						.getNodeValueUsingJpath(responseString,
								"$..periodEndBalance");
				JsonReadWriteUtils.compareValueAndLogReport(
						expectedPeriodEndBalance, ActualPeriodEndBalance,
						"periodEndBalance");

				String expectedNormalRetirementDate = queryResultSet
						.getString("NORMALRETIREMENTDATE");
				String ActualNormalRetirementDate = JsonReadWriteUtils
						.getNodeValueUsingJpath(responseString,
								"$..normalRetirementDate");
				JsonReadWriteUtils.compareValueAndLogReport(
						expectedNormalRetirementDate,
						ActualNormalRetirementDate, "normalRetirementDate");

				String expectedEarlyRetirementDate = queryResultSet
						.getString("EARLYRETIREMENTDATE");
				String ActualEarlyRetirementDate = JsonReadWriteUtils
						.getNodeValueUsingJpath(responseString,
								"$..EarlyRetirementDate");
				JsonReadWriteUtils.compareValueAndLogReport(
						expectedEarlyRetirementDate, ActualEarlyRetirementDate,
						"EarlyRetirementDate");

				String expectedNormalRetirementDBAMT = queryResultSet
						.getString("NORMALRETIREMENTDBAMT");
				String ActualNormalRetirementDBAMT = JsonReadWriteUtils
						.getNodeValueUsingJpath(responseString,
								"$..normalRetirementDbAmount");
				JsonReadWriteUtils
						.compareValueAndLogReport(
								expectedNormalRetirementDBAMT,
								ActualNormalRetirementDBAMT,
								"NormalRetirementDbAmount");
				String expectedEarlyRetirementDBAMT = queryResultSet
						.getString("EARLYRETIREMENTDBAMT");
				String ActualEarlyRetirementDBAMT = JsonReadWriteUtils
						.getNodeValueUsingJpath(responseString,
								"$..EarlyRetirementDbAmount");
				JsonReadWriteUtils.compareValueAndLogReport(
						expectedEarlyRetirementDBAMT,
						ActualEarlyRetirementDBAMT, "EarlyRetirementDbAmount");

				String expectedAccruedBenefitAmount = queryResultSet
						.getString("ACCRUEDBENEFITAMT");
				String ActualAccruedBenefitAmount = JsonReadWriteUtils
						.getNodeValueUsingJpath(responseString,
								"$..AccruedBenefitAmount");
				JsonReadWriteUtils.compareValueAndLogReport(
						expectedAccruedBenefitAmount,
						ActualAccruedBenefitAmount, "AccruedBenefitAmount");

				String expectedVestedBalance = queryResultSet
						.getString("VESTEDBALANCE");
				String ActualVestedBalance = JsonReadWriteUtils
						.getNodeValueUsingJpath(responseString,
								"$..VestedBalance");
				JsonReadWriteUtils.compareValueAndLogReport(
						expectedVestedBalance, ActualVestedBalance,
						"VestedBalance");

				String expectedVestedPercentage = queryResultSet
						.getString("VESTEDPERCENTAGE");
				String ActualVestedPercentage = JsonReadWriteUtils
						.getNodeValueUsingJpath(responseString,
								"$..VestedPercentage");
				JsonReadWriteUtils.compareValueAndLogReport(
						expectedVestedPercentage, ActualVestedPercentage,
						"VestedPercentage");

				String expectedVestedAccruedBenfitAmount = queryResultSet
						.getString("VESTEDACCRUEDBENEFITAMT");
				String ActualVestedAccruedBenfitAmount = JsonReadWriteUtils
						.getNodeValueUsingJpath(responseString,
								"$..vestedAccruedBenefitAmount");
				JsonReadWriteUtils.compareValueAndLogReport(
						expectedVestedAccruedBenfitAmount,
						ActualVestedAccruedBenfitAmount,
						"vestedAccruedBenefitAmount");

				String expectedYearsOfService = queryResultSet
						.getString("YEARSOFSERVICE");
				String ActualYearsOfService = JsonReadWriteUtils
						.getNodeValueUsingJpath(responseString,
								"$..YearsOfService");
				JsonReadWriteUtils.compareValueAndLogReport(
						expectedYearsOfService, ActualYearsOfService,
						"YearsOfService");

				String expectedFinalAveragePay = queryResultSet
						.getString("FINALAVERAGEPAY");
				String ActualFinalAveragePay = JsonReadWriteUtils
						.getNodeValueUsingJpath(responseString,
								"$..finalAveragePay");
				JsonReadWriteUtils.compareValueAndLogReport(
						expectedFinalAveragePay, ActualFinalAveragePay,
						"finalAveragePay");

				String expectedCostOfLivingAdjustedPercentage = queryResultSet
						.getString("COSTOFLIVINGADJPCT");
				String ActualCostOfLivingAdjustedPercentage = JsonReadWriteUtils
						.getNodeValueUsingJpath(responseString,
								"$..costOfLivingAdjustedPercentage");
				JsonReadWriteUtils.compareValueAndLogReport(
						expectedCostOfLivingAdjustedPercentage,
						ActualCostOfLivingAdjustedPercentage,
						"costOfLivingAdjustedPercentage");

				String expectedtotalInPeriodCreditAmount = queryResultSet
						.getString("TOTALINPERIODCREDITAMT");
				String ActualtotalInPeriodCreditAmount = JsonReadWriteUtils
						.getNodeValueUsingJpath(responseString,
								"$..totalInPeriodCreditAmount");
				JsonReadWriteUtils.compareValueAndLogReport(
						expectedtotalInPeriodCreditAmount,
						ActualtotalInPeriodCreditAmount,
						"totalInPeriodCreditAmount");

				String expectedtotalInPeriodDebitAmount = queryResultSet
						.getString("TOTALINPERIODDEBITAMT");
				String ActualtotalInPeriodDebitAmount = JsonReadWriteUtils
						.getNodeValueUsingJpath(responseString,
								"$..totalInPeriodDebitAmount");
				JsonReadWriteUtils.compareValueAndLogReport(
						expectedtotalInPeriodDebitAmount,
						ActualtotalInPeriodDebitAmount,
						"YearsOftotalInPeriodDebitAmountService");

				String expectedtotalInPeriodAdjustedAmount = queryResultSet
						.getString("TOTALINPERIODADJAMT");
				String ActualtotalInPeriodAdjustedAmount = JsonReadWriteUtils
						.getNodeValueUsingJpath(responseString,
								"$..totalInPeriodAdjustedAmount");
				JsonReadWriteUtils.compareValueAndLogReport(
						expectedtotalInPeriodAdjustedAmount,
						ActualtotalInPeriodAdjustedAmount,
						"totalInPeriodAdjustedAmount");

				String expectedplanInterestRate = queryResultSet
						.getString("PLANINTERESTRATE");
				String ActualplanInterestRate = JsonReadWriteUtils
						.getNodeValueUsingJpath(responseString,
								"$..planInterestRate");
				JsonReadWriteUtils.compareValueAndLogReport(
						expectedplanInterestRate, ActualplanInterestRate,
						"planInterestRate");

				String expectedpayCreditRate = queryResultSet
						.getString("PAYCREDITRATE");
				String ActualpayCreditRate = JsonReadWriteUtils
						.getNodeValueUsingJpath(responseString,
								"$..payCreditRate");
				JsonReadWriteUtils.compareValueAndLogReport(
						expectedpayCreditRate, ActualpayCreditRate,
						"payCreditRate");

				String expectedfutureBalanceFreezeDate = queryResultSet
						.getString("FUTUREBALANCEFREEZEDATE");
				String ActualfutureBalanceFreezeDate = JsonReadWriteUtils
						.getNodeValueUsingJpath(responseString,
								"$..futureBalanceFreezeDate");
				JsonReadWriteUtils.compareValueAndLogReport(
						expectedfutureBalanceFreezeDate,
						ActualfutureBalanceFreezeDate,
						"futureBalanceFreezeDate");

				String expectedemployeeEndBalance = queryResultSet
						.getString("EMPLOYEEENDBALANCE");
				String ActualemployeeEndBalance = JsonReadWriteUtils
						.getNodeValueUsingJpath(responseString,
								"$..employeeEndBalance");
				JsonReadWriteUtils.compareValueAndLogReport(
						expectedemployeeEndBalance, ActualemployeeEndBalance,
						"employeeEndBalance");

				String expectedemployerEndBalance = queryResultSet
						.getString("EMPLOYERENDBALANCE");
				String ActualemployerEndBalance = JsonReadWriteUtils
						.getNodeValueUsingJpath(responseString,
								"$..employerEndBalance");
				JsonReadWriteUtils.compareValueAndLogReport(
						expectedemployerEndBalance, ActualemployerEndBalance,
						"employerEndBalance");

				String expectedperiodEndTotalShares = queryResultSet
						.getString("PERIODENDTOTALSHARES");
				String ActualperiodEndTotalShares = JsonReadWriteUtils
						.getNodeValueUsingJpath(responseString,
								"$..periodEndTotalShares");
				JsonReadWriteUtils.compareValueAndLogReport(
						expectedperiodEndTotalShares,
						ActualperiodEndTotalShares, "periodEndTotalShares");

				String expectedperiodBeginTotalShares = queryResultSet
						.getString("PERIODBEGINSHAREPRICE");
				String ActualperiodBeginTotalShares = JsonReadWriteUtils
						.getNodeValueUsingJpath(responseString,
								"$..periodBeginSharePrice");
				JsonReadWriteUtils.compareValueAndLogReport(
						expectedperiodBeginTotalShares,
						ActualperiodBeginTotalShares, "periodBeginSharePrice");

				String expectedinvestmentBalance = queryResultSet
						.getString("INVESTMENTBALANCE");
				String ActualinvestmentBalance = JsonReadWriteUtils
						.getNodeValueUsingJpath(responseString,
								"$..investmentBalance");
				JsonReadWriteUtils.compareValueAndLogReport(
						expectedinvestmentBalance, ActualinvestmentBalance,
						"investmentBalance");

				String expectedliquidBalance = queryResultSet
						.getString("LIQUIDBALANCE");
				String ActualliquidBalance = JsonReadWriteUtils
						.getNodeValueUsingJpath(responseString,
								"$..liquidBalance");
				JsonReadWriteUtils.compareValueAndLogReport(
						expectedliquidBalance, ActualliquidBalance,
						"liquidBalance");

				String expectedannualContributionAmount = queryResultSet
						.getString("ANNUALCONTRIBAMT");
				String ActualannualContributionAmount = JsonReadWriteUtils
						.getNodeValueUsingJpath(responseString,
								"$..annualContributionAmount");
				JsonReadWriteUtils.compareValueAndLogReport(
						expectedannualContributionAmount,
						ActualannualContributionAmount,
						"annualContributionAmount");

				String expectedinvestmentNetAssumption = queryResultSet
						.getString("INVESTMENTNETASSUMPTION");
				String ActualinvestmentNetAssumption = JsonReadWriteUtils
						.getNodeValueUsingJpath(responseString,
								"$..investmentNetAssumption");
				JsonReadWriteUtils.compareValueAndLogReport(
						expectedinvestmentNetAssumption,
						ActualinvestmentNetAssumption,
						"investmentNetAssumption");

				String expectedtotalCompensationAmount = queryResultSet
						.getString("TOTALCOMPENSATIONAMT");
				String ActualtotalCompensationAmount = JsonReadWriteUtils
						.getNodeValueUsingJpath(responseString,
								"$..totalCompensationAmount");
				JsonReadWriteUtils.compareValueAndLogReport(
						expectedtotalCompensationAmount,
						ActualtotalCompensationAmount,
						"totalCompensationAmount");

				String expectedservicePoints = queryResultSet
						.getString("SERVICEPOINTS");
				String ActualservicePoints = JsonReadWriteUtils
						.getNodeValueUsingJpath(responseString,
								"$..servicePoints");
				JsonReadWriteUtils.compareValueAndLogReport(
						expectedservicePoints, ActualservicePoints,
						"servicePoints");

				String expectedaccruedCredits = queryResultSet
						.getString("ACCRUEDCREDITS");
				String ActualaccruedCredits = JsonReadWriteUtils
						.getNodeValueUsingJpath(responseString,
								"$..accruedCredits");
				JsonReadWriteUtils.compareValueAndLogReport(
						expectedaccruedCredits, ActualaccruedCredits,
						"accruedCredits");

				String expectedfeParticipatnCode = queryResultSet
						.getString("FEPARTICIPANTCODE");
				String ActualfeParticipatnCode = JsonReadWriteUtils
						.getNodeValueUsingJpath(responseString,
								"$..feParticipatnCode");
				JsonReadWriteUtils.compareValueAndLogReport(
						expectedfeParticipatnCode, ActualfeParticipatnCode,
						"feParticipatnCode");

				String expectedstatementEndDate = queryResultSet
						.getString("STATEMENTENDDATE");
				String ActualstatementEndDate = JsonReadWriteUtils
						.getNodeValueUsingJpath(responseString,
								"$..statementEndDate");
				JsonReadWriteUtils.compareValueAndLogReport(
						expectedstatementEndDate, ActualstatementEndDate,
						"statementEndDate");

				String expectedvendorPptStatusCode = queryResultSet
						.getString("VENDORPPTSTATUSCODE");
				String ActualvendorPptStatusCode = JsonReadWriteUtils
						.getNodeValueUsingJpath(responseString,
								"$..vendorPptStatusCode");
				JsonReadWriteUtils.compareValueAndLogReport(
						expectedvendorPptStatusCode, ActualvendorPptStatusCode,
						"vendorPptStatusCode");

				String expectedvendorParticipantId = queryResultSet
						.getString("VENDORPARTICIPANTID");
				String ActualvendorParticipantId = JsonReadWriteUtils
						.getNodeValueUsingJpath(responseString,
								"$..vendorParticipantId");
				JsonReadWriteUtils.compareValueAndLogReport(
						expectedvendorParticipantId, ActualvendorParticipantId,
						"vendorParticipantId");

				String expectedaccruedBenefitCurAge = queryResultSet
						.getString("ACCRUEDBENEFITCURAGE");
				String ActualaccruedBenefitCurAge = JsonReadWriteUtils
						.getNodeValueUsingJpath(responseString,
								"$..accruedBenefitCurAge");
				JsonReadWriteUtils.compareValueAndLogReport(
						expectedaccruedBenefitCurAge,
						ActualaccruedBenefitCurAge, "accruedBenefitCurAge");

				String expectedaccruedBenefitNrdAge = queryResultSet
						.getString("ACCRUEDBENEFITNRDAGE");
				String ActualaccruedBenefitNrdAge = JsonReadWriteUtils
						.getNodeValueUsingJpath(responseString,
								"$..accruedBenefitNrdAge");
				JsonReadWriteUtils.compareValueAndLogReport(
						expectedaccruedBenefitNrdAge,
						ActualaccruedBenefitNrdAge, "accruedBenefitNrdAge");

				String expectedimmediateAnnuity55Amt = queryResultSet
						.getString("IMMEDIATEANNUITY55AMT");
				String ActualimmediateAnnuity55Amt = JsonReadWriteUtils
						.getNodeValueUsingJpath(responseString,
								"$..immediateAnnuity55Amt");
				JsonReadWriteUtils.compareValueAndLogReport(
						expectedimmediateAnnuity55Amt,
						ActualimmediateAnnuity55Amt, "immediateAnnuity55Amt");

				String expectedimmediateAnnuity60Amt = queryResultSet
						.getString("IMMEDIATEANNUITY60AMT");
				String ActualimmediateAnnuity60Amt = JsonReadWriteUtils
						.getNodeValueUsingJpath(responseString,
								"$..immediateAnnuity60Amt");
				JsonReadWriteUtils.compareValueAndLogReport(
						expectedimmediateAnnuity60Amt,
						ActualimmediateAnnuity60Amt, "immediateAnnuity60Amt");

				String expectedimmediateAnnuity62Amt = queryResultSet
						.getString("IMMEDIATEANNUITY62AMT");
				String ActualimmediateAnnuity62Amt = JsonReadWriteUtils
						.getNodeValueUsingJpath(responseString,
								"$..immediateAnnuity62Amt");
				JsonReadWriteUtils.compareValueAndLogReport(
						expectedimmediateAnnuity62Amt,
						ActualimmediateAnnuity62Amt, "immediateAnnuity62Amt");

				String expectedimmediateAnnuity65Amt = queryResultSet
						.getString("IMMEDIATEANNUITY65AMT");
				String ActualimmediateAnnuity65Amt = JsonReadWriteUtils
						.getNodeValueUsingJpath(responseString,
								"$..immediateAnnuity65Amt");
				JsonReadWriteUtils.compareValueAndLogReport(
						expectedimmediateAnnuity65Amt,
						ActualimmediateAnnuity65Amt, "immediateAnnuity65Amt");

				String expectedimmediateAnnuity70Amt = queryResultSet
						.getString("IMMEDIATEANNUITY70AMT");
				String ActualimmediateAnnuity70Amt = JsonReadWriteUtils
						.getNodeValueUsingJpath(responseString,
								"$..immediateAnnuity70Amt");
				JsonReadWriteUtils.compareValueAndLogReport(
						expectedimmediateAnnuity70Amt,
						ActualimmediateAnnuity70Amt, "immediateAnnuity70Amt");

				String expectedaggrPriorYearSpend = queryResultSet
						.getString("AGGRPRIORYEARSPEND");
				String ActualaggrPriorYearSpend = JsonReadWriteUtils
						.getNodeValueUsingJpath(responseString,
								"$..aggrPriorYearSpend");
				JsonReadWriteUtils.compareValueAndLogReport(
						expectedaggrPriorYearSpend, ActualaggrPriorYearSpend,
						"aggrPriorYearSpend");

				String expectedinvestmentThreshold = queryResultSet
						.getString("INVESTMENTTHRESHOLD");
				String ActualinvestmentThreshold = JsonReadWriteUtils
						.getNodeValueUsingJpath(responseString,
								"$..investmentThreshold");
				JsonReadWriteUtils.compareValueAndLogReport(
						expectedinvestmentThreshold, ActualinvestmentThreshold,
						"investmentThreshold");

				String expectedmonthlyMaintFeeCharged = queryResultSet
						.getString("MONTHLYMAINTFEECHARGED");
				String ActualmonthlyMaintFeeCharged = JsonReadWriteUtils
						.getNodeValueUsingJpath(responseString,
								"$..monthlyMaintFeeCharged");
				JsonReadWriteUtils.compareValueAndLogReport(
						expectedmonthlyMaintFeeCharged,
						ActualmonthlyMaintFeeCharged, "monthlyMaintFeeCharged");

				String expectedhsaAcctStatus = queryResultSet
						.getString("HSAACCTSTATUS");
				String ActualhsaAcctStatus = JsonReadWriteUtils
						.getNodeValueUsingJpath(responseString,
								"$..hsaAcctStatus");
				JsonReadWriteUtils.compareValueAndLogReport(
						expectedhsaAcctStatus, ActualhsaAcctStatus,
						"hsaAcctStatus");

				String expectedhsaCoverageType = queryResultSet
						.getString("HSACOVERAGETYPE");
				String ActualhsaCoverageType = JsonReadWriteUtils
						.getNodeValueUsingJpath(responseString,
								"$..hsaCoverageType");
				JsonReadWriteUtils.compareValueAndLogReport(
						expectedhsaCoverageType, ActualhsaCoverageType,
						"hsaCoverageType");

				String expectedpartIndicDataChgStatus = queryResultSet
						.getString("PARTINDICDATACHGSTATUS");
				String ActualpartIndicDataChgStatus = JsonReadWriteUtils
						.getNodeValueUsingJpath(responseString,
								"$..partIndicDataChgStatus");
				JsonReadWriteUtils.compareValueAndLogReport(
						expectedpartIndicDataChgStatus,
						ActualpartIndicDataChgStatus, "partIndicDataChgStatus");

				String expectedaggrCurrentYearSpend = queryResultSet
						.getString("AGGRCURRENTYEARSPEND");
				String ActualaggrCurrentYearSpend = JsonReadWriteUtils
						.getNodeValueUsingJpath(responseString,
								"$..aggrCurrentYearSpend");
				JsonReadWriteUtils.compareValueAndLogReport(
						expectedaggrCurrentYearSpend,
						ActualaggrCurrentYearSpend, "aggrCurrentYearSpend");

			}
		}
	}

	public void verifyGAServiceVODetails(ResultSet queryResultSet,
			String responseString) throws SQLException, ParseException {
		if (queryResultSet != null) {
			queryResultSet.afterLast();
			while (queryResultSet.previous()) {
				String expectedSdsvCode = queryResultSet.getString("SDSVCODE");
				String actualSdsvCode = JsonReadWriteUtils
						.getNodeValueUsingJpath(responseString, "$..sdsvCode");
				JsonReadWriteUtils.compareValueAndLogReport(expectedSdsvCode,
						actualSdsvCode, "sdsvCode");

				String expectedsdsvSubcode = queryResultSet
						.getString("SDSVSUBCODE");
				String actualsdsvSubcode = JsonReadWriteUtils
						.getNodeValueUsingJpath(responseString,
								"$..sdsvSubcode");
				JsonReadWriteUtils.compareValueAndLogReport(
						expectedsdsvSubcode, actualsdsvSubcode, "sdsvSubcode");

				String expectedmethodCode = queryResultSet
						.getString("METHODCODE");
				String ActualmethodCode = JsonReadWriteUtils
						.getNodeValueUsingJpath(responseString, "$..methodCode");
				JsonReadWriteUtils.compareValueAndLogReport(expectedmethodCode,
						ActualmethodCode, "methodCode");

				String expectedgcsBasis = queryResultSet.getString("GCSBASIS");
				String ActualgcsBasis = JsonReadWriteUtils
						.getNodeValueUsingJpath(responseString, "$..gcsBasis");
				JsonReadWriteUtils.compareValueAndLogReport(expectedgcsBasis,
						ActualgcsBasis, "gcsBasis");

				String expectedgcsValue = queryResultSet.getString("GCSBASIS");
				String ActualgcsValue = JsonReadWriteUtils
						.getNodeValueUsingJpath(responseString, "$..gcsBasis");
				JsonReadWriteUtils.compareValueAndLogReport(expectedgcsValue,
						ActualgcsValue, "gcsValue");

				String expectedrecovId = queryResultSet.getString("RECOVID");
				String ActualrecovId = JsonReadWriteUtils
						.getNodeValueUsingJpath(responseString, "$..recovId");
				JsonReadWriteUtils.compareValueAndLogReport(expectedrecovId,
						ActualrecovId, "recovId");

				String Actualeffdate = JsonReadWriteUtils
						.getNodeValueUsingJpath(responseString, "$..effdate");
				JsonReadWriteUtils.compareDbWithDateInResponse(Actualeffdate,
						queryResultSet.getDate("EFFDATE"), "effdate");

				String expectedtermdate = queryResultSet.getString("TERMDATE");
				String Actualtermdate = JsonReadWriteUtils
						.getNodeValueUsingJpath(responseString, "$..termdate");
				JsonReadWriteUtils.compareValueAndLogReport(expectedtermdate,
						Actualtermdate, "termdate");

				String expectedcustomServiceId = queryResultSet
						.getString("CUSTOMSERVICEID");
				String ActualcustomServiceId = JsonReadWriteUtils
						.getNodeValueUsingJpath(responseString,
								"$..customServiceId");
				JsonReadWriteUtils.compareValueAndLogReport(
						expectedcustomServiceId, ActualcustomServiceId,
						"customServiceId");

				String expecteddescription = queryResultSet
						.getString("DESCRIPTION");
				String Actualdescription = JsonReadWriteUtils
						.getNodeValueUsingJpath(responseString,
								"$..description");
				JsonReadWriteUtils.compareValueAndLogReport(
						expecteddescription, Actualdescription, "description");

				String expecteddisplayOrder = queryResultSet
						.getString("DISPLAYORDER");
				String ActualdisplayOrder = JsonReadWriteUtils
						.getNodeValueUsingJpath(responseString,
								"$..displayOrder");
				JsonReadWriteUtils.compareValueAndLogReport(
						expecteddisplayOrder, ActualdisplayOrder,
						"displayOrder");
				break;

			}
		}
	}

}

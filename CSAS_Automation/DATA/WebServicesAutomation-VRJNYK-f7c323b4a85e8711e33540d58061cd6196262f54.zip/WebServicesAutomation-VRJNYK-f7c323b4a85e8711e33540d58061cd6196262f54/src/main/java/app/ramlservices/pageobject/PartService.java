package app.ramlservices.pageobject;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;

import lib.DB;
import lib.Reporter;
import lib.Stock;
import util.CommonLib;

import com.aventstack.extentreports.Status;

public class PartService {

	CommonLib utilities;
	ResultSet queryResultSet;

	/**
	 * Validate InvestmentSevice Details.
	 * 
	 * @throws SQLException
	 * @throws ParseException
	 */
	public void validateInvestmentServiceDetailsForStepInfoExist()
			throws SQLException, ParseException {
		utilities = new CommonLib();
		String responseString = utilities.getHttpResponseAsString();
		System.out.println("res is    " + responseString);
		Reporter.logEvent(Status.INFO, "The response", responseString, false);
		queryResultSet = getPartServiceTrueData();
		String investServiceValue = queryResultSet.getString(1);
		System.out.println("investServiceValue is ===== " + investServiceValue);

	}

	/**
	 * Validate InvestmentSevice Details.
	 * 
	 * @throws SQLException
	 * @throws ParseException
	 */
	public void validateInvestmentServiceDetailsForStepInfodoesNotExist()
			throws SQLException, ParseException {
		utilities = new CommonLib();
		String responseString = utilities.getHttpResponseAsString();
		System.out.println("res is    " + responseString);
		Reporter.logEvent(Status.INFO, "The response", responseString, false);
		queryResultSet = getPartServiceFalseData();
		String investServiceValue = queryResultSet.getString(1);
		System.out.println("investServiceValue is ===== " + investServiceValue);

	}

	public ResultSet getPartServiceTrueData() {
		String query = Stock.getTestQuery("FetchPartServiceTrueData")[1];
		String db = Stock.getTestQuery("FetchPartServiceTrueData")[0];
		String subIdParam = Stock.GetParameterValue("subIdParam");
		String subSubjectIdParam = Stock.GetParameterValue("subSubjectIdParam");
		String evtyCodeParam = Stock.GetParameterValue("evtyCodeParam");
		String sdtyCodeParam = Stock.GetParameterValue("sdtyCodeParam");
		String BeginDateParam = Stock.GetParameterValue("BeginDateParam");
		String EndDateParam = Stock.GetParameterValue("EndDateParam");
		String updatedFutureRateQuery = query.replace("?", subIdParam);
		updatedFutureRateQuery.replace("subSubjectId", subSubjectIdParam);
		updatedFutureRateQuery.replace("evtyCode", evtyCodeParam);
		updatedFutureRateQuery.replace("sdtyCode", sdtyCodeParam);
		updatedFutureRateQuery.replace("endDate", EndDateParam);
		updatedFutureRateQuery.replace("beginDate", BeginDateParam);
		return queryResultSet = DB.executeQuery(db, updatedFutureRateQuery);
	}

	public ResultSet getPartServiceFalseData() {
		String query = Stock.getTestQuery("FetchPartServicefalseData")[1];
		String db = Stock.getTestQuery("FetchPartServicefalseData")[0];
		String subIdParam = Stock.GetParameterValue("subIdParam");
		String subSubjectIdParam = Stock.GetParameterValue("subSubjectIdParam");
		String evtyCodeParam = Stock.GetParameterValue("evtyCodeParam");
		String sdtyCodeParam = Stock.GetParameterValue("sdtyCodeParam");
		String BeginDateParam = Stock.GetParameterValue("BeginDateParam");
		String EndDateParam = Stock.GetParameterValue("EndDateParam");
		String updatedFutureRateQuery = query.replace("?", subIdParam);
		updatedFutureRateQuery.replace("subSubjectId", subSubjectIdParam);
		updatedFutureRateQuery.replace("evtyCode", evtyCodeParam);
		updatedFutureRateQuery.replace("sdtyCode", sdtyCodeParam);
		updatedFutureRateQuery.replace("endDate", EndDateParam);
		updatedFutureRateQuery.replace("beginDate", BeginDateParam);
		return queryResultSet = DB.executeQuery(db, updatedFutureRateQuery);
	}

}

package app.webservice.pageobjects.pptenrollmentinfo;

import lib.Stock;

public class PptEnrollmentInfoValues {

	String annualSalary;
	String consent;
	String personalEmail;
	String workEmail;
	String emailPrimaryIndicator;
	String userName;
	String pin;
	String securityQuestion;
	String securityAnswer;
//	String challengeQuestionIdAnswerMap;
	
	ChallengeQuestionIdAnswerMap challengeQuestionIdAnswerMap;
	public ChallengeQuestionIdAnswerMap challengeQuestionIdAnswerMap() {
		return challengeQuestionIdAnswerMap;
	}
	public void setChallengeQuestionIdAnswerMap(
			ChallengeQuestionIdAnswerMap challengeQuestionIdAnswerMap) {
		this.challengeQuestionIdAnswerMap = challengeQuestionIdAnswerMap;
	}
	
	String loginPhrase;
	String loginImage;
	String ssnExtRsnCode;
	
	pptDocumentsSchemaConsentSets participantDocumentSchemaConsentSets;
	
	public pptDocumentsSchemaConsentSets getParticipantDocumentSchemaConsentSets() {
		return participantDocumentSchemaConsentSets;
	}
	public void setParticipantDocumentSchemaConsentSets(
			pptDocumentsSchemaConsentSets participantDocumentSchemaConsentSets) {
		this.participantDocumentSchemaConsentSets = participantDocumentSchemaConsentSets;
	}
	String gaId;
	String accessCustomizaionCode;
	String accessTypeCode;
	String gcsValue;
	String gcsBasis;
	String ssoToken;
	String ssnExistsStatus;
	String registrationStatus;
	String allowedToEnroll;
	String enrollmentType;
	String acxiomCheckFlag;
		
	PartAgrmtDTO partagrmtDTO;
	
	public PartAgrmtDTO getPartagrmtDTO() {
		return partagrmtDTO;
	}
	public void setPartagrmtDTO(PartAgrmtDTO partagrmtDTO) {
		this.partagrmtDTO = partagrmtDTO;
	}
	
	
	Individual individual;	
	public Individual getIndividual() {
		return individual;
	}
	public void setIndividual(Individual individual) {
		this.individual = individual;
	}
	
	Address address;
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
	
	
	Employment employment;
	public Employment getEmployment() {
		return employment;
	}
	public void setEmployment(Employment employment) {
		this.employment = employment;
	}
	
	
	IndEmails indEmails = new IndEmails();	
	public IndEmails getIndEmails() {
		return indEmails;
	}
	public void setIndEmails(IndEmails indEmails) {
		this.indEmails = indEmails;
	}
	
	
	String iraBrokerFundingDTO;
	String addressChangeable;
	String partAgreementExists;
	String usingAltAuth;
	
	public void setAnnualSalary(String annualSalary) {
		this.annualSalary = annualSalary;
	}
	public void setConsent(String consent) {
		this.consent = consent;
	}
	public void setPersonalEmail(String personalEmail) {
		this.personalEmail = personalEmail;
	}
	public void setWorkEmail(String workEmail) {
		this.workEmail = workEmail;
	}
	public void setEmailPrimaryIndicator(String emailPrimaryIndicator) {
		this.emailPrimaryIndicator = emailPrimaryIndicator;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public void setPin(String pin) {
		this.pin = pin;
	}
	public void setSecurityQuestion(String securityQuestion) {
		this.securityQuestion = securityQuestion;
	}
	public void setSecurityAnswer(String securityAnswer) {
		this.securityAnswer = securityAnswer;
	}
	public void setLoginPhrase(String loginPhrase) {
		this.loginPhrase = loginPhrase;
	}
	public void setLoginImage(String loginImage) {
		this.loginImage = loginImage;
	}
	public void setSsnExtRsnCode(String ssnExtRsnCode) {
		this.ssnExtRsnCode = ssnExtRsnCode;
	}
	public void setGaId(String gaId) {
		this.gaId = gaId;
	}
	public void setAccessCustomizaionCode(String accessCustomizaionCode) {
		this.accessCustomizaionCode = accessCustomizaionCode;
	}
	public void setAccessTypeCode(String accessTypeCode) {
		this.accessTypeCode = accessTypeCode;
	}
	public void setGcsValue(String gcsValue) {
		this.gcsValue = gcsValue;
	}
	public void setGcsBasis(String gcsBasis) {
		this.gcsBasis = gcsBasis;
	}
	public void setSsoToken(String ssoToken) {
		this.ssoToken = ssoToken;
	}
	public void setSsnExistsStatus(String ssnExistsStatus) {
		this.ssnExistsStatus = ssnExistsStatus;
	}
	public void setRegistrationStatus(String registrationStatus) {
		this.registrationStatus = registrationStatus;
	}
	public void setAllowedToEnroll(String allowedToEnroll) {
		this.allowedToEnroll = allowedToEnroll;
	}
	public void setEnrollmentType(String enrollmentType) {
		this.enrollmentType = enrollmentType;
	}
	public void setAcxiomCheckFlag(String acxiomCheckFlag) {
		this.acxiomCheckFlag = acxiomCheckFlag;
	}
	public void setIraBrokerFundingDTO(String iraBrokerFundingDTO) {
		this.iraBrokerFundingDTO = iraBrokerFundingDTO;
	}
	public void setAddressChangeable(String addressChangeable) {
		this.addressChangeable = addressChangeable;
	}
	public void setPartAgreementExists(String partAgreementExists) {
		this.partAgreementExists = partAgreementExists;
	}
	public void setUsingAltAuth(String usingAltAuth) {
		this.usingAltAuth = usingAltAuth;
	}

	
}

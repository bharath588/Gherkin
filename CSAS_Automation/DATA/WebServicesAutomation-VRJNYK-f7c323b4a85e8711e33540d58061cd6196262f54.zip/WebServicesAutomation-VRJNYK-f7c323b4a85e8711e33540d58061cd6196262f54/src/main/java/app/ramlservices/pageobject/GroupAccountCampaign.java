package app.ramlservices.pageobject;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import lib.DB;
import lib.Reporter;
import lib.Stock;
import app.webservice.pageobjects.JsonReadWriteUtils;

import com.aventstack.extentreports.Status;

import util.CommonLib;

public class GroupAccountCampaign {
	CommonLib utilities;
	ResultSet queryResultSet;
	
	/**
	 * Validate CampaignData service response string.
	 * @throws SQLException
	 */
	public void validateGroupACcountCampaignInfo() throws SQLException,ParseException {
		utilities = new CommonLib();
		String responseString = utilities.getHttpResponseAsString();
		System.out.println("res is    "+responseString);
		Reporter.logEvent(Status.INFO, "The response", responseString,false);
		utilities = new CommonLib();
		queryResultSet=DB.executeQuery(Stock.getTestQuery("fetchGroupAccountCampaignDetails")[0], Stock.getTestQuery("fetchGroupAccountCampaignDetails")[1]);
		virifyGroupACcountCampaignInfo(responseString,queryResultSet);
	}
		

	/**
	 * Validate CampaignData service response string.
	 * @throws SQLException
	 */
	public void virifyGroupACcountCampaignInfo(String responseString,ResultSet queryResultSet) throws SQLException,ParseException {
		
		while(queryResultSet.next()){
			Timestamp dpdateTime = queryResultSet.getTimestamp("GCEDPDATETIME");
			SimpleDateFormat sdf = new SimpleDateFormat("dd-MMM-yyyy HH:mm:ss");
			String dpDateTime  = sdf.format(dpdateTime);
			String expectedStatusCode = queryResultSet.getString("GCESTATUSCODE");
			//$..book[?(@.price==8.99),?(@.category=='fiction')]
			String actualCampaigngaId = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
					"$..[?(@.dpdateTime==\""+dpDateTime+"\" && @.statusCode==\""+expectedStatusCode+"\")]..gaId");
			String expectedCampaigngaId = queryResultSet.getString("GAID");
			JsonReadWriteUtils.compareValueAndLogReport(actualCampaigngaId, expectedCampaigngaId, "GAID");
			
			String actualCampaignContentCatCode = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
					"$..[?(@.dpdateTime==\""+dpDateTime+"\" && @.statusCode==\""+expectedStatusCode+"\")]..campaignContentCatCode");
			String expectedCampaignContentCatCode = queryResultSet.getString("CONTENTCATEGORYCODE");
			JsonReadWriteUtils.compareValueAndLogReport(actualCampaignContentCatCode, expectedCampaignContentCatCode, "ContentCatCode");
			
			String actualCampaignContentDescription = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
					"$..[?(@.dpdateTime==\""+dpDateTime+"\" && @.statusCode==\""+expectedStatusCode+"\")]..campaignContentDescription");
			String expectedCampaignContentDescription = queryResultSet.getString("CONTENTCATEGORYDESCR");
			JsonReadWriteUtils.compareValueAndLogReport(actualCampaignContentDescription, expectedCampaignContentDescription, "campaignContentCode");
			
			String actualStatusCode = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
					"$..[?(@.dpdateTime==\""+dpDateTime+"\" && @.statusCode==\""+expectedStatusCode+"\")]..statusCode");
			//String expectedStatusCode = queryResultSet.getString("GCESTATUSCODE");
			JsonReadWriteUtils.compareValueAndLogReport(actualStatusCode, expectedStatusCode, "StatusCode");
			
			String actualDefaultIndicator = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
					"$..[?(@.dpdateTime==\""+dpDateTime+"\" && @.statusCode==\""+expectedStatusCode+"\")]..defaultIndicator");
			String expectedDefaultIndicator = queryResultSet.getString("GCEDEFUALTINDICATOR");
			JsonReadWriteUtils.compareValueAndLogReport(actualDefaultIndicator, expectedDefaultIndicator, "DefaultIndicator");
			
			String actualDpdateTime = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
					"$..[?(@.dpdateTime==\""+dpDateTime+"\" && @.statusCode==\""+expectedStatusCode+"\")]..dpdateTime");
			JsonReadWriteUtils.compareTimestamp(actualDpdateTime, queryResultSet.getTimestamp("GCEDPDATETIME"), "DpdateTime");
			
			String actualEffDate = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
					"$..[?(@.dpdateTime==\""+dpDateTime+"\" && @.statusCode==\""+expectedStatusCode+"\")]..effDate");
			JsonReadWriteUtils.compareDbWithDateInResponse(actualEffDate,queryResultSet.getDate("GCEEFFDATE"), "effDate");
			
			String actualtermDate = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
					"$..[?(@.dpdateTime==\""+dpDateTime+"\" && @.statusCode==\""+expectedStatusCode+"\")]..termDate");
			JsonReadWriteUtils.compareDbWithDateInResponse(actualtermDate,queryResultSet.getDate("GCETERMDATE"), "termDate");
			
			String actualcampaignChangeReasonCode = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
					"$..[?(@.dpdateTime==\""+dpDateTime+"\" && @.statusCode==\""+expectedStatusCode+"\")]..campaignChangeReasonCode");
			String changeReasonCode =queryResultSet.getString("CHANGEREASONCODE");
			JsonReadWriteUtils.compareValueAndLogReport(actualcampaignChangeReasonCode, changeReasonCode, "campaignChangeReasonCode");
			
			String actualcampaignChangeDescription = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
					"$..[?(@.dpdateTime==\""+dpDateTime+"\" && @.statusCode==\""+expectedStatusCode+"\")]..campaignChangeDescription");
			String expectedcampaignChangeReasonCode = queryResultSet.getString("CHANGEREASONDESCR");
			JsonReadWriteUtils.compareValueAndLogReport(actualcampaignChangeDescription, expectedcampaignChangeReasonCode, "campaignChangeDescription");
			
			String actualchangedByUserLogonId = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
					"$..[?(@.dpdateTime==\""+dpDateTime+"\" && @.statusCode==\""+expectedStatusCode+"\")]..changedByUserLogonId");
			String expectedchangedByUserLogonId = queryResultSet.getString("GCEUSERLOGONID");
			JsonReadWriteUtils.compareValueAndLogReport(actualchangedByUserLogonId, expectedchangedByUserLogonId, "changedByUserLogonId");
			
			String actualrequestedByFirstName = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
					"$..[?(@.dpdateTime==\""+dpDateTime+"\" && @.statusCode==\""+expectedStatusCode+"\")]..requestedByFirstName");
			String expectedrequestedByFirstName = queryResultSet.getString("CSFIRSTNAME");
			JsonReadWriteUtils.compareValueAndLogReport(actualrequestedByFirstName, expectedrequestedByFirstName, "requestedByFirstName");
			
			String actualrequestedByLastName= JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
					"$..[?(@.dpdateTime==\""+dpDateTime+"\" && @.statusCode==\""+expectedStatusCode+"\")]..requestedByLastName");
			String expectedrequestedByLastName = queryResultSet.getString("CSLASTNAME");
			JsonReadWriteUtils.compareValueAndLogReport(actualrequestedByLastName, expectedrequestedByLastName, "requestedByLastName");
		}
		}
	
	/**
	 * Validate CampaignData service response string.
	 * @throws SQLException
	 */
	public void validateStatusOffGroupACcountCampaignInfo() throws SQLException,ParseException {
		utilities = new CommonLib();
		String responseString = utilities.getHttpResponseAsString();
		System.out.println("res is    "+responseString);
		Reporter.logEvent(Status.INFO, "The response", responseString,false);
		queryResultSet=DB.executeQuery(Stock.getTestQuery("fetchStatusOffGroupAccountCampaignDetails")[0], Stock.getTestQuery("fetchStatusOffGroupAccountCampaignDetails")[1]);
		virifyGroupACcountCampaignInfo(responseString, queryResultSet);
		}
	
	/**
	 * Validate CampaignData service response string.
	 * @throws SQLException
	 */
	public void validateStatusOffAndONGroupACcountCampaignInfo() throws SQLException,ParseException {
		utilities = new CommonLib();
		String responseString = utilities.getHttpResponseAsString();
		System.out.println("res is    "+responseString);
		Reporter.logEvent(Status.INFO, "The response", responseString,false);
		queryResultSet=DB.executeQuery(Stock.getTestQuery("fetchGroupAccountCampaignDetails")[0], Stock.getTestQuery("fetchGroupAccountCampaignDetails")[1]);
		virifyGroupACcountCampaignInfo(responseString,queryResultSet);
		queryResultSet=DB.executeQuery(Stock.getTestQuery("fetchStatusOffGroupAccountCampaignDetails")[0], Stock.getTestQuery("fetchStatusOffGroupAccountCampaignDetails")[1]);
		virifyGroupACcountCampaignInfo(responseString, queryResultSet);
		
		}
	
	
		/**
		 * Validate CampaignData service response string.
		 * @throws SQLException
		 *//*
		public void virifyStatusOffGroupACcountCampaignInfo(String responseString) throws SQLException,ParseException {
			queryResultSet=DB.executeQuery(Stock.getTestQuery("fetchStatusOffGroupAccountCampaignDetails")[0], Stock.getTestQuery("fetchStatusOffGroupAccountCampaignDetails")[1]);
			while(queryResultSet.next()){
				Timestamp dpdateTime = queryResultSet.getTimestamp("GCEDPDATETIME");
				SimpleDateFormat sdf = new SimpleDateFormat("dd-MMM-yyyy HH:mm:ss");
				String dpDateTime  = sdf.format(dpdateTime);
				String contentCategoryCode =queryResultSet.getString("CONTENTCATEGORYCODE");
				String actualCampaigngaId = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
						"$..[?(@.dpdateTime==\""+dpDateTime+"\" && @.statusCode==\""+expectedStatusCode+"\")]..gaId");
				String expectedCampaigngaId = queryResultSet.getString("GAID");
				JsonReadWriteUtils.compareValueAndLogReport(actualCampaigngaId, expectedCampaigngaId, "GAID");
				
				String actualCampaignContentCatCode = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
						"$..[?(@.dpdateTime==\""+dpDateTime+"\" && @.statusCode==\""+expectedStatusCode+"\")]..campaignContentCatCode");
				JsonReadWriteUtils.compareValueAndLogReport(actualCampaignContentCatCode, contentCategoryCode, "ContentCatCode");
				
				String actualCampaignContentDescription = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
						"$..[?(@.dpdateTime==\""+dpDateTime+"\" && @.statusCode==\""+expectedStatusCode+"\")]..campaignContentDescription");
				String expectedCampaignContentDescription = queryResultSet.getString("CONTENTCATEGORYDESCR");
				JsonReadWriteUtils.compareValueAndLogReport(actualCampaignContentDescription, expectedCampaignContentDescription, "campaignContentCode");
				
				String actualStatusCode = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
						"$..[?(@.dpdateTime==\""+dpDateTime+"\" && @.statusCode==\""+expectedStatusCode+"\")]..statusCode");
				String expectedStatusCode = queryResultSet.getString("GCESTATUSCODE");
				JsonReadWriteUtils.compareValueAndLogReport(actualStatusCode, expectedStatusCode, "StatusCode");
				
				String actualDefaultIndicator = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
						"$..[?(@.dpdateTime==\""+dpDateTime+"\" && @.statusCode==\""+expectedStatusCode+"\")]..defaultIndicator");
				String expectedDefaultIndicator = queryResultSet.getString("GCEDEFUALTINDICATOR");
				JsonReadWriteUtils.compareValueAndLogReport(actualDefaultIndicator, expectedDefaultIndicator, "DefaultIndicator");
				
				String actualDpdateTime = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
						"$..[?(@.dpdateTime==\""+dpDateTime+"\" && @.statusCode==\""+expectedStatusCode+"\")]..dpdateTime");
				JsonReadWriteUtils.compareTimestamp(actualDpdateTime, queryResultSet.getTimestamp("GCEDPDATETIME"), "DpdateTime");
				
				String actualEffDate = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
						"$..[?(@.dpdateTime==\""+dpDateTime+"\" && @.statusCode==\""+expectedStatusCode+"\")]..effDate");
				JsonReadWriteUtils.compareDbWithDateInResponse(actualEffDate,queryResultSet.getDate("GCEEFFDATE"), "effDate");
				
				String actualtermDate = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
						"$..[?(@.dpdateTime==\""+dpDateTime+"\" && @.statusCode==\""+expectedStatusCode+"\")]..termDate");
				JsonReadWriteUtils.compareDbWithDateInResponse(actualtermDate,queryResultSet.getDate("GCETERMDATE"), "termDate");
				
				String actualcampaignChangeReasonCode = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
						"$..[?(@.dpdateTime==\""+dpDateTime+"\" && @.statusCode==\""+expectedStatusCode+"\")]..campaignChangeReasonCode");
				String expectedcampaignChangeReasonCode =queryResultSet.getString("CHANGEREASONCODE");
				JsonReadWriteUtils.compareValueAndLogReport(actualcampaignChangeReasonCode, expectedcampaignChangeReasonCode, "campaignChangeReasonCode");
				
				String actualcampaignChangeDescription = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
						"$..[?(@.dpdateTime==\""+dpDateTime+"\" && @.statusCode==\""+expectedStatusCode+"\")]..campaignChangeDescription");
				String expectedcampaignChangeDescription = queryResultSet.getString("CHANGEREASONDESCR");
				JsonReadWriteUtils.compareValueAndLogReport(actualcampaignChangeDescription, expectedcampaignChangeDescription, "campaignChangeDescription");
				
				String actualchangedByUserLogonId = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
						"$..[?(@.dpdateTime==\""+dpDateTime+"\" && @.statusCode==\""+expectedStatusCode+"\")]..changedByUserLogonId");
				String expectedchangedByUserLogonId = queryResultSet.getString("GCEUSERLOGONID");
				JsonReadWriteUtils.compareValueAndLogReport(actualchangedByUserLogonId, expectedchangedByUserLogonId, "changedByUserLogonId");
				
				String actualrequestedByFirstName = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
						"$..[?(@.dpdateTime==\""+dpDateTime+"\" && @.statusCode==\""+expectedStatusCode+"\")]..requestedByFirstName");
				String expectedrequestedByFirstName = queryResultSet.getString("CSFIRSTNAME");
				JsonReadWriteUtils.compareValueAndLogReport(actualrequestedByFirstName, expectedrequestedByFirstName, "requestedByFirstName");
				
				String actualrequestedByLastName= JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
						"$..[?(@.dpdateTime==\""+dpDateTime+"\" && @.statusCode==\""+expectedStatusCode+"\")]..requestedByLastName");
				String expectedrequestedByLastName = queryResultSet.getString("CSLASTNAME");
				JsonReadWriteUtils.compareValueAndLogReport(actualrequestedByLastName, expectedrequestedByLastName, "requestedByLastName");
			}
	}*/
}

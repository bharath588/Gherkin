package app.practice;

import java.util.ArrayList;
import java.util.List;

import webservices.util.JsonUtil;

public class Impl {

	public static void main(String[] args) throws Exception {

		
		Clazz clz = new Clazz();
		clz.setAddress("Blr");
		clz.setClasName("LKG");

		Clazz clz1 = new Clazz();
		clz1.setAddress("CHn");
		clz1.setClasName("uKG");
		
		List<Clazz> classList = new ArrayList<>();
		classList.add(clz1);
		classList.add(clz);
		
		Department dept = new Department();
		dept.setDeptId(1);
		dept.setDeptName("CS");
		dept.setObjClass(classList);
		
		Student std = new Student();
		std.setId(12);
		std.setName("Sam");
		std.setDept(dept);
		
		
		String jsonString = JsonUtil.writeToJson(std);
		System.out.println(jsonString);
		
	}

}

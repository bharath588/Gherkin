package app.webservice.pageobjects.pptenrollmentinfo;

public class Address {

	String indId;
	String seqnbr;
	String effdate;
	String primaryResInd;
	String scndLineMailing;
	String firstLineMailing;
	String city;
	String zipCode;
	String stateCode;
	String country;
	String relIndId;
	String termDate;
	String defaultCode;
	String equifaxRequestDate;
	String restrcIndicator;
	String county;
	String mailHoldDate;
	String validationSourceCode;
	
	public void setIndId(String indId) {
		this.indId = indId;
	}
	public void setSeqnbr(String seqnbr) {
		this.seqnbr = seqnbr;
	}
	public void setEffdate(String effdate) {
		this.effdate = effdate;
	}
	public void setPrimaryResInd(String primaryResInd) {
		this.primaryResInd = primaryResInd;
	}
	public void setScndLineMailing(String scndLineMailing) {
		this.scndLineMailing = scndLineMailing;
	}
	public void setFirstLineMailing(String firstLineMailing) {
		this.firstLineMailing = firstLineMailing;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}
	public void setStateCode(String stateCode) {
		this.stateCode = stateCode;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public void setRelIndId(String relIndId) {
		this.relIndId = relIndId;
	}
	public void setTermDate(String termDate) {
		this.termDate = termDate;
	}
	public void setDefaultCode(String defaultCode) {
		this.defaultCode = defaultCode;
	}
	public void setEquifaxRequestDate(String equifaxRequestDate) {
		this.equifaxRequestDate = equifaxRequestDate;
	}
	public void setRestrcIndicator(String restrcIndicator) {
		this.restrcIndicator = restrcIndicator;
	}
	public void setCounty(String county) {
		this.county = county;
	}
	public void setMailHoldDate(String mailHoldDate) {
		this.mailHoldDate = mailHoldDate;
	}
	public void setValidationSourceCode(String validationSourceCode) {
		this.validationSourceCode = validationSourceCode;
	}
	
	
}

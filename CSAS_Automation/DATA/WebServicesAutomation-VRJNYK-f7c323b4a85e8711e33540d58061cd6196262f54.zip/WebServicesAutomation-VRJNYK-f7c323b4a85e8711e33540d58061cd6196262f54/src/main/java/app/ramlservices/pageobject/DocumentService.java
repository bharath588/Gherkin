package app.ramlservices.pageobject;

import java.sql.ResultSet;
import java.sql.SQLException;

import lib.DB;
import lib.Reporter;
import lib.Stock;
import app.webservice.pageobjects.JsonReadWriteUtils;

import com.aventstack.extentreports.Status;

import util.CommonLib;

public class DocumentService {
	CommonLib utilities;
	ResultSet queryResultSet;

	public void validateResponseDocumentLocationURL() throws SQLException {
		utilities = new CommonLib();
		String responseString = utilities.getHttpResponseAsString();
		System.out.println(responseString);
		Reporter.logEvent(Status.INFO, "The response", responseString, false);

		queryResultSet = DB.executeQuery(
				Stock.getTestQuery("fetchDocumentURL")[0],
				Stock.getTestQuery("fetchDocumentURL")[1]);
		while (queryResultSet.next()) {
			String docLoctionUrl = JsonReadWriteUtils.getNodeValueUsingJpath(
					responseString, "$..docLocationUrl");

			String expectedDocLocationUrl = queryResultSet
					.getString("LOCATION");
			JsonReadWriteUtils.compareValueAndLogReport(docLoctionUrl,
					expectedDocLocationUrl, "DocumentURL");
		}
	}

	public void validateDocumentLocationURL() throws SQLException {
		utilities = new CommonLib();
		String responseString = utilities.getHttpResponseAsString();
		System.out.println(responseString);
		Reporter.logEvent(Status.INFO, "The response", responseString, false);

		String docLoctionUrl = JsonReadWriteUtils.getNodeValueUsingJpath(
				responseString, "$..docLocationUrl");

		String expectedDocLocationUrl = Stock
				.GetParameterValue("docLocationUrl");
		JsonReadWriteUtils.compareValueAndLogReport(docLoctionUrl,
				expectedDocLocationUrl, "DocumentURL");
	}
}

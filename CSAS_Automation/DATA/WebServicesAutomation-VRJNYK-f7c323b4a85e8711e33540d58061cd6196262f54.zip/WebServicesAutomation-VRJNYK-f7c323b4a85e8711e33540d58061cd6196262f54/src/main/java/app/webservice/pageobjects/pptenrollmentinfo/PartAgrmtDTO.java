package app.webservice.pageobjects.pptenrollmentinfo;

public class PartAgrmtDTO {

	String gaId;
	String indId;
	String stmtProcCode;
	String effdate;
	String statusCode;
	String statusEffdate;
	String ownershipInd;
	String ownershipSettlmtDate;
	String paIndId;
	String paGaId;
	String pinAuthCode;
	String statusSubcode;
	String lastCntDate;
	String pinEffdate;
	String restrcCode;
	String firstContribDate;
	String stmtHoldReasonCode;
	String stmtHoldReasonNarrative;
	String stmtSystemRej;
	String stmtSystemRejDate;
	String stmtSystemRejOverride;
	String restrcNarrative;
	String appStateCode;
	String mdAgeRecalcCode;
	String mdGrandfatherAssetUsedCode;
	String mdBenefBirthDate;
	String mdBenefSpouseCode;
	String annuityCommDate;
	String extClientAcctNbr;
	String narrative;
	String mdGrandfatherMdib;
	String freeLookEndDate;
	String vestingHoldCode;
	String lastFullyVestCalcDate;
	String disabilityDate;
	String schwabPolicyId;
	String salesPersnId;
	String saleSourceCode;
	String appCompltnCode;
	String vestParticipationDate;
	String incompleteRelatedIndivCode;
	String prospectusCode;
	String mdApply75YearRuleInd;
	String mdBeneInd;
	String partCashHoldCode;
	String partDisbHoldCode;
	String partCashHoldNarrative;
	String statusChgDpdate;
	String takeoverTypeCode;
	String mdInitialFactor;
	String priorContractNbr;
	String lastPdiAddrUpdateEvId;
	String beneElectedCalcMthd;
	String beneElectedCalcMthdDate;
	String rmdBeginDate;
	String mergerDate;
	String mergerCode;
	String activeRmdDueInd;
	String qjsaRmdWaiverDate;
	String qjsaRmdWaiverSpouseDate;
	String deathIndicatorFlag;
	String erContributionServicePoint;
	String rowId;
	

	public void setBeneElectedCalcMthdDate(String beneElectedCalcMthdDate) {
		this.beneElectedCalcMthdDate = beneElectedCalcMthdDate;
	}
	public void setLastFullyVestCalcDate(String lastFullyVestCalcDate) {
		this.lastFullyVestCalcDate = lastFullyVestCalcDate;
	}
	public void setGaId(String gaId) {
		this.gaId = gaId;
	}
	public void setIndId(String indId) {
		this.indId = indId;
	}
	public void setStmtProcCode(String stmtProcCode) {
		this.stmtProcCode = stmtProcCode;
	}
	public void setEffdate(String effdate) {
		this.effdate = effdate;
	}
	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}
	public void setStatusEffdate(String statusEffdate) {
		this.statusEffdate = statusEffdate;
	}
	public void setOwnershipInd(String ownershipInd) {
		this.ownershipInd = ownershipInd;
	}
	public void setOwnershipSettlmtDate(String ownershipSettlmtDate) {
		this.ownershipSettlmtDate = ownershipSettlmtDate;
	}
	public void setPaIndId(String paIndId) {
		this.paIndId = paIndId;
	}
	public void setPaGaId(String paGaId) {
		this.paGaId = paGaId;
	}
	public void setPinAuthCode(String pinAuthCode) {
		this.pinAuthCode = pinAuthCode;
	}
	public void setStatusSubcode(String statusSubcode) {
		this.statusSubcode = statusSubcode;
	}
	public void setLastCntDate(String lastCntDate) {
		this.lastCntDate = lastCntDate;
	}
	public void setPinEffdate(String pinEffdate) {
		this.pinEffdate = pinEffdate;
	}
	public void setRestrcCode(String restrcCode) {
		this.restrcCode = restrcCode;
	}
	public void setFirstContribDate(String firstContribDate) {
		this.firstContribDate = firstContribDate;
	}
	public void setStmtHoldReasonCode(String stmtHoldReasonCode) {
		this.stmtHoldReasonCode = stmtHoldReasonCode;
	}
	public void setStmtHoldReasonNarrative(String stmtHoldReasonNarrative) {
		this.stmtHoldReasonNarrative = stmtHoldReasonNarrative;
	}
	public void setStmtSystemRej(String stmtSystemRej) {
		this.stmtSystemRej = stmtSystemRej;
	}
	public void setStmtSystemRejDate(String stmtSystemRejDate) {
		this.stmtSystemRejDate = stmtSystemRejDate;
	}
	public void setStmtSystemRejOverride(String stmtSystemRejOverride) {
		this.stmtSystemRejOverride = stmtSystemRejOverride;
	}
	public void setRestrcNarrative(String restrcNarrative) {
		this.restrcNarrative = restrcNarrative;
	}
	public void setAppStateCode(String appStateCode) {
		this.appStateCode = appStateCode;
	}
	public void setMdAgeRecalcCode(String mdAgeRecalcCode) {
		this.mdAgeRecalcCode = mdAgeRecalcCode;
	}
	public void setMdGrandfatherAssetUsedCode(String mdGrandfatherAssetUsedCode) {
		this.mdGrandfatherAssetUsedCode = mdGrandfatherAssetUsedCode;
	}
	public void setMdBenefBirthDate(String mdBenefBirthDate) {
		this.mdBenefBirthDate = mdBenefBirthDate;
	}
	public void setMdBenefSpouseCode(String mdBenefSpouseCode) {
		this.mdBenefSpouseCode = mdBenefSpouseCode;
	}
	public void setAnnuityCommDate(String annuityCommDate) {
		this.annuityCommDate = annuityCommDate;
	}
	public void setExtClientAcctNbr(String extClientAcctNbr) {
		this.extClientAcctNbr = extClientAcctNbr;
	}
	public void setNarrative(String narrative) {
		this.narrative = narrative;
	}
	public void setMdGrandfatherMdib(String mdGrandfatherMdib) {
		this.mdGrandfatherMdib = mdGrandfatherMdib;
	}
	public void setFreeLookEndDate(String freeLookEndDate) {
		this.freeLookEndDate = freeLookEndDate;
	}
	public void setVestingHoldCode(String vestingHoldCode) {
		this.vestingHoldCode = vestingHoldCode;
	}
	public void setDisabilityDate(String disabilityDate) {
		this.disabilityDate = disabilityDate;
	}
	public void setSchwabPolicyId(String schwabPolicyId) {
		this.schwabPolicyId = schwabPolicyId;
	}
	public void setSalesPersnId(String salesPersnId) {
		this.salesPersnId = salesPersnId;
	}
	public void setSaleSourceCode(String saleSourceCode) {
		this.saleSourceCode = saleSourceCode;
	}
	public void setAppCompltnCode(String appCompltnCode) {
		this.appCompltnCode = appCompltnCode;
	}
	public void setVestParticipationDate(String vestParticipationDate) {
		this.vestParticipationDate = vestParticipationDate;
	}
	public void setIncompleteRelatedIndivCode(String incompleteRelatedIndivCode) {
		this.incompleteRelatedIndivCode = incompleteRelatedIndivCode;
	}
	public void setProspectusCode(String prospectusCode) {
		this.prospectusCode = prospectusCode;
	}
	public void setMdApply75YearRuleInd(String mdApply75YearRuleInd) {
		this.mdApply75YearRuleInd = mdApply75YearRuleInd;
	}
	public void setMdBeneInd(String mdBeneInd) {
		this.mdBeneInd = mdBeneInd;
	}
	public void setPartCashHoldCode(String partCashHoldCode) {
		this.partCashHoldCode = partCashHoldCode;
	}
	public void setPartDisbHoldCode(String partDisbHoldCode) {
		this.partDisbHoldCode = partDisbHoldCode;
	}
	public void setPartCashHoldNarrative(String partCashHoldNarrative) {
		this.partCashHoldNarrative = partCashHoldNarrative;
	}
	public void setStatusChgDpdate(String statusChgDpdate) {
		this.statusChgDpdate = statusChgDpdate;
	}
	public void setTakeoverTypeCode(String takeoverTypeCode) {
		this.takeoverTypeCode = takeoverTypeCode;
	}
	public void setMdInitialFactor(String mdInitialFactor) {
		this.mdInitialFactor = mdInitialFactor;
	}
	public void setPriorContractNbr(String priorContractNbr) {
		this.priorContractNbr = priorContractNbr;
	}
	public void setLastPdiAddrUpdateEvId(String lastPdiAddrUpdateEvId) {
		this.lastPdiAddrUpdateEvId = lastPdiAddrUpdateEvId;
	}
	public void setBeneElectedCalcMthd(String beneElectedCalcMthd) {
		this.beneElectedCalcMthd = beneElectedCalcMthd;
	}
	public void setRmdBeginDate(String rmdBeginDate) {
		this.rmdBeginDate = rmdBeginDate;
	}
	public void setMergerDate(String mergerDate) {
		this.mergerDate = mergerDate;
	}
	public void setMergerCode(String mergerCode) {
		this.mergerCode = mergerCode;
	}
	public void setActiveRmdDueInd(String activeRmdDueInd) {
		this.activeRmdDueInd = activeRmdDueInd;
	}
	public void setQjsaRmdWaiverDate(String qjsaRmdWaiverDate) {
		this.qjsaRmdWaiverDate = qjsaRmdWaiverDate;
	}
	public void setQjsaRmdWaiverSpouseDate(String qjsaRmdWaiverSpouseDate) {
		this.qjsaRmdWaiverSpouseDate = qjsaRmdWaiverSpouseDate;
	}
	public void setDeathIndicatorFlag(String deathIndicatorFlag) {
		this.deathIndicatorFlag = deathIndicatorFlag;
	}
	public void setErContributionServicePoint(String erContributionServicePoint) {
		this.erContributionServicePoint = erContributionServicePoint;
	}
	public void setRowId(String rowId) {
		this.rowId = rowId;
	}
		
	
}

package app.webservice.pageobjects;

import java.util.List;
import java.util.Map;

public class JsonParser {

	String name;
	String id;
	String address;
	Map<String,Inner> innerObj;
	
	
	public Map<String,Inner> getInnerObj() {
		return innerObj;
	}
	public void setInnerObj(Map<String,Inner> innerObj) {
		this.innerObj = innerObj;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	
	
	public void addObj()
	{
		
	}
}

 class Inner{
	
	 String inName;
	 String inAddress;
	public String getInName() {
		return inName;
	}
	public void setInName(String inName) {
		this.inName = inName;
	}
	public String getInAddress() {
		return inAddress;
	}
	public void setInAddress(String inAddress) {
		this.inAddress = inAddress;
	}
	 
}
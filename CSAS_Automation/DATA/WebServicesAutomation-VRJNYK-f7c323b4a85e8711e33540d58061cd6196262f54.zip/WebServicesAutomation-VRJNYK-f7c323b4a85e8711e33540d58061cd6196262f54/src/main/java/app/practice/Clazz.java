package app.practice;

public class Clazz {

	
	String clasName;
	String address;
	public String getClasName() {
		return clasName;
	}
	public void setClasName(String clasName) {
		this.clasName = clasName;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}	
}

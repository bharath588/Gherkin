package app.webservice.pageobjects.pptenrollmentinfo;

public class IndEmails {

	String indId;
	String typeCode;
	String emailAddress;
	String effdate;
	String statusCode;
	String restricCode;
	String holdReasonCode;
	String termdate;
	String subTypeCode;
	
	public void setIndId(String indId) {
		this.indId = indId;
	}
	public void setTypeCode(String typeCode) {
		this.typeCode = typeCode;
	}
	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}
	public void setEffdate(String effdate) {
		this.effdate = effdate;
	}
	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}
	public void setRestricCode(String restricCode) {
		this.restricCode = restricCode;
	}
	public void setHoldReasonCode(String holdReasonCode) {
		this.holdReasonCode = holdReasonCode;
	}
	public void setTermdate(String termdate) {
		this.termdate = termdate;
	}
	public void setSubTypeCode(String subTypeCode) {
		this.subTypeCode = subTypeCode;
	}
}

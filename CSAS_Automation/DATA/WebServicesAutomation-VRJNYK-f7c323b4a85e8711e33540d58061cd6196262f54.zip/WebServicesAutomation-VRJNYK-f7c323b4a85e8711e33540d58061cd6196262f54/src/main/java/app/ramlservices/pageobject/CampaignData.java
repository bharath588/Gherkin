package app.ramlservices.pageobject;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import lib.DB;
import lib.Reporter;
import lib.Stock;
import util.CommonLib;
import app.webservice.pageobjects.JsonReadWriteUtils;
import com.aventstack.extentreports.Status;

public class CampaignData {
	CommonLib utilities;
	ResultSet queryResultSet;

	/**
	 * Validate Campaign type category response string.
	 * 
	 * @throws SQLException
	 */
	public void validateCampaignTypeCategoryData() throws SQLException,
			ParseException {
		utilities = new CommonLib();
		String responseString = utilities.getHttpResponseAsString();
		System.out.println("res is    " + responseString);
		Reporter.logEvent(Status.INFO, "The response", responseString, false);

		verifyCategoryData(responseString);
	}

	/**
	 * Validate Campaign type reason response string.
	 * 
	 * @throws SQLException
	 */
	public void validateCampaignTypeReasonData() throws SQLException,
			ParseException {
		utilities = new CommonLib();
		String responseString = utilities.getHttpResponseAsString();
		System.out.println("res is    " + responseString);
		Reporter.logEvent(Status.INFO, "The response", responseString, false);
		verifyReasonData(responseString);
	}

	/**
	 * Validate Campaign type category/reason service response string.
	 * 
	 * @throws SQLException
	 */
	public void validateCampaignTypeCategoryAndReasonData()
			throws SQLException, ParseException {
		utilities = new CommonLib();
		String responseString = utilities.getHttpResponseAsString();
		System.out.println("res is    " + responseString);
		Reporter.logEvent(Status.INFO, "The response", responseString, false);
		verifyReasonData(responseString);
		verifyCategoryData(responseString);
	}

	/**
	 * Verify Campaign type "REASON" data.
	 * 
	 * @param responseString
	 * @throws ParseException
	 * @throws SQLException
	 */
	private void verifyReasonData(String responseString) throws ParseException,
			SQLException {

		queryResultSet = DB.executeQuery(
				Stock.getTestQuery("fetchCampaignChangeReasonDetails")[0],
				Stock.getTestQuery("fetchCampaignChangeReasonDetails")[1]);
		while (queryResultSet.next()) {
			String code = queryResultSet.getString("CODE");
			if (code.equalsIgnoreCase("null")) {
				continue;
			}
			String actualCampaignContentCode = JsonReadWriteUtils
					.getNodeValueUsingJpath(responseString,
							"$..[?(@.campaignChangeCode==\"" + code
									+ "\")]..campaignChangeCode");
			JsonReadWriteUtils.compareValueAndLogReport(
					actualCampaignContentCode, code, "campaignContentCode");

			String actualCampaignContentDescription = JsonReadWriteUtils
					.getNodeValueUsingJpath(responseString,
							"$..[?(@.campaignChangeCode==\"" + code
									+ "\")]..campaignChangeDescription");
			String expectedCampaignContentDescription = queryResultSet
					.getString("DESCRIPTION");
			JsonReadWriteUtils.compareValueAndLogReport(
					actualCampaignContentDescription,
					expectedCampaignContentDescription, "campaignContentCode");

			String actualCampaignContentEffDate = JsonReadWriteUtils
					.getNodeValueUsingJpath(responseString,
							"$..[?(@.campaignChangeCode==\"" + code
									+ "\")]..campaignChangeEffDate");
			JsonReadWriteUtils
					.compareDbWithDateInResponse(actualCampaignContentEffDate,
							queryResultSet.getDate("EFFDATE"),
							"campaignContentEffDate");

			String actualCampaignContentTermDate = JsonReadWriteUtils
					.getNodeValueUsingJpath(responseString,
							"$..[?(@.campaignChangeCode==\"" + code
									+ "\")]..campaignChangeTermDate");
			JsonReadWriteUtils.compareDbWithDateInResponse(
					actualCampaignContentTermDate,
					queryResultSet.getDate("TERMDATE"),
					"campaignContentTermDate");

			String actualCampaignContentDpdateTime = JsonReadWriteUtils
					.getNodeValueUsingJpath(responseString,
							"$..[?(@.campaignChangeCode==\"" + code
									+ "\")]..campaignChangeDpdateTime");
			JsonReadWriteUtils.compareDbWithDateInResponse(
					actualCampaignContentDpdateTime,
					queryResultSet.getDate("DPDATE_TIME"),
					"campaignContentDpdateTime");
		}
	}

	/**
	 * Verify Campaign type "CATEGORY" data.
	 * 
	 * @param responseString
	 * @throws SQLException
	 * @throws ParseException
	 */
	private void verifyCategoryData(String responseString) throws SQLException,
			ParseException {
		queryResultSet = DB.executeQuery(
				Stock.getTestQuery("fetchCampaignContentCategoryDetails")[0],
				Stock.getTestQuery("fetchCampaignContentCategoryDetails")[1]);
		while (queryResultSet.next()) {
			String code = queryResultSet.getString("CODE");
			String actualCampaignContentCode = JsonReadWriteUtils
					.getNodeValueUsingJpath(responseString,
							"$..[?(@.campaignContentCode==\"" + code
									+ "\")]..campaignContentCode");
			JsonReadWriteUtils.compareValueAndLogReport(
					actualCampaignContentCode, code, "campaignContentCode");

			String actualCampaignContentDescription = JsonReadWriteUtils
					.getNodeValueUsingJpath(responseString,
							"$..[?(@.campaignContentCode==\"" + code
									+ "\")]..campaignContentDescription");
			String expectedCampaignContentDescription = queryResultSet
					.getString("DESCRIPTION");
			JsonReadWriteUtils.compareValueAndLogReport(
					actualCampaignContentDescription,
					expectedCampaignContentDescription, "campaignContentCode");

			String actualCampaignContentEffDate = JsonReadWriteUtils
					.getNodeValueUsingJpath(responseString,
							"$..[?(@.campaignContentCode==\"" + code
									+ "\")]..campaignContentEffDate");
			JsonReadWriteUtils
					.compareDbWithDateInResponse(actualCampaignContentEffDate,
							queryResultSet.getDate("EFFDATE"),
							"campaignContentEffDate");

			String actualCampaignContentTermDate = JsonReadWriteUtils
					.getNodeValueUsingJpath(responseString,
							"$..[?(@.campaignContentCode==\"" + code
									+ "\")]..campaignContentTermDate");
			JsonReadWriteUtils.compareDbWithDateInResponse(
					actualCampaignContentTermDate,
					queryResultSet.getDate("TERMDATE"),
					"campaignContentTermDate");

			String actualCampaignContentDpdateTime = JsonReadWriteUtils
					.getNodeValueUsingJpath(responseString,
							"$..[?(@.campaignContentCode==\"" + code
									+ "\")]..campaignContentDpdateTime");
			JsonReadWriteUtils.compareDbWithDateInResponse(
					actualCampaignContentDpdateTime,
					queryResultSet.getDate("DPDATE_TIME"),
					"campaignContentDpdateTime");
		}
	}
}

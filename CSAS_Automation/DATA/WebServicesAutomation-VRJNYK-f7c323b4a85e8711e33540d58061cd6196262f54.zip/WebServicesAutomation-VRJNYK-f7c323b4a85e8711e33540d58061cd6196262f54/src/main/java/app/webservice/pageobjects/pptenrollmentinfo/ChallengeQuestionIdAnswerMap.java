package app.webservice.pageobjects.pptenrollmentinfo;

public class ChallengeQuestionIdAnswerMap {

}

package app.webservice.pageobjects;

import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class MainCls {

	public static void main(String[] args) throws JsonProcessingException {

		Inner inner = new Inner();
		Inner inner1 = new Inner();
		Map<String,Inner> objList = new LinkedHashMap<>();
		inner.setInName("inName");
		inner.setInAddress("inAddress");
		JsonParser objParser = new JsonParser();
		
		
		inner1.setInAddress("addr2");
		inner1.setInName("inName2");
		objList.put("First",inner1);
		objList.put("Second",inner);
		objParser.setAddress("BLR");
		objParser.setId("Id");
		objParser.setName("Name");
		objParser.setInnerObj(objList);
		
		
		
		
		ObjectMapper mapper = new ObjectMapper();
		
		String jsonString = mapper.writeValueAsString(objParser);
		System.out.println(jsonString);

	}

}

/**
 * 
 */
package app.ramlservices.pageobject;

import java.sql.ResultSet;

import org.apache.commons.lang3.StringUtils;

import lib.DB;
import lib.Reporter;
import lib.Stock;
import app.webservice.pageobjects.JsonReadWriteUtils;

import com.aventstack.extentreports.Status;

import util.CommonLib;

/**
 * @author rvpndy
 *
 */
public class DocumentServices {

	CommonLib utilities;
	ResultSet queryResultSet;


	public void validateResponsBcom5419DocumentLocation(){
		try{
			utilities = new CommonLib();
			String responseString = utilities.getHttpResponseAsString();
			Reporter.logEvent(Status.INFO, "The response", responseString,
					false);
			String[]query = Stock.getTestQuery("getDocumentLocation");
			queryResultSet = DB.executeQuery(query[0], 
					query[1], Stock.GetParameterValue("DMTY_CODE"),
					Stock.GetParameterValue("DLR_CODE"));
			while(queryResultSet.next()){
				String docLocationUrl = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
						"$..docLocationUrl");
				
				String dbUrl = StringUtils.replace(queryResultSet.getString("LOCATION"), "<GA_ID>", Stock.GetParameterValue("docGaId"));
				JsonReadWriteUtils.compareValueAndLogReport(docLocationUrl, dbUrl, 
						"docLocationUrl");

			}
		}
		catch(Exception e){
			e.printStackTrace();
		}
	}

}

package app.webservice.pageobjects;

public class ParticipantTokens {

	String indId;
	String gaId;
	String ssn;
	String firstName;
	String lastName;
	String middleName;
	String birthDate;
	String statusCode;
	String statusSubCode;
	boolean primaryParticipant;
	boolean defaultPlan;
	String pinAuthCode;
	String dbname;

	public String getIndId() {
		return indId;
	}

	public void setIndId(String indId) {
		this.indId = indId;
	}

	public String getGaId() {
		return gaId;
	}

	public void setGaId(String gaId) {
		this.gaId = gaId;
	}

	public String getSsn() {
		return ssn;
	}

	public void setSsn(String ssn) {
		this.ssn = ssn;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getMiddleName() {
		return middleName;
	}

	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}

	public String getBirthDate() {
		return birthDate;
	}

	public void setBirthDate(String birthDate) {
		this.birthDate = birthDate;
	}

	public String getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}

	public String getStatusSubCode() {
		return statusSubCode;
	}

	public void setStatusSubCode(String statusSubCode) {
		this.statusSubCode = statusSubCode;
	}

	public boolean isPrimaryParticipant() {
		return primaryParticipant;
	}

	public void setPrimaryParticipant(boolean primaryParticipant) {
		this.primaryParticipant = primaryParticipant;
	}

	public boolean isDefaultPlan() {
		return defaultPlan;
	}

	public void setDefaultPlan(boolean defaultPlan) {
		this.defaultPlan = defaultPlan;
	}

	public String getPinAuthCode() {
		return pinAuthCode;
	}

	public void setPinAuthCode(String pinAuthCode) {
		this.pinAuthCode = pinAuthCode;
	}

	public String getDbname() {
		return dbname;
	}

	public void setDbname(String dbname) {
		this.dbname = dbname;
	}
}

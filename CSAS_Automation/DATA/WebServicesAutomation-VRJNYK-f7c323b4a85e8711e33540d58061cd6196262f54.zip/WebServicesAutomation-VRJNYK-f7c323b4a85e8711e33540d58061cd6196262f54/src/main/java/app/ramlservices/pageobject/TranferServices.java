package app.ramlservices.pageobject;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;

import lib.DB;
import lib.Reporter;
import lib.Stock;
import util.CommonLib;
import app.webservice.pageobjects.JsonReadWriteUtils;

import com.aventstack.extentreports.Status;

public class TranferServices {
	CommonLib utilities;
	ResultSet queryResultSet;

	/**
	 * Method to verify transfer service API response with database.
	 * 
	 * @throws SQLException
	 * @throws ParseException
	 */
	public void validateBCOM6130TranferServiceResponse() throws SQLException,
			ParseException {
		utilities = new CommonLib();
		String responseString = utilities.getHttpResponseAsString();
		System.out.println("RESPONSE IS    " + responseString);
		Reporter.logEvent(Status.INFO, "The response", responseString, false);

		String expectedId = Stock.GetParameterValue("id");
		String actualId = JsonReadWriteUtils.getNodeValueUsingJpath(
				responseString, "$..id");
		JsonReadWriteUtils.compareValueAndLogReport(actualId, expectedId, "ID");

		String expectedevId = Stock.GetParameterValue("evId");
		String actualevId = JsonReadWriteUtils.getNodeValueUsingJpath(
				responseString, "$..evId");
		JsonReadWriteUtils.compareValueAndLogReport(actualevId, expectedevId,
				"evId");

		String expectedtrfType = Stock.GetParameterValue("trfType");
		String actualtrfType = JsonReadWriteUtils.getNodeValueUsingJpath(
				responseString, "$..typeTrf.trfType");
		JsonReadWriteUtils.compareValueAndLogReport(actualtrfType,
				expectedtrfType, "trfType");

		String expectedTypeTrfVal = Stock.GetParameterValue("TypeTrfVal");
		String actualTypeTrfVal = JsonReadWriteUtils.getNodeValueUsingJpath(
				responseString, "$..typeTrf.val");
		JsonReadWriteUtils.compareValueAndLogReport(actualTypeTrfVal,
				expectedTypeTrfVal, "TypeTrfVal");

		String expectedparamsDiscriminatorTrfType = Stock
				.GetParameterValue("paramsDiscriminatorTrfType");
		String actualparamsDiscriminatorTrfType = JsonReadWriteUtils
				.getNodeValueUsingJpath(responseString,
						"$..params.discriminator.trfType");
		JsonReadWriteUtils.compareValueAndLogReport(
				actualparamsDiscriminatorTrfType,
				expectedparamsDiscriminatorTrfType,
				"paramsDiscriminatorTrfType");

		String expecteddescriptorDiscriminatorTrfVal = Stock
				.GetParameterValue("descriptorDiscriminatorTrfVal");
		String actualdescriptorDiscriminatorTrfVal = JsonReadWriteUtils
				.getNodeValueUsingJpath(responseString,
						"$..descriptor.discriminator.val");
		JsonReadWriteUtils.compareValueAndLogReport(
				actualdescriptorDiscriminatorTrfVal,
				expecteddescriptorDiscriminatorTrfVal,
				"descriptorDiscriminatorTrfVal ");

		String expecteddescriptorDiscriminatorTrfType = Stock
				.GetParameterValue("descriptorDiscriminatorTrfType");
		String actualdescriptorDiscriminatorTrfType = JsonReadWriteUtils
				.getNodeValueUsingJpath(responseString,
						"$..descriptor.discriminator.trfType");
		JsonReadWriteUtils.compareValueAndLogReport(
				actualdescriptorDiscriminatorTrfType,
				expecteddescriptorDiscriminatorTrfType,
				"descriptorDiscriminatorTrfType");

		String expectedreqAmount = Stock.GetParameterValue("reqAmount");
		String actualreqAmount = JsonReadWriteUtils.getNodeValueUsingJpath(
				responseString, "$..[?(@.val==\"" + expectedreqAmount
						+ "\")]..val");
		JsonReadWriteUtils.compareValueAndLogReport(actualreqAmount,
				expectedreqAmount, "reqAmount");

		String expectedvalgaid = Stock.GetParameterValue("valgaid");
		String actualvalgaid = JsonReadWriteUtils.getNodeValueUsingJpath(
				responseString, "$..params.val.gaId");
		JsonReadWriteUtils.compareValueAndLogReport(actualvalgaid,
				expectedvalgaid, "valgaid");

		String expectedvalindId = Stock.GetParameterValue("valindId");
		String actualvalindId = JsonReadWriteUtils.getNodeValueUsingJpath(
				responseString, "$..params.val.indId");
		JsonReadWriteUtils.compareValueAndLogReport(actualvalindId,
				expectedvalindId, "valindId ");

		String expectedtimeStamp = Stock.GetParameterValue("timeStamp");
		String actualtimeStamp = JsonReadWriteUtils.getNodeValueUsingJpath(
				responseString, "$..timeStamp");
		JsonReadWriteUtils.compareValueAndLogReport(actualtimeStamp,
				expectedtimeStamp, "timeStamp");
		String expectedeffDate = Stock.GetParameterValue("effDate");
		String actualeffDate = JsonReadWriteUtils.getNodeValueUsingJpath(
				responseString, "$..effDate");
		JsonReadWriteUtils.compareValueAndLogReport(actualeffDate,
				expectedeffDate, "effDate");

		String expectedtermDate = Stock.GetParameterValue("termDate");
		String actualtermDate = JsonReadWriteUtils.getNodeValueUsingJpath(
				responseString, "$..termDate");
		JsonReadWriteUtils.compareValueAndLogReport(actualtermDate,
				expectedtermDate, "termDate");

		String expectednextSchedTrfDate = Stock
				.GetParameterValue("nextSchedTrfDate");
		String actualnextSchedTrfDate = JsonReadWriteUtils
				.getNodeValueUsingJpath(responseString, "$..nextSchedTrfDate");
		JsonReadWriteUtils.compareValueAndLogReport(actualnextSchedTrfDate,
				expectednextSchedTrfDate, "nextSchedTrfDate");

		String expectedstatusCode = Stock.GetParameterValue("statusCode");
		String actualstatusCode = JsonReadWriteUtils.getNodeValueUsingJpath(
				responseString, "$..statusCode");
		JsonReadWriteUtils.compareValueAndLogReport(actualstatusCode,
				expectedstatusCode, "statusCode");

		String expectednbrOfPeriods = Stock.GetParameterValue("nbrOfPeriods");
		String actualnbrOfPeriods = JsonReadWriteUtils.getNodeValueUsingJpath(
				responseString, "$..nbrOfPeriods");
		JsonReadWriteUtils.compareValueAndLogReport(actualnbrOfPeriods,
				expectednbrOfPeriods, "nbrOfPeriods");

		String expectedperiodQual = Stock.GetParameterValue("periodQual");
		String actualperiodQual = JsonReadWriteUtils.getNodeValueUsingJpath(
				responseString, "$..periodQual");
		JsonReadWriteUtils.compareValueAndLogReport(actualperiodQual,
				expectedperiodQual, "periodQual");

		String expectedcurrentPeriodNbr = Stock
				.GetParameterValue("currentPeriodNbr");
		String actualcurrentPeriodNbr = JsonReadWriteUtils
				.getNodeValueUsingJpath(responseString, "$..currentPeriodNbr");
		JsonReadWriteUtils.compareValueAndLogReport(actualcurrentPeriodNbr,
				expectedcurrentPeriodNbr, "currentPeriodNbr");

		String expectedgaamModelNbr = Stock.GetParameterValue("gaamModelNbr");
		String actualgaamModelNbr = JsonReadWriteUtils.getNodeValueUsingJpath(
				responseString, "$..gaamModelNbr");
		JsonReadWriteUtils.compareValueAndLogReport(actualgaamModelNbr,
				expectedgaamModelNbr, "gaamModelNbr");

		String expectedsetNumber = Stock.GetParameterValue("setNumber");
		String actualsetNumber = JsonReadWriteUtils.getNodeValueUsingJpath(
				responseString, "$..setNumber");
		JsonReadWriteUtils.compareValueAndLogReport(actualsetNumber,
				expectedsetNumber, "setNumber");

		String expectedtmplSetNumber = Stock.GetParameterValue("tmplSetNumber");
		String actualtmplSetNumber = JsonReadWriteUtils.getNodeValueUsingJpath(
				responseString, "$..tmplSetNumber");
		JsonReadWriteUtils.compareValueAndLogReport(actualtmplSetNumber,
				expectedtmplSetNumber, "tmplSetNumber");

		String expectedsdmtCodeERB = Stock.GetParameterValue("sdmtCodeERB");
		String actualsdmtCodeERB = JsonReadWriteUtils.getNodeValueUsingJpath(
				responseString, "$..[?(@.sdmtCode==\"" + expectedsdmtCodeERB
						+ "\")]..sdmtCode");
		JsonReadWriteUtils.compareValueAndLogReport(actualsdmtCodeERB,
				expectedsdmtCodeERB, "sdmtCodeERB");

		String expectedsdmtCodeQPR = Stock.GetParameterValue("sdmtCodeQPR");
		String actualsdmtCodeQPR = JsonReadWriteUtils.getNodeValueUsingJpath(
				responseString, "$..[?(@.sdmtCode==\"" + expectedsdmtCodeQPR
						+ "\")]..sdmtCode");
		JsonReadWriteUtils.compareValueAndLogReport(actualsdmtCodeQPR,
				expectedsdmtCodeQPR, "sdmtCodeQPR");

		String expectedgdmtSeqnbr = Stock.GetParameterValue("gdmtSeqnbr");
		String actualgdmtSeqnbr = JsonReadWriteUtils.getNodeValueUsingJpath(
				responseString, "$..[?(@.gdmtSeqnbr==\"" + expectedgdmtSeqnbr
						+ "\")]..gdmtSeqnbr");
		JsonReadWriteUtils.compareValueAndLogReport(actualgdmtSeqnbr,
				expectedgdmtSeqnbr, "gdmtSeqnbr");

		String expectedgroupingCode = Stock.GetParameterValue("groupingCode");
		String actualgroupingCode = JsonReadWriteUtils.getNodeValueUsingJpath(
				responseString, "$..groupingCode");
		JsonReadWriteUtils.compareValueAndLogReport(actualgroupingCode,
				expectedgroupingCode, "groupingCode");

		String expectedsourceVal = Stock.GetParameterValue("sourceVal");
		String actualsourceVal = JsonReadWriteUtils.getNodeValueUsingJpath(
				responseString, "$..[?(@.val==\"" + expectedsourceVal
						+ "\")]..val");
		JsonReadWriteUtils.compareValueAndLogReport(actualsourceVal,
				expectedsourceVal, "sourceVal");

		String expectedtrfDenom = Stock.GetParameterValue("trfDenom");
		String actualtrfDenom = JsonReadWriteUtils.getNodeValueUsingJpath(
				responseString, "$..[?(@.trfDenom==\"" + expectedtrfDenom
						+ "\")]..trfDenom");
		JsonReadWriteUtils.compareValueAndLogReport(actualtrfDenom,
				expectedtrfDenom, "trfDenom");

		String expectedpcCode = Stock.GetParameterValue("pcCode");
		String actualpcCode = JsonReadWriteUtils.getNodeValueUsingJpath(
				responseString, "$..pcCode");
		JsonReadWriteUtils.compareValueAndLogReport(actualpcCode,
				expectedpcCode, "pcCode");

		String expectedsdioId = Stock.GetParameterValue("sdioId");
		String actualsdioId = JsonReadWriteUtils.getNodeValueUsingJpath(
				responseString, "$..[?(@.sdioId==\"" + expectedsdioId
						+ "\")]..sdioId");
		JsonReadWriteUtils.compareValueAndLogReport(actualsdioId,
				expectedsdioId, "sdioId");

		String expectedgaioQual = Stock.GetParameterValue("gaioQual");
		String actualgaioQual = JsonReadWriteUtils.getNodeValueUsingJpath(
				responseString, "$..gaioQual");
		JsonReadWriteUtils.compareValueAndLogReport(actualgaioQual,
				expectedgaioQual, "gaioQual");

		String expectedsdteLength = Stock.GetParameterValue("sdteLength");
		String actualsdteLength = JsonReadWriteUtils.getNodeValueUsingJpath(
				responseString, "$..sdteLength");
		JsonReadWriteUtils.compareValueAndLogReport(actualsdteLength,
				expectedsdteLength, "sdteLength");

		String expectedsdteLengthQual = Stock
				.GetParameterValue("sdteLengthQual");
		String actualsdteLengthQual = JsonReadWriteUtils
				.getNodeValueUsingJpath(responseString, "$..sdteLengthQual");
		JsonReadWriteUtils.compareValueAndLogReport(actualsdteLengthQual,
				expectedsdteLengthQual, "sdteLengthQual");

		String expectedfundLegalName = Stock.GetParameterValue("fundLegalName");
		String actualfundLegalName = JsonReadWriteUtils.getNodeValueUsingJpath(
				responseString, "$..fundLegalName");
		JsonReadWriteUtils.compareValueAndLogReport(actualfundLegalName,
				expectedfundLegalName, "fundLegalName");

		String expectedfundShortName = Stock.GetParameterValue("fundShortName");
		String actualfundShortName = JsonReadWriteUtils.getNodeValueUsingJpath(
				responseString, "$..fundShortName");
		JsonReadWriteUtils.compareValueAndLogReport(actualfundShortName,
				expectedfundShortName, "fundShortName");

		String expectedstdFundName = Stock.GetParameterValue("stdFundName");
		String actualstdFundName = JsonReadWriteUtils.getNodeValueUsingJpath(
				responseString, "$..stdFundName");
		JsonReadWriteUtils.compareValueAndLogReport(actualstdFundName,
				expectedstdFundName, "stdFundName");

		String expectedvaluationEffdate = Stock
				.GetParameterValue("valuationEffdate");
		String actualvaluationEffdate = JsonReadWriteUtils
				.getNodeValueUsingJpath(responseString, "$..valuationEffdate");
		JsonReadWriteUtils.compareValueAndLogReport(actualvaluationEffdate,
				expectedvaluationEffdate, "valuationEffdate");

		String expectedunitValue = Stock.GetParameterValue("unitValue");
		String actualunitValue = JsonReadWriteUtils.getNodeValueUsingJpath(
				responseString, "$..unitValue");
		JsonReadWriteUtils.compareValueAndLogReport(actualunitValue,
				expectedunitValue, "unitValue");

		String expectedunitsOwned = Stock.GetParameterValue("unitsOwned");
		String actualunitsOwned = JsonReadWriteUtils.getNodeValueUsingJpath(
				responseString, "$..unitsOwned");
		JsonReadWriteUtils.compareValueAndLogReport(actualunitsOwned,
				expectedunitsOwned, "unitsOwned");

		String expectedacctBalance = Stock.GetParameterValue("acctBalance");
		String actualacctBalance = JsonReadWriteUtils.getNodeValueUsingJpath(
				responseString, "$..acctBalance");
		JsonReadWriteUtils.compareValueAndLogReport(actualacctBalance,
				expectedacctBalance, "acctBalance");

		String expectedcategoryCode = Stock.GetParameterValue("categoryCode");
		String actualcategoryCode = JsonReadWriteUtils.getNodeValueUsingJpath(
				responseString, "$..categoryCode");
		JsonReadWriteUtils.compareValueAndLogReport(actualcategoryCode,
				expectedcategoryCode, "categoryCode");

		String expectedfundTypeCode = Stock.GetParameterValue("fundTypeCode");
		String actualfundTypeCode = JsonReadWriteUtils.getNodeValueUsingJpath(
				responseString, "$..fundTypeCode");
		JsonReadWriteUtils.compareValueAndLogReport(actualfundTypeCode,
				expectedfundTypeCode, "fundTypeCode");

		String expectedmoneyMarketInd = Stock
				.GetParameterValue("moneyMarketInd");
		String actualmoneyMarketInd = JsonReadWriteUtils
				.getNodeValueUsingJpath(responseString, "$..moneyMarketInd");
		JsonReadWriteUtils.compareValueAndLogReport(actualmoneyMarketInd,
				expectedmoneyMarketInd, "moneyMarketInd");

		String expectedioCode = Stock.GetParameterValue("ioCode");
		String actualioCode = JsonReadWriteUtils.getNodeValueUsingJpath(
				responseString, "$..ioCode");
		JsonReadWriteUtils.compareValueAndLogReport(actualioCode,
				expectedioCode, "ioCode");

		String expectedtmplElementNumber = Stock
				.GetParameterValue("tmplElementNumber");
		String actualtmplElementNumber = JsonReadWriteUtils
				.getNodeValueUsingJpath(responseString, "$..tmplElementNumber");
		JsonReadWriteUtils.compareValueAndLogReport(actualtmplElementNumber,
				expectedtmplElementNumber, "tmplElementNumber");

		String expectedreqAmountVal = Stock.GetParameterValue("reqAmountVal");
		String actualreqAmountVal = JsonReadWriteUtils.getNodeValueUsingJpath(
				responseString, "$..reqAmount.val");
		JsonReadWriteUtils.compareValueAndLogReport(actualreqAmountVal,
				expectedreqAmountVal, "reqAmountVal");

		String expectedlegalName = Stock.GetParameterValue("legalName");
		String actuallegalName = JsonReadWriteUtils.getNodeValueUsingJpath(
				responseString, "$..legalName");
		JsonReadWriteUtils.compareValueAndLogReport(actuallegalName,
				expectedlegalName, "legalName");

		String expectedshortName = Stock.GetParameterValue("shortName");
		String actualshortName = JsonReadWriteUtils.getNodeValueUsingJpath(
				responseString, "$..shortName");
		JsonReadWriteUtils.compareValueAndLogReport(actualshortName,
				expectedshortName, "shortName");

		String expecteddisplayOrder = Stock.GetParameterValue("displayOrder");
		String actualdisplayOrder = JsonReadWriteUtils.getNodeValueUsingJpath(
				responseString, "$..displayOrder");
		JsonReadWriteUtils.compareValueAndLogReport(actualdisplayOrder,
				expecteddisplayOrder, "displayOrder");

		String expectedsiPcCode = Stock.GetParameterValue("siPcCode");
		String actualsiPcCode = JsonReadWriteUtils.getNodeValueUsingJpath(
				responseString, "$..siPcCode");
		JsonReadWriteUtils.compareValueAndLogReport(actualsiPcCode,
				expectedsiPcCode, "siPcCode");

		String expectedsiStatusCode = Stock.GetParameterValue("siStatusCode");
		String actualsiStatusCode = JsonReadWriteUtils.getNodeValueUsingJpath(
				responseString, "$..siStatusCode");
		JsonReadWriteUtils.compareValueAndLogReport(actualsiStatusCode,
				expectedsiStatusCode, "siStatusCode");

		String expectedsiStatusEffdate = Stock
				.GetParameterValue("siStatusEffdate");
		String actualsiStatusEffdate = JsonReadWriteUtils
				.getNodeValueUsingJpath(responseString, "$..siStatusEffdate");
		JsonReadWriteUtils.compareValueAndLogReport(actualsiStatusEffdate,
				expectedsiStatusEffdate, "IsiStatusEffdateD");

		String expectedsiCategoryCode = Stock
				.GetParameterValue("siCategoryCode");
		String actualsiCategoryCode = JsonReadWriteUtils
				.getNodeValueUsingJpath(responseString, "$..siCategoryCode");
		JsonReadWriteUtils.compareValueAndLogReport(actualsiCategoryCode,
				expectedsiCategoryCode, "siCategoryCode");

		String expectedsiFundTypeCode = Stock
				.GetParameterValue("siFundTypeCode");
		String actualsiFundTypeCode = JsonReadWriteUtils
				.getNodeValueUsingJpath(responseString, "$..siFundTypeCode");
		JsonReadWriteUtils.compareValueAndLogReport(actualsiFundTypeCode,
				expectedsiFundTypeCode, "siFundTypeCode");

		String expectedsiMoneyMarketInd = Stock
				.GetParameterValue("siMoneyMarketInd");
		String actualsiMoneyMarketInd = JsonReadWriteUtils
				.getNodeValueUsingJpath(responseString, "$..siMoneyMarketInd");
		JsonReadWriteUtils.compareValueAndLogReport(actualsiMoneyMarketInd,
				expectedsiMoneyMarketInd, "siMoneyMarketInd");

		String expectedgiStatusCode = Stock.GetParameterValue("giStatusCode");
		String actualgiStatusCode = JsonReadWriteUtils.getNodeValueUsingJpath(
				responseString, "$..giStatusCode");
		JsonReadWriteUtils.compareValueAndLogReport(actualgiStatusCode,
				expectedgiStatusCode, "giStatusCode");

		String expectedgiStatusEffdate = Stock
				.GetParameterValue("giStatusEffdate");
		String actualgiStatusEffdate = JsonReadWriteUtils
				.getNodeValueUsingJpath(responseString, "$..giStatusEffdate");
		JsonReadWriteUtils.compareValueAndLogReport(actualgiStatusEffdate,
				expectedgiStatusEffdate, "giStatusEffdate");

		String expectedgiSubStatusCode = Stock
				.GetParameterValue("giSubStatusCode");
		String actualgiSubStatusCode = JsonReadWriteUtils
				.getNodeValueUsingJpath(responseString, "$..giSubStatusCode");
		JsonReadWriteUtils.compareValueAndLogReport(actualgiSubStatusCode,
				expectedgiSubStatusCode, "giSubStatusCode");

		String expectedgiRecKeepingLevelCode = Stock
				.GetParameterValue("giRecKeepingLevelCode");
		String actualgiRecKeepingLevelCode = JsonReadWriteUtils
				.getNodeValueUsingJpath(responseString,
						"$..giRecKeepingLevelCode");
		JsonReadWriteUtils.compareValueAndLogReport(
				actualgiRecKeepingLevelCode, expectedgiRecKeepingLevelCode,
				"giRecKeepingLevelCode");

		String expectedaiSdteLength = Stock.GetParameterValue("aiSdteLength");
		String actualaiSdteLength = JsonReadWriteUtils.getNodeValueUsingJpath(
				responseString, "$..aiSdteLength");
		JsonReadWriteUtils.compareValueAndLogReport(actualaiSdteLength,
				expectedaiSdteLength, "aiSdteLength");

		String expectedaiSdteLengthQual = Stock
				.GetParameterValue("aiSdteLengthQual");
		String actualaiSdteLengthQual = JsonReadWriteUtils
				.getNodeValueUsingJpath(responseString, "$..aiSdteLengthQual");
		JsonReadWriteUtils.compareValueAndLogReport(actualaiSdteLengthQual,
				expectedaiSdteLengthQual, "aiSdteLengthQual");

		String expectedaiSddetyCode = Stock.GetParameterValue("aiSddetyCode");
		String actualaiSddetyCode = JsonReadWriteUtils.getNodeValueUsingJpath(
				responseString, "$..aiSddetyCode");
		JsonReadWriteUtils.compareValueAndLogReport(actualaiSddetyCode,
				expectedaiSddetyCode, "aiSddetyCode");

		String expectedaiEffdate = Stock.GetParameterValue("aiEffdate");
		String actualaiEffdate = JsonReadWriteUtils.getNodeValueUsingJpath(
				responseString, "$..aiEffdate");
		JsonReadWriteUtils.compareValueAndLogReport(actualaiEffdate,
				expectedaiEffdate, "aiEffdate");

		String expectedaiTermdate = Stock.GetParameterValue("aiTermdate");
		String actualaiTermdate = JsonReadWriteUtils.getNodeValueUsingJpath(
				responseString, "$..aiTermdate");
		JsonReadWriteUtils.compareValueAndLogReport(actualaiTermdate,
				expectedaiTermdate, "aiTermdate");

		String expectedaiPartAllocnInd = Stock
				.GetParameterValue("aiPartAllocnInd");
		String actualaiPartAllocnInd = JsonReadWriteUtils
				.getNodeValueUsingJpath(responseString, "$..aiPartAllocnInd");
		JsonReadWriteUtils.compareValueAndLogReport(actualaiPartAllocnInd,
				expectedaiPartAllocnInd, "aiPartAllocnInd");

		String expectedprAnnuityCommInd = Stock
				.GetParameterValue("prAnnuityCommInd");
		String actualprAnnuityCommInd = JsonReadWriteUtils
				.getNodeValueUsingJpath(responseString, "$..prAnnuityCommInd");
		JsonReadWriteUtils.compareValueAndLogReport(actualprAnnuityCommInd,
				expectedprAnnuityCommInd, "prAnnuityCommInd");

		String expectedemptyioCode = Stock.GetParameterValue("emptyioCode");
		String actualemptyioCode = JsonReadWriteUtils.getNodeValueUsingJpath(
				responseString, "$..emptyioCode");
		JsonReadWriteUtils.compareValueAndLogReport(actualemptyioCode,
				expectedemptyioCode, "emptyioCode");

		String expectedfeeEffdate = Stock.GetParameterValue("feeEffdate");
		String actualfeeEffdate = JsonReadWriteUtils.getNodeValueUsingJpath(
				responseString, "$..feeEffdate");
		JsonReadWriteUtils.compareValueAndLogReport(actualfeeEffdate,
				expectedfeeEffdate, "feeEffdate");

		String expectedfeeTermDate = Stock.GetParameterValue("feeTermDate");
		String actualfeeTermDate = JsonReadWriteUtils.getNodeValueUsingJpath(
				responseString, "$..feeTermDate");
		JsonReadWriteUtils.compareValueAndLogReport(actualfeeTermDate,
				expectedfeeTermDate, "feeTermDate");

		String expectedfeePercent = Stock.GetParameterValue("feePercent");
		String actualfeePercent = JsonReadWriteUtils.getNodeValueUsingJpath(
				responseString, "$..feePercent");
		JsonReadWriteUtils.compareValueAndLogReport(actualfeePercent,
				expectedfeePercent, "feePercent");

		String expectedfeeMinHoldingDays = Stock
				.GetParameterValue("feeMinHoldingDays");
		String actualfeeMinHoldingDays = JsonReadWriteUtils
				.getNodeValueUsingJpath(responseString, "$..feeMinHoldingDays");
		JsonReadWriteUtils.compareValueAndLogReport(actualfeeMinHoldingDays,
				expectedfeeMinHoldingDays, "feeMinHoldingDays");

		String expectedfeeDeminAmount = Stock
				.GetParameterValue("feeDeminAmount");
		String actualfeeDeminAmount = JsonReadWriteUtils
				.getNodeValueUsingJpath(responseString, "$..feeDeminAmount");
		JsonReadWriteUtils.compareValueAndLogReport(actualfeeDeminAmount,
				expectedfeeDeminAmount, "feeDeminAmount");

		String expectedfeeTypeCode = Stock.GetParameterValue("feeTypeCode");
		String actualfeeTypeCode = JsonReadWriteUtils.getNodeValueUsingJpath(
				responseString, "$..feeTypeCode");
		JsonReadWriteUtils.compareValueAndLogReport(actualfeeTypeCode,
				expectedfeeTypeCode, "feeTypeCode");

		String expectedfeeStdRuleId = Stock.GetParameterValue("feeStdRuleId");
		String actualfeeStdRuleId = JsonReadWriteUtils.getNodeValueUsingJpath(
				responseString, "$..feeStdRuleId");
		JsonReadWriteUtils.compareValueAndLogReport(actualfeeStdRuleId,
				expectedfeeStdRuleId, "feeStdRuleId");

		String expectedfeeActivityType = Stock
				.GetParameterValue("feeActivityType");
		String actualfeeActivityType = JsonReadWriteUtils
				.getNodeValueUsingJpath(responseString, "$..feeActivityType");
		JsonReadWriteUtils.compareValueAndLogReport(actualfeeActivityType,
				expectedfeeActivityType, "feeActivityType");

		String expectedalongSideAssetModelInd = Stock
				.GetParameterValue("alongSideAssetModelInd");
		String actualalongSideAssetModelInd = JsonReadWriteUtils
				.getNodeValueUsingJpath(responseString,
						"$..alongSideAssetModelInd");
		JsonReadWriteUtils.compareValueAndLogReport(
				actualalongSideAssetModelInd, expectedalongSideAssetModelInd,
				"alongSideAssetModelInd");

		String expectedalongSideNonModelInd = Stock
				.GetParameterValue("alongSideNonModelInd");
		String actualalongSideNonModelInd = JsonReadWriteUtils
				.getNodeValueUsingJpath(responseString,
						"$..alongSideNonModelInd");
		JsonReadWriteUtils.compareValueAndLogReport(actualalongSideNonModelInd,
				expectedalongSideNonModelInd, "alongSideNonModelInd");

		String expectedemptystatusCode = Stock
				.GetParameterValue("emptystatusCode");
		String actualemptystatusCode = JsonReadWriteUtils
				.getNodeValueUsingJpath(responseString,
						"$..[?(@.statusCode ==\"" + expectedemptystatusCode
								+ "\")]..statusCode");
		JsonReadWriteUtils.compareValueAndLogReport(actualemptystatusCode,
				expectedemptystatusCode, "statusCode");

		String expectedemptyGaid = Stock.GetParameterValue("emptyGaid");
		String actualemptyGaid = JsonReadWriteUtils.getNodeValueUsingJpath(
				responseString, "$..[?(@.gaId ==\"" + expectedemptyGaid
						+ "\")]..gaId");
		JsonReadWriteUtils.compareValueAndLogReport(actualemptyGaid,
				expectedemptyGaid, "gaId");

		String expectedemptyIndId = Stock.GetParameterValue("emptyIndId");
		String actualemptyIndId = JsonReadWriteUtils.getNodeValueUsingJpath(
				responseString, "$..[?(@.indId ==\"" + expectedemptyIndId
						+ "\")]..indId");
		JsonReadWriteUtils.compareValueAndLogReport(actualemptyIndId,
				expectedemptyIndId, "indId");

	}

	/**
	 * Method t fetch transfer service data from DB and validate with API
	 * response.
	 * 
	 * @throws SQLException
	 * @throws ParseException
	 */
	public void validateTranferServiceResponse() throws SQLException,
			ParseException {
		utilities = new CommonLib();
		String responseString = utilities.getHttpResponseAsString();
		System.out.println("RESPONSE IS    " + responseString);
		Reporter.logEvent(Status.INFO, "The response", responseString, false);

		// Get trfCode from test data.
		String trfCode = Stock.GetParameterValue("TrfCode");

		// Get SQl resultset based on trfCode.
		if (trfCode == "AUTOBAL") {
			queryResultSet = DB.executeQuery(
					Stock.getTestQuery("fetchTranferServiceDetails")[0],
					Stock.getTestQuery("fetchTranferServiceDetails")[1]);
		} else if (trfCode == "REBAL") {
			queryResultSet = DB.executeQuery(
					Stock.getTestQuery("fetchReBalTranferServiceDetails")[0],
					Stock.getTestQuery("fetchReBalTranferServiceDetails")[1]);
		} else {
			queryResultSet = DB
					.executeQuery(
							Stock.getTestQuery("fetchEmptyTrfTranferServiceDetails")[0],
							Stock.getTestQuery("fetchEmptyTrfTranferServiceDetails")[1]);
		}

		while (queryResultSet.next()) {
			String trfDesc = queryResultSet.getString("DESCR");
			String actualevID = JsonReadWriteUtils.getNodeValueUsingJpath(
					responseString, "$..[?(@.trfDesc==\"" + trfDesc
							+ "\")]..evId");
			String expectedevID = queryResultSet.getString("EVID");
			JsonReadWriteUtils.compareValueAndLogReport(actualevID,
					expectedevID, "evID");

			String actualevtyCode = JsonReadWriteUtils.getNodeValueUsingJpath(
					responseString, "$..[?(@.trfDesc==\"" + trfDesc
							+ "\")]..evtyCode");
			String expectedeCode = queryResultSet.getString("EVTYCODE");
			JsonReadWriteUtils.compareValueAndLogReport(actualevtyCode,
					expectedeCode, "evtyCode");

			String actualmasterEvtyCode = JsonReadWriteUtils
					.getNodeValueUsingJpath(responseString,
							"$..[?(@.trfDesc==\"" + trfDesc
									+ "\")]..masterEvtyCode");
			String expectedmasterEvtyCode = queryResultSet
					.getString("MASTEREVTYCODE");
			JsonReadWriteUtils.compareValueAndLogReport(actualmasterEvtyCode,
					expectedmasterEvtyCode, "masterEvtyCode");

			String actualtrfTypeCode = JsonReadWriteUtils
					.getNodeValueUsingJpath(responseString,
							"$..[?(@.trfDesc==\"" + trfDesc
									+ "\")]..trfTypeCode");
			String expectedtrfTypeCode = queryResultSet
					.getString("TRFTYPECODE");
			JsonReadWriteUtils.compareValueAndLogReport(actualtrfTypeCode,
					expectedtrfTypeCode, "trfTypeCode");

			String actualtrfDesc = JsonReadWriteUtils.getNodeValueUsingJpath(
					responseString, "$..[?(@.trfDesc==\"" + trfDesc
							+ "\")]..trfDesc");
			JsonReadWriteUtils.compareValueAndLogReport(actualtrfDesc, trfDesc,
					"trfDesc");

			String actualstatusCode = JsonReadWriteUtils
					.getNodeValueUsingJpath(responseString,
							"$..[?(@.trfDesc==\"" + trfDesc
									+ "\")]..statusCode");
			String expectedestatusCode = queryResultSet.getString("STATUSCODE");
			JsonReadWriteUtils.compareValueAndLogReport(actualstatusCode,
					expectedestatusCode, "statusCode");

			String actualFreqCode = JsonReadWriteUtils.getNodeValueUsingJpath(
					responseString, "$..[?(@.trfDesc==\"" + trfDesc
							+ "\")]..freqCode");
			String expectedfreqCode = queryResultSet.getString("FREQCODE");
			JsonReadWriteUtils.compareValueAndLogReport(actualFreqCode,
					expectedfreqCode, "freqCode");

			String actualeffDate = JsonReadWriteUtils.getNodeValueUsingJpath(
					responseString, "$..[?(@.trfDesc==\"" + trfDesc
							+ "\")]..effDate");
			JsonReadWriteUtils.compareDbWithDateInResponse(actualeffDate,
					queryResultSet.getDate("EFFDATE"), "effDate");

			String actualtermDate = JsonReadWriteUtils.getNodeValueUsingJpath(
					responseString, "$..[?(@.trfDesc==\"" + trfDesc
							+ "\")]..termDate");
			JsonReadWriteUtils.compareDbWithDateInResponse(actualtermDate,
					queryResultSet.getDate("TERMDATE"), "termDate");

			String actualcancelStatus = JsonReadWriteUtils
					.getNodeValueUsingJpath(responseString,
							"$..[?(@.trfDesc==\"" + trfDesc
									+ "\")]..cancelStatus");
			String expectedcancelStatus = queryResultSet
					.getString("CANCELSTATUSCODE");
			JsonReadWriteUtils.compareValueAndLogReport(actualcancelStatus,
					expectedcancelStatus, "cancelStatus");

			String actualgroupingCode = JsonReadWriteUtils
					.getNodeValueUsingJpath(responseString,
							"$..[?(@.trfDesc==\"" + trfDesc
									+ "\")]..groupingCode");
			String expectedgroupingCode = queryResultSet
					.getString("GROUPINGCODE");
			JsonReadWriteUtils.compareValueAndLogReport(actualgroupingCode,
					expectedgroupingCode, "groupingCode");

		}
	}

}
package app.webservice.pageobjects;

import java.util.ArrayList;
public class Response {
	
	String username;
	String authCredentialsToken;
	boolean registrationUpdateRequired;
	String password;
	String accuCode;
	String accuAccessTypeCode;
	boolean changePasscodeRequired;
	boolean contactInfoUpdateRequired;
	String cusRegCode;
	String userId;
	boolean registrationRequired;
	String regId;
	ArrayList<ParticipantTokens> participantTokens;

	
	
	public String getusername() {
		return username;
	}

	public void setusername(String username) {
		this.username = username;
	}

	public String getAuthCredentialsToken() {
		return authCredentialsToken;
	}

	public void setAuthCredentialsToken(String authCredentialsToken) {
		this.authCredentialsToken = authCredentialsToken;
	}

	public boolean isRegistrationUpdateRequired() {
		return registrationUpdateRequired;
	}

	public void setRegistrationUpdateRequired(boolean registrationUpdateRequired) {
		this.registrationUpdateRequired = registrationUpdateRequired;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getAccuCode() {
		return accuCode;
	}

	public void setAccuCode(String accuCode) {
		this.accuCode = accuCode;
	}

	public String getAccuAccessTypeCode() {
		return accuAccessTypeCode;
	}

	public void setAccuAccessTypeCode(String accuAccessTypeCode) {
		this.accuAccessTypeCode = accuAccessTypeCode;
	}

	public boolean isChangePasscodeRequired() {
		return changePasscodeRequired;
	}

	public void setChangePasscodeRequired(boolean changePasscodeRequired) {
		this.changePasscodeRequired = changePasscodeRequired;
	}

	public boolean isContactInfoUpdateRequired() {
		return contactInfoUpdateRequired;
	}

	public void setContactInfoUpdateRequired(boolean contactInfoUpdateRequired) {
		this.contactInfoUpdateRequired = contactInfoUpdateRequired;
	}

	public String getCusRegCode() {
		return cusRegCode;
	}

	public void setCusRegCode(String cusRegCode) {
		this.cusRegCode = cusRegCode;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public boolean isRegistrationRequired() {
		return registrationRequired;
	}

	public void setRegistrationRequired(boolean registrationRequired) {
		this.registrationRequired = registrationRequired;
	}

	public String getRegId() {
		return regId;
	}

	public void setRegId(String regId) {
		this.regId = regId;
	}

	public ArrayList<ParticipantTokens> getParticipantTokens() {
		return participantTokens;
	}

	public void setParticipantTokens(
			ArrayList<ParticipantTokens> participantTokens) {
		this.participantTokens = participantTokens;
	}
}

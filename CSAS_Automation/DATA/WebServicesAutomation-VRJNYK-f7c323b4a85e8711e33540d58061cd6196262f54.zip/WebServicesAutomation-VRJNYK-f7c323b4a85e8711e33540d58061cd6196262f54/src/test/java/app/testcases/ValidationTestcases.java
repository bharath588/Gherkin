package app.testcases;
/*	package app.webservice.testcases;
	
	import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;
import java.lang.reflect.Method;
import java.net.URI;
import java.net.URLEncoder;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import lib.DB;
import lib.Reporter;

import com.aventstack.extentreports.*;

import lib.Stock;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;
import org.json.simple.JSONObject;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
	










import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;




import webservices.util.WebserviceUtil;

import com.fasterxml.jackson.databind.JsonNode;

import app.webservice.pageobjects.Attributes;
import app.webservice.pageobjects.Values;
import app.webservice.pageobjects.JsonUtil;
import app.webservice.pageobjects.ParticipantTokens;
import app.webservice.pageobjects.Response;
	
	
import app.webservice.pageobjects.XmlUtils;
import core.framework.Globals;
	
	public class ValidationTestcases {
	
		WebserviceUtil webserviceUtil;
		String url;
		String jsonRequestString;
		String jsonResponseString;
		ResultSet queryResultSet = null;
	
	
		private LinkedHashMap<Integer, Map<String, String>> testData = null;
		String tcName;
		private Response response;
	
	
		@BeforeClass
		public void InitTest() throws Exception {
			Stock.getParam(Globals.GC_TESTCONFIGLOC
					+ Globals.GC_CONFIGFILEANDSHEETNAME + ".xls");
		Reporter.initializeModule(this.getClass().getName());
	}
	
	
	@DataProvider
	public Object[][] setData(Method tc) throws Exception {
		prepTestData(tc);
		return Stock.setDataProvider(this.testData);
	}
	
	
	private void prepTestData(Method testCase) throws Exception {
		this.testData = Stock.getTestData(this.getClass().getPackage()
				.getName(), testCase.getName());
	}
	
	
	@Test(dataProvider = "setData")
	public void testRESTResponse(int itr, Map<String, String> testdata)
			throws NoSuchFieldException, SecurityException {
		webserviceUtil = new WebserviceUtil();
		try {
			Reporter.initializeReportForTC(itr,
					"Validating restful webservice");
			Response response = new Response();
			//ArrayList<ParticipantTokens> partList = new ArrayList<>();
			response.setusername(Stock.GetParameterValue("username"));
			response.setPassword(Stock.GetParameterValue("password"));
			response.setAccuCode(Stock.GetParameterValue("accuCode"));
			response.setAccuAccessTypeCode(Stock
					.GetParameterValue("accuAccesstypeCode"));
	
			//			ParticipantTokens part = new ParticipantTokens();
			//			part.setDbname(Stock.GetParameterValue("dbName"));
			//			part.setSsn(Stock.GetParameterValue("ssn"));
			//			part.setStatusSubCode(Stock.GetParameterValue("subCode"));
			//			partList.add(part);
			//	response.setParticipantTokens(partList);
			jsonRequestString = JsonUtil.writeToJson(response);
			
			Reporter.logEvent(Status.INFO, "Json request body", jsonRequestString, false);
			jsonResponseString= webserviceUtil.getHttpResponseAsString(webserviceUtil
					.getResponseasJsonforPostRequest(Stock.GetParameterValue("url"), jsonRequestString));
			JsonNode jsonNode = JsonUtil.convertJsonStringtoJsonNode(jsonResponseString);
			if((jsonNode.findValuesAsText("userName")).equals(Stock.GetParameterValue("username")))
					{
				Reporter.logEvent(Status.PASS, "Check the response", "THe response is as expected", false);
					}
	
		} catch (Exception e) {
			e.printStackTrace();
			Globals.exception = e;
			String errorMsg = e.getMessage();
			Reporter.logEvent(Status.FAIL, "A run time exception occured.",errorMsg,false);
		} catch (Error ae) {
			ae.printStackTrace();
			Globals.error = ae;
			String errorMsg = ae.getMessage();
			Reporter.logEvent(Status.FAIL, "Assertion Error Occured",
					errorMsg,false);
		} finally {
			try {
				Reporter.finalizeTCReport();
			} catch (Exception e1) {
				e1.printStackTrace();
			}
		}
	}
	
	//@Test
	//public void testRESTResponseXml()
	//{
	//	common = new Common();
	//	String xmlString = null;
	//	url = "http://fss-dapps1:8614/security/authenticate/participant?";
	//	try {
	//		String json = common.getHttpResponseAsString(common.getResponseasXml(url,xmlString));	
	//	} catch (ClientProtocolException e) {
	//		e.printStackTrace();
	//	} catch (IOException e) {
	//		e.printStackTrace();
	//	}
	//}
	@Test(dataProvider = "setData")
	public void testSOAPResponse(int itr, Map<String, String> testdata) throws ClientProtocolException, IOException
	{
		File xmlFile = new File("products.xml");
		Reader fileReader = new FileReader(xmlFile);
		BufferedReader bufReader = new BufferedReader(fileReader);
	
		StringBuilder sb = new StringBuilder();
		String line = bufReader.readLine();
		while( line != null){
			sb.append(line).append("\n");
			line = bufReader.readLine();
		}
		// Create a StringEntity for the SOAP XML.
		String body =sb.toString();
		StringEntity stringEntity = new StringEntity(body, "UTF-8");
		stringEntity.setChunked(true);
	
		// Request parameters and other properties.
		HttpPost httpPost = new HttpPost("http://fss-dmule1nb-esb:8080/bpi/service/SsgIpsProxyService");
		httpPost.setEntity(stringEntity);
		httpPost.addHeader("Accept", "text/xml");
		httpPost.addHeader("SOAPAction", "");
	
		// Execute and get the response.
			@SuppressWarnings({ "resource", "deprecation" })
			HttpClient httpClient = new DefaultHttpClient();
			HttpResponse response = httpClient.execute(httpPost);
			HttpEntity entity = response.getEntity();
	
			String strResponse = null;
			if (entity != null) {
				strResponse = EntityUtils.toString(entity);
			}
			System.out.println(strResponse);
		}

	@Test(dataProvider = "setData")
	public void testInterRESTResponse(int itr, Map<String, String> testdata)
			throws NoSuchFieldException, SecurityException {
		webserviceUtil = new WebserviceUtil();
		try {
			Reporter.initializeReportForTC(itr,
					Globals.GC_MANUAL_TC_NAME);
			Attributes reqAttributes = new Attributes();
			reqAttributes.setUsername(Stock.GetParameterValue("username"));
			reqAttributes.setPassword(Stock.GetParameterValue("password"));
			reqAttributes.setAccuCode(Stock.GetParameterValue("accuCode"));
			jsonRequestString = JsonUtil.writeToJson(reqAttributes);
			
			Reporter.logEvent(Status.INFO, "Request body of first response", jsonRequestString, false);
			
			HttpResponse resp = webserviceUtil
					.getResponseasJsonforPostRequest(Stock.GetParameterValue("url"), jsonRequestString);
			String authCode = resp.getFirstHeader("Authorization").getValue();
			
			
			Reporter.logEvent(Status.INFO, "The Auth code to be taken for second webservice header", 
					"The Auth code to be taken for second webservice header is" + authCode, false);
			
			//Second service
			Values value = new Values();
			value.setRvLowValue(Stock.GetParameterValue("rvLowValue"));
			jsonRequestString = JsonUtil.writeToJsonInclNull(value);
			
			Reporter.logEvent(Status.INFO, "Request body of second response", jsonRequestString, false);
			
			HttpPost httpReq = webserviceUtil.getPostRequest(Stock.GetParameterValue("url2"), jsonRequestString);
			httpReq.addHeader("Authorization", "JWT "+authCode);
			httpReq.addHeader("inDb", "isis");
			
			
			HttpResponse resp1 = webserviceUtil.getResponse(httpReq);
			
			
			Reporter.logEvent(Status.INFO, "Response form second webservice",resp1.toString(), false);
			
			if(resp1.getStatusLine().getStatusCode() == 200)
			{
			jsonResponseString= webserviceUtil.getHttpResponseAsString(resp1);
			if(!jsonResponseString.equals(null))
			{
			NodeList nl = XmlUtils.getXmlTagValues(jsonResponseString, "//referenceValuesDTO");
			Reporter.logEvent(Status.INFO, "Response form second webservice",jsonResponseString, false);
			for(int iCount=0;iCount<nl.getLength();iCount++)
			{
				Element houseHoldIdElement=(Element) nl.item(iCount);	
				houseHoldId=houseHoldIdElement.getElementsByTagName("HouseholdId").item(0).getTextContent();
			}
			
			Element houseHoldIdElement=(Element) nl.item(0);	
			String rvDomain = houseHoldIdElement.getElementsByTagName("rvDomain").item(0).getTextContent();
			String rvLowValue = houseHoldIdElement.getElementsByTagName("rvLowValue").item(0).getTextContent();
			String rvMeaning = houseHoldIdElement.getElementsByTagName("rvMeaning").item(0).getTextContent();
			String rvType = houseHoldIdElement.getElementsByTagName("rvType").item(0).getTextContent();
			String rv_Meaning = null;
			ResultSet rs = DB.executeQuery(Stock.getTestQuery("getISISValues")[0],Stock.getTestQuery("getISISValues")[1],
					rvLowValue,rvType,rvDomain);
			if(rs != null)
			{
				while(rs.next())
				{
					rv_Meaning = rs.getString("rv_meaning");
				}
			}
			if(rv_Meaning.equalsIgnoreCase(rvMeaning))
			{
				Reporter.logEvent(Status.PASS, "Verify the value in DB", "The value in DB ="+rv_Meaning  
						+ " & the value in response = "+ rvMeaning, false);
			}	
			}
			}
			System.out.println();
		} catch (Exception e) {
			e.printStackTrace();
			Globals.exception = e;
			String errorMsg = e.getMessage();
			Reporter.logEvent(Status.FAIL, "A run time exception occured.",errorMsg,false);
		} catch (Error ae) {
			ae.printStackTrace();
			Globals.error = ae;
			String errorMsg = ae.getMessage();
			Reporter.logEvent(Status.FAIL, "Assertion Error Occured",
					errorMsg,false);
		} finally {
			try {
				Reporter.finalizeTCReport();
			} catch (Exception e1) {
				e1.printStackTrace();
			}
		}
	}
	
	@Test(dataProvider = "setData")
	public void testgetIncomeData(int itr, Map<String, String> testdata)
			throws NoSuchFieldException, SecurityException {
	
		webserviceUtil = new WebserviceUtil();
		try {
			Reporter.initializeReportForTC(itr,"Validating restful webservice");			
			response = new Response();
			
			response.setusername(Stock.GetParameterValue("username"));
			response.setPassword(Stock.GetParameterValue("password"));
						
			jsonRequestString = JsonUtil.writeToJson(response);
						
			HttpResponse resp1 = webserviceUtil.getResponseasJsonforPostRequest(Stock.GetParameterValue("url1"), jsonRequestString);	
			System.out.println(resp1.toString());
			String authCode = resp1.getFirstHeader("Authorization").getValue();
			System.out.println("AuthCode: "+authCode);
			Reporter.logEvent(Status.PASS, "Running Authentication Service.","AuthCode: "+authCode,false);
			
			HttpGet httpget = new HttpGet(Stock.GetParameterValue("url2"));
			Reporter.logEvent(Status.PASS, "URL of the Service","URI: "+Stock.GetParameterValue("url2"),false);
			httpget.addHeader("Authorization", "JWT "+authCode);			
			
			HttpResponse resp2 = webserviceUtil.getResponseasJsonforGet(httpget);
			System.out.println(resp2);
			System.out.println("Status Code: "+resp2.getStatusLine().getStatusCode());
			if(resp2.getStatusLine().getStatusCode() == 200){
			Reporter.logEvent(Status.PASS, "Running Web Service to get Income Data ","Response: "+resp2,false);
			
			String responseString = webserviceUtil.getHttpResponseAsString(resp2);
			JsonNode jsonObj = JsonUtil.convertJsonStringtoJsonNode(responseString);
			System.out.println("From SERVICE: \tsalAmount: "+jsonObj.get("salAmt"));
			String[] jsonString = jsonObj.toString().split(",");
			Reporter.logEvent(Status.PASS, "Getting Response from Service","Response: "+Arrays.toString(jsonString),false);
			
			queryResultSet = DB.executeQuery(Stock.getTestQuery("fetchSalaryForWebServiceIncomeData")[0], Stock.getTestQuery("fetchSalaryForWebServiceIncomeData")[1],Stock.GetParameterValue("indId"));
			if(queryResultSet.next()){
			Reporter.logEvent(Status.PASS, "Validating from Database","IND_ID: "+queryResultSet.getString("ind_id")+
					"\nEFFDATE: "+queryResultSet.getString("EFFDATE")+
					"\nSALAMT: "+queryResultSet.getString("SAL_AMT")+
					"\nHIREDATE: "+queryResultSet.getString("HIRE_DATE"),false);
			}
			System.out.println("From DATABASE:\tSalAmt: "+queryResultSet.getString("sal_amt"));
			}
			else{
				Reporter.logEvent(Status.FAIL, "Running Web Service to get Income Data ","Response: "+resp2,false);
			}
		} catch (Exception e) {
			e.printStackTrace();
			Globals.exception = e;
			String errorMsg = e.getMessage();
			Reporter.logEvent(Status.FAIL, "A run time exception occured.",errorMsg,false);
		} catch (Error ae) {
			ae.printStackTrace();
			Globals.error = ae;
			String errorMsg = ae.getMessage();
			Reporter.logEvent(Status.FAIL, "Assertion Error Occured",
					errorMsg,false);
		} finally {
			try {
				Reporter.finalizeTCReport();
			} catch (Exception e1) {
				e1.printStackTrace();
			}
		}
	
			
	}
	
	@Test(dataProvider = "setData")
	public void testgetIncomeData_WhenInvalidValuePassed(int itr, Map<String, String> testdata)
			throws NoSuchFieldException, SecurityException {
		
		webserviceUtil = new WebserviceUtil();
		try {
			Reporter.initializeReportForTC(itr,"Validating Participant Services webservice");			
			response = new Response();
			
			response.setusername(Stock.GetParameterValue("username"));
			response.setPassword(Stock.GetParameterValue("password"));
						
			jsonRequestString = JsonUtil.writeToJson(response);
						
			HttpResponse resp1 = webserviceUtil.getResponseasJsonforPostRequest(Stock.GetParameterValue("url1"), jsonRequestString);	
			System.out.println(resp1.toString());
			String authCode = resp1.getFirstHeader("Authorization").getValue();
			System.out.println("AuthCode: "+authCode);
			Reporter.logEvent(Status.PASS, "Running Authentication Service.","AuthCode: "+authCode,false);
			
			HttpGet httpget = new HttpGet(Stock.GetParameterValue("url2"));			
			httpget.addHeader("Authorization", "JWT "+authCode);			
			Reporter.logEvent(Status.PASS, "URL of the Service","URI: "+Stock.GetParameterValue("url2"),false);
			
			HttpResponse resp2 = webserviceUtil.getResponseasJsonforGet(httpget);
			Reporter.logEvent(Status.PASS, "Running Web Service to get Income Data when Invalid value is passed.","Response: "+resp2,false);
			System.out.println(resp2);
			System.out.println("Status Code: "+resp2.getStatusLine().getStatusCode());
			
			if(resp2.getStatusLine().getStatusCode() == 400){
			Reporter.logEvent(Status.PASS, "Getting Status Code of Service","StatCode: "+resp2.getStatusLine().getStatusCode(),false);
			
			String responseString = webserviceUtil.getHttpResponseAsString(resp2);
			try{
			JsonNode jsonObj = JsonUtil.convertJsonStringtoJsonNode(responseString);
			}
			catch(Exception e){
				System.out.println(e);
				Reporter.logEvent(Status.PASS, "Getting the Response: ","Empty Response Validated\n"+ e,false);
			}
			}
			else{
				Reporter.logEvent(Status.FAIL, "Getting Status Code of Service","StatCode: "+resp2.getStatusLine().getStatusCode(),false);
			}
			} catch (Exception e) {
			e.printStackTrace();
			Globals.exception = e;
			String errorMsg = e.getMessage();
			Reporter.logEvent(Status.FAIL, "A run time exception occured.",errorMsg,false);
		} catch (Error ae) {
			ae.printStackTrace();
			Globals.error = ae;
			String errorMsg = ae.getMessage();
			Reporter.logEvent(Status.FAIL, "Assertion Error Occured",
					errorMsg,false);
		} finally {
			try {
				Reporter.finalizeTCReport();
			} catch (Exception e1) {
				e1.printStackTrace();
			}
		}
	
		
	}
	
	
	@Test(dataProvider = "setData")
	public void testgetIncomeData_WhenBlankValuePassed(int itr, Map<String, String> testdata)
			throws NoSuchFieldException, SecurityException {
	//	Scanner myscanner = new Scanner(System.in);
		webserviceUtil = new WebserviceUtil();
		
		try {
			Reporter.initializeReportForTC(itr,"Validating Participant Services webservice");			
			response = new Response();
			
			response.setusername(Stock.GetParameterValue("username"));
			response.setPassword(Stock.GetParameterValue("password"));
						
			jsonRequestString = JsonUtil.writeToJson(response);
			
			HttpResponse resp1 = webserviceUtil.getResponseasJsonforPostRequest(Stock.GetParameterValue("url1"), jsonRequestString);	
			System.out.println(resp1.toString());
			String authCode = resp1.getFirstHeader("Authorization").getValue();
			System.out.println("AuthCode: "+authCode);
			Reporter.logEvent(Status.PASS, "Running Authentication Service.","AuthCode: "+authCode,false);
			
			String url2 = Stock.GetParameterValue("url2");
			
			Pattern pattern = Pattern.compile("\\s");
			Matcher matcher = pattern.matcher(url2);
			boolean found = matcher.find();
			
			if(found){
				url2 = webserviceUtil.convertBlankSpacesToString(url2);
			}
			
		//	System.out.println("URL encoded -- " + url2);
			
			URI uri = new URI(url2);
			HttpGet httpget = new HttpGet("http://fss-dapps1:8516/participantComponents/rest/participantServices?db=%20&gaId=99537-01&indId=12147573/incomeData");
						
			httpget.addHeader("Authorization", "JWT "+authCode);
						
	//		Reporter.logEvent(Status.PASS, "URL of the Service","URI: "+url2,false);
			
			HttpResponse resp2 = webserviceUtil.getResponseasJsonforGet(httpget);
			Reporter.logEvent(Status.PASS, "Running Web Service to get Income Data when Blank value is passed.","Response: "+resp2,false);
			System.out.println(resp2);
			System.out.println("Status Code: "+resp2.getStatusLine().getStatusCode());
			if(resp2.getStatusLine().getStatusCode() == 404){
			Reporter.logEvent(Status.PASS, "Getting Status Code of Service","StatCode: "+resp2.getStatusLine().getStatusCode(),false);
			
			String responseString = webserviceUtil.getHttpResponseAsString(resp2);
			try{
			JsonNode jsonObj = JsonUtil.convertJsonStringtoJsonNode(responseString);
			}
			catch(Exception e){
				System.out.println(e);
				Reporter.logEvent(Status.PASS, "Getting the Response: ","Empty Response Validated\n"+ e,false);
			}
			}
			else{
				Reporter.logEvent(Status.FAIL, "Getting Status Code of Service","StatCode: "+resp2.getStatusLine().getStatusCode(),false);
			}
			} catch (Exception e) {
			e.printStackTrace();
			Globals.exception = e;
			String errorMsg = e.getMessage();
			Reporter.logEvent(Status.FAIL, "A run time exception occured.",errorMsg,false);
		} catch (Error ae) {
			ae.printStackTrace();
			Globals.error = ae;
			String errorMsg = ae.getMessage();
			Reporter.logEvent(Status.FAIL, "Assertion Error Occured",errorMsg,false);
		} finally {
			try {
				Reporter.finalizeTCReport();
			} catch (Exception e1) {
				e1.printStackTrace();
			}
		}
	
		
	}
	
	@Test(dataProvider = "setData")
	public void testgetIncomeData_WhenNullValuePassed(int itr, Map<String, String> testdata)
			throws NoSuchFieldException, SecurityException {
	//	Scanner myscanner = new Scanner(System.in);
		webserviceUtil = new WebserviceUtil();
		try {
			Reporter.initializeReportForTC(itr,"Validating Participant Services webservice");			
			response = new Response();
			
			response.setusername(Stock.GetParameterValue("username"));
			response.setPassword(Stock.GetParameterValue("password"));
						
			jsonRequestString = JsonUtil.writeToJson(response);
			
			HttpResponse resp1 = webserviceUtil.getResponseasJsonforPostRequest(Stock.GetParameterValue("url1"), jsonRequestString);	
			System.out.println(resp1.toString());
			String authCode = resp1.getFirstHeader("Authorization").getValue();
			System.out.println("AuthCode: "+authCode);
			Reporter.logEvent(Status.PASS, "Running Authentication Service.","AuthCode: "+authCode,false);
			
			String url2 = webserviceUtil.convertBlankSpacesToString(Stock.GetParameterValue("url2"));
			
			System.out.println("URL encoded -- " + url2);
			
			URI uri = new URI(url2);
			HttpGet httpget = new HttpGet(uri);
			
		//	HttpGet httpget = new HttpGet(url2);			
			httpget.addHeader("Authorization", "JWT "+authCode);
						
			Reporter.logEvent(Status.PASS, "URL of the Service","URI: "+url2,false);
			
			HttpResponse resp2 = webserviceUtil.getResponseasJsonforGet(httpget);
			Reporter.logEvent(Status.PASS, "Running Web Service to get Income Data when Null value is passed.","Response: "+resp2,false);
			System.out.println(resp2);
			System.out.println("Status Code: "+resp2.getStatusLine().getStatusCode());
			if(resp2.getStatusLine().getStatusCode() == 500){
			Reporter.logEvent(Status.PASS, "Getting Status Code of Service","StatCode: "+resp2.getStatusLine().getStatusCode(),false);
			
			String responseString = webserviceUtil.getHttpResponseAsString(resp2);
			try{
			JsonNode jsonObj = JsonUtil.convertJsonStringtoJsonNode(responseString);
			}
			catch(Exception e){
				System.out.println(e);
				Reporter.logEvent(Status.PASS, "Getting the Response: ","Empty Response Validated\n"+ e,false);
			}
			}
			else{
				Reporter.logEvent(Status.FAIL, "Getting Status Code of Service","StatCode: "+resp2.getStatusLine().getStatusCode(),false);
			}
			} catch (Exception e) {
			e.printStackTrace();
			Globals.exception = e;
			String errorMsg = e.getMessage();
			Reporter.logEvent(Status.FAIL, "A run time exception occured.",errorMsg,false);
		} catch (Error ae) {
			ae.printStackTrace();
			Globals.error = ae;
			String errorMsg = ae.getMessage();
			Reporter.logEvent(Status.FAIL, "Assertion Error Occured",errorMsg,false);
		} finally {
			try {
				Reporter.finalizeTCReport();
			} catch (Exception e1) {
				e1.printStackTrace();
			}
		}
	
		
	}

	@Test(dataProvider = "setData")
	public void testgetIncomeData_WhenBlankValuePassed1(int itr, Map<String, String> testdata)
			throws NoSuchFieldException, SecurityException {
	//	Scanner myscanner = new Scanner(System.in);
		webserviceUtil = new WebserviceUtil();
		try {
			Reporter.initializeReportForTC(itr,"Validating Participant Services webservice");			
			response = new Response();
			
			response.setusername(Stock.GetParameterValue("username"));
			response.setPassword(Stock.GetParameterValue("password"));
						
			jsonRequestString = JsonUtil.writeToJson(response);
			
			HttpResponse resp1 = webserviceUtil.getResponseasJsonforPostRequest(Stock.GetParameterValue("url1"), jsonRequestString);	
			System.out.println(resp1.toString());
			String authCode = resp1.getFirstHeader("Authorization").getValue();
			System.out.println("AuthCode: "+authCode);
			Reporter.logEvent(Status.PASS, "Running Authentication Service.","AuthCode: "+authCode,false);
			
			Attributes attributes = new Attributes();
			attributes.setDatabase(" ");
			attributes.setGaId("99537-01");
			attributes.setIndId("12147573");
			
	//		String jsonStr = JsonUtil.writeToJson(attributes);
	//		System.out.println("json: "+jsonStr);				
			String url2 = Stock.GetParameterValue("url2").concat("/db/"+attributes.getDatabase()+"/gaId/"+attributes.getGaId()+"/indId/"+attributes.getIndId()+"/incomeData");
			HttpGet httpget = new HttpGet(url2);
			
			System.out.println(url2);
			httpget.addHeader("Authorization", "JWT "+authCode);
						
	//		Reporter.logEvent(Status.PASS, "URL of the Service","URI: "+url2,false);
			
			HttpResponse resp2 = webserviceUtil.getResponseasJsonforGet(httpget);
			Reporter.logEvent(Status.PASS, "Running Web Service to get Income Data when Null value is passed.","Response: "+resp2,false);
			System.out.println(resp2);
			System.out.println("Status Code: "+resp2.getStatusLine().getStatusCode());
			if(resp2.getStatusLine().getStatusCode() == 404){
			Reporter.logEvent(Status.PASS, "Getting Status Code of Service","StatCode: "+resp2.getStatusLine().getStatusCode(),false);
		
			String responseString = webserviceUtil.getHttpResponseAsString(resp2);
			try{
			JsonNode jsonObj = JsonUtil.convertJsonStringtoJsonNode(responseString);
			}
			catch(Exception e){
				System.out.println(e);
				Reporter.logEvent(Status.PASS, "Getting the Response: ","Empty Response Validated\n"+ e,false);
			}
			}
			else{
				Reporter.logEvent(Status.FAIL, "Getting Status Code of Service","StatCode: "+resp2.getStatusLine().getStatusCode(),false);
			}
			} catch (Exception e) {
			e.printStackTrace();
			Globals.exception = e;
			String errorMsg = e.getMessage();
			Reporter.logEvent(Status.FAIL, "A run time exception occured.",errorMsg,false);
		} catch (Error ae) {
			ae.printStackTrace();
			Globals.error = ae;
			String errorMsg = ae.getMessage();
			Reporter.logEvent(Status.FAIL, "Assertion Error Occured",errorMsg,false);
		} finally {
			try {
				Reporter.finalizeTCReport();
			} catch (Exception e1) {
				e1.printStackTrace();
			}
		}	
	}

	}
	
	
	
*/
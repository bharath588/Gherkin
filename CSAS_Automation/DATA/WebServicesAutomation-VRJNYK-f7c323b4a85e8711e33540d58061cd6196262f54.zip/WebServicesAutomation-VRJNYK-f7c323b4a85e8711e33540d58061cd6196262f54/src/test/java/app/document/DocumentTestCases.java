/**@author srsvnk
 * 
 */
package app.document;

import java.lang.reflect.Method;
import java.util.LinkedHashMap;
import java.util.Map;

import lib.Reporter;
import lib.Stock;

import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import util.CommonLib;
import webservices.util.JsonUtil;
import webservices.util.WebserviceUtil;
import app.ramlservices.pageobject.DocumentService;
import app.webservice.pageobjects.Response;

import com.aventstack.extentreports.Status;

import core.framework.Globals;

public class DocumentTestCases {
	private LinkedHashMap<Integer, Map<String, String>> testData = null;
	CommonLib utilities;
	DocumentService document;
	WebserviceUtil web = null;
	Response response;
	String jsonRequestString;
	String jsonResponseString;

	// ResultSet queryResultSet;

	@BeforeClass
	public void InitTest() throws Exception {
		Reporter.initializeModule(this.getClass().getSimpleName());
	}

	@DataProvider
	public Object[][] setData(Method tc) throws Exception {
		tc.getName();
		prepTestData(tc);
		return Stock.setDataProvider(this.testData);
	}

	private void prepTestData(Method testCase) throws Exception {
		this.testData = Stock.getTestData(this.getClass().getPackage()
				.getName(), testCase.getName());
	}

	/**
	 * <pre>
	 * Test Case is used  to validate to Get a document Location url of type customDataTypes with the correct input provided in the request.
	 * </pre>
	 * 
	 * <pre>
	 * Test Case is used  to validate to Get a a document Location url of type customDataTypes when accessCode value is passed empty in the request.
	 * </pre>
	 * 
	 * @param itr
	 *            : Iteration number
	 * @param testData
	 *            Test data map.
	 */
	@Test(dataProvider = "setData")
	public void TC01_Document_DocumentLocation_Positive_Flow(int itr,
			Map<String, String> testData) {
		String requestURL;
		try {
			Reporter.initializeReportForTC(itr, Globals.GC_MANUAL_TC_NAME,
					Stock.GetParameterValue("description"));
			Reporter.logEvent(Status.INFO,
					"Test Data used for iteration" + itr,
					CommonLib.getIterationDataAsString(testData), false);
			requestURL = JsonUtil.formRequestURL(
					Stock.GetParameterValue("serviceURL"),
					Stock.GetParameterValue("accessCode"),
					Stock.GetParameterValue("docType"),
					Stock.GetParameterValue("sdioId"),
					Stock.GetParameterValue("gaId"));
			System.out.println(requestURL);
			utilities = new CommonLib();
			utilities.triggerService(requestURL);
			utilities.validateResponseStatusCode();
			document = new DocumentService();
			document.validateResponseDocumentLocationURL();
		} catch (Exception e) {
			e.printStackTrace();
			Globals.exception = e;
			String errorMsg = e.getMessage();
			Reporter.logEvent(Status.FAIL, "A run time exception occured.",
					errorMsg, false);
		} finally {
			try {
				Reporter.finalizeTCReport();
			} catch (Exception e1) {
				e1.printStackTrace();
			}
		}
	}

	/**
	 * <pre>
	 * Test Case is used  to validate to Geta document Location url of type customDataTypes when gaId value is passed empty in the request.
	 * </pre>
	 * 
	 * <pre>
	 * Test Case is used  to validate to Get a document Location url of type customDataTypes when docType value is passed empty in the request.
	 * </pre>
	 * 
	 * @param itr
	 *            : Iteration number
	 * @param testData
	 *            Test data map.
	 */
	@Test(dataProvider = "setData")
	public void TC02_Document_DocumentLocation_Nagative_Flow(int itr,
			Map<String, String> testData) {
		String requestURL;
		try {
			Reporter.initializeReportForTC(itr, Globals.GC_MANUAL_TC_NAME,
					Stock.GetParameterValue("description"));
			Reporter.logEvent(Status.INFO,
					"Test Data used for iteration" + itr,
					CommonLib.getIterationDataAsString(testData), false);
			requestURL = JsonUtil.formRequestURL(
					Stock.GetParameterValue("serviceURL"),
					Stock.GetParameterValue("accessCode"),
					Stock.GetParameterValue("docType"),
					Stock.GetParameterValue("sdioId"),
					Stock.GetParameterValue("gaId"));
			System.out.println(requestURL);
			utilities = new CommonLib();
			utilities.triggerService(requestURL);
			utilities.validateResponseStatusCodeWithoutClientMessage();
		} catch (Exception e) {
			e.printStackTrace();
			Globals.exception = e;
			String errorMsg = e.getMessage();
			Reporter.logEvent(Status.FAIL, "A run time exception occured.",
					errorMsg, false);
		} finally {
			try {
				Reporter.finalizeTCReport();
			} catch (Exception e1) {
				e1.printStackTrace();
			}
		}

	}

	/**
	 * <pre>
	 * Test Case is used  to validate to Get a document Location url of type customDataTypes when sdioId field is removed from the request.
	 * </pre>
	 * 
	 * @param itr
	 *            : Iteration number
	 * @param testData
	 *            Test data map.
	 */
	@Test(dataProvider = "setData")
	public void TC03_Document_DocumentLocation_Positive_Flow(int itr,
			Map<String, String> testData) {
		String requestURL;
		try {
			Reporter.initializeReportForTC(itr, Globals.GC_MANUAL_TC_NAME,
					Stock.GetParameterValue("description"));
			Reporter.logEvent(Status.INFO,
					"Test Data used for iteration" + itr,
					CommonLib.getIterationDataAsString(testData), false);
			requestURL = JsonUtil.formRequestURL(
					Stock.GetParameterValue("serviceURL"),
					Stock.GetParameterValue("accessCode"),
					Stock.GetParameterValue("docType"),
					Stock.GetParameterValue("sdioId"),
					Stock.GetParameterValue("gaId"));
			System.out.println(requestURL);
			utilities = new CommonLib();
			utilities.triggerService(requestURL);
			utilities.validateResponseStatusCode();
			document = new DocumentService();
			//document.validateDocumentLocationURL();
		} catch (Exception e) {
			e.printStackTrace();
			Globals.exception = e;
			String errorMsg = e.getMessage();
			Reporter.logEvent(Status.FAIL, "A run time exception occured.",
					errorMsg, false);
		} finally {
			try {
				Reporter.finalizeTCReport();
			} catch (Exception e1) {
				e1.printStackTrace();
			}
		}
	}

	/**
	 * <pre>
	 * Test Case is used  to validate to Get a document Location url of type customDataTypes when invalid header is passed with JWT.
	 * </pre>
	 * 
	 * <pre>
	 * Test Case is used  to validate to Get a document Location url of type customDataTypes when valid header is passed without JWT.
	 * </pre>
	 * 
	 * @param itr
	 *            : Iteration number
	 * @param testData
	 *            Test data map.
	 */
	@Test(dataProvider = "setData")
	public void TC04_Document_DocumentLocation_Nagative_Flow(int itr,
			Map<String, String> testData) {
		String requestURL;
		try {
			Reporter.initializeReportForTC(itr, Globals.GC_MANUAL_TC_NAME,
					Stock.GetParameterValue("description"));
			Reporter.logEvent(Status.INFO,
					"Test Data used for iteration" + itr,
					CommonLib.getIterationDataAsString(testData), false);
			requestURL = JsonUtil.formRequestURL(
					Stock.GetParameterValue("serviceURL"),
					Stock.GetParameterValue("docType"),
					Stock.GetParameterValue("sdioId"),
					Stock.GetParameterValue("gaId"));
			System.out.println(requestURL);
			utilities = new CommonLib();
			utilities.triggerServiceWhenAuthDoesNotHaveJWT(requestURL);
			utilities.validateResponseStatusCode();
		} catch (Exception e) {
			e.printStackTrace();
			Globals.exception = e;
			String errorMsg = e.getMessage();
			Reporter.logEvent(Status.FAIL, "A run time exception occured.",
					errorMsg, false);
		} finally {
			try {
				Reporter.finalizeTCReport();
			} catch (Exception e1) {
				e1.printStackTrace();
			}
		}
	}

	/**
	 * <pre>
	 * Test Case is used  to validate to Get a document Location url of type customDataTypes when different method is passed instead of GET method.
	 * </pre>
	 * 
	 * @param itr
	 *            : Iteration number
	 * @param testData
	 *            Test data map.
	 */
	@Test(dataProvider = "setData")
	public void TC05_Document_DocumentLocation_Nagative_Flow(int itr,
			Map<String, String> testData) {
		String requestURL = null;
		try {
			Reporter.initializeReportForTC(itr, Globals.GC_MANUAL_TC_NAME,
					Stock.GetParameterValue("description"));
			web = new WebserviceUtil();
			response = new Response();
			response.setusername(Stock.GetParameterValue("username"));
			response.setPassword(Stock.GetParameterValue("password"));
			jsonRequestString = JsonUtil.writeToJson(response);
			// Get authcode and construct a request URL.
			HttpResponse resp1 = web.getResponseasJsonforPostRequest(
					Stock.GetParameterValue("authURL"), jsonRequestString);
			String authCode = resp1.getFirstHeader("Authorization").getValue();
			requestURL = JsonUtil.formRequestURL(
					Stock.GetParameterValue("serviceURL"),
					Stock.GetParameterValue("docType"),
					Stock.GetParameterValue("sdioId"),
					Stock.GetParameterValue("gaId"));
			// Add header and Make http request and get the response.
			HttpPost postReq = new HttpPost(requestURL);
			postReq.addHeader("Authorization", "JWT " + authCode);
			HttpResponse postRes = web.getResponse(postReq);
			String statusCode = String.valueOf(postRes.getStatusLine()
					.getStatusCode());
			String expectedStatusCode = Stock.GetParameterValue("responseCode");
			String reasonPhrase = postRes.getStatusLine().getReasonPhrase();
			// Verify http status code.
			// String exceptionMessage =
			// postReq.getFirstHeader("exceptionMessage").getValue();
			System.out.println("code " + statusCode + "reasonPhrase  "
					+ reasonPhrase + "exception  ");
			if (statusCode.equalsIgnoreCase(expectedStatusCode)) {
				Reporter.logEvent(Status.PASS, "Verify the status code",
						"Expected " + expectedStatusCode + " Actual "
								+ statusCode + "\nReason Phrase "
								+ reasonPhrase, false);
			} else {
				Reporter.logEvent(Status.FAIL, "Verify the status code",
						"Expected " + expectedStatusCode + " Actual "
								+ statusCode + "\nReason Phrase "
								+ reasonPhrase, false);
			}

		} catch (Exception e) {
			e.printStackTrace();
			Globals.exception = e;
			String errorMsg = e.getMessage();
			Reporter.logEvent(Status.FAIL, "A run time exception occured.",
					errorMsg, false);
		} finally {
			try {
				Reporter.finalizeTCReport();
			} catch (Exception e1) {
				e1.printStackTrace();
			}
		}
	}

	/**
	 * <pre>
	 * Test Case is used  to validate to Get a document Location url of
	 *  type customDataTypes with the correct input provided in the request.
	 * 
	 * </pre>
	 * 
	 * @param itr
	 *            : Iteration number
	 * @param testData
	 *            Test data map.
	 */
	@Test(dataProvider = "setData")
	public void TC_06_BCOM_5419_DocLocation_Positive_Flow(int itr,
			Map<String, String> testData) {
		String requestURL;
		try {
			Reporter.initializeReportForTC(itr, Globals.GC_MANUAL_TC_NAME,
					Stock.GetParameterValue("description"));
			Reporter.logEvent(Status.INFO,
					"Test Data used for iteration" + itr,
					CommonLib.getIterationDataAsString(testData), false);
			requestURL = JsonUtil.formRequestURL(
					Stock.GetParameterValue("serviceURL"),
					Stock.GetParameterValue("gaId"),
					Stock.GetParameterValue("accessCode"),
					Stock.GetParameterValue("docType"));
			utilities = new CommonLib();
			utilities.triggerService(requestURL);
			utilities.validateResponseStatusCode();
			document = new DocumentService();
			document.validateDocumentLocationURL();
		} catch (Exception e) {
			e.printStackTrace();
			Globals.exception = e;
			String errorMsg = e.getMessage();
			Reporter.logEvent(Status.FAIL, "A run time exception occured.",
					errorMsg, false);
		} finally {
			try {
				Reporter.finalizeTCReport();
			} catch (Exception e1) {
				e1.printStackTrace();
			}
		}
	}
	/**
	 * <pre>
	 * Test Case is used  to validate to Geta document Location url of type 
	 * customDataTypes when parameter value is passed empty in the request.
	 * 
	 * </pre>
	 * 
	 * @param itr
	 *            : Iteration number
	 * @param testData
	 *            Test data map.
	 */
	@Test(dataProvider = "setData")
	public void TC_07_BCOM_5419_DocLocation_Negative_Flow(int itr,
			Map<String, String> testData) {
		String requestURL;
		try {
			Reporter.initializeReportForTC(itr, Globals.GC_MANUAL_TC_NAME,
					Stock.GetParameterValue("description"));
			Reporter.logEvent(Status.INFO,
					"Test Data used for iteration" + itr,
					CommonLib.getIterationDataAsString(testData), false);
			requestURL = JsonUtil.formRequestURL(
					Stock.GetParameterValue("serviceURL"),
					Stock.GetParameterValue("gaId"),
					Stock.GetParameterValue("accessCode"),
					Stock.GetParameterValue("docType"));
			utilities = new CommonLib();
			utilities.triggerService(requestURL);
			utilities.validateResponseStatusCodeWithoutClientMessage();
		} catch (Exception e) {
			e.printStackTrace();
			Globals.exception = e;
			String errorMsg = e.getMessage();
			Reporter.logEvent(Status.FAIL, "A run time exception occured.",
					errorMsg, false);
		} finally {
			try {
				Reporter.finalizeTCReport();
			} catch (Exception e1) {
				e1.printStackTrace();
			}
		}
	}
	/**
	 * <pre>
	 * Test Case is used  to validate to Get a document Location url of type customDataTypes when invalid header is passed with JWT.
	 * </pre>
	 * 
	 * <pre>
	 * Test Case is used  to validate to Get a document Location url of type customDataTypes when valid header is passed without JWT.
	 * </pre>
	 * 
	 * @param itr
	 *            : Iteration number
	 * @param testData
	 *            Test data map.
	 */
	@Test(dataProvider = "setData")
	public void TC_08_BCOM_5419_DocLocation_Negative_Flow(int itr,
			Map<String, String> testData) {
		String requestURL;
		try {
			Reporter.initializeReportForTC(itr, Globals.GC_MANUAL_TC_NAME,
					Stock.GetParameterValue("description"));
			Reporter.logEvent(Status.INFO,
					"Test Data used for iteration" + itr,
					CommonLib.getIterationDataAsString(testData), false);
			requestURL = JsonUtil.formRequestURL(
					Stock.GetParameterValue("serviceURL"),
					Stock.GetParameterValue("gaId"),
					Stock.GetParameterValue("accessCode"),
					Stock.GetParameterValue("docType"));
			System.out.println(requestURL);
			utilities = new CommonLib();
			utilities.triggerServiceWhenAuthDoesNotHaveJWT(requestURL);
			utilities.validateResponseStatusCode();
		} catch (Exception e) {
			e.printStackTrace();
			Globals.exception = e;
			String errorMsg = e.getMessage();
			Reporter.logEvent(Status.FAIL, "A run time exception occured.",
					errorMsg, false);
		} finally {
			try {
				Reporter.finalizeTCReport();
			} catch (Exception e1) {
				e1.printStackTrace();
			}
		}
	}
}
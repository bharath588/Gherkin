package app.ramlservice.testcases;

import java.lang.reflect.Method;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import lib.DB;
import lib.Reporter;
import lib.Stock;
import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.client.methods.HttpGet;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import webservices.util.JsonUtil;
import webservices.util.WebserviceUtil;
import app.webservice.pageobjects.JsonReadWriteUtils;
import app.webservice.pageobjects.Response;

import com.aventstack.extentreports.Status;

import core.framework.Globals;

public class NQDistributionTestCases {

	private LinkedHashMap<Integer, Map<String, String>> testData = null;
	WebserviceUtil web = null;
	Response response;
	String jsonRequestString;
	String jsonResponseString;
	ResultSet queryResultSet;
	String sdmtCodeForMntyId324 = "$..structureDisbursementGroupMoneyTypes[?(@.mntyId == 324)].sdmtCode";
	String sdmtCodeForMntyId403 = "$..structureDisbursementGroupMoneyTypes[?(@.mntyId == 403)].sdmtCode";
	String sdmtCodeForMntyId505 = "$..structureDisbursementGroupMoneyTypes[?(@.mntyId == 505)].sdmtCode";

	@BeforeClass
	public void InitTest() throws Exception {
		Reporter.initializeModule(this.getClass().getSimpleName());
	}

	@DataProvider
	public Object[][] setData(Method tc) throws Exception {
		tc.getName();
		prepTestData(tc);
		return Stock.setDataProvider(this.testData);
	}

	private void prepTestData(Method testCase) throws Exception {
		this.testData = Stock.getTestData(this.getClass().getPackage()
				.getName(), testCase.getName());
	}

	@Test(dataProvider = "setData")
	public void TC01_BCOM_NQ_Distribution_view_table_results(int itr,
			Map<String, String> testdata) {
		String requestUrl = null;
		try {
			Reporter.initializeReportForTC(itr, "");
			web = new WebserviceUtil();
			String endPoint = "db/" + Stock.GetParameterValue("dbName")
					+ "/gaId/" + Stock.GetParameterValue("gaId") + "/indId/"
					+ Stock.GetParameterValue("indId");
			response = new Response();

			response.setusername(Stock.GetParameterValue("username"));
			response.setPassword(Stock.GetParameterValue("password"));

			jsonRequestString = JsonUtil.writeToJson(response);

			Reporter.logEvent(Status.INFO, "Request body of first response",
					jsonRequestString, false);

			HttpResponse resp1 = web.getResponseasJsonforPostRequest(
					Stock.GetParameterValue("authURL"), jsonRequestString);
			System.out.println(resp1.toString());
			String authCode = resp1.getFirstHeader("Authorization").getValue();
			System.out.println("AuthCode: " + authCode);

			Reporter.logEvent(Status.INFO,
					"The Auth code to be taken for second webservice header",
					"\nThe Auth code to be taken for second webservice header is:\n"
							+ authCode, false);
			requestUrl = Stock.GetParameterValue("serviceURL") + endPoint;
			Reporter.logEvent(Status.INFO, "The request url for GET",
					requestUrl, false);
			HttpGet getReq = new HttpGet(requestUrl);
			getReq.addHeader("Authorization", "JWT " + authCode);
			HttpResponse response = web.getResponseasJsonforGet(getReq);
			int code = response.getStatusLine().getStatusCode();

			if (code == 200)
				Reporter.logEvent(Status.PASS, "Verify the status code",
						"Expected 200" + " Actual " + code, false);
			else
				Reporter.logEvent(Status.FAIL, "Verify the status code",
						"Expected 200" + " Actual " + code, false);
			String responseString = web.getHttpResponseAsString(response);
			Reporter.logEvent(Status.INFO, "The response", responseString,
					false);
			Map<String, String> testdataMap = (Stock
					.getTestDataAsCaseSensitive(this.getClass().getPackage()
							.getName(),
							(Thread.currentThread().getStackTrace())[1]
									.getMethodName())).get(itr);
			JsonReadWriteUtils
			.verifyJsonNodeValues(testdataMap, responseString);
			JsonReadWriteUtils
			.getMatchingNodes(responseString,
					"$..structureDisbursementGroupMoneyTypes[?(@.mntyId == 324)]");
			Stock.setConfigParam("TARGETDB",
					"D_" + Stock.GetParameterValue("dbName").toUpperCase());

			queryResultSet = DB.executeQuery("TARGETDB",
					Stock.getTestQuery("getNonQualPptAccInfoQuery")[1],
					Stock.GetParameterValue("gaId"),
					Stock.GetParameterValue("indId"));

			while (queryResultSet.next()) {
				String mntyId = queryResultSet.getString("GA_NQ_STRUC_MNTY_ID");
				String sdmtCodeinDB = queryResultSet
						.getString("GA_NQ_STRUC_MNTY_SDMT_CODE");

				String sdmtCodeInResponse = JsonReadWriteUtils
						.getNodeValueUsingJpath(responseString,
								"$..structureDisbursementGroupMoneyTypes[?(@.mntyId == "
										+ mntyId + ")].sdmtCode");
				if (sdmtCodeInResponse.equalsIgnoreCase(sdmtCodeinDB)) {
					Reporter.logEvent(Status.PASS,
							"Compare SDMT code in response with Database",
							"SDMT codes are same in repsonse and database"
									+ "\n In Response : " + sdmtCodeInResponse
									+ "\n In database : " + sdmtCodeinDB, false);
				} else {
					Reporter.logEvent(Status.FAIL,
							"Compare SDMT code in response with Database",
							"SDMT codes are same in repsonse and database"
									+ "\n In Response : " + sdmtCodeInResponse
									+ "\n In database : " + sdmtCodeinDB, false);
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
			Globals.exception = e;
			String errorMsg = e.getMessage();
			Reporter.logEvent(Status.FAIL, "A run time exception occured.",
					errorMsg, false);
		} catch (Error ae) {
			ae.printStackTrace();
			Globals.error = ae;
			String errorMsg = ae.getMessage();
			Reporter.logEvent(Status.FAIL, "Assertion Error Occured", errorMsg,
					false);
		} finally {
			try {
				Reporter.finalizeTCReport();
			} catch (Exception e1) {
				e1.printStackTrace();
			}
		}
	}

	@Test(dataProvider = "setData")
	public void TC01_BCOM_NQ_Get_Plan_Rules(int itr,
			Map<String, String> testdata) {
		String requestUrl = null;
		try {
			Reporter.initializeReportForTC(itr, "");
			web = new WebserviceUtil();
			String endPoint = "db/" + Stock.GetParameterValue("dbName")
					+ "/gaId/" + Stock.GetParameterValue("gaId");
			response = new Response();

			response.setusername(Stock.GetParameterValue("username"));
			response.setPassword(Stock.GetParameterValue("password"));

			jsonRequestString = JsonUtil.writeToJson(response);

			Reporter.logEvent(Status.INFO, "Request body of first response",
					jsonRequestString, false);

			HttpResponse resp1 = web.getResponseasJsonforPostRequest(
					Stock.GetParameterValue("authURL"), jsonRequestString);
			System.out.println(resp1.toString());
			String authCode = resp1.getFirstHeader("Authorization").getValue();
			System.out.println("AuthCode: " + authCode);

			Reporter.logEvent(Status.INFO,
					"The Auth code to be taken for second webservice header",
					"\nThe Auth code to be taken for second webservice header is:\n"
							+ authCode, false);
			requestUrl = Stock.GetParameterValue("serviceURL") + endPoint;
			Reporter.logEvent(Status.INFO, "The request url for GET",
					requestUrl, false);
			HttpGet getReq = new HttpGet(requestUrl);
			getReq.addHeader("Authorization", "JWT " + authCode);
			HttpResponse response = web.getResponseasJsonforGet(getReq);
			int code = response.getStatusLine().getStatusCode();

			if (code == 200)
				Reporter.logEvent(Status.PASS, "Verify the status code",
						"Expected 200" + " Actual " + code, false);
			else
				Reporter.logEvent(Status.FAIL, "Verify the status code",
						"Expected 200" + " Actual " + code, false);
			String responseString = web.getHttpResponseAsString(response);
			System.out.println("response string is   "+responseString);
			Reporter.logEvent(Status.INFO, "The response", responseString,
					false);

			Stock.setConfigParam("TARGETDB",
					"D_" + Stock.GetParameterValue("dbName").toUpperCase());

			queryResultSet = DB.executeQuery("TARGETDB",
					Stock.getTestQuery("getStrucProperties")[1],
					Stock.GetParameterValue("gaId"));

			while (queryResultSet.next()) {
				String id = queryResultSet.getString("ID");

				String nameInResponse = JsonReadWriteUtils
						.getNodeValueUsingJpath(responseString,
								"$..[?(@.id == " + id + ")].name");

				String strucTypeCode = JsonReadWriteUtils
						.getNodeValueUsingJpath(responseString,
								"$..[?(@.id == " + id + ")].strucTypeCode");

				String effdate = JsonReadWriteUtils.getNodeValueUsingJpath(
						responseString, "$..[?(@.id == " + id + ")].effDate");

				String termDate = JsonReadWriteUtils.getNodeValueUsingJpath(
						responseString, "$..[?(@.id == " + id + ")].termDate");

				String description = JsonReadWriteUtils.getNodeValueUsingJpath(
						responseString, "$..[?(@.id == " + id
						+ ")].description");

				String seqNbr = JsonReadWriteUtils.getNodeValueUsingJpath(
						responseString, "$..[?(@.id == " + id + ")].seqNbr");

				String statusCode = JsonReadWriteUtils
						.getNodeValueUsingJpath(responseString,
								"$..[?(@.id == " + id + ")].statusCode");

				// /String classYear =
				// JsonReadWriteUtils.getNodeValueUsingJpath(
				// responseString, "$..[?(@.id == " + id + ")].classYear");

				String strucTypeDesc = JsonReadWriteUtils
						.getNodeValueUsingJpath(responseString,
								"$..[?(@.id == " + id
								+ ")].strucTypeDescription");


				JsonReadWriteUtils.compareValueAndLogReport(nameInResponse,
						queryResultSet.getString("NAME"),"NAME");

				JsonReadWriteUtils.compareValueAndLogReport(strucTypeCode,
						queryResultSet.getString("STRUC_TYPE_CODE"),"STRUC_TYPE_CODE");


				JsonReadWriteUtils.compareDbWithDateInResponse(effdate,
						queryResultSet.getDate("EFFDATE"),"EFFDATE");

				JsonReadWriteUtils.compareValueAndLogReport(termDate,
						queryResultSet.getString("TERMDATE"),"TERMDATE");

				JsonReadWriteUtils.compareValueAndLogReport(description,
						queryResultSet.getString("DESCRIPTION"),"DESCRIPTION");
				JsonReadWriteUtils.compareValueAndLogReport(seqNbr,
						queryResultSet.getString("DISPLAY_SEQNBR"),"SEQUENCE NUMBER");
				JsonReadWriteUtils.compareValueAndLogReport(statusCode,
						queryResultSet.getString("STATUS_CODE"),"STATUS CODE");

				JsonReadWriteUtils.compareValueAndLogReport(strucTypeDesc,
						queryResultSet.getString("STRUCTYPEDESCRIPTION"),"Structure type description");
			}

			queryResultSet = DB.executeQuery("TARGETDB",
					Stock.getTestQuery("getNQContributionQuery")[1],
					Stock.GetParameterValue("gaId"));

			while (queryResultSet.next()) {
				String nqEnrlId = queryResultSet.getString("NQENRLID");

				String gaNqStrcId = JsonReadWriteUtils.getNodeValueUsingJpath(
						responseString, "$..enrlPeriodInfo[?(@.id==" + nqEnrlId
						+ ")].gaNQStrucId");

				String name = JsonReadWriteUtils.getNodeValueUsingJpath(
						responseString, "$..enrlPeriodInfo[?(@.id==" + nqEnrlId
						+ ")].name");

				String beginDate = JsonReadWriteUtils.getNodeValueUsingJpath(
						responseString, "$..enrlPeriodInfo[?(@.id==" + nqEnrlId
						+ ")].beginDate");

				String endDate = JsonReadWriteUtils.getNodeValueUsingJpath(
						responseString, "$..enrlPeriodInfo[?(@.id==" + nqEnrlId
						+ ")].endDate");
				String statusCode = JsonReadWriteUtils.getNodeValueUsingJpath(
						responseString, "$..enrlPeriodInfo[?(@.id==" + nqEnrlId
						+ ")].statusCode");
				String description = JsonReadWriteUtils.getNodeValueUsingJpath(
						responseString, "$..enrlPeriodInfo[?(@.id==" + nqEnrlId
						+ ")].description");
				String endOfEnrollProcessing = JsonReadWriteUtils
						.getNodeValueUsingJpath(responseString,
								"$..enrlPeriodInfo[?(@.id==" + nqEnrlId
								+ ")].endOfEnrollProcessing");

				JsonReadWriteUtils.compareValueAndLogReport(gaNqStrcId,
						queryResultSet.getString("NQENRLGANQSTRUCID"),"NQENRLGANQSTRUCID");
				JsonReadWriteUtils.compareValueAndLogReport(name,
						queryResultSet.getString("NQENRLNAME"),"NQENROLLNAME");
				JsonReadWriteUtils.compareValueAndLogReport(statusCode,
						queryResultSet.getString("NQENRLSTATUSCODE"),"NQENRLSTATUSCODE");
				JsonReadWriteUtils.compareValueAndLogReport(description,
						queryResultSet.getString("NQENRLDESCRIPTION"),"NQENRLDESCRIPTION");

				// DB compare do here

				/**
				 * DB compare
				 */
				JsonReadWriteUtils.compareDbWithDateInResponse(beginDate,
						queryResultSet.getDate("NQENRLBEGINDATE"),"NQENRLBEGINDATE");

				JsonReadWriteUtils.compareDbWithDateInResponse(endDate,
						queryResultSet.getDate("NQENRLENDDATE"),"NQENRLENDDATE");

				JsonReadWriteUtils.compareDbWithDateInResponse(
						endOfEnrollProcessing,
						queryResultSet.getDate("NQENRLENDOFENRLPROCESSING"),"NQENRLENDOFENRLPROCESSING");


				String contrbtnInfoId = JsonReadWriteUtils
						.getNodeValueUsingJpath(responseString,
								"$..enrlPeriodInfo[?(@.id==" + nqEnrlId
								+ ")].contributionPeriodInfo..id");

				String gaNqStruEnrlPeriodId = JsonReadWriteUtils
						.getNodeValueUsingJpath(
								responseString,
								"$..enrlPeriodInfo[?(@.id=="
										+ nqEnrlId
										+ ")].contributionPeriodInfo..gaNQStruEnrollPeriodId");

				String startDate = JsonReadWriteUtils.getNodeValueUsingJpath(
						responseString, "$..enrlPeriodInfo[?(@.id==" + nqEnrlId
						+ ")].contributionPeriodInfo..startDate");

				String stopDate = JsonReadWriteUtils.getNodeValueUsingJpath(
						responseString, "$..enrlPeriodInfo[?(@.id==" + nqEnrlId
						+ ")].contributionPeriodInfo..stopDate");

				String contrStatusCode = JsonReadWriteUtils
						.getNodeValueUsingJpath(
								responseString,
								"$..enrlPeriodInfo[?(@.id=="
										+ nqEnrlId
										+ ")].contributionPeriodInfo..statusCode");

				String contrStatusDesc = JsonReadWriteUtils
						.getNodeValueUsingJpath(
								responseString,
								"$..enrlPeriodInfo[?(@.id=="
										+ nqEnrlId
										+ ")].contributionPeriodInfo..statusDescription");

				String contrName = JsonReadWriteUtils.getNodeValueUsingJpath(
						responseString, "$..enrlPeriodInfo[?(@.id==" + nqEnrlId
						+ ")].contributionPeriodInfo..name");

				JsonReadWriteUtils.compareValueAndLogReport(contrbtnInfoId,
						queryResultSet.getString("NQCONTRIBID"),"NQCONTRIBID");
				JsonReadWriteUtils.compareValueAndLogReport(
						gaNqStruEnrlPeriodId, queryResultSet
						.getString("NQCONTRIBGANQSTRUENRLPERIODID"),"NQCONTRIBGANQSTRUENRLPERIODID");
				JsonReadWriteUtils.compareValueAndLogReport(contrStatusCode,
						queryResultSet.getString("NQCONTRIBSTATUSCODE"),"NQCONTRIBSTATUSCODE");
				JsonReadWriteUtils.compareValueAndLogReport(contrStatusDesc,
						queryResultSet.getString("NQCONTRIBSTATUSDESCRIPTION"),"NQCONTRIBSTATUSDESCRIPTION");
				JsonReadWriteUtils.compareValueAndLogReport(contrName,
						queryResultSet.getString("NQCONTRIBNAME"),"NQCONTRIBNAME");

				JsonReadWriteUtils.compareDbWithDateInResponse(startDate,
						queryResultSet.getDate("NQCONTRIBSTARTDATE"),"NQCONTRIBSTARTDATE");

				JsonReadWriteUtils.compareDbWithDateInResponse(stopDate,
						queryResultSet.getDate("NQCONTRIBSTOPDATE"),"NQCONTRIBSTOPDATE");

				break;

			}

			// 6th Query
			queryResultSet = DB.executeQuery("TARGETDB",
					Stock.getTestQuery("getDisbDetails")[1],
					Stock.GetParameterValue("gaId"));

			while (queryResultSet.next()) {
				String gaNqMethodReqItemId = queryResultSet
						.getString("GANQDISBMTHDREQITEMID");

				String gaNqDisbRsnId = JsonReadWriteUtils
						.getNodeValueUsingJpath(responseString,
								"$..gaNqDisbusmentMethodRequiredItem[?(@.gaNqDisbMthdReqItemId=="
										+ gaNqMethodReqItemId
										+ ")].gaNqDisbRsnMthdId");
				String dsmdCode = JsonReadWriteUtils.getNodeValueUsingJpath(
						responseString,
						"$..gaNqDisbusmentMethodRequiredItem[?(@.gaNqDisbMthdReqItemId=="
								+ gaNqMethodReqItemId + ")].dsmdCode");
				String disbMethdItemTypeCode = JsonReadWriteUtils
						.getNodeValueUsingJpath(responseString,
								"$..gaNqDisbusmentMethodRequiredItem[?(@.gaNqDisbMthdReqItemId=="
										+ gaNqMethodReqItemId
										+ ")].disbMethodItemTypeCode");
				String gaNqDMRIHigh = JsonReadWriteUtils
						.getNodeValueUsingJpath(responseString,
								"$..gaNqDisbusmentMethodRequiredItem[?(@.gaNqDisbMthdReqItemId=="
										+ gaNqMethodReqItemId
										+ ")].gaNqDMRIRangeHighValue");
				String gaNqDMRILow = JsonReadWriteUtils.getNodeValueUsingJpath(
						responseString,
						"$..gaNqDisbusmentMethodRequiredItem[?(@.gaNqDisbMthdReqItemId=="
								+ gaNqMethodReqItemId
								+ ")].gaNqDMRIRangeLowValue");
				String gaNqDMRIType = JsonReadWriteUtils
						.getNodeValueUsingJpath(responseString,
								"$..gaNqDisbusmentMethodRequiredItem[?(@.gaNqDisbMthdReqItemId=="
										+ gaNqMethodReqItemId
										+ ")].gaNqDMRIRangeValueType");

				String ovrideIndicator = JsonReadWriteUtils
						.getNodeValueUsingJpath(responseString,
								"$..gaNqDisbusmentMethodRequiredItem[?(@.gaNqDisbMthdReqItemId=="
										+ gaNqMethodReqItemId
										+ ")].overrideAllowedIndicator");
				String disbMethdRangeHighValue = JsonReadWriteUtils
						.getNodeValueUsingJpath(responseString,
								"$..gaNqDisbusmentMethodRequiredItem[?(@.gaNqDisbMthdReqItemId=="
										+ gaNqMethodReqItemId
										+ ")].disbMthdReqItemRangeHighValue");
				String disbMthdRangeLowValue = JsonReadWriteUtils
						.getNodeValueUsingJpath(responseString,
								"$..gaNqDisbusmentMethodRequiredItem[?(@.gaNqDisbMthdReqItemId=="
										+ gaNqMethodReqItemId
										+ ")].disbMthdReqItemRangeLowValue");
				String disbMthdRangeValueType = JsonReadWriteUtils
						.getNodeValueUsingJpath(responseString,
								"$..gaNqDisbusmentMethodRequiredItem[?(@.gaNqDisbMthdReqItemId=="
										+ gaNqMethodReqItemId
										+ ")].disbMthdReqItemRangeValueType");
				String disbMthdItemTypeDesc = JsonReadWriteUtils
						.getNodeValueUsingJpath(responseString,
								"$..gaNqDisbusmentMethodRequiredItem[?(@.gaNqDisbMthdReqItemId=="
										+ gaNqMethodReqItemId
										+ ")].disbMthdItemTypeDescription");
				String disbMthdItemDispTag = JsonReadWriteUtils
						.getNodeValueUsingJpath(responseString,
								"$..gaNqDisbusmentMethodRequiredItem[?(@.gaNqDisbMthdReqItemId=="
										+ gaNqMethodReqItemId
										+ ")].disbMthdItemTypeDisplayTag");
				String disbMthdDesc = JsonReadWriteUtils
						.getNodeValueUsingJpath(responseString,
								"$..gaNqDisbusmentMethodRequiredItem[?(@.gaNqDisbMthdReqItemId=="
										+ gaNqMethodReqItemId
										+ ")].disbMthdDescription");

				String disbMthdReqItemSeqNbr = JsonReadWriteUtils
						.getNodeValueUsingJpath(
								responseString,
								"$..gaNqDisbusmentMethodRequiredItem[?(@.gaNqDisbMthdReqItemId=="
										+ gaNqMethodReqItemId
										+ ")].disbMethodReqItemDetails..sequenceNbr");

				String disbMthdReqItemPermitedVal = JsonReadWriteUtils
						.getNodeValueUsingJpath(
								responseString,
								"$..gaNqDisbusmentMethodRequiredItem[?(@.gaNqDisbMthdReqItemId=="
										+ gaNqMethodReqItemId
										+ ")].disbMethodReqItemDetails..permittedValue");

				JsonReadWriteUtils.compareValueAndLogReport(gaNqDisbRsnId,
						queryResultSet.getString("GANQDISBRSNMTHDID"),"GANQDISBRSNMTHDID");
				JsonReadWriteUtils.compareValueAndLogReport(dsmdCode,
						queryResultSet.getString("DSMDCODE"),"DSMDCODE");
				JsonReadWriteUtils.compareValueAndLogReport(
						disbMethdItemTypeCode,
						queryResultSet.getString("DISBMETHODITEMTYPECODE"),"DISBMETHODITEMTYPECODE");
				JsonReadWriteUtils.compareValueAndLogReport(gaNqDMRIHigh,
						queryResultSet.getString("GANQDMRIRANGEHIGHVALUE"),"GANQDMRIRANGEHIGHVALUE");
				JsonReadWriteUtils.compareValueAndLogReport(gaNqDMRILow,
						queryResultSet.getString("GANQDMRIRANGELOWVALUE"),"GANQDMRIRANGELOWVALUE");
				JsonReadWriteUtils.compareValueAndLogReport(gaNqDMRIType,
						queryResultSet.getString("GANQDMRIRANGEVALUETYPE"),"GANQDMRIRANGEVALUETYPE");
				JsonReadWriteUtils.compareValueAndLogReport(ovrideIndicator,
						queryResultSet.getString("OVERRIDEALLOWEDINDICATOR"),"OVERRIDEALLOWEDINDICATOR");
				JsonReadWriteUtils.compareValueAndLogReport(
						disbMethdRangeHighValue, queryResultSet
						.getString("DISBMTHDREQITEMRANGEHIGHVALUE"),"DISBMTHDREQITEMRANGEHIGHVALUE");
				JsonReadWriteUtils.compareValueAndLogReport(
						disbMthdRangeLowValue, queryResultSet
						.getString("DISBMTHDREQITEMRANGELOWVALUE"),"DISBMTHDREQITEMRANGELOWVALUE");
				JsonReadWriteUtils.compareValueAndLogReport(
						disbMthdRangeValueType, queryResultSet
						.getString("DISBMTHDREQITEMRANGEVALUETYPE"),"DISBMTHDREQITEMRANGEVALUETYPE");
				JsonReadWriteUtils
				.compareValueAndLogReport(
						disbMthdItemTypeDesc,
						queryResultSet
						.getString("DISBMTHDITEMTYPEDESCRIPTION"),"DISBMTHDITEMTYPEDESCRIPTION");
				JsonReadWriteUtils.compareValueAndLogReport(
						disbMthdItemDispTag,
						queryResultSet.getString("DISBMTHDITEMTYPEDISPLAYTAG"),"DISBMTHDITEMTYPEDISPLAYTAG");

				JsonReadWriteUtils.compareValueAndLogReport(disbMthdDesc,
						queryResultSet.getString("DISBMTHDDESCRIPTION"),"DISBMTHDDESCRIPTION");
				JsonReadWriteUtils.compareValueAndLogReport(
						disbMthdReqItemSeqNbr,
						queryResultSet.getString("MTHDREQITMSEQUENCENBR"),"MTHDREQITMSEQUENCENBR");
				JsonReadWriteUtils.compareValueAndLogReport(
						disbMthdReqItemPermitedVal,
						queryResultSet.getString("MTHDREQITMPERMITTEDVALUE"),"MTHDREQITMPERMITTEDVALUE");
				break;
			}

			// 3rd Query
			queryResultSet = DB.executeQuery("TARGETDB",
					Stock.getTestQuery("getnqContPeriodDefQuery")[1],
					Stock.GetParameterValue("gaId"));

			List<?> gaNqDefTypeCodeList = null;
			List<?> gaNqEffDateList = null;
			List<?> gaNqTermDateList = null;
			List<?> gaNqDefRateFlagList = null;
			int index = 0;
			String prevNqPeriodId = null;

			while (queryResultSet.next()) {
				String periodId = queryResultSet
						.getString("GA_NQ_CONTRIB_PERIOD_ID");

				if (prevNqPeriodId == null
						|| !periodId.equalsIgnoreCase(prevNqPeriodId)) {
					gaNqDefTypeCodeList = JsonReadWriteUtils
							.getAllMatchingNodeValues(responseString,
									"$..contributionPeriodDefrlTpInfo[?(@.gaNQContributionPeriodId == "
											+ periodId + ")].deferralTypeCode");
					gaNqEffDateList = JsonReadWriteUtils
							.getAllMatchingNodeValues(responseString,
									"$..contributionPeriodDefrlTpInfo[?(@.gaNQContributionPeriodId == "
											+ periodId + ")].effectiveDate");
					gaNqTermDateList = JsonReadWriteUtils
							.getAllMatchingNodeValues(responseString,
									"$..contributionPeriodDefrlTpInfo[?(@.gaNQContributionPeriodId == "
											+ periodId + ")].terminationDate");
					gaNqDefRateFlagList = JsonReadWriteUtils
							.getAllMatchingNodeValues(responseString,
									"$..contributionPeriodDefrlTpInfo[?(@.gaNQContributionPeriodId == "
											+ periodId
											+ ")].everGreenDeferralRateFlag");

					index = 0;
					prevNqPeriodId = periodId;
				}

				JsonReadWriteUtils.compareValueAndLogReport(gaNqDefTypeCodeList
						.get(index).toString(), queryResultSet
						.getString("DEFERRAL_TYPE_CODE"),"DEFERRAL_TYPE_CODE");
				JsonReadWriteUtils.compareDbWithDateInResponse(gaNqEffDateList
						.get(index).toString(), queryResultSet
						.getDate("EFFDATE"),"EFFDATE");
				JsonReadWriteUtils.compareDbWithDateInResponse(gaNqTermDateList
						.get(index).toString(), queryResultSet
						.getDate("TERMDATE"),"TERMDATE");
				JsonReadWriteUtils.compareValueAndLogReport(gaNqDefRateFlagList
						.get(index).toString(), queryResultSet
						.getString("EVERGREEN_DEFERRAL_RATE_FLAG"),"EVERGREEN_DEFERRAL_RATE_FLAG");

				index++;

			}

			// 5th Query

			queryResultSet = DB.executeQuery("TARGETDB",
					Stock.getTestQuery("getnqDisbDetailsQuery")[1],
					Stock.GetParameterValue("gaId"));

			String prevNqDisbRsnId = null;

			while (queryResultSet.next()) {
				String nqDisbRsnId = queryResultSet.getString("NQDISBRSNID");

				if (prevNqDisbRsnId == null || prevNqDisbRsnId != nqDisbRsnId) {

					prevNqDisbRsnId = nqDisbRsnId;
					String disbOptionId = JsonReadWriteUtils
							.getNodeValueUsingJpath(responseString,
									"$..disbursementReasonInfo[?(@.id =="
											+ nqDisbRsnId + ")].disbOptionId");

					String nqDisbCode = JsonReadWriteUtils
							.getNodeValueUsingJpath(responseString,
									"$..disbursementReasonInfo[?(@.id =="
											+ nqDisbRsnId + ")].dsrsCode");

					String nqDisbSeqNbr = JsonReadWriteUtils
							.getNodeValueUsingJpath(responseString,
									"$..disbursementReasonInfo[?(@.id =="
											+ nqDisbRsnId + ")].displaySeqNbr");

					String nqDisbCustomName = JsonReadWriteUtils
							.getNodeValueUsingJpath(responseString,
									"$..disbursementReasonInfo[?(@.id =="
											+ nqDisbRsnId + ")].customName");

					String nqDisbCustomDesc = JsonReadWriteUtils
							.getNodeValueUsingJpath(responseString,
									"$..disbursementReasonInfo[?(@.id =="
											+ nqDisbRsnId
											+ ")].customDescription");

					String nqDisbRsnDispInd = JsonReadWriteUtils
							.getNodeValueUsingJpath(responseString,
									"$..disbursementReasonInfo[?(@.id =="
											+ nqDisbRsnId
											+ ")].suppressPartDisplayIind");

					String nqDisbRsnMthdId = JsonReadWriteUtils
							.getNodeValueUsingJpath(responseString,
									"$..disbursementReasonInfo[?(@.id =="
											+ nqDisbRsnId
											+ ")].passiveDefaultEnrollmentInd");

					JsonReadWriteUtils.compareValueAndLogReport(disbOptionId,
							queryResultSet.getString("NQDISBRSNOPTID"),"NQDISBRSNOPTID");
					JsonReadWriteUtils.compareValueAndLogReport(nqDisbCode,
							queryResultSet.getString("NQDISBRSNDSRSCODE"),"NQDISBRSNDSRSCODE");
					JsonReadWriteUtils
					.compareValueAndLogReport(
							nqDisbSeqNbr,
							queryResultSet
							.getString("NQDISBRSNDISPLAYSEQNMBR"),"NQDISBRSNDISPLAYSEQNMBR");
					JsonReadWriteUtils.compareValueAndLogReport(
							nqDisbCustomName,
							queryResultSet.getString("NQDISBRSNCUSTOMNAME"),"NQDISBRSNCUSTOMNAME");
					JsonReadWriteUtils.compareValueAndLogReport(
							nqDisbCustomDesc,
							queryResultSet.getString("NQDISBRSNCUSTOMDESC"),"NQDISBRSNCUSTOMDESC");
					JsonReadWriteUtils.compareValueAndLogReport(
							nqDisbRsnDispInd,
							queryResultSet.getString("NQDISBRSNDISPLAYIND"),"NQDISBRSNDISPLAYIND");
					JsonReadWriteUtils.compareValueAndLogReport(
							nqDisbRsnMthdId,
							queryResultSet.getString("NQDISBRSNENROLLMENTIND"),"NQDISBRSNENROLLMENTIND");

					// 2nd part

					String nqDisbMthdId = queryResultSet
							.getString("NQDISBRSNMTHDID");

					String dsmdCode = JsonReadWriteUtils
							.getNodeValueUsingJpath(responseString,
									"$..disbursementReasonMethod[?(@.id =="
											+ nqDisbMthdId + ")].dsmdCode");

					String customName = JsonReadWriteUtils
							.getNodeValueUsingJpath(responseString,
									"$..disbursementReasonMethod[?(@.id =="
											+ nqDisbMthdId + ")].customName");

					String customDescription = JsonReadWriteUtils
							.getNodeValueUsingJpath(responseString,
									"$..disbursementReasonMethod[?(@.id =="
											+ nqDisbMthdId
											+ ")].customDescription");

					String descr = JsonReadWriteUtils.getNodeValueUsingJpath(
							responseString,
							"$..disbursementReasonMethod[?(@.id =="
									+ nqDisbMthdId + ")].descr");

					JsonReadWriteUtils.compareValueAndLogReport(dsmdCode,
							queryResultSet.getString("NQDISBRSNMTHDDSMDCODE"),"NQDISBRSNMTHDDSMDCODE");

					JsonReadWriteUtils
					.compareValueAndLogReport(
							customName,
							queryResultSet
							.getString("NQDISBRSNMTHDCUSTOMNAME"),"NQDISBRSNMTHDCUSTOMNAME");
					JsonReadWriteUtils
					.compareValueAndLogReport(
							customDescription,
							queryResultSet
							.getString("NQDISBRSNMTHDCUSTOMDESC"),"NQDISBRSNMTHDCUSTOMDESC");
					JsonReadWriteUtils.compareValueAndLogReport(descr,
							queryResultSet.getString("NQDISBMTHDDESCR"),"NQDISBMTHDDESCR");

					// 3rd

					String nqDusbMthMgId = queryResultSet
							.getString("NQDISBRSNMTHTMGID");

					String ngTmgCode = JsonReadWriteUtils
							.getNodeValueUsingJpath(responseString,
									"$..disbursementReasonMethodTmg[?(@.id =="
											+ nqDusbMthMgId + ")].tmgCode");

					String nqTmgFlag = JsonReadWriteUtils
							.getNodeValueUsingJpath(responseString,
									"$..disbursementReasonMethodTmg[?(@.id =="
											+ nqDusbMthMgId
											+ ")].automatedSolutionFlag");
					String nqTmgDesc = JsonReadWriteUtils
							.getNodeValueUsingJpath(responseString,
									"$..disbursementReasonMethodTmg[?(@.id =="
											+ nqDusbMthMgId
											+ ")].disbTimingDescription");

					String tmgCustomName = JsonReadWriteUtils
							.getNodeValueUsingJpath(responseString,
									"$..disbursementReasonMethodTmg[?(@.id =="
											+ nqDusbMthMgId + ")].customName");

					String tmgCustDesc = JsonReadWriteUtils
							.getNodeValueUsingJpath(responseString,
									"$..disbursementReasonMethodTmg[?(@.id =="
											+ nqDusbMthMgId
											+ ")].customDescription");

					JsonReadWriteUtils.compareValueAndLogReport(ngTmgCode,
							queryResultSet.getString("NQDISBRSNMTHTMGCODE"),"NQDISBRSNMTHTMGCODE");

					JsonReadWriteUtils.compareValueAndLogReport(nqTmgFlag,
							queryResultSet.getString("NQDISBRSNMTHTMGFLAG"),"NQDISBRSNMTHTMGFLAG");
					JsonReadWriteUtils.compareValueAndLogReport(nqTmgDesc,
							queryResultSet.getString("NQTIMINGDESCRIPTION"),"NQTIMINGDESCRIPTION");
					JsonReadWriteUtils.compareValueAndLogReport(tmgCustomName,
							queryResultSet
							.getString("NQDISBRSNMTHTMGCUSTOMNAME"),"NQDISBRSNMTHTMGCUSTOMNAME");
					JsonReadWriteUtils.compareValueAndLogReport(tmgCustDesc,
							queryResultSet
							.getString("NQDISBRSNMTHTMGCUSTOMDESC"),"NQDISBRSNMTHTMGCUSTOMDESC");

					String ngDisbTmgReqItemId = queryResultSet
							.getString("NQDISBTMGREQITEMID");

					String tmgItemTypeCode = JsonReadWriteUtils
							.getNodeValueUsingJpath(responseString,
									"$..disbursementTMGReqItem[?(@.id == "
											+ ngDisbTmgReqItemId
											+ ")].tmgItemTypeCode");
					String tmgValueType = JsonReadWriteUtils
							.getNodeValueUsingJpath(responseString,
									"$..disbursementTMGReqItem[?(@.id == "
											+ ngDisbTmgReqItemId
											+ ")].rangeValueType");
					String tmgCode = JsonReadWriteUtils.getNodeValueUsingJpath(
							responseString,
							"$..disbursementTMGReqItem[?(@.id == "
									+ ngDisbTmgReqItemId + ")].tmgCode");

					String timingCode = JsonReadWriteUtils
							.getNodeValueUsingJpath(responseString,
									"$..disbursementTMGReqItem[?(@.id == "
											+ ngDisbTmgReqItemId
											+ ")].disbTimingReqItem.timingCode");

					String timingItemTypeCode = JsonReadWriteUtils
							.getNodeValueUsingJpath(
									responseString,
									"$..disbursementTMGReqItem[?(@.id == "
											+ ngDisbTmgReqItemId
											+ ")].disbTimingReqItem.timingItemTypeCode");

					String timingRangeValueType = JsonReadWriteUtils
							.getNodeValueUsingJpath(
									responseString,
									"$..disbursementTMGReqItem[?(@.id == "
											+ ngDisbTmgReqItemId
											+ ")].disbTimingReqItem.timingRangeValueType");

					JsonReadWriteUtils.compareValueAndLogReport(
							tmgItemTypeCode, queryResultSet
							.getString("NQDISBTMGREQITEMITEMTYPE"),"NQDISBTMGREQITEMITEMTYPE");
					JsonReadWriteUtils.compareValueAndLogReport(tmgValueType,
							queryResultSet
							.getString("NQDISBTMGREQITEMVALUETYPE"),"NQDISBTMGREQITEMVALUETYPE");
					JsonReadWriteUtils
					.compareValueAndLogReport(tmgCode, queryResultSet
							.getString("NQDISBTMGREQITEMTMGCODE"),"NQDISBTMGREQITEMTMGCODE");
					JsonReadWriteUtils.compareValueAndLogReport(timingCode,
							queryResultSet.getString("NQTIMINGREQCODE"),"NQTIMINGREQCODE");
					JsonReadWriteUtils.compareValueAndLogReport(
							timingItemTypeCode,
							queryResultSet.getString("NQTIMINGREQITEMTYPE"),"NQTIMINGREQITEMTYPE");
					JsonReadWriteUtils.compareValueAndLogReport(
							timingRangeValueType,
							queryResultSet.getString("NQTIMINGREQVALUETYPE"),"NQTIMINGREQVALUETYPE");

				}
				break;
			}

		} catch (Exception e) {
			e.printStackTrace();
			Globals.exception = e;
			String errorMsg = e.getMessage();
			Reporter.logEvent(Status.FAIL, "A run time exception occured.",
					errorMsg, false);
		} catch (Error ae) {
			ae.printStackTrace();
			Globals.error = ae;
			String errorMsg = ae.getMessage();
			Reporter.logEvent(Status.FAIL, "Assertion Error Occured", errorMsg,
					false);
		} finally {
			try {
				Reporter.finalizeTCReport();
			} catch (Exception e1) {
				e1.printStackTrace();
			}
		}
	}

	@Test(dataProvider="setData")
	public void TC03_BCOM_NQ_Get_Account_Based_Defferal_Positive_Flow(int itr, Map<String, String>testData)
	{
		String requestUrl = null;
		ArrayList<String> nqStrucIDs = new ArrayList<String>();
		ArrayList<String> nqStrucEnrlPeriodID = new ArrayList<String>();
		int i=0;
		int j=0;
		try
		{
			Reporter.initializeReportForTC(itr, "");
			web = new WebserviceUtil();
			/*String endPoint = "db/" + Stock.GetParameterValue("dbName")
					+ "/gaId/" + Stock.GetParameterValue("gaId")
					+"/indId/"+Stock.GetParameterValue("indId")
					+"/effDate/"+Stock.GetParameterValue("effdate");*/
			String endPoint = JsonUtil.formRequestURL(Stock.GetParameterValue("serviceURL"), 
					Stock.GetParameterValue("gaId"),
					Stock.GetParameterValue("dbName"),
					Stock.GetParameterValue("indId"));
			response = new Response();

			response.setusername(Stock.GetParameterValue("username"));
			response.setPassword(Stock.GetParameterValue("password"));

			jsonRequestString = JsonUtil.writeToJson(response);

			Reporter.logEvent(Status.INFO, "Request body of first response",
					jsonRequestString, false);

			HttpResponse resp1 = web.getResponseasJsonforPostRequest(
					Stock.GetParameterValue("authURL"), jsonRequestString);
			System.out.println(resp1.toString());
			String authCode = resp1.getFirstHeader("Authorization").getValue();
			System.out.println("AuthCode: " + authCode);

			Reporter.logEvent(Status.INFO,
					"The Auth code for second webservice header",
					"\nThe Auth code for second webservice header is:\n"
							+ authCode, false);
			requestUrl = Stock.GetParameterValue("serviceURL") + endPoint;
			Reporter.logEvent(Status.INFO, "The request url for GET",
					requestUrl, false);
			HttpGet getReq = new HttpGet(requestUrl);
			getReq.addHeader("Authorization", "JWT " + authCode);
			HttpResponse response = web.getResponseasJsonforGet(getReq);
			int code = response.getStatusLine().getStatusCode();

			if (code == 200)
				Reporter.logEvent(Status.PASS, "Verify the status code",
						"Expected 200" + " Actual " + code, false);
			else
				Reporter.logEvent(Status.FAIL, "Verify the status code",
						"Expected 200" + " Actual " + code, false);
			String responseString = web.getHttpResponseAsString(response);
			Reporter.logEvent(Status.INFO, "The response", responseString,
					false);

			Stock.setConfigParam("TARGETDB",
					"D_" + Stock.GetParameterValue("dbName").toUpperCase());
			//get NQ Struc ID
			queryResultSet = DB.executeQuery("TARGETDB",
					Stock.getTestQuery("getNqStrucID")[1],
					Stock.GetParameterValue("gaId"),
					Stock.GetParameterValue("effdate"),
					Stock.GetParameterValue("effdate"));

			while(queryResultSet.next())
			{
				nqStrucIDs.add(i, queryResultSet.getString("ID"));
				i++;
			}

			System.out.println("nq Struc IDs"+nqStrucIDs);

			//get NQ Struc Enrol period id
			for(int k=0;k<nqStrucIDs.size();k++)
			{
				queryResultSet = DB.executeQuery("TARGETDB",
						Stock.getTestQuery("getNqStrucEnrlPeriodID")[1],
						nqStrucIDs.get(k),
						nqStrucIDs.get(k),
						Stock.GetParameterValue("effdate"));
				while(queryResultSet.next())
				{
					nqStrucEnrlPeriodID.add(j, queryResultSet.getString("ID"));
					j++;
				}
			}
			System.out.println("nq Struc enrollment period IDs"+nqStrucEnrlPeriodID);
			//get Account based deferral
			for(int k=0;k<nqStrucEnrlPeriodID.size();k++)
			{
				queryResultSet = DB.executeQuery("TARGETDB", 
						Stock.getTestQuery("getAccountBasedDeferralInfo")[1], 
						Stock.GetParameterValue("indId"),
						Stock.GetParameterValue("gaId"),
						nqStrucEnrlPeriodID.get(k));
			}

		}
		catch(Exception e)
		{
			e.printStackTrace();
			Globals.exception = e;
			String errorMsg = e.getMessage();
			Reporter.logEvent(Status.FAIL, "A run time exception occured.",
					errorMsg, false);
		}
		catch (Error ae) {
			ae.printStackTrace();
			Globals.error = ae;
			String errorMsg = ae.getMessage();
			Reporter.logEvent(Status.FAIL, "Assertion Error Occured", errorMsg,
					false);
		} finally {
			try {
				Reporter.finalizeTCReport();
			} catch (Exception e1) {
				e1.printStackTrace();
			}
		}
	}

	@Test(dataProvider="setData")
	public void TC03_01_BCOM_NQ_Get_Account_Based_Defferal_Negative_Flow(int itr, Map<String, String>testData)
	{
		String requestUrl = null;
		try
		{
			Reporter.initializeReportForTC(itr, "");
			web = new WebserviceUtil();
			String endPoint = "db/" + Stock.GetParameterValue("dbName")
					+ "/gaId/" + Stock.GetParameterValue("gaId")
					+"/indId/"+Stock.GetParameterValue("indId")
					+"/effDate/"+Stock.GetParameterValue("effdate");
			response = new Response();

			response.setusername(Stock.GetParameterValue("username"));
			response.setPassword(Stock.GetParameterValue("password"));

			jsonRequestString = JsonUtil.writeToJson(response);

			Reporter.logEvent(Status.INFO, "Request body of first response",
					jsonRequestString, false);

			HttpResponse resp1 = web.getResponseasJsonforPostRequest(
					Stock.GetParameterValue("authURL"), jsonRequestString);
			System.out.println(resp1.toString());
			String authCode = resp1.getFirstHeader("Authorization").getValue();
			System.out.println("AuthCode: " + authCode);

			Reporter.logEvent(Status.INFO,
					"The Auth code for second webservice header",
					"\nThe Auth code for second webservice header is:\n"
							+ authCode, false);
			requestUrl = Stock.GetParameterValue("serviceURL") + endPoint;
			Reporter.logEvent(Status.INFO, "The request url for GET",
					requestUrl, false);
			HttpGet getReq = new HttpGet(requestUrl);
			getReq.addHeader("Authorization", "JWT " + authCode+"Invalid");
			HttpResponse response = web.getResponseasJsonforGet(getReq);
			int code = response.getStatusLine().getStatusCode();

			if (code == 500)
				Reporter.logEvent(Status.PASS, "Verify the status code",
						"Expected 500" + " Actual " + code, false);
			else
				Reporter.logEvent(Status.FAIL, "Verify the status code",
						"Expected 500" + " Actual " + code, false);
			String responseString = web.getHttpResponseAsString(response);
			Reporter.logEvent(Status.INFO, "The response", responseString,
					false);

		}
		catch(Exception e)
		{
			e.printStackTrace();
			Globals.exception = e;
			String errorMsg = e.getMessage();
			Reporter.logEvent(Status.FAIL, "A run time exception occured.",
					errorMsg, false);
		}
		catch (Error ae) {
			ae.printStackTrace();
			Globals.error = ae;
			String errorMsg = ae.getMessage();
			Reporter.logEvent(Status.FAIL, "Assertion Error Occured", errorMsg,
					false);
		} finally {
			try {
				Reporter.finalizeTCReport();
			} catch (Exception e1) {
				e1.printStackTrace();
			}
		}


	}

	@SuppressWarnings("unchecked")
	@Test(dataProvider="setData")
	public void TC04_01_BCOM_NQ_NonQual_Get_Part_Disb_Deferral_Elections_Positive_Flow(int itr, Map<String,String> testData)
	{
		String requestUrl = null;
		String strucID = null;

		try
		{
			Reporter.initializeReportForTC(itr, 
					"Test Case validates the NonQual Get Part Distribution Deferral Elections for"
							+ " Single Elections input provided in the request.");
			web = new WebserviceUtil();
			String endPoint = "db/" + Stock.GetParameterValue("dbName")
					+ "/gaId/" + Stock.GetParameterValue("gaId")
					+"/indId/"+Stock.GetParameterValue("indId")
					+"?strucId="+Stock.GetParameterValue("strucId");

			response = new Response();

			response.setusername(Stock.GetParameterValue("username"));
			response.setPassword(Stock.GetParameterValue("password"));

			jsonRequestString = JsonUtil.writeToJson(response);

			Reporter.logEvent(Status.INFO, "Request body of first response",
					jsonRequestString, false);

			HttpResponse resp1 = web.getResponseasJsonforPostRequest(
					Stock.GetParameterValue("authURL"), jsonRequestString);
			System.out.println(resp1.toString());
			String authCode = resp1.getFirstHeader("Authorization").getValue();
			System.out.println("AuthCode: " + authCode);

			Reporter.logEvent(Status.INFO,
					"The Auth code for second webservice header",
					"\nThe Auth code for second webservice header is:\n"
							+ authCode, false);
			requestUrl = Stock.GetParameterValue("serviceURL") + endPoint;
			Reporter.logEvent(Status.INFO, "The request url for GET",
					requestUrl, false);
			HttpGet getReq = new HttpGet(requestUrl);
			getReq.addHeader("Authorization", "JWT " + authCode);
			HttpResponse response = web.getResponseasJsonforGet(getReq);
			int code = response.getStatusLine().getStatusCode();

			if (code == 200)
				Reporter.logEvent(Status.PASS, "Verify the status code",
						"Expected 200" + " Actual " + code, false);
			else
				Reporter.logEvent(Status.FAIL, "Verify the status code",
						"Expected 200" + " Actual " + code, false);
			String responseString = web.getHttpResponseAsString(response);
			Reporter.logEvent(Status.INFO, "The response", responseString,
					false);

			Stock.setConfigParam("TARGETDB",
					"D_" + Stock.GetParameterValue("dbName").toUpperCase());
			//1st Query-->Verify Structure table details in the response
			queryResultSet = DB.executeQuery("TARGETDB", Stock.getTestQuery("getStrucIDDefElec")[1], 
					Stock.GetParameterValue("gaId"),
					Stock.GetParameterValue("strucId"));
			while(queryResultSet.next())
			{
				strucID = queryResultSet.getString("ID");

				String strucNameInRes = JsonReadWriteUtils.
						getNodeValueUsingJpath(responseString, 
								"$..[?(@.strucId=="+strucID+")].structureName");

				String displaySeqInRes = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
						"$..[?(@.strucId=="+strucID+")].displaySequence");
				String strucMnyTypIdInRes = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
						"$..[?(@.strucId=="+strucID+")].strucMntyId");
				String strucDescInRes = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
						"$..[?(@.strucId=="+strucID+")].structureDesc");
				String strucTypeCodeInRes = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
						"$..[?(@.strucId=="+strucID+")].structureTypeCode");
				String strucClsYearInRes = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
						"$..[?(@.strucId=="+strucID+")].structureClassYear");

				JsonReadWriteUtils.compareValueAndLogReport(strucNameInRes, 
						queryResultSet.getString("NAME"), "Structure Name");
				JsonReadWriteUtils.compareValueAndLogReport(displaySeqInRes, 
						queryResultSet.getString("DISPLAY_SEQNBR"), "DISPLAY_SEQNBR");
				JsonReadWriteUtils.compareValueAndLogReport(strucDescInRes, 
						queryResultSet.getString("DESCRIPTION"), "DESCRIPTION");
				JsonReadWriteUtils.compareValueAndLogReport(strucTypeCodeInRes, 
						queryResultSet.getString("STRUC_TYPE_CODE"), "STRUC_TYPE_CODE");
				JsonReadWriteUtils.compareValueAndLogReport(strucClsYearInRes, 
						queryResultSet.getString("CLASS_YEAR"), "CLASS_YEAR");


			}

			//2nd part--> Verify NQ_PART_DISB_REQUEST_VIEW table data
			queryResultSet = DB.executeQuery("TARGETDB", Stock.getTestQuery("getSingleElectionData")[1],
					Stock.GetParameterValue("gaId"),
					Stock.GetParameterValue("indId"),
					Stock.GetParameterValue("strucId"));
			while(queryResultSet.next())
			{
				String strucDisbGrpNameInRes = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
						"$..[?(@.strucId=="+strucID+")]..structureDisbursementGroupName");
				String strucDisbGrpDescInRes = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
						"$..[?(@.strucId=="+strucID+")]..structureDisbursementGroupDesc");
				String effDateInRes = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
						"$..[?(@.strucId=="+strucID+")]..effDate");

				String termDateInRes = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
						"$..[?(@.strucId=="+strucID+")]..termDate");
				String strucDisbGrpIdInRes = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
						"$..[?(@.strucId=="+strucID+")]..structureDisbursementGroupId");

				List<String> sdmatCodeInRes = (List<String>)JsonReadWriteUtils.getAllMatchingNodeValues(
						responseString, "$..[?(@.strucId=="+strucID+")]..structureDisbursementGroupMoneyTypes..sdmtCode");
				Set<String> sdmtCodesInRes = new HashSet<String>(sdmatCodeInRes);

				List<String> mntyIdsInRes = (List<String>) JsonReadWriteUtils.getAllMatchingNodeValues(
						responseString,"$..[?(@.strucId=="+strucID+")]..structureDisbursementGroupMoneyTypes..mntyId");
				Set<String> mntyIdInRes = new HashSet<String>(mntyIdsInRes);

				List<String> gdmtSeqNbrInRes = (List<String>) JsonReadWriteUtils.getAllMatchingNodeValues(
						responseString,"$..[?(@.strucId=="+strucID+")]..structureDisbursementGroupMoneyTypes..gdmtSeqNbr");
				Set<String> gdmtSeqNbrsInRes = new HashSet<String>(gdmtSeqNbrInRes);


				String disbOptNameInRes = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
						"$..[?(@.strucId=="+strucID+")]..disbursementOption.disbursementOptionName");
				String disbOptIdInRes = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
						"$..[?(@.strucId=="+strucID+")]..disbursementOption.disbursementOptionId");

				List<String> reasonCodesInRes = (List<String>) JsonReadWriteUtils.getAllMatchingNodeValues(responseString, 
						"$..[?(@.strucId=="+strucID+")]..disbursementOption..reasonCode");
				Set<String> reasonCodeInRes = new HashSet<String>(reasonCodesInRes);

				String suppressPartDisplayIndInRes = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
						"$..[?(@.strucId=="+strucID+")]..disbursementOption..suppressPartDisplayInd");

				List<String> disbursementReasonMethodTimingIdsInRes = (List<String>) JsonReadWriteUtils.getAllMatchingNodeValues(responseString, 
						"$..[?(@.strucId=="+strucID+")]..disbursementOption..disbursementReasonMethodTimingId");
				Set<String> disbursementReasonMethodTimingIdInRes = new HashSet<String>(disbursementReasonMethodTimingIdsInRes);
				String passiveDefaultEnrollmentIndInRes = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
						"$..[?(@.strucId=="+strucID+")]..disbursementOption..passiveDefaultEnrollmentInd");

				List<String> disbReasonDispSeqsInRes = (List<String>) JsonReadWriteUtils.getAllMatchingNodeValues(responseString, 
						"$..[?(@.strucId=="+strucID+")]..disbursementOption..disbursementReasonDisplaySequence");
				Set<String> disbReasonDispSeqInRes = new HashSet<String>(disbReasonDispSeqsInRes);

				List<String> disbReasonCustNamesInRes = (List<String>) JsonReadWriteUtils.getAllMatchingNodeValues(responseString, 
						"$..[?(@.strucId=="+strucID+")]..disbursementOption..disbursementReasonCustomName");
				Set<String> disbReasonCustNameInRes = new HashSet<String>(disbReasonCustNamesInRes);
				List<String> disbReasonCustDescsInRes = (List<String>) JsonReadWriteUtils.getAllMatchingNodeValues(responseString, 
						"$..[?(@.strucId=="+strucID+")]..disbursementOption..disbursementReasonCustomDescription");
				Set<String> disbReasonCustDescInRes = new HashSet<String>(disbReasonCustDescsInRes);
				String methodCodeInRes = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
						"$..[?(@.strucId=="+strucID+")]..disbursementOption..methodCode");
				String disbMthdCustmNameInRes = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
						"$..[?(@.strucId=="+strucID+")]..disbursementOption..disbursementMethodCustomName");
				String disbMthdCustmDescInRes = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
						"$..[?(@.strucId=="+strucID+")]..disbursementOption..disbursementMethodCustomDescription");
				String methodRequestItemIdInRes = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
						"$..[?(@.strucId=="+strucID+")]..disbursementOption..methodRequestItemId");
				String methodReqstItmSeqInRes = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
						"$..[?(@.strucId=="+strucID+")]..disbursementOption..methodRequestItemSequence");
				String methodRequestItemCodeInRes = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
						"$..[?(@.strucId=="+strucID+")]..disbursementOption..methodRequestItemCode");
				String methodRequestItemDescriptionInRes= JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
						"$..[?(@.strucId=="+strucID+")]..disbursementOption..methodRequestItemDescription");
				String methodRequestItemTypeCodeInRes = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
						"$..[?(@.strucId=="+strucID+")]..disbursementOption..methodRequestItemTypeCode");
				String methodRequestItemDateValueInRes = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
						"$..[?(@.strucId=="+strucID+")]..disbursementOption..methodRequestItemDateValue");
				String methodRequestItemNumericValueInRes= JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
						"$..[?(@.strucId=="+strucID+")]..disbursementOption..methodRequestItemNumericValue");
				String methodRequestItemCharacterValueInRes = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
						"$..[?(@.strucId=="+strucID+")]..disbursementOption..methodRequestItemCharacterValue");

				String timingCodeInRes = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
						"$..[?(@.strucId=="+strucID+")]..disbursementOption..timingCode");

				List<String> disbTimingCustomNamesInRes = (List<String>)JsonReadWriteUtils.getAllMatchingNodeValues(responseString, 
						"$..[?(@.strucId=="+strucID+")]..disbursementOption..disbursementTimingCustomName");
				Set<String> disbTimingCustomNameInRes = new HashSet<String>(disbTimingCustomNamesInRes);


				List<String> disbTimingCustmDescsInRes = (List<String>)JsonReadWriteUtils.getAllMatchingNodeValues(responseString, 
						"$..[?(@.strucId=="+strucID+")]..disbursementOption..disbursementTimingCustomDescription");
				Set<String> disbTimingCustmDescInRes = new HashSet<String>(disbTimingCustmDescsInRes);

				String timingReqItmIdInRes = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
						"$..[?(@.strucId=="+strucID+")]..disbursementOption..timingRequestItemId");
				String timingRequestItemSequenceInRes = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
						"$..[?(@.strucId=="+strucID+")]..disbursementOption..timingRequestItemSequence");
				String timingRequestItemDescriptionInRes = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
						"$..[?(@.strucId=="+strucID+")]..disbursementOption..timingRequestItemDescription");
				String timingRequestItemTypeCodeInRes = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
						"$..[?(@.strucId=="+strucID+")]..disbursementOption..timingRequestItemTypeCode");
				String timingRequestItemNumericValueInRes = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
						"$..[?(@.strucId=="+strucID+")]..disbursementOption..timingRequestItemNumericValue");
				String timingPassiveDefaultEnrollmentIndInRes = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
						"$..[?(@.strucId=="+strucID+")]..disbursementOption..timingPassiveDefaultEnrollmentInd");
				String timingRequestItemCharacterValueInRes = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
						"$..[?(@.strucId=="+strucID+")]..disbursementOption..timingRequestItemCharacterValue");
				String timingRequestItemDateValueInRes = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
						"$..[?(@.strucId=="+strucID+")]..disbursementOption..timingRequestItemDateValue");
				if (JsonReadWriteUtils.compareDbWithDateInResponse(effDateInRes, queryResultSet.getDate("NQ_DIST_REQ_EFFDATE"))){
					JsonReadWriteUtils.compareValueAndLogReport(strucDisbGrpNameInRes,
							queryResultSet.getString("GA_NQ_STRUC_DISB_GRP_NAME"), "structureDisbursementGroupName");
					JsonReadWriteUtils.compareValueAndLogReport(strucDisbGrpDescInRes, 
							queryResultSet.getString("GA_NQ_STRUC_DISB_GRP_DESC"), "structureDisbursementGroupDesc");
					JsonReadWriteUtils.compareDbWithDateInResponse(effDateInRes, 
							queryResultSet.getDate("NQ_DIST_REQ_EFFDATE"), "effDate");
					JsonReadWriteUtils.compareValueAndLogReport(termDateInRes, 
							queryResultSet.getString("NQ_DIST_REQ_TERMDATE"), "termDate");
					JsonReadWriteUtils.compareValueAndLogReport(strucDisbGrpIdInRes, 
							queryResultSet.getString("NQ_DIST_REQ_DISB_GRP_ID"), "structureDisbursementGroupId");

					if(sdmtCodesInRes.contains(queryResultSet.getString("GA_NQ_STRUC_MNTY_SDMT_CODE")))
					{
						Reporter.logEvent(Status.PASS,"Check sdmtCode:"+ queryResultSet.getString("GA_NQ_STRUC_MNTY_SDMT_CODE")
								+" is available in response", "Response value is available in database", false);
					}
					else
					{
						Reporter.logEvent(Status.FAIL,"Check sdmtCode:"+ queryResultSet.getString("GA_NQ_STRUC_MNTY_SDMT_CODE")
								+" is available in response", "Response value is available in database", false);
					}
					if(gdmtSeqNbrsInRes.contains(queryResultSet.getString("GA_NQ_STRUC_MNTY_SEQNBR")))
					{
						Reporter.logEvent(Status.PASS,"Check gdmtSeqNbr:"+ queryResultSet.getString("GA_NQ_STRUC_MNTY_SEQNBR")
								+" is available in response", "Response value is available in database", false);
					}
					else
					{
						Reporter.logEvent(Status.FAIL,"Check gdmtSeqNbr:"+ queryResultSet.getString("GA_NQ_STRUC_MNTY_SEQNBR")
								+" is available in response", "Response value is available in database", false);
					}
					if(mntyIdInRes.contains(queryResultSet.getString("GA_NQ_STRUC_MNTY_ID")))
					{
						Reporter.logEvent(Status.PASS,"Check mntyIdInRes:"+ queryResultSet.getString("GA_NQ_STRUC_MNTY_ID")
								+" is available in response", "Response value is available in database", false);
					}
					else
					{
						Reporter.logEvent(Status.FAIL,"Check mntyIdInRes:"+ queryResultSet.getString("GA_NQ_STRUC_MNTY_ID")
								+" is available in response", "Response value is available in database", false);
					}
					/*JsonReadWriteUtils.compareValueAndLogReport(mntyIdInRes.get(i), 
						queryResultSet.getString("GA_NQ_STRUC_MNTY_ID"), "mntyId");
				JsonReadWriteUtils.compareValueAndLogReport(gdmtSeqNbrInRes.get(i), 
						queryResultSet.getString("GA_NQ_STRUC_MNTY_SEQNBR"), "gdmtSeqNbr");*/

					JsonReadWriteUtils.compareValueAndLogReport(disbOptNameInRes, 
							queryResultSet.getString("GA_NQ_DISB_OPTION_NAME"), "disbursementOptionName");
					JsonReadWriteUtils.compareValueAndLogReport(disbOptIdInRes, 
							queryResultSet.getString("GA_NQ_DISB_OPTION_ID"), "disbursementOptionId");

					JsonReadWriteUtils.compareValueAndLogReport(reasonCodeInRes, 
							queryResultSet.getString("GA_NQ_DISB_REASON_CODE"), "reasonCode");

					JsonReadWriteUtils.compareValueAndLogReport(suppressPartDisplayIndInRes, 
							queryResultSet.getString("GA_NQ_DISB_RSN_SUP_PRT_DSP"), "suppressPartDisplayInd");
					JsonReadWriteUtils.compareValueAndLogReport(disbursementReasonMethodTimingIdInRes, 
							queryResultSet.getString("NQ_DISTREAS_MTHD_TMG_ID"), "disbursementReasonMethodTimingId");
					JsonReadWriteUtils.compareValueAndLogReport(passiveDefaultEnrollmentIndInRes, 
							queryResultSet.getString("GA_NQ_DISB_RSN_PSV_DEF_ENR"), "passiveDefaultEnrollmentInd");
					JsonReadWriteUtils.compareValueAndLogReport(disbReasonDispSeqInRes, 
							queryResultSet.getString("GA_NQ_DISB_REASON_DSPL_SEQ"), "disbursementReasonDisplaySequence");
					JsonReadWriteUtils.compareValueAndLogReport(disbReasonCustNameInRes, 
							queryResultSet.getString("GA_NQ_DISB_REASON_NAME"), "disbursementReasonCustomName");
					JsonReadWriteUtils.compareValueAndLogReport(disbReasonCustDescInRes, 
							queryResultSet.getString("GA_NQ_DISB_REASON_DESC"), "disbursementReasonCustomDescription");

					JsonReadWriteUtils.compareValueAndLogReport(methodCodeInRes, 
							queryResultSet.getString("DIST_MTHD_CODE"),"methodCode");
					JsonReadWriteUtils.compareValueAndLogReport(disbMthdCustmNameInRes, 
							queryResultSet.getString("DIST_MTHD_NAME"),"disbursementMethodCustomName");
					JsonReadWriteUtils.compareValueAndLogReport(disbMthdCustmDescInRes, 
							queryResultSet.getString("DIST_MTHD_DESC"),"disbursementMethodCustomDescription");
					JsonReadWriteUtils.compareValueAndLogReport(methodRequestItemIdInRes, 
							queryResultSet.getString("NQ_DISTREQ_ELCTMTHD_ITMID"),"methodRequestItemId");
					JsonReadWriteUtils.compareValueAndLogReport(methodReqstItmSeqInRes, 				
							queryResultSet.getString("NQ_DIST_MTHD_REQ_ELCT_SEQNBR"),"methodRequestItemSequence");
					JsonReadWriteUtils.compareValueAndLogReport(methodRequestItemCodeInRes, 
							queryResultSet.getString("DIST_METHOD_ITM_TYPE_CODE"),"methodRequestItemCode");
					JsonReadWriteUtils.compareValueAndLogReport(methodRequestItemDescriptionInRes, 
							queryResultSet.getString("DIST_METHOD_ITM_TYPE_DESC"),"methodRequestItemDescription");
					JsonReadWriteUtils.compareValueAndLogReport(methodRequestItemTypeCodeInRes, 
							queryResultSet.getString("DIST_METHOD_ITM_TYPE_CODE"),"methodRequestItemTypeCode");
					JsonReadWriteUtils.compareValueAndLogReport(methodRequestItemDateValueInRes, 
							queryResultSet.getString("NQ_DISTREQ_ELCTMTHD_ITM_DTVAL"),"methodRequestItemDateValue");
					JsonReadWriteUtils.compareValueAndLogReport(methodRequestItemNumericValueInRes, 
							queryResultSet.getString("NQ_DISTREQ_ELCTMTHD_ITM_NUMVAL"),"methodRequestItemNumericValue");
					JsonReadWriteUtils.compareValueAndLogReport(methodRequestItemCharacterValueInRes, 
							queryResultSet.getString("NQ_DISTREQ_ELCTMTHD_ITM_CHVAL"),"methodRequestItemCharacterValue");

					JsonReadWriteUtils.compareValueAndLogReport(timingCodeInRes, 
							queryResultSet.getString("GA_NQ_DISB_TMG_CODE"),"timingCode");
					JsonReadWriteUtils.compareValueAndLogReport(disbTimingCustomNameInRes, 
							queryResultSet.getString("GA_NQ_DISB_TMG_NAME"),"disbursementTimingCustomName");
					JsonReadWriteUtils.compareValueAndLogReport(disbTimingCustmDescInRes, 
							queryResultSet.getString("GA_NQ_DISB_TMG_DESC"),"disbursementTimingCustomDescription");
					JsonReadWriteUtils.compareValueAndLogReport(timingReqItmIdInRes, 
							queryResultSet.getString("NQ_DISTREQ_ELCT_TMG_ITM_ID"),"timingRequestItemId");
					JsonReadWriteUtils.compareValueAndLogReport(timingRequestItemSequenceInRes, 
							queryResultSet.getString("NQ_DIST_TMG_REQ_ELCT_SEQNBR"),"timingRequestItemSequence");
					JsonReadWriteUtils.compareValueAndLogReport(timingRequestItemDescriptionInRes, 
							queryResultSet.getString("DIST_TIMING_ITMTYPE_DESC"),"timingRequestItemDescription");
					JsonReadWriteUtils.compareValueAndLogReport(timingRequestItemTypeCodeInRes, 
							queryResultSet.getString("DIST_TIMING_ITMTYPE_CODE"),"timingRequestItemTypeCode");

					JsonReadWriteUtils.compareValueAndLogReport(timingRequestItemNumericValueInRes, 
							queryResultSet.getString("NQ_DISTREQ_ELCT_TMG_ITM_NUMVAL"),"timingRequestItemNumericValue");
					JsonReadWriteUtils.compareValueAndLogReport(timingPassiveDefaultEnrollmentIndInRes, 
							queryResultSet.getString("GA_NQ_DISB_TMG_PSV_DEF_ENR"),"timingPassiveDefaultEnrollmentInd");
					JsonReadWriteUtils.compareValueAndLogReport(timingRequestItemCharacterValueInRes, 
							queryResultSet.getString("NQ_DISTREQ_ELCT_TMG_ITM_CHVAL"),"timingRequestItemCharacterValue");
					JsonReadWriteUtils.compareValueAndLogReport(timingRequestItemDateValueInRes, 
							queryResultSet.getString("NQ_DISTREQ_ELCT_TMG_ITM_DTVAL"),"timingRequestItemDateValue");
				}}
		}
		catch(Exception e)
		{
			e.printStackTrace();
			Globals.exception = e;
			String errorMsg = e.getMessage();
			Reporter.logEvent(Status.FAIL, "A run time exception occured.",
					errorMsg, false);
		}
		finally {
			try {
				Reporter.finalizeTCReport();
			} catch (Exception e1) {
				e1.printStackTrace();
			}
		}
	}

	/**
	 * @param itr
	 * @param testData
	 */
	@Test(dataProvider="setData")
	public void TC04_02_BCOM_NQ_NonQual_Get_Part_Disb_Deferral_Elections_Negative_Flow(int itr, Map<String,String> testData)
	{
		String requestURL;
		try
		{
			Reporter.initializeReportForTC(itr, Globals.GC_MANUAL_TC_NAME,
					Stock.GetParameterValue("description"));
			web = new WebserviceUtil();
			requestURL = JsonUtil.formRequestURL(Stock.GetParameterValue("serviceURL"), Stock.GetParameterValue("dbName"),
					Stock.GetParameterValue("gaId"),
					Stock.GetParameterValue("indId"),
					Stock.GetParameterValue("strucId"));
			System.out.println(requestURL);
			response = new Response();
			response.setusername(Stock.GetParameterValue("username"));
			response.setPassword(Stock.GetParameterValue("password"));

			jsonRequestString = JsonUtil.writeToJson(response);
			HttpResponse authResponse = web.getResponseasJsonforPostRequest(Stock.GetParameterValue("authURL"), jsonRequestString);
			String authCode = authResponse.getFirstHeader("Authorization").getValue();
			System.out.println(authCode);
			HttpGet getReq = new HttpGet(requestURL);
			getReq.addHeader("Authorization", "JWT " + authCode);
			HttpResponse serviceResponse = web.getResponseasJsonforGet(getReq);
			System.out.println(serviceResponse);
			int code = serviceResponse.getStatusLine().getStatusCode();
			String message = serviceResponse.getStatusLine().getReasonPhrase();

			if(Integer.toString(code).equalsIgnoreCase(Stock.GetParameterValue("responseCode"))&& code==HttpStatus.SC_OK){
				Reporter.logEvent(Status.PASS, "Verify the status code",
						"Expected " +Stock.GetParameterValue("responseCode") + " Actual " + code+"\nReason Phrase "+message, false);
			}
			else if(Integer.toString(code).equalsIgnoreCase(Stock.GetParameterValue("responseCode"))&& code!=HttpStatus.SC_OK)
			{
				Reporter.logEvent(Status.PASS, "Verify the status code",
						"Expected " +Stock.GetParameterValue("responseCode") + " Actual " + code+"\nReason Phrase "+message+"\n"+"Exception message is "
								+serviceResponse.getFirstHeader("exceptionMessage").getValue(), false);
			}
			else
			{
				Reporter.logEvent(Status.FAIL, "Verify the status code",
						"Expected " +Stock.GetParameterValue("responseCode") + " Actual " + code, false);

			}


		}
		catch(Exception e)
		{
			e.printStackTrace();
			Globals.exception = e;
			String errorMsg = e.getMessage();
			Reporter.logEvent(Status.FAIL, "A run time exception occured.",
					errorMsg, false);
		}
		finally {
			try {
				Reporter.finalizeTCReport();
			} catch (Exception e1) {
				e1.printStackTrace();
			}
		}
	}


	/**
	 * @param itr
	 * @param testData
	 */
	@Test(dataProvider="setData")
	public void TC01_BCOM_NQ_Save_Nq_Enrollment_Info(int itr, Map<String,String> testData)
	{
		String requestURL=null;
		try
		{
			Reporter.initializeReportForTC(itr, Globals.GC_MANUAL_TC_NAME, Stock.GetParameterValue("description"));
			web = new WebserviceUtil();
			response = new Response();
			response.setusername(Stock.GetParameterValue("username"));
			response.setPassword(Stock.GetParameterValue("password"));

			jsonRequestString = JsonUtil.writeToJson(response);
			Reporter.logEvent(Status.INFO, "Request body of first response",
					jsonRequestString, false);

			HttpResponse resp1 = web.getResponseasJsonforPostRequest(
					Stock.GetParameterValue("authURL"), jsonRequestString);
			System.out.println(resp1.toString());
			String authCode = resp1.getFirstHeader("Authorization").getValue();
			System.out.println("AuthCode: " + authCode);

			Reporter.logEvent(Status.INFO,
					"The Auth code for second webservice header",
					"\nThe Auth code for second webservice header is:\n"
							+ authCode, false);
			String requestBody = JsonUtil.readFromExtJsonFile(Stock.GetParameterValue("inputFilePath"));

			requestURL = Stock.GetParameterValue("serviceURL");

			HttpResponse saveResponse = web.getResponseasJsonforPostRequest(requestURL,requestBody,"JWT " + authCode);

			int code = saveResponse.getStatusLine().getStatusCode();

			String message = saveResponse.getStatusLine().getReasonPhrase();
			//Header[] hdr = saveResponse.getAllHeaders();
			//String exception = saveResponse.getFirstHeader("exceptionCause").getValue();

			if (Integer.toString(code).equalsIgnoreCase(Stock.GetParameterValue("responseCode"))
					&& code==HttpStatus.SC_CREATED)
				Reporter.logEvent(Status.PASS, "Verify the status code",
						"Expected 201" + " Actual " + code+" "+message, false);
			else
				Reporter.logEvent(Status.FAIL, "Verify the status code",
						"Expected 201" + " Actual " + code+" "+message, false);
			String responseString = web.getHttpResponseAsString(saveResponse);
			Reporter.logEvent(Status.INFO, "The response", responseString,
					false);
			//Read response body
			String eventId = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, "$..evId");
			String saveMessage = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, "$..message");
			Reporter.logEvent(Status.INFO, "Save Message", saveMessage, false);
			int eventIdInDatabase = Integer.parseInt(eventId)+1;
			queryResultSet = DB.executeQuery("TARGETDB", Stock.getTestQuery("saveResultFromNqDisbReqTable")[1],String.valueOf(eventIdInDatabase));
			while(queryResultSet.next())
			{
				String inputIndId = JsonReadWriteUtils.getNodeValueUsingJpath(requestBody, "$..indId");
				String inputGaId = JsonReadWriteUtils.getNodeValueUsingJpath(requestBody, "$..gaId");
				String inputStructureTypeCode = JsonReadWriteUtils.getNodeValueUsingJpath(requestBody, "$..strucTypeCode");
				String gaNQStrucDisbGrpId = JsonReadWriteUtils.getNodeValueUsingJpath(requestBody, "$..gaNQStrucDisbGrpId");
				String gaNQDisbRsnMthdTmgId = JsonReadWriteUtils.getNodeValueUsingJpath(requestBody, "$..gaNQDisbRsnMthdTmgId");
				String effectiveDate = JsonReadWriteUtils.getNodeValueUsingJpath(requestBody, "$..nqDisbElectionsDTO[*].effDate");

				JsonReadWriteUtils.compareValueAndLogReport(inputIndId, queryResultSet.getString("IND_ID"), "Individual Id");
				JsonReadWriteUtils.compareValueAndLogReport(inputGaId, queryResultSet.getString("GA_ID"), "GA ID");
				//JsonReadWriteUtils.compareValueAndLogReport(inputStructureTypeCode, queryResultSet.getString(""), "strucTypeCode");
				JsonReadWriteUtils.compareValueAndLogReport(gaNQStrucDisbGrpId,queryResultSet.getString("GA_NQ_STRUC_DISB_GRP_ID"),
						"gaNQStrucDisbGrpId");
				JsonReadWriteUtils.compareValueAndLogReport(gaNQDisbRsnMthdTmgId,queryResultSet.getString("GA_NQ_DISB_RSN_MTHD_TMG_ID"),
						"gaNQDisbRsnMthdTmgId");
				JsonReadWriteUtils.compareDbWithDateInResponse(effectiveDate, queryResultSet.getDate("EFFDATE"), "effDate");
			}

		}
		catch(Exception e)
		{
			e.printStackTrace();
			Globals.exception = e;
			String errorMsg = e.getMessage();
			Reporter.logEvent(Status.FAIL, "A run time exception occured.",
					errorMsg, false);
		}
		finally {
			try {
				Reporter.finalizeTCReport();
			} catch (Exception e1) {
				e1.printStackTrace();
			}
		}
	}
}

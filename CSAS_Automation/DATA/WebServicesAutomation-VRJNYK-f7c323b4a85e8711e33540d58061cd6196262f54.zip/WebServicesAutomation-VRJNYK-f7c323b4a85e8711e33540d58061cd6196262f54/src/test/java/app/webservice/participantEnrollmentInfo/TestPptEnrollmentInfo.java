package app.webservice.participantEnrollmentInfo;

import java.lang.reflect.Method;
import java.sql.ResultSet;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

import lib.Reporter;
import lib.Stock;

import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.aventstack.extentreports.Status;

import app.webservice.pageobjects.JsonUtil;
import app.webservice.pageobjects.Response;
import app.webservice.pageobjects.WebserviceUtil;
import app.webservice.pageobjects.pptenrollmentinfo.ChallengeQuestionIdAnswerMap;
import app.webservice.pageobjects.pptenrollmentinfo.MyObjHolder;
import app.webservice.pageobjects.pptenrollmentinfo.PptEnrollmentInfoValues;
import app.webservice.pageobjects.pptenrollmentinfo.Address;
import app.webservice.pageobjects.pptenrollmentinfo.Employment;
import app.webservice.pageobjects.pptenrollmentinfo.IndEmails;
import app.webservice.pageobjects.pptenrollmentinfo.Individual;
import app.webservice.pageobjects.pptenrollmentinfo.PartAgrmtDTO;
import app.webservice.pageobjects.pptenrollmentinfo.pptDocumentsSchemaConsentSets;
import core.framework.Globals;

public class TestPptEnrollmentInfo {

	WebserviceUtil webserviceUtil;
	String url;
	String jsonRequestString;
	String jsonResponseString;
	ResultSet queryResultSet = null;


	private LinkedHashMap<Integer, Map<String, String>> testData = null;
	String tcName;
	private Response response;


	@BeforeClass
	public void InitTest() throws Exception {
		Stock.getParam(Globals.GC_TESTCONFIGLOC+ Globals.GC_CONFIGFILEANDSHEETNAME + ".xls");
		Reporter.initializeModule(this.getClass().getName());
	}


	@DataProvider
	public Object[][] setData(Method tc) throws Exception {
		prepTestData(tc);
		return Stock.setDataProvider(this.testData);
	}


	private void prepTestData(Method testCase) throws Exception {
		this.testData = Stock.getTestData(this.getClass().getPackage()
			.getName(), testCase.getName());
	}
	
	@Test(dataProvider = "setData")
	public void testPptEnrollmentInfo(int itr, Map<String, String> testdata)
			throws NoSuchFieldException, SecurityException {
	
		webserviceUtil = new WebserviceUtil();
		try {
			Reporter.initializeReportForTC(itr,	Globals.GC_MANUAL_TC_NAME);
			response = new Response();
			
			response.setusername(Stock.GetParameterValue("username1"));
			response.setPassword(Stock.GetParameterValue("password"));
						
			jsonRequestString = JsonUtil.writeToJson(response);
			
			Reporter.logEvent(Status.INFO, "Request body of first response", jsonRequestString, false);			
			HttpResponse resp1 = webserviceUtil.getResponseasJsonforPostRequest(Stock.GetParameterValue("url1"), jsonRequestString);	
			System.out.println(resp1.toString());
			String authCode = resp1.getFirstHeader("Authorization").getValue();
			System.out.println("AuthCode: "+authCode);		
			
			Reporter.logEvent(Status.INFO, "The Auth code to be taken for second webservice header", 
					"\nThe Auth code to be taken for second webservice header is:\n" + authCode, false);
			
			//Second Service
			/*
			Class PptEnrollmentInfoValues: Setting values for class PptEnrollmentInfoValues
			*/
			PptEnrollmentInfoValues pptenrollmentinfovalues = new PptEnrollmentInfoValues();
			
			pptenrollmentinfovalues.setAnnualSalary(Stock.GetParameterValue("annualSalary"));
			pptenrollmentinfovalues.setConsent(Stock.GetParameterValue("consent"));
			pptenrollmentinfovalues.setPersonalEmail(Stock.GetParameterValue("personalEmail"));
			pptenrollmentinfovalues.setWorkEmail(Stock.GetParameterValue("workEmail"));
			pptenrollmentinfovalues.setEmailPrimaryIndicator(Stock.GetParameterValue("emailPrimaryIndicator"));
			pptenrollmentinfovalues.setUserName(Stock.GetParameterValue("userName"));
			pptenrollmentinfovalues.setPin(Stock.GetParameterValue("pin"));
			pptenrollmentinfovalues.setSecurityQuestion(Stock.GetParameterValue("securityQuestion"));
			pptenrollmentinfovalues.setSecurityAnswer(Stock.GetParameterValue("securityAnswer"));
			
			ChallengeQuestionIdAnswerMap challengeqsIdAnsMap = new ChallengeQuestionIdAnswerMap();
			pptenrollmentinfovalues.setChallengeQuestionIdAnswerMap(challengeqsIdAnsMap); 
			
//			pptenrollmentinfovalues.setChallengeQuestionIdAnswerMap(Stock.GetParameterValue("challengeQuestionIdAnswerMap"));
			
			pptenrollmentinfovalues.setLoginPhrase(Stock.GetParameterValue("loginPhrase"));			
			pptenrollmentinfovalues.setLoginImage(Stock.GetParameterValue("loginImage"));
			pptenrollmentinfovalues.setSsnExtRsnCode(Stock.GetParameterValue("ssnExtRsnCode"));
			
			/*
			Class pptDocumentsSchemaConsentSets
			*/
			pptDocumentsSchemaConsentSets pptdoc = new pptDocumentsSchemaConsentSets();
			
			pptenrollmentinfovalues.setParticipantDocumentSchemaConsentSets(pptdoc);
			
			pptdoc.setMyPart(Stock.GetParameterValue("myPart"));
			pptdoc.setMyEffdate(Stock.GetParameterValue("myEffdate"));
			pptdoc.setMyTermdate(Stock.GetParameterValue("myTermdate"));
			pptdoc.setMySchemaTypeCode(Stock.GetParameterValue("mySchemaTypeCode"));
			pptdoc.setMySchemaCode(Stock.GetParameterValue("mySchemaCode"));
			pptdoc.setMySchemaLabel(Stock.GetParameterValue("mySchemaLabel"));
			pptdoc.setMySchemaDescr(Stock.GetParameterValue("mySchemaDescr"));
//			pptdoc.setMyObjHolder(Stock.GetParameterValue("myObjHolder"));
			
			MyObjHolder myObj = new MyObjHolder();
			pptdoc.setMyObjHolder(myObj);
			
			pptdoc.setMyDocumentSchemaGrpgConsents(Stock.GetParameterValue("myDocumentSchemaGrpgConsents"));
			
			pptenrollmentinfovalues.setGaId(Stock.GetParameterValue("gaId"));
			pptenrollmentinfovalues.setAccessCustomizaionCode(Stock.GetParameterValue("accessCustomizaionCode"));
			pptenrollmentinfovalues.setAccessTypeCode(Stock.GetParameterValue("accessTypeCode"));
			pptenrollmentinfovalues.setGcsValue(Stock.GetParameterValue("gcsValue"));
			pptenrollmentinfovalues.setGcsBasis(Stock.GetParameterValue("gcsBasis"));
			pptenrollmentinfovalues.setSsoToken(Stock.GetParameterValue("ssoToken"));
			pptenrollmentinfovalues.setSsnExistsStatus(Stock.GetParameterValue("ssnExistsStatus"));
			pptenrollmentinfovalues.setRegistrationStatus(Stock.GetParameterValue("registrationStatus"));
			pptenrollmentinfovalues.setAllowedToEnroll(Stock.GetParameterValue("allowedToEnroll"));
			pptenrollmentinfovalues.setEnrollmentType(Stock.GetParameterValue("enrollmentType"));
			pptenrollmentinfovalues.setAcxiomCheckFlag(Stock.GetParameterValue("acxiomCheckFlag"));	
			
			

			/*
			Class PartAgrmtDTO
			*/
			PartAgrmtDTO partagrmtdto = new PartAgrmtDTO();
			pptenrollmentinfovalues.setPartagrmtDTO(partagrmtdto);
			
			partagrmtdto.setGaId(Stock.GetParameterValue("gaId"));
			partagrmtdto.setIndId(Stock.GetParameterValue("indId"));
			partagrmtdto.setStmtProcCode(Stock.GetParameterValue("stmtProcCode"));
			partagrmtdto.setEffdate(Stock.GetParameterValue("effdate"));
			partagrmtdto.setStatusCode(Stock.GetParameterValue("statusCode"));
			partagrmtdto.setStatusEffdate(Stock.GetParameterValue("statusEffdate"));
			partagrmtdto.setOwnershipInd(Stock.GetParameterValue("ownershipInd"));
			partagrmtdto.setOwnershipSettlmtDate(Stock.GetParameterValue("ownershipSettlmtDate"));
			partagrmtdto.setPaIndId(Stock.GetParameterValue("paIndId"));
			partagrmtdto.setPaGaId(Stock.GetParameterValue("paGaId"));
			partagrmtdto.setPinAuthCode(Stock.GetParameterValue("pinAuthCode"));
			partagrmtdto.setStatusSubcode(Stock.GetParameterValue("statusSubcode"));
			partagrmtdto.setLastCntDate(Stock.GetParameterValue("lastCntDate"));
			partagrmtdto.setPinEffdate(Stock.GetParameterValue("pinEffdate"));
			partagrmtdto.setRestrcCode(Stock.GetParameterValue("restrcCode"));
			partagrmtdto.setFirstContribDate(Stock.GetParameterValue("firstContribDate"));
			partagrmtdto.setStmtHoldReasonCode(Stock.GetParameterValue("stmtHoldReasonCode"));
			partagrmtdto.setStmtHoldReasonNarrative(Stock.GetParameterValue("stmtHoldReasonNarrative"));
			partagrmtdto.setStmtSystemRej(Stock.GetParameterValue("stmtSystemRej"));
			partagrmtdto.setStmtSystemRejDate(Stock.GetParameterValue("stmtSystemRejDate"));
			partagrmtdto.setStmtSystemRejOverride(Stock.GetParameterValue("stmtSystemRejOverride"));
			partagrmtdto.setRestrcNarrative(Stock.GetParameterValue("restrcNarrative"));
			partagrmtdto.setAppStateCode(Stock.GetParameterValue("appStateCode"));
			partagrmtdto.setMdAgeRecalcCode(Stock.GetParameterValue("mdAgeRecalcCode"));
			partagrmtdto.setMdGrandfatherAssetUsedCode(Stock.GetParameterValue("mdGrandfatherAssetUsedCode"));
			partagrmtdto.setMdBenefBirthDate(Stock.GetParameterValue("mdBenefBirthDate"));
			partagrmtdto.setMdBenefSpouseCode(Stock.GetParameterValue("mdBenefSpouseCode"));
			partagrmtdto.setAnnuityCommDate(Stock.GetParameterValue("annuityCommDate"));
			partagrmtdto.setExtClientAcctNbr(Stock.GetParameterValue("extClientAcctNbr"));
			partagrmtdto.setNarrative(Stock.GetParameterValue("narrative"));
			partagrmtdto.setMdGrandfatherMdib(Stock.GetParameterValue("mdGrandfatherMdib"));
			partagrmtdto.setFreeLookEndDate(Stock.GetParameterValue("freeLookEndDate"));
			partagrmtdto.setVestingHoldCode(Stock.GetParameterValue("vestingHoldCode"));
			partagrmtdto.setLastFullyVestCalcDate(Stock.GetParameterValue("lastFullyVestCalcDate"));
			partagrmtdto.setDisabilityDate(Stock.GetParameterValue("disabilityDate"));
			partagrmtdto.setSchwabPolicyId(Stock.GetParameterValue("schwabPolicyId"));
			partagrmtdto.setSalesPersnId(Stock.GetParameterValue("salesPersnId"));
			partagrmtdto.setSaleSourceCode(Stock.GetParameterValue("saleSourceCode"));
			partagrmtdto.setAppCompltnCode(Stock.GetParameterValue("appCompltnCode"));
			partagrmtdto.setVestParticipationDate(Stock.GetParameterValue("vestParticipationDate"));
			partagrmtdto.setIncompleteRelatedIndivCode(Stock.GetParameterValue("incompleteRelatedIndivCode"));
			partagrmtdto.setProspectusCode(Stock.GetParameterValue("prospectusCode"));
			partagrmtdto.setMdApply75YearRuleInd(Stock.GetParameterValue("mdApply75YearRuleInd"));
			partagrmtdto.setMdBeneInd(Stock.GetParameterValue("mdBeneInd"));
			partagrmtdto.setPartCashHoldCode(Stock.GetParameterValue("partCashHoldCode"));
			partagrmtdto.setPartDisbHoldCode(Stock.GetParameterValue("partDisbHoldCode"));
			partagrmtdto.setPartCashHoldNarrative(Stock.GetParameterValue("partCashHoldNarrative"));
			partagrmtdto.setStatusChgDpdate(Stock.GetParameterValue("statusChgDpdate"));
			partagrmtdto.setTakeoverTypeCode(Stock.GetParameterValue("takeoverTypeCode"));
			partagrmtdto.setMdInitialFactor(Stock.GetParameterValue("mdInitialFactor"));
			partagrmtdto.setPriorContractNbr(Stock.GetParameterValue("priorContractNbr"));
			partagrmtdto.setLastPdiAddrUpdateEvId(Stock.GetParameterValue("lastPdiAddrUpdateEvId"));
			partagrmtdto.setBeneElectedCalcMthd(Stock.GetParameterValue("beneElectedCalcMthd"));
			partagrmtdto.setBeneElectedCalcMthdDate(Stock.GetParameterValue("beneElectedCalcMthdDate"));
			partagrmtdto.setRmdBeginDate(Stock.GetParameterValue("rmdBeginDate"));
			partagrmtdto.setMergerDate(Stock.GetParameterValue("mergerDate"));
			partagrmtdto.setMergerCode(Stock.GetParameterValue("mergerCode"));
			partagrmtdto.setActiveRmdDueInd(Stock.GetParameterValue("activeRmdDueInd"));
			partagrmtdto.setQjsaRmdWaiverDate(Stock.GetParameterValue("qjsaRmdWaiverDate"));
			partagrmtdto.setQjsaRmdWaiverSpouseDate(Stock.GetParameterValue("qjsaRmdWaiverSpouseDate"));
			partagrmtdto.setDeathIndicatorFlag(Stock.GetParameterValue("deathIndicatorFlag"));
			partagrmtdto.setErContributionServicePoint(Stock.GetParameterValue("erContributionServicePoint"));
			partagrmtdto.setRowId(Stock.GetParameterValue("rowId"));
			
			
			/*
			Class Individual
			*/
			Individual ind = new Individual();
			pptenrollmentinfovalues.setIndividual(ind);
			
			ind.setId(Stock.GetParameterValue("id"));
			ind.setLastName(Stock.GetParameterValue("lastName"));
			ind.setFirstname(Stock.GetParameterValue("firstname"));
			ind.setSsn(Stock.GetParameterValue("ssn"));
			ind.setMailingName1(Stock.GetParameterValue("mailingName1"));
			ind.setSdxLastName(Stock.GetParameterValue("sdxLastName"));
			ind.setBirthdate(Stock.GetParameterValue("birthdate"));
			ind.setSex(Stock.GetParameterValue("sex"));
			ind.setNameType(Stock.GetParameterValue("nameType"));
			ind.setRecovmaxAccum(Stock.GetParameterValue("recovmaxAccum"));
			ind.setNextEligLoanDate(Stock.GetParameterValue("nextEligLoanDate"));
			ind.setMaritalStatus(Stock.GetParameterValue("maritalStatus"));
			ind.setDeathdate(Stock.GetParameterValue("deathdate"));
			ind.setPartComncemntDate(Stock.GetParameterValue("partComncemntDate"));
			ind.setTitle(Stock.GetParameterValue("title"));
			ind.setMiddlename(Stock.GetParameterValue("middlename"));
			ind.setRemitIdNbr(Stock.GetParameterValue("remitIdNbr"));
			ind.setSuffix(Stock.GetParameterValue("suffix"));
			ind.setBeeperNbr(Stock.GetParameterValue("beeperNbr"));
			ind.setWorkPhoneNbr(Stock.GetParameterValue("workPhoneNbr"));
			ind.setHomePhoneNbr(Stock.GetParameterValue("homePhoneNbr"));
			ind.setPhoneExtNbr(Stock.GetParameterValue("phoneExtNbr"));
			ind.setFaxNbr(Stock.GetParameterValue("faxNbr"));
			ind.setBeeperAreaCode(Stock.GetParameterValue("beeperAreaCode"));
			ind.setFaxAreaCode(Stock.GetParameterValue("faxAreaCode"));
			ind.setHomePhoneAreaCode(Stock.GetParameterValue("homePhoneAreaCode"));
			ind.setWorkPhoneAreaCode(Stock.GetParameterValue("workPhoneAreaCode"));
			ind.setMailingName2(Stock.GetParameterValue("mailingName2"));
			ind.setMailingName3(Stock.GetParameterValue("mailingName3"));
			ind.setLanguageCode(Stock.GetParameterValue("languageCode"));
			ind.setSsnExt(Stock.GetParameterValue("ssnExt"));
			ind.setSsnExtRsnCode(Stock.GetParameterValue("ssnExtRsnCode"));
			ind.setEmailAddress(Stock.GetParameterValue("emailAddress"));
			ind.setLastNonAdminPdoffLoanDate(Stock.GetParameterValue("lastNonAdminPdoffLoanDate"));
			ind.setBirthDateDefaultIndic(Stock.GetParameterValue("birthDateDefaultIndic"));
			ind.setPassCodeExpDate(Stock.GetParameterValue("passCodeExpDate"));
			ind.setContactVerificationDPDate(Stock.GetParameterValue("contactVerificationDPDate"));
			ind.setMobilePhoneAreaCode(Stock.GetParameterValue("mobilePhoneAreaCode"));
			ind.setMobilePhoneNbr(Stock.GetParameterValue("mobilePhoneNbr"));
			ind.setIntlPhoneNbr(Stock.GetParameterValue("intlPhoneNbr"));
			ind.setIntlPhoneCountryCode(Stock.GetParameterValue("intlPhoneCountryCode"));
			
			
			/*
			Class Address
			*/
			Address addr = new Address();
			pptenrollmentinfovalues.setAddress(addr);
			
			addr.setIndId(Stock.GetParameterValue("indId1"));
			addr.setSeqnbr(Stock.GetParameterValue("seqnbr"));
			addr.setEffdate(Stock.GetParameterValue("effdate2"));
			addr.setPrimaryResInd(Stock.GetParameterValue("primaryResInd"));
			addr.setFirstLineMailing(Stock.GetParameterValue("firstLineMailing"));
			addr.setScndLineMailing(Stock.GetParameterValue("scndLineMailing"));
			addr.setCity(Stock.GetParameterValue("city"));
			addr.setZipCode(Stock.GetParameterValue("zipCode"));
			addr.setStateCode(Stock.GetParameterValue("stateCode"));
			addr.setCountry(Stock.GetParameterValue("country"));
			addr.setRelIndId(Stock.GetParameterValue("relIndId"));
			addr.setTermDate(Stock.GetParameterValue("termDate"));
			addr.setDefaultCode(Stock.GetParameterValue("defaultCode"));
			addr.setEquifaxRequestDate(Stock.GetParameterValue("equifaxRequestDate"));
			addr.setRestrcIndicator(Stock.GetParameterValue("restrcIndicator"));
			addr.setCounty(Stock.GetParameterValue("county"));
			addr.setMailHoldDate(Stock.GetParameterValue("mailHoldDate"));
			addr.setValidationSourceCode(Stock.GetParameterValue("validationSourceCode"));			
			
			
			/*
			Class Employment
			*/
			Employment emp = new Employment();
			pptenrollmentinfovalues.setEmployment(emp);
			
			emp.setIndId(Stock.GetParameterValue("indId2"));
			emp.setGcId(Stock.GetParameterValue("gcId"));
			emp.setHireDate(Stock.GetParameterValue("hireDate"));
			emp.setErAssignedId(Stock.GetParameterValue("erAssignedId"));
			emp.setPercentOwnership(Stock.GetParameterValue("percentOwnership"));
			emp.setEmpTermdate(Stock.GetParameterValue("empTermdate"));
			emp.setHighlyCompensatedInd(Stock.GetParameterValue("highlyCompensatedInd"));
			emp.setOfficerInd(Stock.GetParameterValue("officerInd"));
			emp.setJobDescr(Stock.GetParameterValue("jobDescr"));
			emp.setEmploymentType(Stock.GetParameterValue("employmentType"));
			emp.setTerminationReasonCode(Stock.GetParameterValue("terminationReasonCode"));
			emp.setTermNotificationDateTime(Stock.GetParameterValue("termNotificationDateTime"));
			emp.setEmpTermdateChgDpdateTime(Stock.GetParameterValue("empTermdateChgDpdateTime"));
			emp.setInsiderInd(Stock.GetParameterValue("insiderInd"));
			emp.setSuperOfficerInd(Stock.GetParameterValue("superOfficerInd"));
			emp.setUnionInd(Stock.GetParameterValue("unionInd"));
			emp.setOverseasInd(Stock.GetParameterValue("overseasInd"));
			emp.setOverseasEffdate(Stock.GetParameterValue("overseasEffdate"));
			emp.setFullPartTimeEmployee(Stock.GetParameterValue("fullPartTimeEmployee"));
			
			/*
			Class IndEmails
			*/
			IndEmails indE = new IndEmails();
			pptenrollmentinfovalues.setIndEmails(indE);
			
			indE.setIndId(Stock.GetParameterValue("indId3"));
			indE.setTypeCode(Stock.GetParameterValue("typeCode"));
			indE.setEmailAddress(Stock.GetParameterValue("emailAddress2"));
			indE.setEffdate(Stock.GetParameterValue("effdate3"));
			indE.setStatusCode(Stock.GetParameterValue("statusCode"));
			indE.setRestricCode(Stock.GetParameterValue("restricCode"));
			indE.setHoldReasonCode(Stock.GetParameterValue("holdReasonCode"));
			indE.setTermdate(Stock.GetParameterValue("termdate2"));
			indE.setSubTypeCode(Stock.GetParameterValue("subTypeCode"));
			
			pptenrollmentinfovalues.setIraBrokerFundingDTO(Stock.GetParameterValue("iraBrokerFundingDTO"));
			pptenrollmentinfovalues.setAddressChangeable(Stock.GetParameterValue("addressChangeable"));
			pptenrollmentinfovalues.setPartAgreementExists(Stock.GetParameterValue("partAgreementExists"));
			pptenrollmentinfovalues.setUsingAltAuth(Stock.GetParameterValue("usingAltAuth"));
						
			
						
			jsonRequestString = JsonUtil.writeToJsonInclNull(pptenrollmentinfovalues);
			
			Reporter.logEvent(Status.INFO, "Request body of second response", jsonRequestString, false);
			
			HttpPost httpReq = webserviceUtil.getPostRequest(Stock.GetParameterValue("url2"), jsonRequestString);
			httpReq.addHeader("Authorization", "JWT "+authCode);
			
			HttpResponse resp2 = webserviceUtil.getResponse(httpReq);			
			System.out.println(resp2.toString());
			Reporter.logEvent(Status.INFO, "Response form second webservice",resp2.toString(), false);
			
			if(resp2.getStatusLine().getStatusCode() == 400)
			{
				Reporter.logEvent(Status.PASS, "Running Web Service to get Income Data ","Response: Bad Request",false);
				Reporter.logEvent(Status.PASS, "Validating Status Code ","Expected: 400\nFrom Response: "+resp2.getStatusLine().getStatusCode(),false);
			
			
			}
			else{
				Reporter.logEvent(Status.FAIL, "Running Web Service to get Income Data ","Response: FAILURE",false);
				Reporter.logEvent(Status.FAIL, "Validating Status Code ","Expected: 204\nFrom Response: "+resp2.getStatusLine().getStatusCode(),false);
			}			
			
			
		}catch (Exception e) {
			e.printStackTrace();
			Globals.exception = e;
			String errorMsg = e.getMessage();
			Reporter.logEvent(Status.FAIL, "A run time exception occured.",errorMsg,false);
		}
		finally {
			try {
				Reporter.finalizeTCReport();
			} catch (Exception e1) {
				e1.printStackTrace();
			}
		}
		
	}	
}

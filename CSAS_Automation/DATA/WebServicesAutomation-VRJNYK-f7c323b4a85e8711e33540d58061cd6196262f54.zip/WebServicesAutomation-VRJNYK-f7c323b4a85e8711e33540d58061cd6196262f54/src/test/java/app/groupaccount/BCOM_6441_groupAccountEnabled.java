package app.groupaccount;

import java.lang.reflect.Method;
import java.net.URLEncoder;
import java.util.LinkedHashMap;
import java.util.Map;

import lib.Reporter;
import lib.Stock;

import org.apache.commons.codec.DecoderException;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.utils.URIBuilder;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import util.CommonLib;
import webservices.util.JsonUtil;
import webservices.util.WebserviceUtil;
import app.ramlservices.pageobject.CampaignData;
import app.webservice.pageobjects.Response;

import com.aventstack.extentreports.Status;

import core.framework.Globals;

public class BCOM_6441_groupAccountEnabled {
	private LinkedHashMap<Integer, Map<String, String>> testData = null;
	CommonLib utilities;
	WebserviceUtil web = null;
	Response response;
	String jsonRequestString;
	String jsonResponseString;
	CampaignData campaignData;

	@BeforeClass
	public void InitTest() throws Exception {
		Reporter.initializeModule(this.getClass().getSimpleName());
	}

	@DataProvider
	public Object[][] setData(Method tc) throws Exception {
		tc.getName();
		prepTestData(tc);
		return Stock.setDataProvider(this.testData);
	}

	private void prepTestData(Method testCase) throws Exception {
		this.testData = Stock.getTestData(this.getClass().getPackage()
				.getName(), testCase.getName());
	}
	
	/**
	 * <pre>
	 * Test Case is used to get list of campaign type category information with the correct input provided in the request.
	 * </pre>
	 * 
	 * @param itr
	 *            : Iteration number
	 * @param testData
	 *            Test data map.
	 */
	@Test(dataProvider = "setData")
	public void TC01_BCOM_6441_groupAccountEnabled_Positive_Flow(int itr,
			Map<String, String> testData) throws ClientProtocolException, DecoderException, InterruptedException{
		String requestURL;
		try {
			Reporter.initializeReportForTC(itr, Globals.GC_MANUAL_TC_NAME,
					Stock.GetParameterValue("description"));
			Reporter.logEvent(Status.INFO,
					"Test Data used for iteration" + itr,
					CommonLib.getIterationDataAsString(testData), false);
			/*import org.apache.http.client.utils.URIBuilder;

			URIBuilder ub = new URIBuilder("http://example.com/query");
			ub.addParameter("q", "random word �500 bank \$");
			String url = ub.toString();*/
			//String encodeUrl = URLEncodedUtils.
			//String str  = URLEncoder.encode(param,"UTF-8");

			//String param = ub.toString();
			/*String param = Stock.GetParameterValue("sdsvCode");
			String str  = URLEncoder.encode(param,"UTF-8");*/
			requestURL = JsonUtil.formRequestURL(
					Stock.GetParameterValue("serviceURL"),
					Stock.GetParameterValue("db"),
					Stock.GetParameterValue("gaId"),
					Stock.GetParameterValue("sdsvCode"),
					Stock.GetParameterValue("sdsvSubCode"));
			
			System.out.println(requestURL);
			/*String requestURL1  = URLEncoder.encode(requestURL,"UTF-8");
			System.out.println("Encoded url is   "+requestURL1);*/
			utilities = new CommonLib();
			utilities.triggerService(requestURL);
			utilities.validateResponseStatusCode();
			
			String responseString = utilities.getHttpResponseAsString();
			System.out.println("res is    "+responseString);
			Reporter.logEvent(Status.INFO, "The response", responseString,false);
			
		} catch (Exception e) {
			e.printStackTrace();
			Globals.exception = e;
			String errorMsg = e.getMessage();
			Reporter.logEvent(Status.FAIL, "A run time exception occured.",
					errorMsg, false);
		} finally {
			try {
				Reporter.finalizeTCReport();
			} catch (Exception e1) {
				e1.printStackTrace();
			}
		}
	}
	/**
	 * <pre>
	 * Test Case is used to get list of campaign type category information with the correct input provided in the request.
	 * </pre>
	 * 
	 * @param itr
	 *            : Iteration number
	 * @param testData
	 *            Test data map.
	 */
	@Test(dataProvider = "setData")
	public void TC02_BCOM_6441_groupAccountEnabled_Negative_Flow(int itr,
			Map<String, String> testData) throws ClientProtocolException, DecoderException, InterruptedException{
		String requestURL;
		try {
			Reporter.initializeReportForTC(itr, Globals.GC_MANUAL_TC_NAME,
					Stock.GetParameterValue("description"));
			Reporter.logEvent(Status.INFO,
					"Test Data used for iteration" + itr,
					CommonLib.getIterationDataAsString(testData), false);
			
			requestURL = JsonUtil.formRequestURL(
					Stock.GetParameterValue("serviceURL"),
					Stock.GetParameterValue("db"),
					Stock.GetParameterValue("gaId"),
					Stock.GetParameterValue("sdsvCode"),
					Stock.GetParameterValue("sdsvSubCode"));
			
			System.out.println(requestURL);
			/*String requestURL1  = URLEncoder.encode(requestURL,"UTF-8");
			System.out.println("Encoded url is   "+requestURL1);*/
			utilities = new CommonLib();
			utilities.triggerService(requestURL);
			utilities.validateResponseStatusCodeWithoutClientMessage();
		} catch (Exception e) {
			e.printStackTrace();
			Globals.exception = e;
			String errorMsg = e.getMessage();
			Reporter.logEvent(Status.FAIL, "A run time exception occured.",
					errorMsg, false);
		} finally {
			try {
				Reporter.finalizeTCReport();
			} catch (Exception e1) {
				e1.printStackTrace();
			}
		}
	}
	

}

package app.tranfers;

import java.lang.reflect.Method;
import java.util.LinkedHashMap;
import java.util.Map;

import lib.DB;
import lib.Reporter;
import lib.Stock;

import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpPut;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import util.CommonLib;
import webservices.util.JsonUtil;
import webservices.util.WebserviceUtil;
import app.ramlservices.pageobject.TranferServices;
import app.webservice.pageobjects.JsonReadWriteUtils;
import app.webservice.pageobjects.Response;

import com.aventstack.extentreports.Status;

import core.framework.Globals;

public class BCOM_6131_TranferTestCases {
	private LinkedHashMap<Integer, Map<String, String>> testData = null;
	CommonLib utilities;
	WebserviceUtil web = null;
	Response response;
	String jsonRequestString;
	String jsonResponseString;
	TranferServices tranferServices;

	@BeforeClass
	public void InitTest() throws Exception {
		Reporter.initializeModule(this.getClass().getSimpleName());
	}

	@DataProvider
	public Object[][] setData(Method tc) throws Exception {
		tc.getName();
		prepTestData(tc);
		return Stock.setDataProvider(this.testData);
	}

	private void prepTestData(Method testCase) throws Exception {
		this.testData = Stock.getTestData(this.getClass().getPackage()
				.getName(), testCase.getName());
	}

	/**
	 * <pre>
	 * Test Case is used to verify if the service aReturns a list of IsisMessageDTO when correct set of data which has status code as PER TRF and cancel has already been performed on the data is passed in the request.
	 * </pre>
	 * <pre>
	 * Test Case is used to verify if the service aReturns a list of IsisMessageDTO  when invalid value is passed in incancelreason field.
	 * </pre>
	 * <pre>
	 * Test Case is used to verify if the service aReturns a list of IsisMessageDTO   when ineffdate  field is removed from the request.
	 * </pre>
	 * 
	 * @param itr
	 *            : Iteration number
	 * @param testData
	 *            Test data map.
	 */
	@Test(dataProvider = "setData")
	public void DDTC_32570_32575_32588_Tranfer_6131_Positive_Flow(int itr,
			Map<String, String> testData) {
		String requestURL;
			try
			{
				Reporter.initializeReportForTC(itr, Globals.GC_MANUAL_TC_NAME, Stock.GetParameterValue("description"));
				web = new WebserviceUtil();
				response = new Response();
				response.setusername(Stock.GetParameterValue("username"));
				response.setPassword(Stock.GetParameterValue("password"));
				jsonRequestString = JsonUtil.writeToJson(response);
				
				// Get the authcode from service.
				HttpResponse resp1 = web.getResponseasJsonforPostRequest(
						Stock.GetParameterValue("authURL"), jsonRequestString);
				String authCode = resp1.getFirstHeader("Authorization").getValue();
				System.out.println("AuthCode: " + authCode);
				Reporter.logEvent(Status.INFO,
						"The Auth code for second webservice header",
						"\nThe Auth code for second webservice header is:\n"
								+ authCode, false);
				
				// Get request body from json file.
				String requestBody = JsonUtil.readInputDataFromJsonFile(Stock.GetParameterValue("inputFilePath"));
				
				// Construct request URL.
				requestURL = JsonUtil.formRequestURL(
						Stock.GetParameterValue("serviceURL"),
						Stock.GetParameterValue("db"),
						Stock.GetParameterValue("gaId"),
						Stock.GetParameterValue("indid"),
						Stock.GetParameterValue("inCancelReason"),
						Stock.GetParameterValue("inEffDate"));
				System.out.println("request url    "+requestURL);
				HttpResponse putRes = web.getResponseasJsonforPutRequest(requestURL,requestBody,"JWT " + authCode);

				// Verify HttpStatus code and reason phrase.
				verifyHttpStatusCodes(putRes);
				
				String responseString = web.getHttpResponseAsString(putRes);
				Reporter.logEvent(Status.INFO, "The response", responseString,false);
				
			}
	
			catch(Exception e)
			{
				e.printStackTrace();
				Globals.exception = e;
				String errorMsg = e.getMessage();
				Reporter.logEvent(Status.FAIL, "A run time exception occured.",
						errorMsg, false);
			}
			finally {
				try {
					Reporter.finalizeTCReport();
				} catch (Exception e1) {
					e1.printStackTrace();
				}
			}
	}
	
	/**
	 * <pre>
	 * Test Case is used to verify if the service aReturns a list of IsisMessageDTO when another correct set of data which has created transfer request newly and status code is PER_TRF.
	 * </pre>
	 * <pre>
	 * Test Case is used to verify if the service aReturns a list of IsisMessageDTO when another correct set of data which has created transfer request newly and status code is PARTCAN in TRF_basic table.
	 * </pre>
	 * @param itr
	 *            : Iteration number
	 * @param testData
	 *            Test data map.
	 */
	@Test(dataProvider = "setData")
	public void DDTC_32571_32592_Tranfer_6131_Positive_Flow(int itr,
			Map<String, String> testData) {
		String requestURL;
			try
			{
				Reporter.initializeReportForTC(itr, Globals.GC_MANUAL_TC_NAME, Stock.GetParameterValue("description"));
				web = new WebserviceUtil();
				response = new Response();
				response.setusername(Stock.GetParameterValue("username"));
				response.setPassword(Stock.GetParameterValue("password"));
				jsonRequestString = JsonUtil.writeToJson(response);
				
				// Get the authcode from service.
				HttpResponse resp1 = web.getResponseasJsonforPostRequest(
						Stock.GetParameterValue("authURL"), jsonRequestString);
				String authCode = resp1.getFirstHeader("Authorization").getValue();
				System.out.println("AuthCode: " + authCode);
				Reporter.logEvent(Status.INFO,
						"The Auth code for second webservice header",
						"\nThe Auth code for second webservice header is:\n"
								+ authCode, false);
				
				// Get request body from json file.
				String requestBody = JsonUtil.readInputDataFromJsonFile(Stock.GetParameterValue("inputFilePath"));
				
				// Construct request URL.
				requestURL = JsonUtil.formRequestURL(
						Stock.GetParameterValue("serviceURL"),
						Stock.GetParameterValue("db"),
						Stock.GetParameterValue("gaId"),
						Stock.GetParameterValue("indid"),
						Stock.GetParameterValue("inCancelReason"),
						Stock.GetParameterValue("inEffDate"));
				System.out.println("request url    "+requestURL);
				
				HttpResponse putRes = web.getResponseasJsonforPutRequest(requestURL,requestBody,"JWT " + authCode);

				// Verify HttpStatus code and reason phrase.
				verifyHttpStatusCodes(putRes);
				String responseString = web.getHttpResponseAsString(putRes);
				Reporter.logEvent(Status.INFO, "The response", responseString,false);
			}
	
			catch(Exception e)
			{
				e.printStackTrace();
				Globals.exception = e;
				String errorMsg = e.getMessage();
				Reporter.logEvent(Status.FAIL, "A run time exception occured.",
						errorMsg, false);
			}
			finally {
				try {
					Reporter.finalizeTCReport();
				} catch (Exception e1) {
					e1.printStackTrace();
				}
			}
	}
	
	/**
	 * Method to verify HttpStatus code.
	 * @param res
	 */
	public void verifyHttpStatusCodes(HttpResponse res){
		String statusCode = String.valueOf(res.getStatusLine().getStatusCode());
		String expectedStatusCode= Stock.GetParameterValue("responseCode"); 
		String reasonPhrase = res.getStatusLine().getReasonPhrase();

		// Verify http status code.
		if(statusCode.equalsIgnoreCase(expectedStatusCode)){
			Reporter.logEvent(Status.PASS, "Verify the status code",
					"Expected " +expectedStatusCode + " Actual " + statusCode+"\nReason Phrase "+reasonPhrase, false);
		}else{
			Reporter.logEvent(Status.FAIL, "Verify the status code",
					"Expected " +expectedStatusCode + " Actual " + statusCode+"\nReason Phrase "+reasonPhrase, false);
		}
		
	}
}
						
			


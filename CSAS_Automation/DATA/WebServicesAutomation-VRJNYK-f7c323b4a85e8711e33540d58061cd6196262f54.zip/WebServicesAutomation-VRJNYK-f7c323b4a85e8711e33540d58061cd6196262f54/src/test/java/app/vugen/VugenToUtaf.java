package app.vugen;

import java.lang.reflect.Method;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.LinkedHashMap;
import java.util.Map;

import lib.DB;
import lib.Reporter;
import lib.Stock;

import org.apache.http.HttpResponse;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.aventstack.extentreports.Status;

import core.framework.Globals;
import util.AgentService;
import util.AuthService;
import util.CommonLib;
import util.WebserviceMethods;
import webservices.util.JsonUtil;
import webservices.util.WebserviceUtil;
import app.webservice.pageobjects.Response;

public class VugenToUtaf {
	
	private LinkedHashMap<Integer, Map<String, String>> testData = null;
	CommonLib utilities;
	WebserviceUtil web = null;
	Response response;
	String jsonRequestString;
	String jsonResponseString;
	ResultSet queryResultSet;
	String authCode;
	AuthService auth;
	public static String requestURL=null;

	@BeforeClass
	public void InitTest() throws Exception {
		Reporter.initializeModule(this.getClass().getSimpleName());
	}

	@DataProvider
	public Object[][] setData(Method tc) throws Exception {
		tc.getName();
		prepTestData(tc);
		return Stock.setDataProvider(this.testData);
	}

	private void prepTestData(Method testCase) throws Exception {
		this.testData = Stock.getTestData(this.getClass().getPackage()
				.getName(), testCase.getName());
	}
	
	@BeforeMethod
	private void preConditionSetup() {
		try {
			Reporter.initializeReportForTC(Stock.getIterations(), Globals.GC_MANUAL_TC_NAME);
			Reporter.logEvent(Status.INFO, "Webservice Precondtion", "Generating authentication code", false);

		
			web = new WebserviceUtil();

			auth = new AuthService();
			authCode = auth.runAuthWebservice();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			Reporter.logEvent(Status.FAIL, "Exception Occured", "Exception "+e.getMessage(), true);
		}
	}
	
	@Test(dataProvider = "setData")
	public void getEnrollService(int itr, Map<String, String> testdata)
	{
		try {
			
			
			
			Reporter.logEvent(Status.INFO, "Testcase Description", Stock.GetParameterValue("description"), false);
			
				String indidType="IND_ID";
				requestURL = WebserviceMethods.formRequestURL(Stock.GetParameterValue("serviceURL"),
						indidType,
						Stock.GetParameterValue("Ind_Id"),
						Stock.GetParameterValue("Ga_id"),
						Stock.GetParameterValue("Db"),
						Stock.GetParameterValue("App"),
						Stock.GetParameterValue("OECMLev"),
						Stock.GetParameterValue("deferrals"),
						Stock.GetParameterValue("AllowDef"),
						Stock.GetParameterValue("inStatus"),
						Stock.GetParameterValue("accuCode"),
						Stock.GetParameterValue("docType")
						);
				
				System.out.println(requestURL);
				WebserviceMethods webMeth= new WebserviceMethods();
				jsonResponseString = webMeth.runGetService(requestURL,authCode);
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			Reporter.logEvent(Status.FAIL, "Exception", "Exception occured: "+e.getMessage(), false);
		}
		finally 
		{
			try   {   Reporter.finalizeTCReport();
			}
			catch (Exception e1)  { e1.printStackTrace(); 
			Reporter.logEvent(Status.FAIL, "Exception", "Exception occured: "+e1.getMessage(), false);}	
		}
	}

	@Test(dataProvider = "setData")
	public void matchRule(int itr, Map<String, String> testdata)
	{
		try {
			
			
			Reporter.logEvent(Status.INFO, "Testcase Description", Stock.GetParameterValue("description"), false);
			
				requestURL = WebserviceMethods.formRequestURL(Stock.GetParameterValue("serviceURL"),
						Stock.GetParameterValue("Ga_id")
						);
				
				System.out.println(requestURL);
				WebserviceMethods webMeth= new WebserviceMethods();
				if(Stock.GetParameterValue("Auth").equalsIgnoreCase("false"))
				{
				jsonResponseString = webMeth.runGetService(requestURL,authCode+"lol");
				}
				else
				{
					jsonResponseString = webMeth.runGetService(requestURL,authCode);
				}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			Reporter.logEvent(Status.FAIL, "Exception", "Exception occured: "+e.getMessage(), false);
		}
		finally 
		{
			try   {   Reporter.finalizeTCReport();
			}
			catch (Exception e1)  { e1.printStackTrace(); 
			Reporter.logEvent(Status.FAIL, "Exception", "Exception occured: "+e1.getMessage(), false);}	
		}
	}
	
	@Test(dataProvider = "setData")
	public void userDefinedField(int itr, Map<String, String> testdata)
	{
		try {
			
			Reporter.logEvent(Status.INFO, "Testcase Description", Stock.GetParameterValue("description"), false);
			
				requestURL = WebserviceMethods.formRequestURL(Stock.GetParameterValue("serviceURL"),
						Stock.GetParameterValue("db"),
						Stock.GetParameterValue("Ga_id"),
						Stock.GetParameterValue("indid"),
						Stock.GetParameterValue("levelCode")
						);
				
				System.out.println(requestURL);
				WebserviceMethods webMeth= new WebserviceMethods();
				if(Stock.GetParameterValue("Auth").equalsIgnoreCase("false"))
				{
				jsonResponseString = webMeth.runGetService(requestURL,authCode+"lol");
				}
				else
				{
					jsonResponseString = webMeth.runGetService(requestURL,authCode);
				}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			Reporter.logEvent(Status.FAIL, "Exception", "Exception occured: "+e.getMessage(), false);
		}
		finally 
		{
			try   {   Reporter.finalizeTCReport();
			}
			catch (Exception e1)  { e1.printStackTrace(); 
			Reporter.logEvent(Status.FAIL, "Exception", "Exception occured: "+e1.getMessage(), false);}	
		}
	}
	
	
	@Test(dataProvider = "setData")
	public void getProjectionFactorsCurvnum(int itr, Map<String, String> testdata)
	{
		try {
			
			
			Reporter.logEvent(Status.INFO, "Testcase Description", Stock.GetParameterValue("description"), false);
			
				requestURL = WebserviceMethods.formRequestURL(Stock.GetParameterValue("serviceURL"),
						Stock.GetParameterValue("curvnum")
						);
				
				System.out.println(requestURL);
				WebserviceMethods webMeth= new WebserviceMethods();
				if(Stock.GetParameterValue("Auth").equalsIgnoreCase("false"))
				{
				jsonResponseString = webMeth.runGetService(requestURL,authCode+"lol");
				}
				else
				{
					jsonResponseString = webMeth.runGetService(requestURL,authCode);
				}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			Reporter.logEvent(Status.FAIL, "Exception", "Exception occured: "+e.getMessage(), false);
		}
		finally 
		{
			try   {   Reporter.finalizeTCReport();
			}
			catch (Exception e1)  { e1.printStackTrace(); 
			Reporter.logEvent(Status.FAIL, "Exception", "Exception occured: "+e1.getMessage(), false);}	
		}
	}
	
	
	@Test(dataProvider = "setData")
	public void getAllProjectionFactors(int itr, Map<String, String> testdata)
	{
		try {
			
			
			Reporter.logEvent(Status.INFO, "Testcase Description", Stock.GetParameterValue("description"), false);
			
				requestURL = WebserviceMethods.formRequestURL(Stock.GetParameterValue("serviceURL")
						);
				
				System.out.println(requestURL);
				WebserviceMethods webMeth= new WebserviceMethods();
				
				jsonResponseString = webMeth.runGetService(requestURL,authCode);
				
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			Reporter.logEvent(Status.FAIL, "Exception", "Exception occured: "+e.getMessage(), false);
		}
		finally 
		{
			try   {   Reporter.finalizeTCReport();
			}
			catch (Exception e1)  { e1.printStackTrace(); 
			Reporter.logEvent(Status.FAIL, "Exception", "Exception occured: "+e1.getMessage(), false);}	
		}
	}
	
	@Test(dataProvider = "setData")
	public void getAssetInfo(int itr, Map<String, String> testdata)
	{
		try {
			
			
			Reporter.logEvent(Status.INFO, "Testcase Description", Stock.GetParameterValue("description"), false);
			
				requestURL = WebserviceMethods.formRequestURL(Stock.GetParameterValue("serviceURL"),
						Stock.GetParameterValue("indid"),
						Stock.GetParameterValue("Ga_id"),
						Stock.GetParameterValue("Ga_id")
						);
				
				System.out.println(requestURL);
				WebserviceMethods webMeth= new WebserviceMethods();
				if(Stock.GetParameterValue("Auth").equalsIgnoreCase("false"))
				{
				jsonResponseString = webMeth.runGetService(requestURL,authCode+"lol");
				}
				else
				{
					jsonResponseString = webMeth.runGetService(requestURL,authCode);
				}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			Reporter.logEvent(Status.FAIL, "Exception", "Exception occured: "+e.getMessage(), false);
		}
		finally 
		{
			try   {   Reporter.finalizeTCReport();
			}
			catch (Exception e1)  { e1.printStackTrace(); 
			Reporter.logEvent(Status.FAIL, "Exception", "Exception occured: "+e1.getMessage(), false);}	
		}
	}
	
	@Test(dataProvider = "setData")
	public void docDescOverride(int itr, Map<String, String> testdata)
	{
		try {
			
			
			Reporter.logEvent(Status.INFO, "Testcase Description", Stock.GetParameterValue("description"), false);
			
				requestURL = WebserviceMethods.formRequestURL(Stock.GetParameterValue("serviceURL"),
						Stock.GetParameterValue("db"),
						Stock.GetParameterValue("ga_id"),
						Stock.GetParameterValue("query")
						);
				
				System.out.println(requestURL);
				WebserviceMethods webMeth= new WebserviceMethods();
				if(Stock.GetParameterValue("Auth").equalsIgnoreCase("false"))
				{
				jsonResponseString = webMeth.runGetService(requestURL,authCode+"lol");
				}
				else
				{
					jsonResponseString = webMeth.runGetService(requestURL,authCode);
				}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			Reporter.logEvent(Status.FAIL, "Exception", "Exception occured: "+e.getMessage(), false);
		}
		finally 
		{
			try   {   Reporter.finalizeTCReport();
			}
			catch (Exception e1)  { e1.printStackTrace(); 
			Reporter.logEvent(Status.FAIL, "Exception", "Exception occured: "+e1.getMessage(), false);}	
		}
	}
	
	@Test(dataProvider = "setData")
	public void investment(int itr, Map<String, String> testdata)
	{
		try {
			
			
			Reporter.logEvent(Status.INFO, "Testcase Description", Stock.GetParameterValue("description"), false);
			
				requestURL = WebserviceMethods.formRequestURL(Stock.GetParameterValue("serviceURL"),
						Stock.GetParameterValue("db"),
						Stock.GetParameterValue("ga_id"),
						Stock.GetParameterValue("indid"),
						Stock.GetParameterValue("query")
						);
				
				System.out.println(requestURL);
				WebserviceMethods webMeth= new WebserviceMethods();
				if(Stock.GetParameterValue("Auth").equalsIgnoreCase("false"))
				{
				jsonResponseString = webMeth.runGetService(requestURL,authCode+"lol");
				}
				else
				{
					jsonResponseString = webMeth.runGetService(requestURL,authCode);
				}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			Reporter.logEvent(Status.FAIL, "Exception", "Exception occured: "+e.getMessage(), false);
		}
		finally 
		{
			try   {   Reporter.finalizeTCReport();
			}
			catch (Exception e1)  { e1.printStackTrace(); 
			Reporter.logEvent(Status.FAIL, "Exception", "Exception occured: "+e1.getMessage(), false);}	
		}
	}
	
	@Test(dataProvider = "setData")
	public void getPlanIndicator(int itr, Map<String, String> testdata)
	{
		try {
			
			
			Reporter.logEvent(Status.INFO, "Testcase Description", Stock.GetParameterValue("description"), false);
			
				requestURL = WebserviceMethods.formRequestURL(Stock.GetParameterValue("serviceURL"),
						Stock.GetParameterValue("ga_id"),
						Stock.GetParameterValue("age")
						);
				
				System.out.println(requestURL);
				WebserviceMethods webMeth= new WebserviceMethods();
				
					jsonResponseString = webMeth.runGetService(requestURL,authCode);
				
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			Reporter.logEvent(Status.FAIL, "Exception", "Exception occured: "+e.getMessage(), false);
		}
		finally 
		{
			try   {   Reporter.finalizeTCReport();
			}
			catch (Exception e1)  { e1.printStackTrace(); 
			Reporter.logEvent(Status.FAIL, "Exception", "Exception occured: "+e1.getMessage(), false);}	
		}
	}
	
	@Test(dataProvider = "setData")
	public void getAllPlanRules(int itr, Map<String, String> testdata)
	{
		try {
			
			
			Reporter.logEvent(Status.INFO, "Testcase Description", Stock.GetParameterValue("description"), false);
			
				requestURL = WebserviceMethods.formRequestURL(Stock.GetParameterValue("serviceURL")
						);
				
				System.out.println(requestURL);
				WebserviceMethods webMeth= new WebserviceMethods();
				
					jsonResponseString = webMeth.runGetService(requestURL,authCode);
				
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			Reporter.logEvent(Status.FAIL, "Exception", "Exception occured: "+e.getMessage(), false);
		}
		finally 
		{
			try   {   Reporter.finalizeTCReport();
			}
			catch (Exception e1)  { e1.printStackTrace(); 
			Reporter.logEvent(Status.FAIL, "Exception", "Exception occured: "+e1.getMessage(), false);}	
		}
	}
	
	@Test(dataProvider = "setData")
	public void getProfitSharing(int itr, Map<String, String> testdata)
	{
		try {
			
			
			Reporter.logEvent(Status.INFO, "Testcase Description", Stock.GetParameterValue("description"), false);
			
				requestURL = WebserviceMethods.formRequestURL(Stock.GetParameterValue("serviceURL"),
						Stock.GetParameterValue("ga_id")
						);
				
				System.out.println(requestURL);
				WebserviceMethods webMeth= new WebserviceMethods();
				
					jsonResponseString = webMeth.runGetService(requestURL,authCode);
				
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			Reporter.logEvent(Status.FAIL, "Exception", "Exception occured: "+e.getMessage(), false);
		}
		finally 
		{
			try   {   Reporter.finalizeTCReport();
			}
			catch (Exception e1)  { e1.printStackTrace(); 
			Reporter.logEvent(Status.FAIL, "Exception", "Exception occured: "+e1.getMessage(), false);}	
		}
	}
	
	@Test(dataProvider = "setData")
	public void getContactInfo(int itr, Map<String, String> testdata)
	{
		try {
			
			
			Reporter.logEvent(Status.INFO, "Testcase Description", Stock.GetParameterValue("description"), false);
			
				requestURL = WebserviceMethods.formRequestURL(Stock.GetParameterValue("serviceURL"),
						Stock.GetParameterValue("db"),
						Stock.GetParameterValue("ga_id"),
						Stock.GetParameterValue("indid")						
						);
				
				System.out.println(requestURL);
				WebserviceMethods webMeth= new WebserviceMethods();
				
					jsonResponseString = webMeth.runGetService(requestURL,authCode);
				
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			Reporter.logEvent(Status.FAIL, "Exception", "Exception occured: "+e.getMessage(), false);
		}
		finally 
		{
			try   {   Reporter.finalizeTCReport();
			}
			catch (Exception e1)  { e1.printStackTrace(); 
			Reporter.logEvent(Status.FAIL, "Exception", "Exception occured: "+e1.getMessage(), false);}	
		}
	}
	
	@Test(dataProvider = "setData")
	public void descOvrd(int itr, Map<String, String> testdata)
	{
		try {
			
			
			Reporter.logEvent(Status.INFO, "Testcase Description", Stock.GetParameterValue("description"), false);
			
				requestURL = WebserviceMethods.formRequestURL(Stock.GetParameterValue("serviceURL"),
						Stock.GetParameterValue("app"),
						Stock.GetParameterValue("func"),
						Stock.GetParameterValue("query")						
						);
				
				System.out.println(requestURL);
				WebserviceMethods webMeth= new WebserviceMethods();
				if(Stock.GetParameterValue("Auth").equalsIgnoreCase("false"))
				{
				jsonResponseString = webMeth.runGetService(requestURL,authCode+"lol");
				}
				else
				{
					jsonResponseString = webMeth.runGetService(requestURL,authCode);
				}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			Reporter.logEvent(Status.FAIL, "Exception", "Exception occured: "+e.getMessage(), false);
		}
		finally 
		{
			try   {   Reporter.finalizeTCReport();
			}
			catch (Exception e1)  { e1.printStackTrace(); 
			Reporter.logEvent(Status.FAIL, "Exception", "Exception occured: "+e1.getMessage(), false);}	
		}
	}
	
	
	
}

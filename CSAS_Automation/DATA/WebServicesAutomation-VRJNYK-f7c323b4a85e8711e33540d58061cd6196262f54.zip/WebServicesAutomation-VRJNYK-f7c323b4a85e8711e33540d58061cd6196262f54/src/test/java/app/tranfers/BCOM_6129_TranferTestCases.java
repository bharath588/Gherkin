package app.tranfers;

import java.lang.reflect.Method;
import java.net.URLEncoder;
import java.util.LinkedHashMap;
import java.util.Map;

import lib.Reporter;
import lib.Stock;

import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import util.CommonLib;
import webservices.util.JsonUtil;
import webservices.util.WebserviceUtil;
import app.ramlservices.pageobject.TranferServices;
import app.webservice.pageobjects.Response;

import com.aventstack.extentreports.Status;

import core.framework.Globals;

public class BCOM_6129_TranferTestCases {
	private LinkedHashMap<Integer, Map<String, String>> testData = null;
	CommonLib utilities;
	WebserviceUtil web = null;
	Response response;
	String jsonRequestString;
	String jsonResponseString;
	TranferServices tranferServices;

	@BeforeClass
	public void InitTest() throws Exception {
		Reporter.initializeModule(this.getClass().getSimpleName());
	}

	@DataProvider
	public Object[][] setData(Method tc) throws Exception {
		tc.getName();
		prepTestData(tc);
		return Stock.setDataProvider(this.testData);
	}

	private void prepTestData(Method testCase) throws Exception {
		this.testData = Stock.getTestData(this.getClass().getPackage()
				.getName(), testCase.getName());
	}
	
	/**
	 * <pre>
	 * Test Case is used to validate response with invalid authorization code
	 * </pre>
	 * 
	 * @param itr
	 *            : Iteration number
	 * @param testData
	 *            Test data map.
	 */
	@Test(dataProvider = "setData")
	public void TC01_Tranfer_6129_Positive_Flow(int itr,
			Map<String, String> testData) {
		String requestURL;
		try {
			Reporter.initializeReportForTC(itr, Globals.GC_MANUAL_TC_NAME,
					Stock.GetParameterValue("description"));
			Reporter.logEvent(Status.INFO,
					"Test Data used for iteration" + itr,
					CommonLib.getIterationDataAsString(testData), false);
			//Encode the parameter.
			String encodedTrfTypeCode  = URLEncoder.encode(Stock.GetParameterValue("trfTypeCode"),"UTF-8");
			requestURL = JsonUtil.formRequestURL(
					Stock.GetParameterValue("serviceURL"),
					Stock.GetParameterValue("db"),
					Stock.GetParameterValue("gaid"),
					Stock.GetParameterValue("indid"),
					Stock.GetParameterValue("startEffDate"),
					Stock.GetParameterValue("endEffDate"),
					encodedTrfTypeCode);
			System.out.println(requestURL);
			utilities = new CommonLib();
			utilities.triggerService(requestURL);
			utilities.validateResponseStatusCode();
			tranferServices = new TranferServices();
			tranferServices.validateTranferServiceResponse();
		} catch (Exception e) {
			e.printStackTrace();
			Globals.exception = e;
			String errorMsg = e.getMessage();
			Reporter.logEvent(Status.FAIL, "A run time exception occured.",
					errorMsg, false);
		} finally {
			try {
				Reporter.finalizeTCReport();
			} catch (Exception e1) {
				e1.printStackTrace();
			}
		}
	}
	/**
	 * <pre>
	 * Test Case is used to validate response with invalid autorization code
	 * </pre>
	 * 
	 * @param itr
	 *            : Iteration number
	 * @param testData
	 *            Test data map.
	 */
	@Test(dataProvider = "setData")
	public void TC02_Tranfer_6129_Negative_Flow(int itr,
			Map<String, String> testData) {
		String requestURL;
		try {
			Reporter.initializeReportForTC(itr, Globals.GC_MANUAL_TC_NAME,
					Stock.GetParameterValue("description"));
			Reporter.logEvent(Status.INFO,
					"Test Data used for iteration" + itr,
					CommonLib.getIterationDataAsString(testData), false);
			requestURL = JsonUtil.formRequestURL(
					Stock.GetParameterValue("serviceURL"),
					Stock.GetParameterValue("db"),
					Stock.GetParameterValue("gaid"),
					Stock.GetParameterValue("indid"),
					Stock.GetParameterValue("startEffDate"),
					Stock.GetParameterValue("endEffDate"),
					Stock.GetParameterValue("trfTypeCode"));
			System.out.println(requestURL);
			utilities = new CommonLib();
			utilities.triggerService(requestURL);
			utilities.validateResponseStatusCodeWithoutClientMessage();
		} catch (Exception e) {
			e.printStackTrace();
			Globals.exception = e;
			String errorMsg = e.getMessage();
			Reporter.logEvent(Status.FAIL, "A run time exception occured.",
					errorMsg, false);
		} finally {
			try {
				Reporter.finalizeTCReport();
			} catch (Exception e1) {
				e1.printStackTrace();
			}
		}
	}
	/**
	 * <pre>
	 * Test Case is used to validate response with invalid autorization code
	 * </pre>
	 * 
	 * @param itr
	 *            : Iteration number
	 * @param testData
	 *            Test data map.
	 */
	@Test(dataProvider = "setData")
	public void TC03_Tranfer_6129_Negative_Flow(int itr,
			Map<String, String> testData) {
		String requestURL;
		try {
			Reporter.initializeReportForTC(itr, Globals.GC_MANUAL_TC_NAME,
					Stock.GetParameterValue("description"));
			Reporter.logEvent(Status.INFO,
					"Test Data used for iteration" + itr,
					CommonLib.getIterationDataAsString(testData), false);
			requestURL = JsonUtil.formRequestURL(
					Stock.GetParameterValue("serviceURL"),
					Stock.GetParameterValue("db"),
					Stock.GetParameterValue("gaid"),
					Stock.GetParameterValue("indid"),
					Stock.GetParameterValue("startEffDate"),
					Stock.GetParameterValue("endEffDate"),
					Stock.GetParameterValue("trfTypeCode"));
			System.out.println(requestURL);
			utilities = new CommonLib();
			utilities.triggerService(requestURL);
			utilities.validateResponseStatusCode();
		} catch (Exception e) {
			e.printStackTrace();
			Globals.exception = e;
			String errorMsg = e.getMessage();
			Reporter.logEvent(Status.FAIL, "A run time exception occured.",
					errorMsg, false);
		} finally {
			try {
				Reporter.finalizeTCReport();
			} catch (Exception e1) {
				e1.printStackTrace();
			}
		}
	}
	/**
	 * <pre>
	 * Test Case is used to get list of campaign category/reason information when db value is passed empty in the request.
	 * </pre>
	 * 
	 * @param itr
	 *            : Iteration number
	 * @param testData
	 *            Test data map.
	 */
	@Test(dataProvider = "setData")
	public void TC04_Tranfer_6129_PostRequest_Flow(int itr,
			Map<String, String> testData) {
		
		String requestURL = null;
	try {
		// Read test data from external document.
		Reporter.initializeReportForTC(itr, Globals.GC_MANUAL_TC_NAME,
				Stock.GetParameterValue("description"));
		web = new WebserviceUtil();
		response = new Response();
		response.setusername(Stock.GetParameterValue("username"));
		response.setPassword(Stock.GetParameterValue("password"));
		jsonRequestString = JsonUtil.writeToJson(response);
		// Get authcode and construct a request URL.
		HttpResponse resp1 = web.getResponseasJsonforPostRequest(
				Stock.GetParameterValue("authURL"), jsonRequestString);
		String authCode = resp1.getFirstHeader("Authorization").getValue();
		requestURL = JsonUtil.formRequestURL(
				Stock.GetParameterValue("serviceURL"),
				Stock.GetParameterValue("db"),
				Stock.GetParameterValue("gaid"),
				Stock.GetParameterValue("indid"),
				Stock.GetParameterValue("startEffDate"),
				Stock.GetParameterValue("endEffDate"),
				Stock.GetParameterValue("trfTypeCode"));
		System.out.println(requestURL);
		// Add header and Make http request and get the response.
		HttpPost postReq = new HttpPost(requestURL);
		postReq.addHeader("Authorization", "JWT " + authCode);
		HttpResponse postRes = web.getResponse(postReq);
		// Get status code and reason phrase from response.
		String statusCode = String.valueOf(postRes.getStatusLine().getStatusCode());
		String expectedStatusCode= Stock.GetParameterValue("responseCode");
		String reasonPhrase = postRes.getStatusLine().getReasonPhrase();
		String exceptionMSG =postRes.getFirstHeader("exceptionMessage").getValue();
		
		// Verify http status code.
		if(statusCode.equalsIgnoreCase(expectedStatusCode)){
			Reporter.logEvent(Status.PASS, "Verify the status code",
					"Expected " +expectedStatusCode + " Actual " + statusCode+"\nReason Phrase "+reasonPhrase+"\n Exception Message  "+exceptionMSG, false);
		}else{
			Reporter.logEvent(Status.FAIL, "Verify the status code",
					"Expected " +expectedStatusCode + " Actual " + statusCode+"\nReason Phrase "+reasonPhrase, false);
		}
	} catch (Exception e) {
		e.printStackTrace();
		Globals.exception = e;
		String errorMsg = e.getMessage();
		Reporter.logEvent(Status.FAIL, "A run time exception occured.",
				errorMsg, false);
	} finally {
		try {
			Reporter.finalizeTCReport();
		} catch (Exception e1) {
			e1.printStackTrace();
		}
	}
}

}

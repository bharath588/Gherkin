package app.beneficiary;

import java.lang.reflect.Method;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.LinkedHashMap;
import java.util.Map;

import lib.DB;
import lib.Reporter;
import lib.Stock;

import org.apache.http.HttpResponse;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import util.CommonLib;
import webservices.util.JsonUtil;
import webservices.util.WebserviceUtil;
import app.webservice.pageobjects.JsonReadWriteUtils;
import app.webservice.pageobjects.Response;

import com.aventstack.extentreports.Status;

import core.framework.Globals;

public class LogChileEventTestCases {
	private LinkedHashMap<Integer, Map<String, String>> testData = null;
	CommonLib utilities;
	WebserviceUtil web = null;
	Response response;
	String jsonRequestString;
	String jsonResponseString;
	ResultSet queryResultSet;

	@BeforeClass
	public void InitTest() throws Exception {
		Reporter.initializeModule(this.getClass().getSimpleName());
	}

	@DataProvider
	public Object[][] setData(Method tc) throws Exception {
		tc.getName();
		prepTestData(tc);
		return Stock.setDataProvider(this.testData);
	}

	private void prepTestData(Method testCase) throws Exception {
		this.testData = Stock.getTestData(this.getClass().getPackage()
				.getName(), testCase.getName());
	}


	/**
	 * <pre>
	 * Test Case is used to verify  the response when correct set of data is passed in the request without Txn Code.
	 * </pre>
	 * <pre>
	 * Test Case is used to verify  the response when another correct set of data is passed in the request with Txn Code.
	 * </pre>
	 * <pre>
	 * Test Case is used to verify  the response when another correct set of data is passed in the request with multiple values in TxnCode.
	 * </pre>
	 * <pre>
	 * Test Case is used to verify  the response when optional parameter creation source is not passed in the request.
	 * </pre>
	 * @param itr
	 * @param testData
	 */
	@Test(dataProvider="setData")
	public void DDTC_33098_33099_33110_33111_LogChildEvent_6475_Positive_Flow(int itr, Map<String,String> testData)
	{
		String requestURL=null;
		try
		{
			Reporter.initializeReportForTC(itr, Globals.GC_MANUAL_TC_NAME, Stock.GetParameterValue("description"));
			web = new WebserviceUtil();
			response = new Response();
			response.setusername(Stock.GetParameterValue("username"));
			response.setPassword(Stock.GetParameterValue("password"));
			jsonRequestString = JsonUtil.writeToJson(response);
			
			// Get the authcode from service.
			HttpResponse resp1 = web.getResponseasJsonforPostRequest(
					Stock.GetParameterValue("authURL"), jsonRequestString);
			String authCode = resp1.getFirstHeader("Authorization").getValue();
			System.out.println("AuthCode: " + authCode);
			Reporter.logEvent(Status.INFO,
					"The Auth code for second webservice header",
					"\nThe Auth code for second webservice header is:\n"
							+ authCode, false);
			
			// Get request body from json file.
			String requestBody = JsonUtil.readFromExtJsonFile(Stock.GetParameterValue("inputFilePath"));
			
			// Construct request URL.
			requestURL = JsonUtil.formRequestURL(Stock.GetParameterValue("serviceURL"),
					Stock.GetParameterValue("db"));

			HttpResponse postRes = web.getResponseasJsonforPostRequest(requestURL,requestBody,"JWT " + authCode);

			// Verify HttpStatus code and reason phrase.
			verifyHttpStatusCodes(postRes);
			String responseString = web.getHttpResponseAsString(postRes);
			Reporter.logEvent(Status.INFO, "The response", responseString,false);
			
			// Verify response Event details with data base data.
			verifyEventDetails(responseString);
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
			Globals.exception = e;
			String errorMsg = e.getMessage();
			Reporter.logEvent(Status.FAIL, "A run time exception occured.",
					errorMsg, false);
		}
		finally {
			try {
				Reporter.finalizeTCReport();
			} catch (Exception e1) {
				e1.printStackTrace();
			}
		}
	}
	
	/**
	 * <pre>
	 * Test Case is used to verify the response when single Mandatory parameter is not passed in the request body.
	 * </pre>
	 * <pre>
	 * Test Case is used to verify  the response when eventtypecode parameter is passed null in the request.
	 * </pre>
	 * @param itr
	 * @param testData
	 */
	@Test(dataProvider="setData")
	public void DDTC_33106_33115_LogChildEvent_6475_Negative_Flow(int itr, Map<String,String> testData)
	{
		String requestURL=null;
		try
		{
			Reporter.initializeReportForTC(itr, Globals.GC_MANUAL_TC_NAME, Stock.GetParameterValue("description"));
			web = new WebserviceUtil();
			response = new Response();
			response.setusername(Stock.GetParameterValue("username"));
			response.setPassword(Stock.GetParameterValue("password"));
			jsonRequestString = JsonUtil.writeToJson(response);
			
			// Get the authcode from service.
			HttpResponse resp1 = web.getResponseasJsonforPostRequest(
					Stock.GetParameterValue("authURL"), jsonRequestString);
			String authCode = resp1.getFirstHeader("Authorization").getValue();
			System.out.println("AuthCode: " + authCode);
			Reporter.logEvent(Status.INFO,
					"The Auth code for second webservice header",
					"\nThe Auth code for second webservice header is:\n"
							+ authCode, false);
			
			// Get request body from json file.
			String requestBody = JsonUtil.readFromExtJsonFile(Stock.GetParameterValue("inputFilePath"));
			
			// Construct request URL.
			requestURL = JsonUtil.formRequestURL(Stock.GetParameterValue("serviceURL"),
					Stock.GetParameterValue("db"));
			HttpResponse postRes = web.getResponseasJsonforPostRequest(requestURL,requestBody,"JWT " + authCode);
			
			// Verify HttpStatus code and reason phrase.
			verifyHttpStatusCodes(postRes);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			Globals.exception = e;
			String errorMsg = e.getMessage();
			Reporter.logEvent(Status.FAIL, "A run time exception occured.",
					errorMsg, false);
		}
		finally {
			try {
				Reporter.finalizeTCReport();
			} catch (Exception e1) {
				e1.printStackTrace();
			}
		}
	}
	
	/**
	 * Method to verify HttpStatus code.
	 * @param res
	 */
	public void verifyHttpStatusCodes(HttpResponse res){
		String statusCode = String.valueOf(res.getStatusLine().getStatusCode());
		String expectedStatusCode= Stock.GetParameterValue("responseCode"); 
		String reasonPhrase = res.getStatusLine().getReasonPhrase();

		// Verify http status code.
		if(statusCode.equalsIgnoreCase(expectedStatusCode)){
			Reporter.logEvent(Status.PASS, "Verify the status code",
					"Expected " +expectedStatusCode + " Actual " + statusCode+"\nReason Phrase "+reasonPhrase, false);
		}else{
			Reporter.logEvent(Status.FAIL, "Verify the status code",
					"Expected " +expectedStatusCode + " Actual " + statusCode+"\nReason Phrase "+reasonPhrase, false);
		}
		
	}
	public void verifyEventDetails(String res) throws SQLException{
		
		String eventID =JsonReadWriteUtils.getNodeValueUsingJpath(res, "$..eventId");
		
		if(Stock.GetParameterValue("db").contains("in02")){
			// get evenId From data base.
			queryResultSet =DB.executeQuery("TARGETDB", Stock.getTestQuery("getEventDetailsFromDB")[1],eventID);
				
		}else{
		// get evenId From data base.
		queryResultSet =DB.executeQuery(Stock.getTestQuery("getEventDetailsFromDB")[0], Stock.getTestQuery("getEventDetailsFromDB")[1],eventID);
		}
		while(queryResultSet.next()){
			String dbEventID = queryResultSet.getString("ID");
			JsonReadWriteUtils.compareValueAndLogReport(eventID, dbEventID, "EventID");
			
			String eventTypeCode= JsonReadWriteUtils.getNodeValueUsingJpath(res, "$..eventTypeCode");
			String dbEventTypeCode = queryResultSet.getString("EVTY_CODE");
			JsonReadWriteUtils.compareValueAndLogReport(eventTypeCode, dbEventTypeCode, "eventTypeCode");
			
			// masterEventId in database set to  zero but in api response getting as empty.
			String masterEventId= JsonReadWriteUtils.getNodeValueUsingJpath(res, "$..masterEventId");
			String dbMasterEventId = queryResultSet.getString("MASTER_EV_ID");
			JsonReadWriteUtils.compareValueAndLogReport(masterEventId, dbMasterEventId, "masterEventId");
			
			String subjectId= JsonReadWriteUtils.getNodeValueUsingJpath(res, "$..subjectId");
			String dbSubjectId= queryResultSet.getString("SUBJECT_ID");
			JsonReadWriteUtils.compareValueAndLogReport(subjectId, dbSubjectId, "subjectId");
			
			String subSubjectId= JsonReadWriteUtils.getNodeValueUsingJpath(res, "$..subSubjectId");
			String dbSubsubjectId = queryResultSet.getString("SUB_SUBJECT_ID");
			JsonReadWriteUtils.compareValueAndLogReport(subSubjectId, dbSubsubjectId, "subSubjectId");
			
		}
		
	}
}

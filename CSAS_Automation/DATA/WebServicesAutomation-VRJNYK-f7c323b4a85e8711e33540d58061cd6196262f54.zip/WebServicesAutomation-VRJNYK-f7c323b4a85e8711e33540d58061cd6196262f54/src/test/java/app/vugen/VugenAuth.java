package app.vugen;

import java.lang.reflect.Method;
import java.sql.ResultSet;
import java.util.LinkedHashMap;
import java.util.Map;

import lib.Reporter;
import lib.Stock;

import org.apache.http.HttpResponse;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.aventstack.extentreports.Status;

import core.framework.Globals;
import util.AgentService;
import util.AuthService;
import util.CommonLib;
import util.WebserviceMethods;
import webservices.util.JsonUtil;
import webservices.util.WebserviceUtil;
import app.webservice.pageobjects.Response;

public class VugenAuth {
	private LinkedHashMap<Integer, Map<String, String>> testData = null;
	CommonLib utilities;
	WebserviceUtil web = null;
	Response response;
	String jsonRequestString;
	String jsonResponseString;
	ResultSet queryResultSet;
	String authCode;
	AuthService auth;
	public static String requestURL=null;

	@BeforeClass
	public void InitTest() throws Exception {
		Reporter.initializeModule(this.getClass().getSimpleName());
	}

	@DataProvider
	public Object[][] setData(Method tc) throws Exception {
		tc.getName();
		prepTestData(tc);
		return Stock.setDataProvider(this.testData);
	}

	private void prepTestData(Method testCase) throws Exception {
		this.testData = Stock.getTestData(this.getClass().getPackage()
				.getName(), testCase.getName());
	}
	
	
	@Test(dataProvider = "setData")
	public void AuthPart(int itr, Map<String, String> testdata)
	{
		try {
			Reporter.initializeReportForTC(itr, Globals.GC_MANUAL_TC_NAME,
					"PartAuth"+Stock.GetParameterValue("description"));
			
			
			Reporter.logEvent(Status.INFO, "Testcase Description", Stock.GetParameterValue("description"), false);
			
			AgentService agntserv;
			String jsonRequestStringAuth = null;
			String jsonRequestString = null;
			String jsonResponseString = null;
			 String authCode;
			WebserviceUtil web = null;
		
				// TODO Auto-generated method stub
				web = new WebserviceUtil();
				agntserv= new AgentService();
				agntserv.setUsername(Stock.GetParameterValue("username"));
				agntserv.setPassword(Stock.GetParameterValue("password"));
				agntserv.setAccuCode(Stock.GetParameterValue("accucode"));
				agntserv.setAccuAccessTypeCode(Stock.GetParameterValue("accutype"));
				jsonRequestStringAuth = JsonUtil.writeToJson(agntserv);
				

				HttpResponse httpResponseForAuth = web.getResponseasJsonforPostRequest(Stock.GetParameterValue("serviceURL"), jsonRequestStringAuth);
				Reporter.logEvent(Status.INFO, "Request URl",Stock.GetParameterValue("serviceURL"), false);
				Reporter.logEvent(Status.INFO, "Payload",jsonRequestStringAuth, false);
				System.out.println(httpResponseForAuth.toString());
				Reporter.logEvent(Status.INFO, "response", httpResponseForAuth.toString(), false);
				
				
				
				if(httpResponseForAuth.getStatusLine().getStatusCode() == Integer.parseInt(Stock.GetParameterValue("status")))
					Reporter.logEvent(Status.PASS, "Verify the Response status", "Response Code: "+Stock.GetParameterValue("status"), false);
				else
					Reporter.logEvent(Status.FAIL, "Verify the Response status", "NOT correct Response: Code!="+Stock.GetParameterValue("status"), false);
				int stat=200;	
				if(httpResponseForAuth.getStatusLine().getStatusCode()==stat||httpResponseForAuth.getStatusLine().getStatusCode()==204){
						authCode = httpResponseForAuth.getFirstHeader("Authorization").getValue();
						System.out.println("AuthCode: " + authCode);
						Reporter.logEvent(Status.PASS, "Verify Authentication Code", "Authentication code has generated successfully\n"
						+ "Authentication Code : " + authCode, false);
					}
				else if(httpResponseForAuth.getFirstHeader("exceptionmessage").getValue()!=null)
				{
					Reporter.logEvent(Status.INFO, "exception message", httpResponseForAuth.getFirstHeader("exceptionmessage").getValue(), false);
					 
				}
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			Reporter.logEvent(Status.FAIL, "Exception", "Exception occured: "+e.getMessage(), false);
		}
		finally 
		{
			try   {   Reporter.finalizeTCReport();
			}
			catch (Exception e1)  { e1.printStackTrace(); 
			Reporter.logEvent(Status.FAIL, "Exception", "Exception occured: "+e1.getMessage(), false);}	
		}
	}
	
	
	@Test(dataProvider = "setData")
	public void AuthPartMissingParam(int itr, Map<String, String> testdata)
	{
		try {
			Reporter.initializeReportForTC(itr, Globals.GC_MANUAL_TC_NAME,
					"PartAuth"+Stock.GetParameterValue("description"));
			
			
			Reporter.logEvent(Status.INFO, "Testcase Description", Stock.GetParameterValue("description"), false);
			
			AgentService agntserv;
			String jsonRequestStringAuth = null;
			String jsonRequestString = null;
			String jsonResponseString = null;
			 String authCode;
			WebserviceUtil web = null;
		
				// TODO Auto-generated method stub
				web = new WebserviceUtil();
				agntserv= new AgentService();
				agntserv.setUsername(Stock.GetParameterValue("username"));
				agntserv.setPassword(Stock.GetParameterValue("password"));
				agntserv.setAccuCode(Stock.GetParameterValue("accucode"));
				//agntserv.setAccuAccessTypeCode(Stock.GetParameterValue("accutype"));
				jsonRequestStringAuth = JsonUtil.writeToJson(agntserv);
				

				HttpResponse httpResponseForAuth = web.getResponseasJsonforPostRequest(Stock.GetParameterValue("serviceURL"), jsonRequestStringAuth);
				Reporter.logEvent(Status.INFO, "Request URl",Stock.GetParameterValue("serviceURL"), false);
				Reporter.logEvent(Status.INFO, "Payload",jsonRequestStringAuth, false);
				System.out.println(httpResponseForAuth.toString());
				Reporter.logEvent(Status.INFO, "response", httpResponseForAuth.toString(), false);
				
				
				
				if(httpResponseForAuth.getStatusLine().getStatusCode() == Integer.parseInt(Stock.GetParameterValue("status")))
					Reporter.logEvent(Status.PASS, "Verify the Response status", "Response Code: "+Stock.GetParameterValue("status"), false);
				else
					Reporter.logEvent(Status.FAIL, "Verify the Response status", "NOT correct Response: Code!="+Stock.GetParameterValue("status"), false);
				int stat=200;	
				if(httpResponseForAuth.getStatusLine().getStatusCode()==stat||httpResponseForAuth.getStatusLine().getStatusCode()==204){
					authCode = httpResponseForAuth.getFirstHeader("Authorization").getValue();
					System.out.println("AuthCode: " + authCode);
					Reporter.logEvent(Status.PASS, "Verify Authentication Code", "Authentication code has generated successfully\n"
					+ "Authentication Code : " + authCode, false);
				}
			else if(httpResponseForAuth.getFirstHeader("exceptionmessage").getValue()!=null)
			{
				Reporter.logEvent(Status.INFO, "exception message", httpResponseForAuth.getFirstHeader("exceptionmessage").getValue(), false);
				 
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			Reporter.logEvent(Status.FAIL, "Exception", "Exception occured: "+e.getMessage(), false);
		}
		finally 
		{
			try   {   Reporter.finalizeTCReport();
			}
			catch (Exception e1)  { e1.printStackTrace(); 
			Reporter.logEvent(Status.FAIL, "Exception", "Exception occured: "+e1.getMessage(), false);}	
		}
	}
	
	
	@Test(dataProvider = "setData")
	public void AgentAuth(int itr, Map<String, String> testdata)
	{
		try {
			Reporter.initializeReportForTC(itr, Globals.GC_MANUAL_TC_NAME,
					"AgentAuth"+Stock.GetParameterValue("description"));
			
			
			Reporter.logEvent(Status.INFO, "Testcase Description", Stock.GetParameterValue("description"), false);
			
			AgentService agntserv;
			String jsonRequestStringAuth = null;
			String jsonRequestString = null;
			String jsonResponseString = null;
			 String authCode;
			WebserviceUtil web = null;
		
				// TODO Auto-generated method stub
				web = new WebserviceUtil();
				agntserv= new AgentService();
				agntserv.setUsername(Stock.GetParameterValue("username"));
				agntserv.setPassword(Stock.GetParameterValue("password"));
			
				jsonRequestStringAuth = JsonUtil.writeToJson(agntserv);
				

				HttpResponse httpResponseForAuth = web.getResponseasJsonforPostRequest(Stock.GetParameterValue("serviceURL"), jsonRequestStringAuth);
				Reporter.logEvent(Status.INFO, "Request URl",Stock.GetParameterValue("serviceURL"), false);
				Reporter.logEvent(Status.INFO, "Payload",jsonRequestStringAuth, false);
				System.out.println(httpResponseForAuth.toString());
				Reporter.logEvent(Status.INFO, "response", httpResponseForAuth.toString(), false);
				
				
				
				if(httpResponseForAuth.getStatusLine().getStatusCode() == Integer.parseInt(Stock.GetParameterValue("status")))
					Reporter.logEvent(Status.PASS, "Verify the Response status", "Response Code: "+Stock.GetParameterValue("status"), false);
				else
					Reporter.logEvent(Status.FAIL, "Verify the Response status", "NOT correct Response: Code!="+Stock.GetParameterValue("status"), false);
				int stat=200;	
				if(httpResponseForAuth.getStatusLine().getStatusCode()==stat||httpResponseForAuth.getStatusLine().getStatusCode()==204){
					authCode = httpResponseForAuth.getFirstHeader("Authorization").getValue();
					System.out.println("AuthCode: " + authCode);
					Reporter.logEvent(Status.PASS, "Verify Authentication Code", "Authentication code has generated successfully\n"
					+ "Authentication Code : " + authCode, false);
				}
			else if(httpResponseForAuth.getFirstHeader("exceptionmessage").getValue()!=null)
			{
				Reporter.logEvent(Status.INFO, "exception message", httpResponseForAuth.getFirstHeader("exceptionmessage").getValue(), false);
				 
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			Reporter.logEvent(Status.FAIL, "Exception", "Exception occured: "+e.getMessage(), false);
		}
		finally 
		{
			try   {   Reporter.finalizeTCReport();
			}
			catch (Exception e1)  { e1.printStackTrace(); 
			Reporter.logEvent(Status.FAIL, "Exception", "Exception occured: "+e1.getMessage(), false);}	
		}
	}
	
	@Test(dataProvider = "setData")
	public void AgentAuthMissingPass(int itr, Map<String, String> testdata)
	{
		try {
			Reporter.initializeReportForTC(itr, Globals.GC_MANUAL_TC_NAME,
					"AgentAuth"+Stock.GetParameterValue("description"));
			
			
			Reporter.logEvent(Status.INFO, "Testcase Description", Stock.GetParameterValue("description"), false);
			
			AgentService agntserv;
			String jsonRequestStringAuth = null;
			String jsonRequestString = null;
			String jsonResponseString = null;
			 String authCode;
			WebserviceUtil web = null;
		
				// TODO Auto-generated method stub
				web = new WebserviceUtil();
				agntserv= new AgentService();
				agntserv.setUsername(Stock.GetParameterValue("username"));
				//agntserv.setPassword(Stock.GetParameterValue("password"));
			
				jsonRequestStringAuth = JsonUtil.writeToJson(agntserv);
				

				HttpResponse httpResponseForAuth = web.getResponseasJsonforPostRequest(Stock.GetParameterValue("serviceURL"), jsonRequestStringAuth);
				Reporter.logEvent(Status.INFO, "Request URl",Stock.GetParameterValue("serviceURL"), false);
				Reporter.logEvent(Status.INFO, "Payload",jsonRequestStringAuth, false);
				System.out.println(httpResponseForAuth.toString());
				Reporter.logEvent(Status.INFO, "response", httpResponseForAuth.toString(), false);
				
				
				
				if(httpResponseForAuth.getStatusLine().getStatusCode() == Integer.parseInt(Stock.GetParameterValue("status")))
					Reporter.logEvent(Status.PASS, "Verify the Response status", "Response Code: "+Stock.GetParameterValue("status"), false);
				else
					Reporter.logEvent(Status.FAIL, "Verify the Response status", "NOT correct Response: Code!="+Stock.GetParameterValue("status"), false);
				int stat=200;	
				if(httpResponseForAuth.getStatusLine().getStatusCode()==stat||httpResponseForAuth.getStatusLine().getStatusCode()==204){
					authCode = httpResponseForAuth.getFirstHeader("Authorization").getValue();
					System.out.println("AuthCode: " + authCode);
					Reporter.logEvent(Status.PASS, "Verify Authentication Code", "Authentication code has generated successfully\n"
					+ "Authentication Code : " + authCode, false);
				}
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			Reporter.logEvent(Status.FAIL, "Exception", "Exception occured: "+e.getMessage(), false);
		}
		finally 
		{
			try   {   Reporter.finalizeTCReport();
			}
			catch (Exception e1)  { e1.printStackTrace(); 
			Reporter.logEvent(Status.FAIL, "Exception", "Exception occured: "+e1.getMessage(), false);}	
		}
	}
	
	@Test(dataProvider = "setData")
	public void ClientAuth(int itr, Map<String, String> testdata)
	{
		try {
			Reporter.initializeReportForTC(itr, Globals.GC_MANUAL_TC_NAME,
					"ClientAuth"+Stock.GetParameterValue("description"));
			
			
			Reporter.logEvent(Status.INFO, "Testcase Description", Stock.GetParameterValue("description"), false);
			
			AgentService agntserv;
			String jsonRequestStringAuth = null;
			String jsonRequestString = null;
			String jsonResponseString = null;
			 String authCode;
			WebserviceUtil web = null;
		
				// TODO Auto-generated method stub
				web = new WebserviceUtil();
				agntserv= new AgentService();
				agntserv.setUsername(Stock.GetParameterValue("username"));
				agntserv.setPassword(Stock.GetParameterValue("password"));
				agntserv.setAccuCode(Stock.GetParameterValue("accucode"));
			
				jsonRequestStringAuth = JsonUtil.writeToJson(agntserv);
				

				HttpResponse httpResponseForAuth = web.getResponseasJsonforPostRequest(Stock.GetParameterValue("serviceURL"), jsonRequestStringAuth);
				Reporter.logEvent(Status.INFO, "Request URl",Stock.GetParameterValue("serviceURL"), false);
				Reporter.logEvent(Status.INFO, "Payload",jsonRequestStringAuth, false);
				System.out.println(httpResponseForAuth.toString());
				Reporter.logEvent(Status.INFO, "response", httpResponseForAuth.toString(), false);
				
				
				
				if(httpResponseForAuth.getStatusLine().getStatusCode() == Integer.parseInt(Stock.GetParameterValue("status")))
					Reporter.logEvent(Status.PASS, "Verify the Response status", "Response Code: "+Stock.GetParameterValue("status"), false);
				else
					Reporter.logEvent(Status.FAIL, "Verify the Response status", "NOT correct Response: Code!="+Stock.GetParameterValue("status"), false);
				int stat=200;	
				if(httpResponseForAuth.getStatusLine().getStatusCode()==stat||httpResponseForAuth.getStatusLine().getStatusCode()==204){
					authCode = httpResponseForAuth.getFirstHeader("Authorization").getValue();
					System.out.println("AuthCode: " + authCode);
					Reporter.logEvent(Status.PASS, "Verify Authentication Code", "Authentication code has generated successfully\n"
					+ "Authentication Code : " + authCode, false);
				}
			else if(httpResponseForAuth.getFirstHeader("exceptionmessage").getValue()!=null)
			{
				Reporter.logEvent(Status.INFO, "exception message", httpResponseForAuth.getFirstHeader("exceptionmessage").getValue(), false);
				 
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			Reporter.logEvent(Status.FAIL, "Exception", "Exception occured: "+e.getMessage(), false);
		}
		finally 
		{
			try   {   Reporter.finalizeTCReport();
			}
			catch (Exception e1)  { e1.printStackTrace(); 
			Reporter.logEvent(Status.FAIL, "Exception", "Exception occured: "+e1.getMessage(), false);}	
		}
	}
	
	
	
	@Test(dataProvider = "setData")
	public void ClientAuthMissPass(int itr, Map<String, String> testdata)
	{
		try {
			Reporter.initializeReportForTC(itr, Globals.GC_MANUAL_TC_NAME,
					"ClientAuth"+Stock.GetParameterValue("description"));
			
			
			Reporter.logEvent(Status.INFO, "Testcase Description", Stock.GetParameterValue("description"), false);
			
			AgentService agntserv;
			String jsonRequestStringAuth = null;
			String jsonRequestString = null;
			String jsonResponseString = null;
			 String authCode;
			WebserviceUtil web = null;
		
				// TODO Auto-generated method stub
				web = new WebserviceUtil();
				agntserv= new AgentService();
				agntserv.setUsername(Stock.GetParameterValue("username"));
				//agntserv.setPassword(Stock.GetParameterValue("password"));
				agntserv.setAccuCode(Stock.GetParameterValue("accucode"));
			
				jsonRequestStringAuth = JsonUtil.writeToJson(agntserv);
				

				HttpResponse httpResponseForAuth = web.getResponseasJsonforPostRequest(Stock.GetParameterValue("serviceURL"), jsonRequestStringAuth);
				Reporter.logEvent(Status.INFO, "Request URl",Stock.GetParameterValue("serviceURL"), false);
				Reporter.logEvent(Status.INFO, "Payload",jsonRequestStringAuth, false);
				System.out.println(httpResponseForAuth.toString());
				Reporter.logEvent(Status.INFO, "response", httpResponseForAuth.toString(), false);
				
				
				
				if(httpResponseForAuth.getStatusLine().getStatusCode() == Integer.parseInt(Stock.GetParameterValue("status")))
					Reporter.logEvent(Status.PASS, "Verify the Response status", "Response Code: "+Stock.GetParameterValue("status"), false);
				else
					Reporter.logEvent(Status.FAIL, "Verify the Response status", "NOT correct Response: Code!="+Stock.GetParameterValue("status"), false);
				int stat=200;	
				if(httpResponseForAuth.getStatusLine().getStatusCode()==stat||httpResponseForAuth.getStatusLine().getStatusCode()==204){
					authCode = httpResponseForAuth.getFirstHeader("Authorization").getValue();
					System.out.println("AuthCode: " + authCode);
					Reporter.logEvent(Status.PASS, "Verify Authentication Code", "Authentication code has generated successfully\n"
					+ "Authentication Code : " + authCode, false);
				}
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			Reporter.logEvent(Status.FAIL, "Exception", "Exception occured: "+e.getMessage(), false);
		}
		finally 
		{
			try   {   Reporter.finalizeTCReport();
			}
			catch (Exception e1)  { e1.printStackTrace(); 
			Reporter.logEvent(Status.FAIL, "Exception", "Exception occured: "+e1.getMessage(), false);}	
		}
	}

}

package app.sponsorcampaign;

import java.lang.reflect.Method;
import java.util.LinkedHashMap;
import java.util.Map;

import lib.Reporter;
import lib.Stock;

import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.aventstack.extentreports.Status;

import core.framework.Globals;
import util.CommonLib;
import webservices.util.JsonUtil;
import webservices.util.WebserviceUtil;
import app.ramlservices.pageobject.GroupAccountCampaign;
import app.webservice.pageobjects.Response;

public class GroupAccountCampaignTestCases {
	private LinkedHashMap<Integer, Map<String, String>> testData = null;
	CommonLib utilities;
	GroupAccountCampaign groupAccountCampaign;
	WebserviceUtil web = null;
	Response response;
	String jsonRequestString;
	String jsonResponseString;


	@BeforeClass
	public void InitTest() throws Exception {
		Reporter.initializeModule(this.getClass().getSimpleName());
	}

	@DataProvider
	public Object[][] setData(Method tc) throws Exception {
		tc.getName();
		prepTestData(tc);
		return Stock.setDataProvider(this.testData);
	}

	private void prepTestData(Method testCase) throws Exception {
		this.testData = Stock.getTestData(this.getClass().getPackage()
				.getName(), testCase.getName());
	}
	
	/**
	 * <pre>
	 * Test Case is used to get groupAccountCampaign with the correct input provided in the request with STATUS Code as ON.
	 * </pre>
	 * 
	 * @param itr
	 *            : Iteration number
	 * @param testData
	 *            Test data map.
	 */
	@Test(dataProvider = "setData")
	public void TC01_GroupAccountCampaign_Status_ON_Positive_Flow(int itr,
			Map<String, String> testData) {
		String requestURL;
		try {
			Reporter.initializeReportForTC(itr, Globals.GC_MANUAL_TC_NAME,
					Stock.GetParameterValue("description"));
			Reporter.logEvent(Status.INFO,
					"Test Data used for iteration" + itr,
					CommonLib.getIterationDataAsString(testData), false);
			requestURL = JsonUtil.formRequestURL(
					Stock.GetParameterValue("serviceURL"),
					Stock.GetParameterValue("db"),
					Stock.GetParameterValue("statusCode"),
					Stock.GetParameterValue("GCID"));
			System.out.println(requestURL);
			utilities = new CommonLib();
			utilities.triggerService(requestURL);
			utilities.validateResponseStatusCodeWithoutClientMessage();
			groupAccountCampaign = new GroupAccountCampaign();
			groupAccountCampaign.validateGroupACcountCampaignInfo();
		} catch (Exception e) {
			e.printStackTrace();
			Globals.exception = e;
			String errorMsg = e.getMessage();
			Reporter.logEvent(Status.FAIL, "A run time exception occured.",
					errorMsg, false);
		} finally {
			try {
				Reporter.finalizeTCReport();
			} catch (Exception e1) {
				e1.printStackTrace();
			}
		}
	}
	
	
	/**
	 * <pre>
	 * Test Case is used to get groupAccountCampaign with the correct input provided in the request with STATUS Code as OFF.
	 * </pre>
	 * 
	 * @param itr
	 *            : Iteration number
	 * @param testData
	 *            Test data map.
	 */
	@Test(dataProvider = "setData")
	public void TC02_GroupAccountCampaign_Status_OFF_Positive_Flow(int itr,
			Map<String, String> testData) {
		String requestURL;
		try {
			Reporter.initializeReportForTC(itr, Globals.GC_MANUAL_TC_NAME,
					Stock.GetParameterValue("description"));
			Reporter.logEvent(Status.INFO,
					"Test Data used for iteration" + itr,
					CommonLib.getIterationDataAsString(testData), false);
			requestURL = JsonUtil.formRequestURL(
					Stock.GetParameterValue("serviceURL"),
					Stock.GetParameterValue("db"),
					Stock.GetParameterValue("statusCode"),
					Stock.GetParameterValue("GCID"));
			System.out.println(requestURL);
			utilities = new CommonLib();
			utilities.triggerService(requestURL);
			utilities.validateResponseStatusCodeWithoutClientMessage();
			groupAccountCampaign = new GroupAccountCampaign();
			groupAccountCampaign.validateStatusOffGroupACcountCampaignInfo();
		} catch (Exception e) {
			e.printStackTrace();
			Globals.exception = e;
			String errorMsg = e.getMessage();
			Reporter.logEvent(Status.FAIL, "A run time exception occured.",
					errorMsg, false);
		} finally {
			try {
				Reporter.finalizeTCReport();
			} catch (Exception e1) {
				e1.printStackTrace();
			}
		}
	}
	
	/**
	 * <pre>
	 * Test Case is used to get groupAccountCampaign when gcId value is passed empty in the request.
	 * </pre>
	 * <pre>
	 * Test Case is used to get groupAccountCampaign when db value is passed empty in the request.
	 * </pre>
	 * <pre>
	 * Test Case is used to get groupAccountCampaign when gcId field is removed from the request.
	 * </pre>
	 * <pre>
	 * Test Case is used to get groupAccountCampaign when db  field is removed from the request.
	 * </pre>
	 * <pre>
	 * Test Case is used to get groupAccountCampaign when db,gcId and statusCode is passed empty in the request.
	 * </pre>
	 * <pre>Test Case is used to get groupAccountCampaign when invalid header is passed with JWT.
	 * </pre>
	 * <pre>Test Case is used to get groupAccountCampaign when invalid header is passed with out JWT.
	 * </pre?
	 * 
	 * @param itr
	 *            : Iteration number
	 * @param testData
	 *            Test data map.
	 */
	@Test(dataProvider = "setData")
	public void TC03_GroupAccountCampaign_Negative_Flow(int itr,
			Map<String, String> testData) {
		String requestURL;
		try {
			Reporter.initializeReportForTC(itr, Globals.GC_MANUAL_TC_NAME,
					Stock.GetParameterValue("description"));
			Reporter.logEvent(Status.INFO,
					"Test Data used for iteration" + itr,
					CommonLib.getIterationDataAsString(testData), false);
			requestURL = JsonUtil.formRequestURL(
					Stock.GetParameterValue("serviceURL"),
					Stock.GetParameterValue("db"),
					Stock.GetParameterValue("statusCode"),
					Stock.GetParameterValue("GCID"));
			System.out.println(requestURL);
			utilities = new CommonLib();
			utilities.triggerService(requestURL);
			utilities.validateResponseStatusCodeWithoutClientMessage();
		} catch (Exception e) {
			e.printStackTrace();
			Globals.exception = e;
			String errorMsg = e.getMessage();
			Reporter.logEvent(Status.FAIL, "A run time exception occured.",
					errorMsg, false);
		} finally {
			try {
				Reporter.finalizeTCReport();
			} catch (Exception e1) {
				e1.printStackTrace();
			}
		}
	}
	/**
	 * <pre>
	 * Test Case is used to get groupAccountCampaign when statusCode  field is passed empty in the request.
	 * </pre>
	 * <pre>
	 * Test Case is used to get groupAccountCampaign when statusCode  field is removed from the request.
	 * </pre>
	 * 
	 * @param itr
	 *            : Iteration number
	 * @param testData
	 *            Test data map.
	 */
	@Test(dataProvider = "setData")
	public void TC04_GroupAccountCampaign_Status_OFF_And_ON_Positive_Flow(int itr,
			Map<String, String> testData) {
		String requestURL;
		try {
			Reporter.initializeReportForTC(itr, Globals.GC_MANUAL_TC_NAME,
					Stock.GetParameterValue("description"));
			Reporter.logEvent(Status.INFO,
					"Test Data used for iteration" + itr,
					CommonLib.getIterationDataAsString(testData), false);
			requestURL = JsonUtil.formRequestURL(
					Stock.GetParameterValue("serviceURL"),
					Stock.GetParameterValue("db"),
					Stock.GetParameterValue("statusCode"),
					Stock.GetParameterValue("GCID"));
			System.out.println(requestURL);
			utilities = new CommonLib();
			utilities.triggerService(requestURL);
			utilities.validateResponseStatusCodeWithoutClientMessage();
			groupAccountCampaign = new GroupAccountCampaign();
			groupAccountCampaign.validateStatusOffAndONGroupACcountCampaignInfo();
		} catch (Exception e) {
			e.printStackTrace();
			Globals.exception = e;
			String errorMsg = e.getMessage();
			Reporter.logEvent(Status.FAIL, "A run time exception occured.",
					errorMsg, false);
		} finally {
			try {
				Reporter.finalizeTCReport();
			} catch (Exception e1) {
				e1.printStackTrace();
			}
		}
	}
	
	/**
	 * <pre>
	 * Test Case is used to get groupAccountCampaign when different method is passed instead of GET method.
	 * </pre>
	 * 
	 * @param itr
	 *            : Iteration number
	 * @param testData
	 *            Test data map.
	 */
	@Test(dataProvider = "setData")
	public void TC05_GroupAccountCampaign_PostRequest_Flow(int itr,
			Map<String, String> testData) {
		
		String requestURL = null;
	try {
		// Read test data from external document.
		Reporter.initializeReportForTC(itr, Globals.GC_MANUAL_TC_NAME,
				Stock.GetParameterValue("description"));
		web = new WebserviceUtil();
		response = new Response();
		response.setusername(Stock.GetParameterValue("username"));
		response.setPassword(Stock.GetParameterValue("password"));
		jsonRequestString = JsonUtil.writeToJson(response);
		// Get authcode and construct a request URL.
		HttpResponse resp1 = web.getResponseasJsonforPostRequest(
				Stock.GetParameterValue("authURL"), jsonRequestString);
		String authCode = resp1.getFirstHeader("Authorization").getValue();
		requestURL = JsonUtil.formRequestURL(
				Stock.GetParameterValue("serviceURL"),
				Stock.GetParameterValue("db"),
				Stock.GetParameterValue("statusCode"),
				Stock.GetParameterValue("GCID"));
		// Add header and Make http request and get the response.
		HttpPost postReq = new HttpPost(requestURL);
		postReq.addHeader("Authorization", "JWT " + authCode);
		HttpResponse postRes = web.getResponse(postReq);
		// Get status code and reason phrase from response.
		String statusCode = String.valueOf(postRes.getStatusLine().getStatusCode());
		String expectedStatusCode= Stock.GetParameterValue("responseCode");
		String reasonPhrase = postRes.getStatusLine().getReasonPhrase();
		System.out.println("code "+statusCode+"reasonPhrase  "+reasonPhrase);
		
		// Verify http status code.
		if(statusCode.equalsIgnoreCase(expectedStatusCode)){
			Reporter.logEvent(Status.PASS, "Verify the status code",
					"Expected " +expectedStatusCode + " Actual " + statusCode+"\nReason Phrase "+reasonPhrase, false);
		}else{
			Reporter.logEvent(Status.FAIL, "Verify the status code",
					"Expected " +expectedStatusCode + " Actual " + statusCode+"\nReason Phrase "+reasonPhrase, false);
		}
	} catch (Exception e) {
		e.printStackTrace();
		Globals.exception = e;
		String errorMsg = e.getMessage();
		Reporter.logEvent(Status.FAIL, "A run time exception occured.",
				errorMsg, false);
	} finally {
		try {
			Reporter.finalizeTCReport();
		} catch (Exception e1) {
			e1.printStackTrace();
		}
	}
}
}

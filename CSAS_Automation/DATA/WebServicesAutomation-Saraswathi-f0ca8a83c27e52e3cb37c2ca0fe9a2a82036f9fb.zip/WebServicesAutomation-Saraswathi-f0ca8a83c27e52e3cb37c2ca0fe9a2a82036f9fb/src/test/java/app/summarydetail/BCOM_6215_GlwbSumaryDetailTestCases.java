package app.summarydetail;

import java.lang.reflect.Method;
import java.util.LinkedHashMap;
import java.util.Map;

import lib.Reporter;
import lib.Stock;

import org.apache.commons.codec.DecoderException;
import org.apache.http.client.ClientProtocolException;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import util.CommonLib;
import webservices.util.JsonUtil;
import webservices.util.WebserviceUtil;
import app.webservice.pageobjects.Response;

import com.aventstack.extentreports.Status;

import core.framework.Globals;

public class BCOM_6215_GlwbSumaryDetailTestCases {
	private LinkedHashMap<Integer, Map<String, String>> testData = null;
	CommonLib utilities;
	WebserviceUtil web = null;
	Response response;
	String jsonRequestString;
	String jsonResponseString;

	@BeforeClass
	public void InitTest() throws Exception {
		Reporter.initializeModule(this.getClass().getSimpleName());
	}

	@DataProvider
	public Object[][] setData(Method tc) throws Exception {
		tc.getName();
		prepTestData(tc);
		return Stock.setDataProvider(this.testData);
	}

	private void prepTestData(Method testCase) throws Exception {
		this.testData = Stock.getTestData(this.getClass().getPackage()
				.getName(), testCase.getName());
	}

	/**
	 * <pre>
	 * Test Case is used to verify if it Returns the list of glwbFundActivityDetails as part of GlwbSumaryDetailActy when correct set of data is passed in the request.
	 * </pre>
	 * 
	 * @param itr
	 *            : Iteration number
	 * @param testData
	 *            Test data map.
	 */
	@Test(dataProvider = "setData")
	public void TC01_6215_GlwbSumaryDetail_Positive_Flow(int itr,
			Map<String, String> testData) throws ClientProtocolException,
			DecoderException, InterruptedException {
		String requestURL;
		try {
			Reporter.initializeReportForTC(itr, Globals.GC_MANUAL_TC_NAME,
					Stock.GetParameterValue("description"));
			Reporter.logEvent(Status.INFO,
					"Test Data used for iteration" + itr,
					CommonLib.getIterationDataAsString(testData), false);
			// Construct request URL.
			requestURL = JsonUtil.formRequestURL(
					Stock.GetParameterValue("serviceURL"),
					Stock.GetParameterValue("db"),
					Stock.GetParameterValue("gaId"),
					Stock.GetParameterValue("indId"),
					Stock.GetParameterValue("sdIoId"),
					Stock.GetParameterValue("startDate"),
					Stock.GetParameterValue("endDate"));

			// Trigger the service and validate response code.
			utilities = new CommonLib();
			utilities.triggerService(requestURL);
			utilities.validateResponseStatusCode();
		} catch (Exception e) {
			e.printStackTrace();
			Globals.exception = e;
			String errorMsg = e.getMessage();
			Reporter.logEvent(Status.FAIL, "A run time exception occured.",
					errorMsg, false);
		} finally {
			try {
				Reporter.finalizeTCReport();
			} catch (Exception e1) {
				e1.printStackTrace();
			}
		}
	}

	/**
	 * <pre>
	 * Test Case is used to verify if it Returns the list of glwbFundActivityDetails as part of GlwbSumaryDetailActy  when invalid value is passed in sdioId field.
	 * </pre>
	 * 
	 * <pre>
	 * Test Case is used to verify if it Returns the list of glwbFundActivityDetails as part of GlwbSumaryDetailActy  when endDate  field is removed from the request.
	 * </pre>
	 * 
	 * <pre>
	 * Test Case is used to verify if it Returns the list of glwbFundActivityDetails as part of GlwbSumaryDetailActy  when db,gaId,indId,sdioId,startDate and endDate is passed empty in the request.
	 * </pre>
	 * 
	 * <pre>
	 * Test Case is used to verify if it Returns the list of glwbFundActivityDetails as part of GlwbSumaryDetailActy  when sdioId  field is removed from the request.
	 * </pre>
	 * 
	 * @param itr
	 *            : Iteration number
	 * @param testData
	 *            Test data map.
	 */
	@Test(dataProvider = "setData")
	public void TC02_6215_GlwbSumaryDetail_Negative_Flow(int itr,
			Map<String, String> testData) throws ClientProtocolException,
			DecoderException, InterruptedException {
		String requestURL;
		try {
			Reporter.initializeReportForTC(itr, Globals.GC_MANUAL_TC_NAME,
					Stock.GetParameterValue("description"));
			Reporter.logEvent(Status.INFO,
					"Test Data used for iteration" + itr,
					CommonLib.getIterationDataAsString(testData), false);
			// Construct request URL.
			requestURL = JsonUtil.formRequestURL(
					Stock.GetParameterValue("serviceURL"),
					Stock.GetParameterValue("db"),
					Stock.GetParameterValue("gaId"),
					Stock.GetParameterValue("indId"),
					Stock.GetParameterValue("sdIoId"),
					Stock.GetParameterValue("startDate"),
					Stock.GetParameterValue("endDate"));

			// Trigger the service and validate response code.
			utilities = new CommonLib();
			utilities.triggerService(requestURL);
			utilities.validateResponseStatusCodeWithoutClientMessage();
		} catch (Exception e) {
			e.printStackTrace();
			Globals.exception = e;
			String errorMsg = e.getMessage();
			Reporter.logEvent(Status.FAIL, "A run time exception occured.",
					errorMsg, false);
		} finally {
			try {
				Reporter.finalizeTCReport();
			} catch (Exception e1) {
				e1.printStackTrace();
			}
		}
	}

}

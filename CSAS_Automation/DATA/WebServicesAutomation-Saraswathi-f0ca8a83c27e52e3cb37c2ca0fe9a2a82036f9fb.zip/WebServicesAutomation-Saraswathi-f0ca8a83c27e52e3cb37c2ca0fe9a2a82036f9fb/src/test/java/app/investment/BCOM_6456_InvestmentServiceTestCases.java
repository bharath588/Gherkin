package app.investment;

import java.lang.reflect.Method;
import java.util.LinkedHashMap;
import java.util.Map;

import lib.Reporter;
import lib.Stock;

import org.apache.commons.codec.DecoderException;
import org.apache.http.client.ClientProtocolException;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import util.CommonLib;
import webservices.util.JsonUtil;

import app.ramlservices.pageobject.InvestmentService;


import com.aventstack.extentreports.Status;

import core.framework.Globals;

public class BCOM_6456_InvestmentServiceTestCases {
	private LinkedHashMap<Integer, Map<String, String>> testData = null;
	CommonLib utilities;
	InvestmentService investmentService;

	@BeforeClass
	public void InitTest() throws Exception {
		Reporter.initializeModule(this.getClass().getSimpleName());
	}

	@DataProvider
	public Object[][] setData(Method tc) throws Exception {
		tc.getName();
		prepTestData(tc);
		return Stock.setDataProvider(this.testData);
	}

	private void prepTestData(Method testCase) throws Exception {
		this.testData = Stock.getTestData(this.getClass().getPackage()
				.getName(), testCase.getName());
	}
	
	/**
	 * <pre>
	 * Test Case is used to get list of campaign type category information with the correct input provided in the request.
	 * </pre>
	 * 
	 * @param itr
	 *            : Iteration number
	 * @param testData
	 *            Test data map.
	 */
	@Test(dataProvider = "setData")
	public void TC01_BCOM_6456_investmentService_Positive_Flow(int itr,
			Map<String, String> testData) throws ClientProtocolException, DecoderException, InterruptedException{
		String requestURL;
		try {
			Reporter.initializeReportForTC(itr, Globals.GC_MANUAL_TC_NAME,
					Stock.GetParameterValue("description"));
			Reporter.logEvent(Status.INFO,
					"Test Data used for iteration" + itr,
					CommonLib.getIterationDataAsString(testData), false);
			
			requestURL = JsonUtil.formRequestURL(
					Stock.GetParameterValue("serviceURL"),
					Stock.GetParameterValue("gaId"),
					Stock.GetParameterValue("db"));
			System.out.println(requestURL);
			
			utilities = new CommonLib();
			utilities.triggerService(requestURL);
			utilities.validateResponseStatusCode();
			investmentService = new InvestmentService();
			investmentService.validateInvestmentServiceDetails();
		} catch (Exception e) {
			e.printStackTrace();
			Globals.exception = e;
			String errorMsg = e.getMessage();
			Reporter.logEvent(Status.FAIL, "A run time exception occured.",
					errorMsg, false);
		} finally {
			try {
				Reporter.finalizeTCReport();
			} catch (Exception e1) {
				e1.printStackTrace();
			}
		}
	}
	/**
	 * <pre>
	 * Test Case is used to get list of campaign type category information with the correct input provided in the request.
	 * </pre>
	 * 
	 * @param itr
	 *            : Iteration number
	 * @param testData
	 *            Test data map.
	 */
	@Test(dataProvider = "setData")
	public void TC02_BCOM_6456_investmentService_Negative_Flow(int itr,
			Map<String, String> testData) throws ClientProtocolException, DecoderException, InterruptedException{
		String requestURL;
		try {
			Reporter.initializeReportForTC(itr, Globals.GC_MANUAL_TC_NAME,
					Stock.GetParameterValue("description"));
			Reporter.logEvent(Status.INFO,
					"Test Data used for iteration" + itr,
					CommonLib.getIterationDataAsString(testData), false);
			
			requestURL = JsonUtil.formRequestURL(
					Stock.GetParameterValue("serviceURL"),
					Stock.GetParameterValue("gaId"),
					Stock.GetParameterValue("db"));
			System.out.println(requestURL);
			
			utilities = new CommonLib();
			utilities.triggerService(requestURL);
			utilities.validateResponseStatusCode();
		} catch (Exception e) {
			e.printStackTrace();
			Globals.exception = e;
			String errorMsg = e.getMessage();
			Reporter.logEvent(Status.FAIL, "A run time exception occured.",
					errorMsg, false);
		} finally {
			try {
				Reporter.finalizeTCReport();
			} catch (Exception e1) {
				e1.printStackTrace();
			}
		}
	}
	/**
	 * <pre>
	 * Test Case is used to get list of campaign type category information with the correct input provided in the request.
	 * </pre>
	 * 
	 * @param itr
	 *            : Iteration number
	 * @param testData
	 *            Test data map.
	 */
	@Test(dataProvider = "setData")
	public void TC03_BCOM_6456_investmentService_Positive_Flow(int itr,
			Map<String, String> testData) throws ClientProtocolException, DecoderException, InterruptedException{
		String requestURL;
		try {
			Reporter.initializeReportForTC(itr, Globals.GC_MANUAL_TC_NAME,
					Stock.GetParameterValue("description"));
			Reporter.logEvent(Status.INFO,
					"Test Data used for iteration" + itr,
					CommonLib.getIterationDataAsString(testData), false);
			
			requestURL = JsonUtil.formRequestURL(
					Stock.GetParameterValue("serviceURL"),
					Stock.GetParameterValue("gaId"),
					Stock.GetParameterValue("db"));
			System.out.println(requestURL);
			
			utilities = new CommonLib();
			utilities.triggerService(requestURL);
			utilities.validateResponseStatusCode();
		} catch (Exception e) {
			e.printStackTrace();
			Globals.exception = e;
			String errorMsg = e.getMessage();
			Reporter.logEvent(Status.FAIL, "A run time exception occured.",
					errorMsg, false);
		} finally {
			try {
				Reporter.finalizeTCReport();
			} catch (Exception e1) {
				e1.printStackTrace();
			}
		}
	}



}

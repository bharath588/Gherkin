package app.sponsorcampaign;

import java.lang.reflect.Method;
import java.util.LinkedHashMap;
import java.util.Map;

import lib.Reporter;
import lib.Stock;

import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import util.CommonLib;
import webservices.util.JsonUtil;
import webservices.util.WebserviceUtil;
import app.ramlservices.pageobject.GroupAccountService;
import app.webservice.pageobjects.Response;

import com.aventstack.extentreports.Status;

import core.framework.Globals;

public class GroupAccountTestCases {
	private LinkedHashMap<Integer, Map<String, String>> testData = null;
	CommonLib utilities;
	GroupAccountService groupAccount;
	WebserviceUtil web = null;
	Response response;
	String jsonRequestString;
	String jsonResponseString;

	@BeforeClass
	public void InitTest() throws Exception {
		Reporter.initializeModule(this.getClass().getSimpleName());
	}

	@DataProvider
	public Object[][] setData(Method tc) throws Exception {
		tc.getName();
		prepTestData(tc);
		return Stock.setDataProvider(this.testData);
	}

	private void prepTestData(Method testCase) throws Exception {
		this.testData = Stock.getTestData(this.getClass().getPackage()
				.getName(), testCase.getName());
	}

	/**
	 * <pre>
	 * Test Case is used to get GroupAccount information with the correct input provided in the request.
	 * </pre>
	 * 
	 * @param itr
	 *            : Iteration number
	 * @param testData
	 *            Test data map.
	 */
	@Test(dataProvider = "setData")
	public void TC01_GroupAccount_Service_Positive_Flow(int itr,
			Map<String, String> testData) {
		String requestURL;
		try {
			// Read test data from external document.
			Reporter.initializeReportForTC(itr, Globals.GC_MANUAL_TC_NAME,
					Stock.GetParameterValue("description"));
			Reporter.logEvent(Status.INFO,
					"Test Data used for iteration" + itr,
					CommonLib.getIterationDataAsString(testData), false);
			// Construct Request URL.
			requestURL = JsonUtil.formRequestURL(
					Stock.GetParameterValue("serviceURL"),
					Stock.GetParameterValue("db"),
					Stock.GetParameterValue("gcId"));
			System.out.println(requestURL);
			// TriggerRequest URL and validate API response code and reason phrase.
			utilities = new CommonLib();
			utilities.triggerService(requestURL);
			utilities.validateResponseStatusCode();
			// Validate GroupAccount Service Info.
			groupAccount = new GroupAccountService();
			groupAccount.validateGroupAccountInformation();
		} catch (Exception e) {
			e.printStackTrace();
			Globals.exception = e;
			String errorMsg = e.getMessage();
			Reporter.logEvent(Status.FAIL, "A run time exception occured.",
					errorMsg, false);
		} finally {
			try {
				Reporter.finalizeTCReport();
			} catch (Exception e1) {
				e1.printStackTrace();
			}
		}
	}
	
	/**
	 * <pre>
	 * Test Case is used to get group account information when gcId value is passed empty in the request.
	 * </pre>
	 * <pre>
	 * Test Case is used to get group account information when db value is passed empty in the request.
	 * </pre>
	 * <pre>
	 * Test Case is used to get group account information when gcId field is removed from the request.
	 * </pre>
	 * <pre>
	 * Test Case is used to get group account information when db field is removed from the request.
	 * </pre>
	 * <pre>
	 * Test Case is used to get GroupAccount information when db,gcId  is passed empty in the request.
	 * </pre>
	 * <pre>
	 * Test Case is used to get GroupAccount information when invalid header is passed with JWT
	 * </pre>
	 * <pre>
	 * Test Case is used to get GroupAccount information when valid header is passed without JWT.
	 * </pre>
	 * 
	 * @param itr
	 *            : Iteration number
	 * @param testData
	 *            Test data map.
	 */
	@Test(dataProvider = "setData")
	public void TC02_GroupAccount_Service_Negative_Flow(int itr,
			Map<String, String> testData) {
		String requestURL;
		try {
			// Read test data from external document.
			Reporter.initializeReportForTC(itr, Globals.GC_MANUAL_TC_NAME,
					Stock.GetParameterValue("description"));
			Reporter.logEvent(Status.INFO,
					"Test Data used for iteration" + itr,
					CommonLib.getIterationDataAsString(testData), false);
			// Construct Request URL.
			requestURL = JsonUtil.formRequestURL(
					Stock.GetParameterValue("serviceURL"),
					Stock.GetParameterValue("db"),
					Stock.GetParameterValue("gcId"));
			System.out.println(requestURL);
			// TriggerRequest URL and validate API response code and reason phrase.
			utilities = new CommonLib();
			utilities.triggerService(requestURL);
			utilities.validateResponseStatusCodeWithoutClientMessage();
		} catch (Exception e) {
			e.printStackTrace();
			Globals.exception = e;
			String errorMsg = e.getMessage();
			Reporter.logEvent(Status.FAIL, "A run time exception occured.",
					errorMsg, false);
		} finally {
			try {
				Reporter.finalizeTCReport();
			} catch (Exception e1) {
				e1.printStackTrace();
			}
		}
	}
	/**
	 * <pre>
	 * Test Case is used to get GroupAccount information when different method is passed instead of GET method
	 * </pre>
	 * 
	 * @param itr
	 *            : Iteration number
	 * @param testData
	 *            Test data map.
	 */
	@Test(dataProvider = "setData")
	public void TC03_GroupAccount_Negative_Flow(int itr,
			Map<String, String> testData) {
		
			String requestURL = null;
		try {
			// Read test data from external document.
			Reporter.initializeReportForTC(itr, Globals.GC_MANUAL_TC_NAME,
					Stock.GetParameterValue("description"));
			web = new WebserviceUtil();
			response = new Response();
			response.setusername(Stock.GetParameterValue("username"));
			response.setPassword(Stock.GetParameterValue("password"));
			jsonRequestString = JsonUtil.writeToJson(response);
			// Get authcode and construct a request URL.
			HttpResponse resp1 = web.getResponseasJsonforPostRequest(
					Stock.GetParameterValue("authURL"), jsonRequestString);
			String authCode = resp1.getFirstHeader("Authorization").getValue();
			requestURL = JsonUtil.formRequestURL(
					Stock.GetParameterValue("serviceURL"),
					Stock.GetParameterValue("db"),
					Stock.GetParameterValue("gcId"));
			// Add header and Make http request and get the response.
			HttpPost postReq = new HttpPost(requestURL);
			postReq.addHeader("Authorization", "JWT " + authCode);
			HttpResponse postRes = web.getResponse(postReq);
			// Get status code and reason phrase from response.
			String statusCode = String.valueOf(postRes.getStatusLine().getStatusCode());
			String expectedStatusCode= Stock.GetParameterValue("responseCode");
			String reasonPhrase = postRes.getStatusLine().getReasonPhrase();
			System.out.println("code "+statusCode+"reasonPhrase  "+reasonPhrase);
			
			// Verify http status code.
			if(statusCode.equalsIgnoreCase(expectedStatusCode)){
				Reporter.logEvent(Status.PASS, "Verify the status code",
						"Expected " +expectedStatusCode + " Actual " + statusCode+"\nReason Phrase "+reasonPhrase, false);
			}else{
				Reporter.logEvent(Status.FAIL, "Verify the status code",
						"Expected " +expectedStatusCode + " Actual " + statusCode+"\nReason Phrase "+reasonPhrase, false);
			}
		} catch (Exception e) {
			e.printStackTrace();
			Globals.exception = e;
			String errorMsg = e.getMessage();
			Reporter.logEvent(Status.FAIL, "A run time exception occured.",
					errorMsg, false);
		} finally {
			try {
				Reporter.finalizeTCReport();
			} catch (Exception e1) {
				e1.printStackTrace();
			}
		}
	}

}

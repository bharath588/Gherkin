package app.beneficiary;
import java.lang.reflect.Method;
import java.sql.ResultSet;
import java.util.LinkedHashMap;
import java.util.Map;

import lib.DB;
import lib.Reporter;
import lib.Stock;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.parser.Parser;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import util.CommonLib;
import webservices.util.JsonUtil;
import webservices.util.WebserviceUtil;
import app.webservice.pageobjects.JsonReadWriteUtils;
import app.webservice.pageobjects.Response;
import com.aventstack.extentreports.Status;
import core.framework.Globals;

	public class BeneficiaryServices {
		private LinkedHashMap<Integer, Map<String, String>> testData = null;
		CommonLib utilities;
		WebserviceUtil web = null;
		Response response;
		String jsonRequestString;
		String jsonResponseString;
		ResultSet queryResultSet;

		@BeforeClass
		public void InitTest() throws Exception {
			Reporter.initializeModule(this.getClass().getSimpleName());
		}

		@DataProvider
		public Object[][] setData(Method tc) throws Exception {
			tc.getName();
			prepTestData(tc);
			return Stock.setDataProvider(this.testData);
		}

		private void prepTestData(Method testCase) throws Exception {
			this.testData = Stock.getTestData(this.getClass().getPackage()
					.getName(), testCase.getName());
		}
		
		
		/**
		 * @param itr
		 * @param testData
		 */
		@Test(dataProvider="setData")
		public void TC01_DEFC16691_Benificary_Positive_Flow(int itr, Map<String,String> testData)
		{
			String requestURL=null;
			try
			{
				Reporter.initializeReportForTC(itr, Globals.GC_MANUAL_TC_NAME, Stock.GetParameterValue("description"));
				web = new WebserviceUtil();
				response = new Response();
				response.setusername(Stock.GetParameterValue("username"));
				response.setPassword(Stock.GetParameterValue("password"));
				jsonRequestString = JsonUtil.writeToJson(response);
				
				// Get the authcode from service.
				HttpResponse resp1 = web.getResponseasJsonforPostRequest(
						Stock.GetParameterValue("authURL"), jsonRequestString);
				String authCode = resp1.getFirstHeader("Authorization").getValue();
				System.out.println("AuthCode: " + authCode);
				Reporter.logEvent(Status.INFO,
						"The Auth code for second webservice header",
						"\nThe Auth code for second webservice header is:\n"
								+ authCode, false);
				
				// Get request body from json file.
				String requestBody = JsonUtil.readInputDataFromJsonFile(Stock.GetParameterValue("inputFilePath"));
				
				// Construct request URL.
				requestURL = JsonUtil.formRequestURL(Stock.GetParameterValue("serviceURL"),
						Stock.GetParameterValue("indid"),
						Stock.GetParameterValue("gaid"),
						Stock.GetParameterValue("marital_status"),
						Stock.GetParameterValue("db"));

				HttpResponse putRes = web.getResponseasJsonforPutRequest(requestURL,requestBody,"JWT " + authCode);

				String statusCode = String.valueOf(putRes.getStatusLine().getStatusCode());
				String expectedStatusCode= Stock.GetParameterValue("responseCode"); 
				String reasonPhrase = putRes.getStatusLine().getReasonPhrase();

				// Verify http status code.
				if(statusCode.equalsIgnoreCase(expectedStatusCode)){
					Reporter.logEvent(Status.PASS, "Verify the status code",
							"Expected " +expectedStatusCode + " Actual " + statusCode+"\nReason Phrase "+reasonPhrase, false);
				}else{
					Reporter.logEvent(Status.FAIL, "Verify the status code",
							"Expected " +expectedStatusCode + " Actual " + statusCode+"\nReason Phrase "+reasonPhrase, false);
				}
				String responseString = web.getHttpResponseAsString(putRes);
				System.out.println("res is    "+responseString);
				Reporter.logEvent(Status.INFO, "The response", responseString,false);
				String eventID =JsonReadWriteUtils.getNodeValueUsingXMLTagName(responseString,"eventId");
				
				// get evenId From data base.
				queryResultSet =DB.executeQuery("TARGETDB", Stock.getTestQuery("getEventIDFromDB")[1],eventID);
				while(queryResultSet.next()){
					String dbEventID = queryResultSet.getString("ID");
					JsonReadWriteUtils.compareValueAndLogReport(eventID, dbEventID, "EventID");
				}
			}
	
			catch(Exception e)
			{
				e.printStackTrace();
				Globals.exception = e;
				String errorMsg = e.getMessage();
				Reporter.logEvent(Status.FAIL, "A run time exception occured.",
						errorMsg, false);
			}
			finally {
				try {
					Reporter.finalizeTCReport();
				} catch (Exception e1) {
					e1.printStackTrace();
				}
			}
		}
	
		
		/**
		 * <pre>
		 * Test Case is used to validate response with invalid autorization code
		 * </pre>
		 * 
		 * @param itr
		 *            : Iteration number
		 * @param testData
		 *            Test data map.
		 */
		@Test(dataProvider = "setData")
		public void TC02_DEFC16691_Benificary_Negative_Flow(int itr,
				Map<String, String> testData) {
			String requestURL;
			try {
				Reporter.initializeReportForTC(itr, Globals.GC_MANUAL_TC_NAME, Stock.GetParameterValue("description"));
				web = new WebserviceUtil();
				response = new Response();
				String authCode ="";
				response.setusername(Stock.GetParameterValue("username"));
				response.setPassword(Stock.GetParameterValue("password"));
				jsonRequestString = JsonUtil.writeToJson(response);
				
				// Get the authcode from service.
				HttpResponse resp1 = web.getResponseasJsonforPostRequest(
						Stock.GetParameterValue("authURL"), jsonRequestString);
				if(Stock.GetParameterValue("Header").equalsIgnoreCase("invalid")){
					authCode =Stock.GetParameterValue("authCode");
					System.out.println("AUTH CODE  "+authCode);
				}else{
				 authCode = resp1.getFirstHeader("Authorization").getValue();
				System.out.println("AuthCode: " + authCode);
				}
				Reporter.logEvent(Status.INFO,
						"The Auth code for second webservice header",
						"\nThe Auth code for second webservice header is:\n"
								+ authCode, false);
				
				// Get request body from json file.
				String requestBody = JsonUtil.readInputDataFromJsonFile(Stock.GetParameterValue("inputFilePath"));
				
				// Construct request URL.
				requestURL = JsonUtil.formRequestURL(Stock.GetParameterValue("serviceURL"),
						Stock.GetParameterValue("indid"),
						Stock.GetParameterValue("gaid"),
						Stock.GetParameterValue("marital_status"),
						Stock.GetParameterValue("db"));
				System.out.println("request url    "+requestURL);

				HttpResponse putRes = web.getResponseasJsonforPutRequest(requestURL,requestBody,"JWT " + authCode);

				String statusCode = String.valueOf(putRes.getStatusLine().getStatusCode());
				String expectedStatusCode= Stock.GetParameterValue("responseCode"); 
				String reasonPhrase = putRes.getStatusLine().getReasonPhrase();
				String exceptionMSG =putRes.getFirstHeader("exceptionMessage").getValue();
				
				// Verify http status code.
				if(statusCode.equalsIgnoreCase(expectedStatusCode)){
					Reporter.logEvent(Status.PASS, "Verify the status code",
							"Expected " +expectedStatusCode + " Actual " + statusCode+"\nReason Phrase "+reasonPhrase+"\n Exception Message  "+exceptionMSG, false);
				}else{
					Reporter.logEvent(Status.FAIL, "Verify the status code",
							"Expected " +expectedStatusCode + " Actual " + statusCode+"\nReason Phrase "+reasonPhrase, false);
				}
			} catch (Exception e) {
				e.printStackTrace();
				Globals.exception = e;
				String errorMsg = e.getMessage();
				Reporter.logEvent(Status.FAIL, "A run time exception occured.",
						errorMsg, false);
			} finally {
				try {
					Reporter.finalizeTCReport();
				} catch (Exception e1) {
					e1.printStackTrace();
				}
			}
		}
		/**
		 * <pre>
		 * Test Case is used to validate response with invalid autorization code
		 * </pre>
		 * 
		 * @param itr
		 *            : Iteration number
		 * @param testData
		 *            Test data map.
		 */
		@Test(dataProvider = "setData")
		public void TC03_DEFC16691_Benificary_Positive_Flow_ExceptionMessages(int itr,
				Map<String, String> testData) {
			String requestURL=null;
			try
			{
				Reporter.initializeReportForTC(itr, Globals.GC_MANUAL_TC_NAME, Stock.GetParameterValue("description"));
				web = new WebserviceUtil();
				response = new Response();
				response.setusername(Stock.GetParameterValue("username"));
				response.setPassword(Stock.GetParameterValue("password"));
				jsonRequestString = JsonUtil.writeToJson(response);
				
				// Get the authcode from service.
				HttpResponse resp1 = web.getResponseasJsonforPostRequest(
						Stock.GetParameterValue("authURL"), jsonRequestString);
				String authCode = resp1.getFirstHeader("Authorization").getValue();
				System.out.println("AuthCode: " + authCode);
				Reporter.logEvent(Status.INFO,
						"The Auth code for second webservice header",
						"\nThe Auth code for second webservice header is:\n"
								+ authCode, false);
				
				// Get request body from json file.
				String requestBody = JsonUtil.readInputDataFromJsonFile(Stock.GetParameterValue("inputFilePath"));
				
				// Construct request URL.
				requestURL = JsonUtil.formRequestURL(Stock.GetParameterValue("serviceURL"),
						Stock.GetParameterValue("indid"),
						Stock.GetParameterValue("gaid"),
						Stock.GetParameterValue("marital_status"),
						Stock.GetParameterValue("db"));

				HttpResponse putRes = web.getResponseasJsonforPutRequest(requestURL,requestBody,"JWT " + authCode);

				String statusCode = String.valueOf(putRes.getStatusLine().getStatusCode());
				String expectedStatusCode= Stock.GetParameterValue("responseCode"); 
				String reasonPhrase = putRes.getStatusLine().getReasonPhrase();

				// Verify http status code.
				if(statusCode.equalsIgnoreCase(expectedStatusCode)){
					Reporter.logEvent(Status.PASS, "Verify the status code",
							"Expected " +expectedStatusCode + " Actual " + statusCode+"\nReason Phrase "+reasonPhrase, false);
				}else{
					Reporter.logEvent(Status.FAIL, "Verify the status code",
							"Expected " +expectedStatusCode + " Actual " + statusCode+"\nReason Phrase "+reasonPhrase, false);
				}
				String responseString = web.getHttpResponseAsString(putRes);
						Document doc = Jsoup.parse(responseString, "", Parser.xmlParser());
						String actualExceptionCode =doc.select("statusCode").text();
						System.out.println("event id   "+statusCode);
						String expectedExceptionCode = Stock.GetParameterValue("exceptionCode"); 
						JsonReadWriteUtils.compareValueAndLogReport(actualExceptionCode, expectedExceptionCode, "exceptionCode");
						
				System.out.println("res is    "+responseString);
				Reporter.logEvent(Status.INFO, "The response", responseString,
						false);
				
				// get evenId From data base.
				
			}
	
			catch(Exception e)
			{
				e.printStackTrace();
				Globals.exception = e;
				String errorMsg = e.getMessage();
				Reporter.logEvent(Status.FAIL, "A run time exception occured.",
						errorMsg, false);
			}
			finally {
				try {
					Reporter.finalizeTCReport();
				} catch (Exception e1) {
					e1.printStackTrace();
				}
			}
		}
		/**
		 * <pre>
		 * Test Case is used to validate response with invalid autorization code
		 * </pre>
		 * 
		 * @param itr
		 *            : Iteration number
		 * @param testData
		 *            Test data map.
		 */
		@Test(dataProvider = "setData")
		public void TC04_DEFC16691_Benificary_Negative_Flow(int itr,
				Map<String, String> testData) {
			String requestURL;
			try {
				Reporter.initializeReportForTC(itr, Globals.GC_MANUAL_TC_NAME, Stock.GetParameterValue("description"));
				web = new WebserviceUtil();
				response = new Response();
				String authCode ="";
				response.setusername(Stock.GetParameterValue("username"));
				response.setPassword(Stock.GetParameterValue("password"));
				jsonRequestString = JsonUtil.writeToJson(response);
				
				// Get the authcode from service.
				HttpResponse resp1 = web.getResponseasJsonforPostRequest(
						Stock.GetParameterValue("authURL"), jsonRequestString);
				if(Stock.GetParameterValue("Header").equalsIgnoreCase("invalid")){
					authCode =Stock.GetParameterValue("authCode");
					System.out.println("AUTH CODE  "+authCode);
				}else{
				 authCode = resp1.getFirstHeader("Authorization").getValue();
				System.out.println("AuthCode: " + authCode);
				}
				Reporter.logEvent(Status.INFO,
						"The Auth code for second webservice header",
						"\nThe Auth code for second webservice header is:\n"
								+ authCode, false);
				
				// Get request body from json file.
				String requestBody = JsonUtil.readInputDataFromJsonFile(Stock.GetParameterValue("inputFilePath"));
				
				// Construct request URL.
				requestURL = JsonUtil.formRequestURL(Stock.GetParameterValue("serviceURL"),
						Stock.GetParameterValue("indid"),
						Stock.GetParameterValue("gaid"),
						Stock.GetParameterValue("marital_status"),
						Stock.GetParameterValue("db"));
				System.out.println("request url    "+requestURL);

				HttpResponse putRes = web.getResponseasJsonforPutRequest(requestURL,requestBody,"JWT " + authCode);

				String statusCode = String.valueOf(putRes.getStatusLine().getStatusCode());
				String expectedStatusCode= Stock.GetParameterValue("responseCode"); 
				String reasonPhrase = putRes.getStatusLine().getReasonPhrase();
				
				// Verify http status code.
				if(statusCode.equalsIgnoreCase(expectedStatusCode)){
					Reporter.logEvent(Status.PASS, "Verify the status code",
							"Expected " +expectedStatusCode + " Actual " + statusCode+"\nReason Phrase "+reasonPhrase, false);
				}else{
					Reporter.logEvent(Status.FAIL, "Verify the status code",
							"Expected " +expectedStatusCode + " Actual " + statusCode+"\nReason Phrase "+reasonPhrase, false);
				}
			} catch (Exception e) {
				e.printStackTrace();
				Globals.exception = e;
				String errorMsg = e.getMessage();
				Reporter.logEvent(Status.FAIL, "A run time exception occured.",
						errorMsg, false);
			} finally {
				try {
					Reporter.finalizeTCReport();
				} catch (Exception e1) {
					e1.printStackTrace();
				}
			}
		}
		/**
		 * <pre>
		 * Test Case is used to get list of campaign category/reason information when db value is passed empty in the request.
		 * </pre>
		 * 
		 * @param itr
		 *            : Iteration number
		 * @param testData
		 *            Test data map.
		 */
		@Test(dataProvider = "setData")
		public void TC05_DEFC16691_Benificary_PostRequest_Flow(int itr,
				Map<String, String> testData) {
			
			String requestURL = null;
		try {
			// Read test data from external document.
			Reporter.initializeReportForTC(itr, Globals.GC_MANUAL_TC_NAME,
					Stock.GetParameterValue("description"));
			web = new WebserviceUtil();
			response = new Response();
			response.setusername(Stock.GetParameterValue("username"));
			response.setPassword(Stock.GetParameterValue("password"));
			jsonRequestString = JsonUtil.writeToJson(response);
			// Get authcode and construct a request URL.
			HttpResponse resp1 = web.getResponseasJsonforPostRequest(
					Stock.GetParameterValue("authURL"), jsonRequestString);
			String authCode = resp1.getFirstHeader("Authorization").getValue();
			requestURL = JsonUtil.formRequestURL(Stock.GetParameterValue("serviceURL"),
					Stock.GetParameterValue("indid"),
					Stock.GetParameterValue("gaid"),
					Stock.GetParameterValue("marital_status"),
					Stock.GetParameterValue("db"));
			System.out.println("request url    "+requestURL);
			// Add header and Make http request and get the response.
			HttpPost postReq = new HttpPost(requestURL);
			postReq.addHeader("Authorization", "JWT " + authCode);
			HttpResponse postRes = web.getResponse(postReq);
			// Get status code and reason phrase from response.
			String statusCode = String.valueOf(postRes.getStatusLine().getStatusCode());
			String expectedStatusCode= Stock.GetParameterValue("responseCode");
			String reasonPhrase = postRes.getStatusLine().getReasonPhrase();
			String exceptionMSG =postRes.getFirstHeader("exceptionMessage").getValue();
			
			// Verify http status code.
			if(statusCode.equalsIgnoreCase(expectedStatusCode)){
				Reporter.logEvent(Status.PASS, "Verify the status code",
						"Expected " +expectedStatusCode + " Actual " + statusCode+"\nReason Phrase "+reasonPhrase+"\n Exception Message  "+exceptionMSG, false);
			}else{
				Reporter.logEvent(Status.FAIL, "Verify the status code",
						"Expected " +expectedStatusCode + " Actual " + statusCode+"\nReason Phrase "+reasonPhrase, false);
			}
		} catch (Exception e) {
			e.printStackTrace();
			Globals.exception = e;
			String errorMsg = e.getMessage();
			Reporter.logEvent(Status.FAIL, "A run time exception occured.",
					errorMsg, false);
		} finally {
			try {
				Reporter.finalizeTCReport();
			} catch (Exception e1) {
				e1.printStackTrace();
			}
		}
	}

	}

package app.webservice.saveAssetInfoList;

//import generallib.DateFormatter;

import java.lang.reflect.Method;
import java.sql.ResultSet;
import java.util.LinkedHashMap;
import java.util.Map;

import lib.DB;
import lib.Reporter;
import lib.Stock;

import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.aventstack.extentreports.Status;

import app.webservice.pageobjects.JsonUtil;
import app.webservice.pageobjects.Response;
import app.webservice.pageobjects.WebserviceUtil;
import app.webservice.pageobjects.saveAssetData;
import core.framework.Globals;

public class TestAssetsDataService {

	WebserviceUtil webserviceUtil;
	String url;
	String jsonRequestString;
	String jsonResponseString;
	ResultSet queryResultSet = null;


	private LinkedHashMap<Integer, Map<String, String>> testData = null;
	String tcName;
	private Response response;


	@BeforeClass
	public void InitTest() throws Exception {
		Stock.getParam(Globals.GC_TESTCONFIGLOC
				+ Globals.GC_CONFIGFILEANDSHEETNAME + ".xls");
		Reporter.initializeModule(this.getClass().getName());
	}


	@DataProvider
	public Object[][] setData(Method tc) throws Exception {
		prepTestData(tc);
		return Stock.setDataProvider(this.testData);
	}


	private void prepTestData(Method testCase) throws Exception {
		this.testData = Stock.getTestData(this.getClass().getPackage()
			.getName(), testCase.getName());
	}
	
	@Test(dataProvider = "setData")
	public void testSaveAssetInfoList(int itr, Map<String, String> testdata)
			throws NoSuchFieldException, SecurityException {
	
		webserviceUtil = new WebserviceUtil();
		try {
			Reporter.initializeReportForTC(itr,	Globals.GC_MANUAL_TC_NAME);
			response = new Response();
			
			response.setusername(Stock.GetParameterValue("username"));
			response.setPassword(Stock.GetParameterValue("password"));
						
			jsonRequestString = JsonUtil.writeToJson(response);
			
			Reporter.logEvent(Status.INFO, "Request body of first response", jsonRequestString, false);			
			HttpResponse resp1 = webserviceUtil.getResponseasJsonforPostRequest(Stock.GetParameterValue("url1"), jsonRequestString);	
			System.out.println(resp1.toString());
			String authCode = resp1.getFirstHeader("Authorization").getValue();
			System.out.println("AuthCode: "+authCode);		
			
Reporter.logEvent(Status.INFO, "The Auth code to be taken for second webservice header", 
					"\nThe Auth code to be taken for second webservice header is:\n" + authCode, false);
			
			//Second Service
			
			saveAssetData value = new saveAssetData();
			value.setActionCode(Stock.GetParameterValue("actCode"));
			value.setAssetId(Stock.GetParameterValue("assetId"));
			value.setValue(Stock.GetParameterValue("value"));
			value.setCategoryId(Stock.GetParameterValue("catId"));
			value.setClientId(Stock.GetParameterValue("clientId"));
			value.setCreatedDate(Stock.GetParameterValue("createDate"));
			value.setCreatedBy(Stock.GetParameterValue("createdBy"));
			value.setDeletableCode(Stock.GetParameterValue("delCode"));
			value.setEditableCode(Stock.GetParameterValue("editCode"));
			value.setIndividualId(Stock.GetParameterValue("indId"));
			value.setMoneyType(Stock.GetParameterValue("moneyType"));
			value.setName(Stock.GetParameterValue("name"));
			value.setPlanId(Stock.GetParameterValue("planId"));
			value.setPresentValue(Stock.GetParameterValue("presentValue"));
			value.setStatus(Stock.GetParameterValue("status"));
			value.setUpdatedBy(Stock.GetParameterValue("updatedBy"));
			value.setUpdatedDate(Stock.GetParameterValue("updatedDate"));
			value.setViewableCode(Stock.GetParameterValue("viewCode"));
			value.setSource(Stock.GetParameterValue("src"));
			
			jsonRequestString = "["+JsonUtil.writeToJsonInclNull(value)+"]";
			
			Reporter.logEvent(Status.INFO, "Request body of second response", jsonRequestString, false);
			
			HttpPost httpReq = webserviceUtil.getPostRequest(Stock.GetParameterValue("url2"), jsonRequestString);
			httpReq.addHeader("Authorization", "JWT "+authCode);
			
			HttpResponse resp2 = webserviceUtil.getResponse(httpReq);			
			
			Reporter.logEvent(Status.INFO, "Response form second webservice",resp2.toString(), false);
			
			if(resp2.getStatusLine().getStatusCode() == 204)
			{
				Reporter.logEvent(Status.PASS, "Running Web Service to get Income Data ","Response: SUCCESS",false);
				Reporter.logEvent(Status.PASS, "Validating Status Code ","Expected: 204\nFrom Response: "+resp2.getStatusLine().getStatusCode(),false);
			
			
			}
			else{
				Reporter.logEvent(Status.FAIL, "Running Web Service to get Income Data ","Response: FAILURE",false);
				Reporter.logEvent(Status.FAIL, "Validating Status Code ","Expected: 204\nFrom Response: "+resp2.getStatusLine().getStatusCode(),false);
			}
			
			queryResultSet = DB.executeQuery(Stock.getTestQuery("fetchDataForPostServiceSaveAssetsData")[0], Stock.getTestQuery("fetchDataForPostServiceSaveAssetsData")[1], Stock.GetParameterValue("assetId"));
			if(queryResultSet.next()){
			Reporter.logEvent(Status.PASS, "Validating from Database\nTABLE NAME: DC_ASSETS_INFO","ASSET_ID: "+queryResultSet.getString("ASSET_ID")+
					"\nINDIVIDUAL_ID: "+queryResultSet.getString("INDIVIDUAL_ID")+
					"\nCLIENT_ID: "+queryResultSet.getString("CLIENT_ID")+
					"\nASSET_NAME: "+queryResultSet.getString("ASSET_NAME")+
					"\nCATEGORY_ID: "+queryResultSet.getString("CATEGORY_ID")+
					"\nPRESENT_VALUE: "+queryResultSet.getString("PRESENT_VALUE")+
					"\nSTATUS: "+queryResultSet.getString("STATUS")+
					"\nCREATED_DATE: "+queryResultSet.getString("CREATED_DATE")+
					"\nCREATED_BY: "+queryResultSet.getString("CREATED_BY")+
					"\nUPDATED_DATE: "+queryResultSet.getString("UPDATED_DATE")+
					"\nUPDATED_BY: "+queryResultSet.getString("UPDATED_BY")+
					"\nUPDATED_DATE: "+queryResultSet.getString("UPDATED_DATE")+
					"\nSOURCE: "+queryResultSet.getString("SOURCE")+
					"\nMONEY_TYPE: "+queryResultSet.getString("MONEY_TYPE")+
					"\nPLAN_ID: "+queryResultSet.getString("PLAN_ID"),false);
			}
		}
		catch (Exception e) {
			e.printStackTrace();
			Globals.exception = e;
			String errorMsg = e.getMessage();
			Reporter.logEvent(Status.FAIL, "A run time exception occured.",errorMsg,false);
		}
		finally {
			try {
				Reporter.finalizeTCReport();
			} catch (Exception e1) {
				e1.printStackTrace();
			}
		}
	}
	
	@Test(dataProvider = "setData")
	public void testSaveAssetInfoListForOnlyMandatoryParam(int itr, Map<String, String> testdata)
			throws NoSuchFieldException, SecurityException {
	
		webserviceUtil = new WebserviceUtil();
		try {
			Reporter.initializeReportForTC(itr,	Globals.GC_MANUAL_TC_NAME);
			response = new Response();
			
			response.setusername(Stock.GetParameterValue("username"));
			response.setPassword(Stock.GetParameterValue("password"));
						
			jsonRequestString = JsonUtil.writeToJson(response);
			
			Reporter.logEvent(Status.INFO, "Request body of first response", jsonRequestString, false);			
			HttpResponse resp1 = webserviceUtil.getResponseasJsonforPostRequest(Stock.GetParameterValue("url1"), jsonRequestString);	
			System.out.println(resp1.toString());
			String authCode = resp1.getFirstHeader("Authorization").getValue();
			System.out.println("AuthCode: "+authCode);		
			
			Reporter.logEvent(Status.INFO, "The Auth code to be taken for second webservice header", 
					"\nThe Auth code to be taken for second webservice header is:\n" + authCode, false);
			
			//Second Service
			
			saveAssetData value = new saveAssetData();
			/*value.setActionCode(Stock.GetParameterValue("actCode"));
			value.setAssetId(Stock.GetParameterValue("assetId"));
			value.setValue(Stock.GetParameterValue("value"));
			*/
			value.setCategoryId(Stock.GetParameterValue("catId"));
			value.setClientId(Stock.GetParameterValue("clientId"));
			
			/*value.setCreatedDate(Stock.GetParameterValue("createDate"));
			value.setCreatedBy(Stock.GetParameterValue("createdBy"));
			value.setDeletableCode(Stock.GetParameterValue("delCode"));
			value.setEditableCode(Stock.GetParameterValue("editCode"));
			*/
			value.setName(Stock.GetParameterValue("name"));
			value.setIndividualId(Stock.GetParameterValue("indId"));
			/*value.setMoneyType(Stock.GetParameterValue("moneyType"));
			value.setPlanId(Stock.GetParameterValue("planId"));
			*/
			value.setPresentValue(Stock.GetParameterValue("presentValue"));
			/*value.setStatus(Stock.GetParameterValue("status"));
			value.setUpdatedBy(Stock.GetParameterValue("updatedBy"));
			value.setUpdatedDate(Stock.GetParameterValue("updatedDate"));
			value.setViewableCode(Stock.GetParameterValue("viewCode"));
			value.setSource(Stock.GetParameterValue("src"));
			*/
			jsonRequestString = "["+JsonUtil.writeToJsonInclNull(value)+"]";
			
			Reporter.logEvent(Status.INFO, "Request body of second response", jsonRequestString, false);
			
			HttpPost httpReq = webserviceUtil.getPostRequest(Stock.GetParameterValue("url2"), jsonRequestString);
			httpReq.addHeader("Authorization", "JWT "+authCode);
			
			HttpResponse resp2 = webserviceUtil.getResponse(httpReq);			
			
			Reporter.logEvent(Status.INFO, "Response form second webservice",resp2.toString(), false);
			
			if(resp2.getStatusLine().getStatusCode() == 204)
			{
				Reporter.logEvent(Status.PASS, "Running Web Service to get Income Data ","Response: SUCCESS",false);
				Reporter.logEvent(Status.PASS, "Validating Status Code ","Expected: 204\nFrom Response: "+resp2.getStatusLine().getStatusCode(),false);
			}
			else{
				Reporter.logEvent(Status.FAIL, "Running Web Service to get Income Data ","Response: FAILURE",false);
				Reporter.logEvent(Status.FAIL, "Validating Status Code ","Expected: 204\nFrom Response: "+resp2.getStatusLine().getStatusCode(),false);
			}
			
			queryResultSet = DB.executeQuery(Stock.getTestQuery("fetchDataForPostServiceSaveAssetsData")[0], Stock.getTestQuery("fetchDataForPostServiceSaveAssetsData")[1], Stock.GetParameterValue("assetId"));
			if(queryResultSet.next()){
			Reporter.logEvent(Status.PASS, "Validating from Database\nTABLE NAME: DC_ASSETS_INFO","ASSET_ID: "+queryResultSet.getString("ASSET_ID")+
					"\nINDIVIDUAL_ID: "+queryResultSet.getString("INDIVIDUAL_ID")+
					"\nCLIENT_ID: "+queryResultSet.getString("CLIENT_ID")+
					"\nASSET_NAME: "+queryResultSet.getString("ASSET_NAME")+
					"\nCATEGORY_ID: "+queryResultSet.getString("CATEGORY_ID")+
					"\nPRESENT_VALUE: "+queryResultSet.getString("PRESENT_VALUE")+
					"\nSTATUS: "+queryResultSet.getString("STATUS")+
					"\nCREATED_DATE: "+queryResultSet.getString("CREATED_DATE")+
					"\nCREATED_BY: "+queryResultSet.getString("CREATED_BY")+
					"\nUPDATED_DATE: "+queryResultSet.getString("UPDATED_DATE")+
					"\nUPDATED_BY: "+queryResultSet.getString("UPDATED_BY")+
					"\nUPDATED_DATE: "+queryResultSet.getString("UPDATED_DATE")+
					"\nSOURCE: "+queryResultSet.getString("SOURCE")+
					"\nMONEY_TYPE: "+queryResultSet.getString("MONEY_TYPE")+
					"\nPLAN_ID: "+queryResultSet.getString("PLAN_ID"),false);
			}
		}		
		catch (Exception e) {
			e.printStackTrace();
			Globals.exception = e;
			String errorMsg = e.getMessage();
			Reporter.logEvent(Status.FAIL, "A run time exception occured.",errorMsg,false);
		}
		finally {
			try {
				Reporter.finalizeTCReport();
			} catch (Exception e1) {
				e1.printStackTrace();
			}
		}
	}
	
}

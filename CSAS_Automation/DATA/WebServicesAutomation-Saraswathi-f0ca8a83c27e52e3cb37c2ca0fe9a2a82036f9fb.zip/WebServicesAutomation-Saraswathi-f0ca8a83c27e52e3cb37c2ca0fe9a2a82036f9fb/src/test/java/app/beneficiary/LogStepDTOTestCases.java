package app.beneficiary;

import java.lang.reflect.Method;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.LinkedHashMap;
import java.util.Map;

import lib.DB;
import lib.Reporter;
import lib.Stock;

import org.apache.http.HttpResponse;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import util.CommonLib;
import webservices.util.JsonUtil;
import webservices.util.WebserviceUtil;
import app.webservice.pageobjects.JsonReadWriteUtils;
import app.webservice.pageobjects.Response;

import com.aventstack.extentreports.Status;

import core.framework.Globals;

public class LogStepDTOTestCases {
private LinkedHashMap<Integer, Map<String, String>> testData = null;
CommonLib utilities;
WebserviceUtil web = null;
Response response;
String jsonRequestString;
String jsonResponseString;
ResultSet queryResultSet;

@BeforeClass
public void InitTest() throws Exception {
	Reporter.initializeModule(this.getClass().getSimpleName());
}

@DataProvider
public Object[][] setData(Method tc) throws Exception {
	tc.getName();
	prepTestData(tc);
	return Stock.setDataProvider(this.testData);
}

private void prepTestData(Method testCase) throws Exception {
	this.testData = Stock.getTestData(this.getClass().getPackage()
			.getName(), testCase.getName());
}


/**
 * @param itr
 * @param testData
 */
@Test(dataProvider="setData")
public void TC01_LogStepDTO_6475_Positive_Flow(int itr, Map<String,String> testData)
{
	String requestURL=null;
	try
	{
		Reporter.initializeReportForTC(itr, Globals.GC_MANUAL_TC_NAME, Stock.GetParameterValue("description"));
		web = new WebserviceUtil();
		response = new Response();
		response.setusername(Stock.GetParameterValue("username"));
		response.setPassword(Stock.GetParameterValue("password"));
		jsonRequestString = JsonUtil.writeToJson(response);
		
		// Verify SeqNBR before a request.
		String EventID = Stock.GetParameterValue("EventID");
		int seq1 =verifySequenceNbr(EventID);
		// Get the authcode from service.
		HttpResponse resp1 = web.getResponseasJsonforPostRequest(
				Stock.GetParameterValue("authURL"), jsonRequestString);
		String authCode = resp1.getFirstHeader("Authorization").getValue();
		System.out.println("AuthCode: " + authCode);
		Reporter.logEvent(Status.INFO,
				"The Auth code for second webservice header",
				"\nThe Auth code for second webservice header is:\n"
						+ authCode, false);
		
		// Get request body from json file.
		String requestBody = JsonUtil.readFromExtJsonFile(Stock.GetParameterValue("inputFilePath"));
		
		// Construct request URL.
		requestURL = JsonUtil.formRequestURL(Stock.GetParameterValue("serviceURL"),
				Stock.GetParameterValue("db"));

		HttpResponse postRes = web.getResponseasJsonforPostRequest(requestURL,requestBody,"JWT " + authCode);

		String statusCode = String.valueOf(postRes.getStatusLine().getStatusCode());
		String expectedStatusCode= Stock.GetParameterValue("responseCode"); 
		String reasonPhrase = postRes.getStatusLine().getReasonPhrase();

		// Verify http status code.
		if(statusCode.equalsIgnoreCase(expectedStatusCode)){
			Reporter.logEvent(Status.PASS, "Verify the status code",
					"Expected " +expectedStatusCode + " Actual " + statusCode+"\nReason Phrase "+reasonPhrase, false);
		}else{
			Reporter.logEvent(Status.FAIL, "Verify the status code",
					"Expected " +expectedStatusCode + " Actual " + statusCode+"\nReason Phrase "+reasonPhrase, false);
		}
		String responseString = web.getHttpResponseAsString(postRes);
		System.out.println("res is    "+responseString);
		Reporter.logEvent(Status.INFO, "The response", responseString,false);
		int seq2 = verifySequenceNbr(EventID);
		if(seq1<seq2){
			Reporter.logEvent(Status.PASS, "Verify the sequence code",
					"Before API call sequence" +seq1 + " After API call sequence " + seq2, false);
		}else{
			Reporter.logEvent(Status.FAIL, "Verify the sequence code",
					"Before API call sequence" +seq1 + " After API call sequence " + seq2, false);
		}
		
	}
		
	
	catch(Exception e)
	{
		e.printStackTrace();
		Globals.exception = e;
		String errorMsg = e.getMessage();
		Reporter.logEvent(Status.FAIL, "A run time exception occured.",
				errorMsg, false);
	}
	finally {
		try {
			Reporter.finalizeTCReport();
		} catch (Exception e1) {
			e1.printStackTrace();
		}
	}
}

/**
 * <pre>
 * Test Case is used to validate response with invalid autorization code
 * </pre>
 * 
 * @param itr
 *            : Iteration number
 * @param testData
 *            Test data map.
 */
@Test(dataProvider = "setData")
public void TC02_LogStepDTO_6475_Negative_Flow(int itr,
		Map<String, String> testData) {
	String requestURL=null;
	try
	{
		Reporter.initializeReportForTC(itr, Globals.GC_MANUAL_TC_NAME, Stock.GetParameterValue("description"));
		web = new WebserviceUtil();
		response = new Response();
		response.setusername(Stock.GetParameterValue("username"));
		response.setPassword(Stock.GetParameterValue("password"));
		jsonRequestString = JsonUtil.writeToJson(response);
		
		// Get the authcode from service.
		HttpResponse resp1 = web.getResponseasJsonforPostRequest(
				Stock.GetParameterValue("authURL"), jsonRequestString);
		String authCode = resp1.getFirstHeader("Authorization").getValue();
		System.out.println("AuthCode: " + authCode);
		Reporter.logEvent(Status.INFO,
				"The Auth code for second webservice header",
				"\nThe Auth code for second webservice header is:\n"
						+ authCode, false);
		
		// Construct request URL.
		requestURL = JsonUtil.formRequestURL(Stock.GetParameterValue("serviceURL"),
						Stock.GetParameterValue("db"));
		
		HttpResponse postRes ;
		if(Stock.GetParameterValue("inputFilePath").equalsIgnoreCase("null")){
			postRes = web.getResponseasJsonforPostRequest(requestURL,"JWT " + authCode);
		}else{
		// Get request body from json file.
		String requestBody = JsonUtil.readFromExtJsonFile(Stock.GetParameterValue("inputFilePath"));
		postRes = web.getResponseasJsonforPostRequest(requestURL,requestBody,"JWT " + authCode);
		}

		String statusCode = String.valueOf(postRes.getStatusLine().getStatusCode());
		String expectedStatusCode= Stock.GetParameterValue("responseCode"); 
		String reasonPhrase = postRes.getStatusLine().getReasonPhrase();

		// Verify http status code.
		if(statusCode.equalsIgnoreCase(expectedStatusCode)){
			Reporter.logEvent(Status.PASS, "Verify the status code",
					"Expected " +expectedStatusCode + " Actual " + statusCode+"\nReason Phrase "+reasonPhrase, false);
		}else{
			Reporter.logEvent(Status.FAIL, "Verify the status code",
					"Expected " +expectedStatusCode + " Actual " + statusCode+"\nReason Phrase "+reasonPhrase, false);
		}
	}
		
	
	catch(Exception e)
	{
		e.printStackTrace();
		Globals.exception = e;
		String errorMsg = e.getMessage();
		Reporter.logEvent(Status.FAIL, "A run time exception occured.",
				errorMsg, false);
	}
	finally {
		try {
			Reporter.finalizeTCReport();
		} catch (Exception e1) {
			e1.printStackTrace();
		}
	}
}

/**
 * <pre>
 * Test Case is used to validate response with invalid autorization code
 * </pre>
 * 
 * @param itr
 *            : Iteration number
 * @param testData
 *            Test data map.
 */
@Test(dataProvider = "setData")
public void TC03_LogNewEvent_6475_Negative_Flow(int itr,
		Map<String, String> testData) {
	String requestURL;
	try {
		Reporter.initializeReportForTC(itr, Globals.GC_MANUAL_TC_NAME, Stock.GetParameterValue("description"));
		web = new WebserviceUtil();
		response = new Response();
		String authCode ="";
		response.setusername(Stock.GetParameterValue("username"));
		response.setPassword(Stock.GetParameterValue("password"));
		jsonRequestString = JsonUtil.writeToJson(response);
		
		// Get the authcode from service.
		HttpResponse resp1 = web.getResponseasJsonforPostRequest(
				Stock.GetParameterValue("authURL"), jsonRequestString);
		if(Stock.GetParameterValue("Header").equalsIgnoreCase("invalid")){
			authCode =Stock.GetParameterValue("authCode");
			System.out.println("AUTH CODE  "+authCode);
		}else{
		 authCode = resp1.getFirstHeader("Authorization").getValue();
		System.out.println("AuthCode: " + authCode);
		}
	
		Reporter.logEvent(Status.INFO,
				"The Auth code for second webservice header",
				"\nThe Auth code for second webservice header is:\n"
						+ authCode, false);
		
		// Get request body from json file.
		String requestBody = JsonUtil.readFromExtJsonFile(Stock.GetParameterValue("inputFilePath"));
		
		// Construct request URL.
		requestURL = JsonUtil.formRequestURL(Stock.GetParameterValue("serviceURL"),
				Stock.GetParameterValue("db"));
		HttpResponse postRes ;
		if(Stock.GetParameterValue("JWT").equalsIgnoreCase("JWT")){
		 postRes = web.getResponseasJsonforPostRequest(requestURL,requestBody,"JWT " + authCode);
		}else{
			 postRes = web.getResponseasJsonforPostRequest(requestURL,requestBody,""+authCode);
		}

		String statusCode = String.valueOf(postRes.getStatusLine().getStatusCode());
		String expectedStatusCode= Stock.GetParameterValue("responseCode"); 
		String reasonPhrase = postRes.getStatusLine().getReasonPhrase();
		String exceptionMSG =postRes.getFirstHeader("exceptionMessage").getValue();

		// Verify http status code.
		if(statusCode.equalsIgnoreCase(expectedStatusCode)){
			Reporter.logEvent(Status.PASS, "Verify the status code",
					"Expected " +expectedStatusCode + " Actual " + statusCode+"\nReason Phrase "+reasonPhrase+",\n Exception Message  "+exceptionMSG, false);
		}else{
			Reporter.logEvent(Status.FAIL, "Verify the status code",
					"Expected " +expectedStatusCode + " Actual " + statusCode+"\nReason Phrase "+reasonPhrase, false);
		}
		String responseString = web.getHttpResponseAsString(postRes);
		System.out.println("res is    "+responseString);
		Reporter.logEvent(Status.INFO, "The response", responseString,false);
		
	} catch (Exception e) {
		e.printStackTrace();
		Globals.exception = e;
		String errorMsg = e.getMessage();
		Reporter.logEvent(Status.FAIL, "A run time exception occured.",
				errorMsg, false);
	} finally {
		try {
			Reporter.finalizeTCReport();
		} catch (Exception e1) {
			e1.printStackTrace();
		}
	}
}

/**
* <pre>
* Test Case is used to get list of campaign category/reason information when db value is passed empty in the request.
* </pre>
* 
* @param itr
*            : Iteration number
* @param testData
*            Test data map.
*/
@Test(dataProvider = "setData")
public void TC04_LogNewEvent_6475_PostRequest_Flow(int itr,
	Map<String, String> testData) {

String requestURL = null;
try {
// Read test data from external document.
Reporter.initializeReportForTC(itr, Globals.GC_MANUAL_TC_NAME,
		Stock.GetParameterValue("description"));
web = new WebserviceUtil();
response = new Response();
response.setusername(Stock.GetParameterValue("username"));
response.setPassword(Stock.GetParameterValue("password"));
jsonRequestString = JsonUtil.writeToJson(response);
// Get authcode and construct a request URL.
HttpResponse resp1 = web.getResponseasJsonforPostRequest(
		Stock.GetParameterValue("authURL"), jsonRequestString);
String authCode = resp1.getFirstHeader("Authorization").getValue();
// Construct request URL.
	requestURL = JsonUtil.formRequestURL(Stock.GetParameterValue("serviceURL"),
			Stock.GetParameterValue("db"));
System.out.println("request url    "+requestURL);

// Get request body from json file.
String requestBody = JsonUtil.readFromExtJsonFile(Stock.GetParameterValue("inputFilePath"));
			
// Add header and Make http request and get the response.
HttpResponse putRes = web.getResponseasJsonforPutRequest(requestURL,requestBody,"JWT " + authCode);
// Get status code and reason phrase from response.
String statusCode = String.valueOf(putRes.getStatusLine().getStatusCode());
String expectedStatusCode= Stock.GetParameterValue("responseCode");
String reasonPhrase = putRes.getStatusLine().getReasonPhrase();
String exceptionMSG =putRes.getFirstHeader("exceptionMessage").getValue();

// Verify http status code.
if(statusCode.equalsIgnoreCase(expectedStatusCode)){
	Reporter.logEvent(Status.PASS, "Verify the status code",
			"Expected " +expectedStatusCode + " Actual " + statusCode+"\nReason Phrase "+reasonPhrase+"\n Exception Message  "+exceptionMSG, false);
}else{
	Reporter.logEvent(Status.FAIL, "Verify the status code",
			"Expected " +expectedStatusCode + " Actual " + statusCode+"\nReason Phrase "+reasonPhrase, false);
}
} catch (Exception e) {
e.printStackTrace();
Globals.exception = e;
String errorMsg = e.getMessage();
Reporter.logEvent(Status.FAIL, "A run time exception occured.",
		errorMsg, false);
} finally {
try {
	Reporter.finalizeTCReport();
} catch (Exception e1) {
	e1.printStackTrace();
}
}
}
public int verifySequenceNbr(String eventID) throws SQLException{
	int seqNbr = 0;
	queryResultSet =DB.executeQuery(Stock.getTestQuery("getSequenceNbrDetailsFromDB")[0], Stock.getTestQuery("getSequenceNbrDetailsFromDB")[1],eventID);
	queryResultSet.afterLast();
	while (queryResultSet.previous()) {
		 seqNbr = queryResultSet.getInt("SEQNBR");
		 System.out.println("seq number is  :"+seqNbr);
		 break;
		
	}
	return seqNbr;
}
}

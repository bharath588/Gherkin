package app.deferrals;

import java.lang.reflect.Method;
import java.util.LinkedHashMap;
import java.util.Map;

import lib.Reporter;
import lib.Stock;

import org.apache.commons.codec.DecoderException;
import org.apache.http.client.ClientProtocolException;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import util.CommonLib;
import webservices.util.JsonUtil;
import webservices.util.WebserviceUtil;
import app.ramlservices.pageobject.PptDeferralInfoVO;
import app.webservice.pageobjects.Response;

import com.aventstack.extentreports.Status;

import core.framework.Globals;

public class BCOM_6479_getPptDeferralInfoVO {
	private LinkedHashMap<Integer, Map<String, String>> testData = null;
	CommonLib utilities;
	WebserviceUtil web = null;
	Response response;
	PptDeferralInfoVO pptDeferralInfoVO;
	String jsonRequestString;
	String jsonResponseString;

	@BeforeClass
	public void InitTest() throws Exception {
		Reporter.initializeModule(this.getClass().getSimpleName());
	}

	@DataProvider
	public Object[][] setData(Method tc) throws Exception {
		tc.getName();
		prepTestData(tc);
		return Stock.setDataProvider(this.testData);
	}

	private void prepTestData(Method testCase) throws Exception {
		this.testData = Stock.getTestData(this.getClass().getPackage()
				.getName(), testCase.getName());
	}
	
	
	/**
	 * <pre>
	 * Test Case is used to get list of campaign type category information with the correct input provided in the request.
	 * </pre>
	 * 
	 * @param itr
	 *            : Iteration number
	 * @param testData
	 *            Test data map.
	 */
	@Test(dataProvider = "setData")
	public void TC01_6479_getPptDeferralInfoVO_PositiveFlow(int itr,
			Map<String, String> testData) throws ClientProtocolException, DecoderException, InterruptedException{
		String requestURL;
		try {
			Reporter.initializeReportForTC(itr, Globals.GC_MANUAL_TC_NAME,
					Stock.GetParameterValue("description"));
			Reporter.logEvent(Status.INFO,
					"Test Data used for iteration" + itr,
					CommonLib.getIterationDataAsString(testData), false);
			
			requestURL = JsonUtil.formRequestURL(
					Stock.GetParameterValue("serviceURL"),
					Stock.GetParameterValue("db"),
					Stock.GetParameterValue("gaId"),
					Stock.GetParameterValue("indId"),
					Stock.GetParameterValue("application"),
					Stock.GetParameterValue("includePastDeferrals"),
					Stock.GetParameterValue("includeAllowedDeferrals"),
					Stock.GetParameterValue("OECMLevel"));
			
			System.out.println(requestURL);
			utilities = new CommonLib();
			utilities.triggerService(requestURL);
			utilities.validateResponseStatusCode(); 
			pptDeferralInfoVO = new PptDeferralInfoVO();
			pptDeferralInfoVO.validatePptDeferralInfoVODetails();
			/*
			String responseString = utilities.getHttpResponseAsString();
			System.out.println("res is    "+responseString);
			Reporter.logEvent(Status.INFO, "The response", responseString,false);*/
			
		} catch (Exception e) {
			e.printStackTrace();
			Globals.exception = e;
			String errorMsg = e.getMessage();
			Reporter.logEvent(Status.FAIL, "A run time exception occured.",
					errorMsg, false);
		} finally {
			try {
				Reporter.finalizeTCReport();
			} catch (Exception e1) {
				e1.printStackTrace();
			}
		}
	}
	/**
	 * <pre>
	 * Test Case is used to get list of campaign type category information with the correct input provided in the request.
	 * </pre>
	 * 
	 * @param itr
	 *            : Iteration number
	 * @param testData
	 *            Test data map.
	 */
	@Test(dataProvider = "setData")
	public void TC02_6479_getPptDeferralInfoVO_NegativeFlow(int itr,
			Map<String, String> testData) throws ClientProtocolException, DecoderException, InterruptedException{
		String requestURL;
		try {
			Reporter.initializeReportForTC(itr, Globals.GC_MANUAL_TC_NAME,
					Stock.GetParameterValue("description"));
			Reporter.logEvent(Status.INFO,
					"Test Data used for iteration" + itr,
					CommonLib.getIterationDataAsString(testData), false);
			
			requestURL = JsonUtil.formRequestURL(
					Stock.GetParameterValue("serviceURL"),
					Stock.GetParameterValue("db"),
					Stock.GetParameterValue("gaId"),
					Stock.GetParameterValue("indId"),
					Stock.GetParameterValue("application"),
					Stock.GetParameterValue("includePastDeferrals"),
					Stock.GetParameterValue("includeAllowedDeferrals"),
					Stock.GetParameterValue("OECMLevel"));
			
			System.out.println(requestURL);
			utilities = new CommonLib();
			utilities.triggerService(requestURL);
			utilities.validateResponseStatusCode(); 
			
			String responseString = utilities.getHttpResponseAsString();
			System.out.println("res is    "+responseString);
			Reporter.logEvent(Status.INFO, "The response", responseString,false);
			
		} catch (Exception e) {
			e.printStackTrace();
			Globals.exception = e;
			String errorMsg = e.getMessage();
			Reporter.logEvent(Status.FAIL, "A run time exception occured.",
					errorMsg, false);
		} finally {
			try {
				Reporter.finalizeTCReport();
			} catch (Exception e1) {
				e1.printStackTrace();
			}
		}
	}
	

}

package app.ramlservices.pageobject;

import java.sql.ResultSet;
import java.sql.SQLException;

import lib.DB;
import lib.Reporter;
import lib.Stock;
import util.CommonLib;
import app.webservice.pageobjects.JsonReadWriteUtils;

import com.aventstack.extentreports.Status;

public class ContactService {
	CommonLib utilities;
	ResultSet queryResultSet;
	/*
	*//**
	 * Validate ContactService Response string.
	 * @throws SQLException
	 *//*
	public void validateContactServiceInformation1() throws SQLException {
		utilities = new CommonLib();
		String responseString = utilities.getHttpResponseAsString();
		System.out.println("res is    "+responseString);
		System.out.println("done");
		Reporter.logEvent(Status.INFO, "The response", responseString,false);
		
		queryResultSet=DB.executeQuery(Stock.getTestQuery("fetchContactServicersDetails")[0], Stock.getTestQuery("fetchContactServicersDetails")[1]);
		while(queryResultSet.next()){
			String typeCode =queryResultSet.getString("TYPE_CODE");
			//"$..[?(@.strucId=="+strucID+")]..disbursementOption..timingRequestItemId"
			//"$..enrlPeriodInfo[?(@.id==" + nqEnrlId+ ")].endDate");
			//'\'' + typeCode + '\''  "\"john\""; 
		String actualFirstName = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
				"$..[?(@.lastName==\""+lastName+"\" && @.typeCode==\""+typeCode+"\")]..firstName");
		String expectedFirstName = queryResultSet.getString("FIRST_NAME");
		JsonReadWriteUtils.compareValueAndLogReport(actualFirstName, expectedFirstName, "FirstName");

		String actualMiddleName = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
				"$..[?(@.typeCode="+typeCode+")]..middleName");
		String expectedMiddleName = queryResultSet.getString("MIDDLE_NAME");
		JsonReadWriteUtils.compareValueAndLogReport(actualMiddleName, expectedMiddleName, "MiddleName");
		
		String actualLastName = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
				"$..[?(@.lastName==\""+lastName+"\" && @.typeCode==\""+typeCode+"\")]..lastName");
		String expectedLastName = queryResultSet.getString("LAST_NAME");
		JsonReadWriteUtils.compareValueAndLogReport(actualLastName, expectedLastName, "LastName");
		
		String actualTypeCode = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
				"$..[?(@.lastName==\""+lastName+"\" && @.typeCode==\""+typeCode+"\")]..typeCode");
		String expectedTypeCode = queryResultSet.getString("TYPE_CODE");
		JsonReadWriteUtils.compareValueAndLogReport(actualTypeCode, expectedTypeCode, "TypeCode");
		
		String actualTypeCodeDescription = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
				"$..[?(@.lastName==\""+lastName+"\" && @.typeCode==\""+typeCode+"\")]..typeCodeDescription");
		String expectedTypeCodeDescription  = queryResultSet.getString("RV_MEANING");
		JsonReadWriteUtils.compareValueAndLogReport(actualTypeCodeDescription , expectedTypeCodeDescription , "TypeCodeDescription");
		
		String actualGaId = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
				"$..[?(@.lastName==\""+lastName+"\" && @.typeCode==\""+typeCode+"\")]..gaId");
		String expectedGaId  = queryResultSet.getString("GAID");
		JsonReadWriteUtils.compareValueAndLogReport(actualGaId , expectedGaId, "GaId");
		
		String actualUserLogonId = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
				"$..[?(@.lastName==\""+lastName+"\" && @.typeCode==\""+typeCode+"\")]..userLogonId");
		String expectedUserLogonId  = queryResultSet.getString("USER_LOGON_ID");
		JsonReadWriteUtils.compareValueAndLogReport(actualUserLogonId , expectedUserLogonId, "userLogonId");
		
		String actualId = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
				"$..[?(@.lastName==\""+lastName+"\" && @.typeCode==\""+typeCode+"\")]..id");
		String expectedId  = queryResultSet.getString("ID");
		JsonReadWriteUtils.compareValueAndLogReport(actualId , expectedId, "Id");
		
		String actualCompanyName = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
				"$..[?(@.lastName==\""+lastName+"\" && @.typeCode==\""+typeCode+"\")]..companyName");
		String expectedCompanyName  = queryResultSet.getString("COMPANY_NAME");
		JsonReadWriteUtils.compareValueAndLogReport(actualCompanyName , expectedCompanyName, "CompanyName");
		
		String actualTitle = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
				"$..[?(@.lastName==\""+lastName+"\" && @.typeCode==\""+typeCode+"\")]..title");
		String expectedTitle  = queryResultSet.getString("TITLE");
		JsonReadWriteUtils.compareValueAndLogReport(actualTitle , expectedTitle, "Title");
		
		String actualNameSuffix = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
				"$..[?(@.lastName==\""+lastName+"\" && @.typeCode==\""+typeCode+"\")]..nameSuffix");
		String expectedNameSuffix  = queryResultSet.getString("NAME_SUFFIX");
		JsonReadWriteUtils.compareValueAndLogReport(actualNameSuffix , expectedNameSuffix, "NameSuffix");
		
		String actualEmployeeDept= JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
				"$..[?(@.lastName==\""+lastName+"\" && @.typeCode==\""+typeCode+"\")]..employeeDept");
		String expectedEmployeeDept  = queryResultSet.getString("EMPLOYEE_DEPT");
		JsonReadWriteUtils.compareValueAndLogReport(actualEmployeeDept , expectedEmployeeDept, "EmployeeDept");
		
		String actualEmployeeNbr = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
				"$..[?(@.lastName==\""+lastName+"\" && @.typeCode==\""+typeCode+"\")]..employeeNbr");
		String expectedEmployeeNbr  = queryResultSet.getString("EMPLOYEE_NBR");
		JsonReadWriteUtils.compareValueAndLogReport(actualEmployeeNbr , expectedEmployeeNbr, "EmployeeNbr");
		
		String actualTaxId = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
				"$..[?(@.lastName==\""+lastName+"\" && @.typeCode==\""+typeCode+"\")]..taxId");
		String expectedTaxId  = queryResultSet.getString("TAX_ID");
		JsonReadWriteUtils.compareValueAndLogReport(actualTaxId , expectedTaxId, "TaxId");
		
		String actualWorkPhoneAreaCode = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
				"$..[?(@.lastName==\""+lastName+"\" && @.typeCode==\""+typeCode+"\")]..workPhoneAreaCode");
		String expectedWorkPhoneAreaCode  = queryResultSet.getString("WORK_PHONE_AREA_CODE");
		JsonReadWriteUtils.compareValueAndLogReport(actualWorkPhoneAreaCode , expectedWorkPhoneAreaCode, "WorkPhoneAreaCode");
		
		String actualWorkPhoneNbr = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
				"$..[?(@.lastName==\""+lastName+"\" && @.typeCode==\""+typeCode+"\")]..workPhoneNbr");
		String expectedWorkPhoneNbr  = queryResultSet.getString("WORK_PHONE_NBR");
		JsonReadWriteUtils.compareValueAndLogReport(actualWorkPhoneNbr , expectedWorkPhoneNbr, "WorkPhoneNbr");
		
		String actualPhoneExtNbr = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
				"$..[?(@.lastName==\""+lastName+"\" && @.typeCode==\""+typeCode+"\")]..phoneExtNbr");
		String expectedPhoneExtNbr  = queryResultSet.getString("PHONE_EXT_NBR");
		JsonReadWriteUtils.compareValueAndLogReport(actualPhoneExtNbr , expectedPhoneExtNbr, "PhoneExtNbr");
		
		String actualFaxAreaCode = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
				"$..[?(@.lastName==\""+lastName+"\" && @.typeCode==\""+typeCode+"\")]..faxAreaCode");
		String expectedFaxAreaCode  = queryResultSet.getString("FAX_AREA_CODE");
		JsonReadWriteUtils.compareValueAndLogReport(actualFaxAreaCode , expectedFaxAreaCode, "FaxAreaCode");
		
		String actualFaxNbr = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
				"$..[?(@.lastName==\""+lastName+"\" && @.typeCode==\""+typeCode+"\")]..faxNbr");
		String expectedFaxNbr = queryResultSet.getString("FAX_NBR");
		JsonReadWriteUtils.compareValueAndLogReport(actualFaxNbr , expectedFaxNbr, "FaxNbr");
		
		String actualBeeperAreaCode= JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
				"$..[?(@.lastName==\""+lastName+"\" && @.typeCode==\""+typeCode+"\")]..beeperAreaCode");
		String expectedBeeperAreaCode  = queryResultSet.getString("BEEPER_AREA_CODE");
		JsonReadWriteUtils.compareValueAndLogReport(actualBeeperAreaCode , expectedBeeperAreaCode, "BeeperAreaCode");
		
		String actualBeeperNbr= JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
				"$..[?(@.lastName==\""+lastName+"\" && @.typeCode==\""+typeCode+"\")]..beeperNbr");
		String expectedBeeperNbr  = queryResultSet.getString("BEEPER_NBR");
		JsonReadWriteUtils.compareValueAndLogReport(actualBeeperNbr , expectedBeeperNbr, "BeeperNbr");
		
		String actualHomePhoneAreaCode = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
				"$..[?(@.lastName==\""+lastName+"\" && @.typeCode==\""+typeCode+"\")]..homePhoneAreaCode");
		String expectedHomePhoneAreaCode  = queryResultSet.getString("HOME_PHONE_AREA_CODE");
		JsonReadWriteUtils.compareValueAndLogReport(actualHomePhoneAreaCode , expectedHomePhoneAreaCode, "IHomePhoneAreaCoded");
		
		String actualHomePhoneNbr = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
				"$..[?(@.lastName==\""+lastName+"\" && @.typeCode==\""+typeCode+"\")]..homePhoneNbr");
		String expectedHomePhoneNbr  = queryResultSet.getString("HOME_PHONE_NBR");
		JsonReadWriteUtils.compareValueAndLogReport(actualHomePhoneNbr , expectedHomePhoneNbr, "HomePhoneNbr");
		
		String actualEmailAddress = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
				"$..[?(@.lastName==\""+lastName+"\" && @.typeCode==\""+typeCode+"\")]..emailAddress");
		String expectedEmailAddres  = queryResultSet.getString("EMAIL_ADDRESS");
		JsonReadWriteUtils.compareValueAndLogReport(actualEmailAddress , expectedEmailAddres, "EmailAddres");
		
		String actualMailingName1 = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
				"$..[?(@.lastName==\""+lastName+"\" && @.typeCode==\""+typeCode+"\")]..mailingName1");
		String expectedMailingName1 = queryResultSet.getString("MAILING_NAME_1");
		JsonReadWriteUtils.compareValueAndLogReport(actualMailingName1 , expectedMailingName1, "MailingName1");
		
		String actualMailingName2 = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
				"$..[?(@.lastName==\""+lastName+"\" && @.typeCode==\""+typeCode+"\")]..mailingName2");
		String expectedMailingName2 = queryResultSet.getString("MAILING_NAME_2");
		JsonReadWriteUtils.compareValueAndLogReport(actualMailingName2 , expectedMailingName2, "MailingName2");
		
		String actualMailingName3 = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
				"$..[?(@.lastName==\""+lastName+"\" && @.typeCode==\""+typeCode+"\")]..mailingName3");
		String expectedMailingName3 = queryResultSet.getString("MAILING_NAME_3");
		JsonReadWriteUtils.compareValueAndLogReport(actualMailingName3 , expectedMailingName3, "MailingName3");
		
		String actualCity = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
				"$..[?(@.lastName==\""+lastName+"\" && @.typeCode==\""+typeCode+"\")]..city");
		String expectedCity  = queryResultSet.getString("CITY");
		JsonReadWriteUtils.compareValueAndLogReport(actualCity , expectedCity, "City");
		
		String actualFirstLineMailing= JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
				"$..[?(@.lastName==\""+lastName+"\" && @.typeCode==\""+typeCode+"\")]..firstLineMailing");
		String expectedFirstLineMailing  = queryResultSet.getString("FIRST_LINE_MAILING");
		JsonReadWriteUtils.compareValueAndLogReport(actualFirstLineMailing , expectedFirstLineMailing, "FirstLineMailing");
		
		String actualSecondLineMailing= JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
				"$..[?(@.lastName==\""+lastName+"\" && @.typeCode==\""+typeCode+"\")]..scndLineMailing");
		String expectedSecondLineMailing  = queryResultSet.getString("SECOND_LINE_MAILING");
		JsonReadWriteUtils.compareValueAndLogReport(actualSecondLineMailing , expectedSecondLineMailing, "SecondLineMailing");
		
		String actualZipCode= JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
				"$..[?(@.lastName==\""+lastName+"\" && @.typeCode==\""+typeCode+"\")]..zipCode");
		String expectedZipCode  = queryResultSet.getString("ZIP_CODE");
		JsonReadWriteUtils.compareValueAndLogReport(actualZipCode , expectedZipCode, "ZipCode");
		
		String actualStateCode = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
				"$..[?(@.lastName==\""+lastName+"\" && @.typeCode==\""+typeCode+"\")]..stateCode");
		String expectedStateCode  = queryResultSet.getString("STATE_CODE");
		JsonReadWriteUtils.compareValueAndLogReport(actualStateCode , expectedStateCode, "StateCode");
		
		String actualCountry = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
				"$..[?(@.lastName==\""+lastName+"\" && @.typeCode==\""+typeCode+"\")]..country");
		String expectedCountry  = queryResultSet.getString("COUNTRY");
		JsonReadWriteUtils.compareValueAndLogReport(actualCountry , expectedCountry, "Country");
		
		}
	}*/
	
	public void validateContactServiceInformation() throws SQLException {
		utilities = new CommonLib();
		String responseString = utilities.getHttpResponseAsString();
		System.out.println("res is    "+responseString);
		System.out.println("done");
		Reporter.logEvent(Status.INFO, "The response", responseString,false);
		
		queryResultSet=DB.executeQuery(Stock.getTestQuery("fetchContactServicersDetails")[0], Stock.getTestQuery("fetchContactServicersDetails")[1]);
		while(queryResultSet.next()){
			
			String typeCode =queryResultSet.getString("TYPE_CODE");
			String lastName= queryResultSet.getString("LAST_NAME");
			String id = queryResultSet.getString("ID");
			//$..[?(@.dpdateTime==\""+dpDateTime+"\" && @.statusCode==\""+expectedStatusCode+"\")]..gaId
			String actualFirstName = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
					"$..[?(@.lastName==\""+lastName+"\" && @.typeCode==\""+typeCode+"\")]..firstName");
			String expectedFirstName = queryResultSet.getString("FIRST_NAME");
			JsonReadWriteUtils.compareValueAndLogReport(actualFirstName, expectedFirstName, "FirstName");

			String actualLastName = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
					"$..[?(@.lastName==\""+lastName+"\" && @.typeCode==\""+typeCode+"\")]..lastName");
			String expectedLastName = queryResultSet.getString("LAST_NAME");
			JsonReadWriteUtils.compareValueAndLogReport(actualLastName, expectedLastName, "LastName");
			
			
			
			String actualUserLogonId = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
					"$..[?(@.lastName==\""+lastName+"\" && @.typeCode==\""+typeCode+"\")]..userLogonId");
			String expectedUserLogonId  = queryResultSet.getString("USER_LOGON_ID");
			JsonReadWriteUtils.compareValueAndLogReport(actualUserLogonId , expectedUserLogonId, "userLogonId");
			
			
			String actualWorkPhoneAreaCode = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
					"$..[?(@.lastName==\""+lastName+"\" && @.typeCode==\""+typeCode+"\")]..workPhoneAreaCode");
			String expectedWorkPhoneAreaCode  = queryResultSet.getString("WORK_PHONE_AREA_CODE");
			JsonReadWriteUtils.compareValueAndLogReport(actualWorkPhoneAreaCode , expectedWorkPhoneAreaCode, "WorkPhoneAreaCode");
			
			String actualWorkPhoneNbr = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
					"$..[?(@.lastName==\""+lastName+"\" && @.typeCode==\""+typeCode+"\")]..workPhoneNbr");
			String expectedWorkPhoneNbr  = queryResultSet.getString("WORK_PHONE_NBR");
			JsonReadWriteUtils.compareValueAndLogReport(actualWorkPhoneNbr , expectedWorkPhoneNbr, "WorkPhoneNbr");
			
			String actualFaxAreaCode = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
					"$..[?(@.lastName==\""+lastName+"\" && @.typeCode==\""+typeCode+"\")]..faxAreaCode");
			String expectedFaxAreaCode  = queryResultSet.getString("FAX_AREA_CODE");
			JsonReadWriteUtils.compareValueAndLogReport(actualFaxAreaCode , expectedFaxAreaCode, "FaxAreaCode");
			
			String actualFaxNbr = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
					"$..[?(@.lastName==\""+lastName+"\" && @.typeCode==\""+typeCode+"\")]..faxNbr");
			String expectedFaxNbr = queryResultSet.getString("FAX_NBR");
			JsonReadWriteUtils.compareValueAndLogReport(actualFaxNbr , expectedFaxNbr, "FaxNbr");
			
			
			String actualMailingName2 = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
					"$..[?(@.lastName==\""+lastName+"\" && @.typeCode==\""+typeCode+"\")]..mailingName2");
			String expectedMailingName2 = queryResultSet.getString("MAILING_NAME_2");
			JsonReadWriteUtils.compareValueAndLogReport(actualMailingName2 , expectedMailingName2, "MailingName2");
			

			if(lastName!=null){

				String actualTypeCode = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
						"$..[?(@.lastName==\""+lastName+"\" && @.typeCode==\""+typeCode+"\")]..typeCode");
				String expectedTypeCode = queryResultSet.getString("TYPE_CODE");
				JsonReadWriteUtils.compareValueAndLogReport(actualTypeCode, expectedTypeCode, "TypeCode");
				
				String actualTypeCodeDescription = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
						"$..[?(@.lastName==\""+lastName+"\" && @.typeCode==\""+typeCode+"\")]..typeCodeDescription");
				String expectedTypeCodeDescription  = queryResultSet.getString("RV_MEANING");
				JsonReadWriteUtils.compareValueAndLogReport(actualTypeCodeDescription , expectedTypeCodeDescription , "TypeCodeDescription");
				
				String actualGaId = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
						"$..[?(@.lastName==\""+lastName+"\" && @.typeCode==\""+typeCode+"\")]..gaId");
				String expectedGaId  = queryResultSet.getString("GAID");
				JsonReadWriteUtils.compareValueAndLogReport(actualGaId , expectedGaId, "GaId");
				String actualId = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
						"$..[?(@.lastName==\""+lastName+"\" && @.typeCode==\""+typeCode+"\")]..id");
				String expectedId  = queryResultSet.getString("ID");
				JsonReadWriteUtils.compareValueAndLogReport(actualId , expectedId, "Id");
				
				String actualCompanyName = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
						"$..[?(@.lastName==\""+lastName+"\" && @.typeCode==\""+typeCode+"\")]..companyName");
				String expectedCompanyName  = queryResultSet.getString("COMPANY_NAME");
				JsonReadWriteUtils.compareValueAndLogReport(actualCompanyName , expectedCompanyName, "CompanyName");

				String actualEmailAddress = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
						"$..[?(@.lastName==\""+lastName+"\" && @.typeCode==\""+typeCode+"\")]..emailAddress");
				String expectedEmailAddres  = queryResultSet.getString("EMAIL_ADDRESS");
				JsonReadWriteUtils.compareValueAndLogReport(actualEmailAddress , expectedEmailAddres, "EmailAddres");
				
				String actualMailingName1 = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
						"$..[?(@.lastName==\""+lastName+"\" && @.typeCode==\""+typeCode+"\")]..mailingName1");
				String expectedMailingName1 = queryResultSet.getString("MAILING_NAME_1");
				JsonReadWriteUtils.compareValueAndLogReport(actualMailingName1 , expectedMailingName1, "MailingName1");
				String actualCity = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
						"$..[?(@.lastName==\""+lastName+"\" && @.typeCode==\""+typeCode+"\")]..city");
				String expectedCity  = queryResultSet.getString("CITY");
				JsonReadWriteUtils.compareValueAndLogReport(actualCity , expectedCity, "City");
				
				String actualZipCode= JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
						"$..[?(@.lastName==\""+lastName+"\" && @.typeCode==\""+typeCode+"\")]..zipCode");
				String expectedZipCode  = queryResultSet.getString("ZIP_CODE");
				JsonReadWriteUtils.compareValueAndLogReport(actualZipCode , expectedZipCode, "ZipCode");
				
				String actualStateCode = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
						"$..[?(@.lastName==\""+lastName+"\" && @.typeCode==\""+typeCode+"\")]..stateCode");
				String expectedStateCode  = queryResultSet.getString("STATE_CODE");
				JsonReadWriteUtils.compareValueAndLogReport(actualStateCode , expectedStateCode, "StateCode");
				
				String actualCountry = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
						"$..[?(@.lastName==\""+lastName+"\" && @.typeCode==\""+typeCode+"\")]..country");
				String expectedCountry  = queryResultSet.getString("COUNTRY");
				JsonReadWriteUtils.compareValueAndLogReport(actualCountry , expectedCountry, "Country");

				String actualFirstLineMailing= JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
						"$..[?(@.lastName==\""+lastName+"\" && @.typeCode==\""+typeCode+"\")]..firstLineMailing");
				String expectedFirstLineMailing  = queryResultSet.getString("FIRST_LINE_MAILING");
				JsonReadWriteUtils.compareValueAndLogReport(actualFirstLineMailing , expectedFirstLineMailing, "FirstLineMailing");
				
				
				
			
			}else{
				String actualTypeCode = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
						"$..[?(@.id==\""+id+"\" && @.typeCode==\""+typeCode+"\")]..typeCode");
				String expectedTypeCode = queryResultSet.getString("TYPE_CODE");
				JsonReadWriteUtils.compareValueAndLogReport(actualTypeCode, expectedTypeCode, "TypeCode");
				
				String actualTypeCodeDescription = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
						"$..[?(@.id==\""+id+"\" && @.typeCode==\""+typeCode+"\")]..typeCodeDescription");
				String expectedTypeCodeDescription  = queryResultSet.getString("RV_MEANING");
				JsonReadWriteUtils.compareValueAndLogReport(actualTypeCodeDescription , expectedTypeCodeDescription , "TypeCodeDescription");
				
				String actualGaId = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
						"$..[?(@.id==\""+id+"\" && @.typeCode==\""+typeCode+"\")]..gaId");
				String expectedGaId  = queryResultSet.getString("GAID");
				JsonReadWriteUtils.compareValueAndLogReport(actualGaId , expectedGaId, "GaId");
				String actualId = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
						"$..[?(@.id==\""+id+"\" && @.typeCode==\""+typeCode+"\")]..id");
				String expectedId  = queryResultSet.getString("ID");
				JsonReadWriteUtils.compareValueAndLogReport(actualId , expectedId, "Id");
				
				String actualCompanyName = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
						"$..[?(@.id==\""+id+"\" && @.typeCode==\""+typeCode+"\")]..companyName");
				String expectedCompanyName  = queryResultSet.getString("COMPANY_NAME");
				JsonReadWriteUtils.compareValueAndLogReport(actualCompanyName , expectedCompanyName, "CompanyName");

				String actualEmailAddress = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
						"$..[?(@.id==\""+id+"\" && @.typeCode==\""+typeCode+"\")]..emailAddress");
				String expectedEmailAddres  = queryResultSet.getString("EMAIL_ADDRESS");
				JsonReadWriteUtils.compareValueAndLogReport(actualEmailAddress , expectedEmailAddres, "EmailAddres");
				
				String actualMailingName1 = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
						"$..[?(@.id==\""+id+"\" && @.typeCode==\""+typeCode+"\")]..mailingName1");
				String expectedMailingName1 = queryResultSet.getString("MAILING_NAME_1");
				JsonReadWriteUtils.compareValueAndLogReport(actualMailingName1 , expectedMailingName1, "MailingName1");
				String actualCity = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
						"$..[?(@.id==\""+id+"\" && @.typeCode==\""+typeCode+"\")]..city");
				String expectedCity  = queryResultSet.getString("CITY");
				JsonReadWriteUtils.compareValueAndLogReport(actualCity , expectedCity, "City");
				String actualZipCode= JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
						"$..[?(@.id==\""+id+"\" && @.typeCode==\""+typeCode+"\")]..zipCode");
				String expectedZipCode  = queryResultSet.getString("ZIP_CODE");
				JsonReadWriteUtils.compareValueAndLogReport(actualZipCode , expectedZipCode, "ZipCode");
				
				String actualStateCode = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
						"$..[?(@.id==\""+id+"\" && @.typeCode==\""+typeCode+"\")]..stateCode");
				String expectedStateCode  = queryResultSet.getString("STATE_CODE");
				JsonReadWriteUtils.compareValueAndLogReport(actualStateCode , expectedStateCode, "StateCode");
				
				String actualCountry = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
						"$..[?(@.id==\""+id+"\" && @.typeCode==\""+typeCode+"\")]..country");
				String expectedCountry  = queryResultSet.getString("COUNTRY");
				JsonReadWriteUtils.compareValueAndLogReport(actualCountry , expectedCountry, "Country");

				String actualFirstLineMailing= JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
						"$..[?(@.id==\""+id+"\" && @.typeCode==\""+typeCode+"\")]..firstLineMailing");
				String expectedFirstLineMailing  = queryResultSet.getString("FIRST_LINE_MAILING");
				JsonReadWriteUtils.compareValueAndLogReport(actualFirstLineMailing , expectedFirstLineMailing, "FirstLineMailing");
				
				
			}
			
		
		}
	}

}

package app.ramlservices.pageobject;

public class NQProperties {

	
	
}

package app.webservice.pageobjects;

public class Values {
	String rvLowValue;
	String rvHighValue;
	String rvAbbreviation;
	String rvTable;
	String rvColumn;
	String rvDomain;
	String rvMeaning;
	String rvType;
	public String getRvLowValue() {
		return rvLowValue;
	}
	public void setRvLowValue(String rvLowValue) {
		this.rvLowValue = rvLowValue;
	}
	public String getRvHighValue() {
		return rvHighValue;
	}
	public void setRvHighValue(String rvHighValue) {
		this.rvHighValue = rvHighValue;
	}
	public String getRvAbbreviation() {
		return rvAbbreviation;
	}
	public void setRvAbbreviation(String rvAbbreviation) {
		this.rvAbbreviation = rvAbbreviation;
	}
	public String getRvTable() {
		return rvTable;
	}
	public void setRvTable(String rvTable) {
		this.rvTable = rvTable;
	}
	public String getRvColumn() {
		return rvColumn;
	}
	public void setRvColumn(String rvColumn) {
		this.rvColumn = rvColumn;
	}
	public String getRvDomain() {
		return rvDomain;
	}
	public void setRvDomain(String rvDomain) {
		this.rvDomain = rvDomain;
	}
	public String getRvMeaning() {
		return rvMeaning;
	}
	public void setRvMeaning(String rvMeaning) {
		this.rvMeaning = rvMeaning;
	}
	public String getRvType() {
		return rvType;
	}
	public void setRvType(String rvType) {
		this.rvType = rvType;
	}

}

package app.ramlservices.pageobject;

import java.sql.ResultSet;
import java.sql.SQLException;

import lib.DB;
import lib.Reporter;
import lib.Stock;
import util.CommonLib;
import app.webservice.pageobjects.JsonReadWriteUtils;

import com.aventstack.extentreports.Status;

public class GroupAccountService {
	CommonLib utilities;
	ResultSet queryResultSet;

	/**
	 * Method to verify GroupAccount service Info with DB Values.
	 * 
	 * @throws SQLException
	 */
	public void validateGroupAccountInformation() throws SQLException {
		// Get API response in string format.
		utilities = new CommonLib();
		String responseString = utilities.getHttpResponseAsString();
		System.out.println(responseString);
		Reporter.logEvent(Status.INFO, "The response", responseString, false);

		// Get GroupAccount Info from DB.
		queryResultSet = DB.executeQuery(
				Stock.getTestQuery("fetchGroupAccountDetails")[0],
				Stock.getTestQuery("fetchGroupAccountDetails")[1]);
		while (queryResultSet.next()) {
			// Get GroupAccount service values from API response.
			String gaId = JsonReadWriteUtils.getNodeValueUsingJpath(
					responseString, "$..gaId");
			String planId = JsonReadWriteUtils.getNodeValueUsingJpath(
					responseString, "$..planId");
			String planLegalName = JsonReadWriteUtils.getNodeValueUsingJpath(
					responseString, "$..planLegalName");
			String marketSegments = JsonReadWriteUtils.getNodeValueUsingJpath(
					responseString, "$..marketSegments");
			String assetsUnderAdminstration = JsonReadWriteUtils
					.getNodeValueUsingJpath(responseString,
							"$..assetsUnderAdminstration");
			// Get GroupAccount values from DB.
			String expectedGaID = queryResultSet.getString("GAID");
			String expectedPlanId = queryResultSet.getString("PLAN_ID");
			String expectedPlanName = queryResultSet.getString("PLAN_NAME");
			String expectedassetsUnderAdminstration = queryResultSet
					.getString("AMOUNT");
			String expectedmarketSegments = Stock
					.GetParameterValue("MARKET_SEGMENTS");
			
			// Verify GroupAccount service Info with DB Values.
			JsonReadWriteUtils.compareValueAndLogReport(gaId, expectedGaID,
					"GAID");
			JsonReadWriteUtils.compareValueAndLogReport(planId, expectedPlanId,
					"PLAN_ID");
			JsonReadWriteUtils.compareValueAndLogReport(planLegalName,
					expectedPlanName, "PLAN_NAME");
			JsonReadWriteUtils.compareValueAndLogReport(marketSegments,
					expectedmarketSegments, "MARKET_SEGMENTS");
			JsonReadWriteUtils.compareValueAndLogReport(
					assetsUnderAdminstration, expectedassetsUnderAdminstration,
					"AssetsUnderAdminstration");
		}
	}
}
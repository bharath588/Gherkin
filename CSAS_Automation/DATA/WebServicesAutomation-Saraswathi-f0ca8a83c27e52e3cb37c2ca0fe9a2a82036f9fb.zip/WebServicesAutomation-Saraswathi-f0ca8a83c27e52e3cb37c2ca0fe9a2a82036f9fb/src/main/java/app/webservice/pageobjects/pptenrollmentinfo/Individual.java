package app.webservice.pageobjects.pptenrollmentinfo;

public class Individual {

	String id;
	String lastName;
	String firstname;
	String ssn;
	String mailingName1;
	String sdxLastName;
	String birthdate;
	String sex;
	String nameType;
	String recovmaxAccum;
	String nextEligLoanDate;
	String maritalStatus;
	String deathdate;
	String partComncemntDate;
	String title;
	String middlename;
	String remitIdNbr;
	String suffix;
	String beeperNbr;
	String workPhoneNbr;
	String homePhoneNbr;
	String phoneExtNbr;
	String faxNbr;
	String beeperAreaCode;
	String faxAreaCode;
	String homePhoneAreaCode;
	String workPhoneAreaCode;
	String mailingName2;
	String mailingName3;
	String languageCode;
	String ssnExt;
	String ssnExtRsnCode;
	String emailAddress;
	String lastNonAdminPdoffLoanDate;
	String birthDateDefaultIndic;
	String passCodeExpDate;
	String contactVerificationDPDate;
	String mobilePhoneAreaCode;
	String mobilePhoneNbr;
	String intlPhoneNbr;
	String intlPhoneCountryCode;
	
	public void setId(String id) {
		this.id = id;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}
	public void setSsn(String ssn) {
		this.ssn = ssn;
	}
	public void setMailingName1(String mailingName1) {
		this.mailingName1 = mailingName1;
	}
	public void setSdxLastName(String sdxLastName) {
		this.sdxLastName = sdxLastName;
	}
	public void setBirthdate(String birthdate) {
		this.birthdate = birthdate;
	}
	public void setSex(String sex) {
		this.sex = sex;
	}
	public void setNameType(String nameType) {
		this.nameType = nameType;
	}
	public void setRecovmaxAccum(String recovmaxAccum) {
		this.recovmaxAccum = recovmaxAccum;
	}
	public void setNextEligLoanDate(String nextEligLoanDate) {
		this.nextEligLoanDate = nextEligLoanDate;
	}
	public void setMaritalStatus(String maritalStatus) {
		this.maritalStatus = maritalStatus;
	}
	public void setDeathdate(String deathdate) {
		this.deathdate = deathdate;
	}
	public void setPartComncemntDate(String partComcemntdate) {
		this.partComncemntDate = partComcemntdate;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public void setMiddlename(String middlename) {
		this.middlename = middlename;
	}
	public void setRemitIdNbr(String remitIdNbr) {
		this.remitIdNbr = remitIdNbr;
	}
	public void setSuffix(String suffix) {
		this.suffix = suffix;
	}
	public void setBeeperNbr(String beeperNbr) {
		this.beeperNbr = beeperNbr;
	}
	public void setWorkPhoneNbr(String workPhoneNbr) {
		this.workPhoneNbr = workPhoneNbr;
	}
	public void setHomePhoneNbr(String homePhoneNbr) {
		this.homePhoneNbr = homePhoneNbr;
	}
	public void setPhoneExtNbr(String phoneExtNbr) {
		this.phoneExtNbr = phoneExtNbr;
	}
	public void setFaxNbr(String faxNbr) {
		this.faxNbr = faxNbr;
	}
	public void setBeeperAreaCode(String beeperAreaCode) {
		this.beeperAreaCode = beeperAreaCode;
	}
	public void setFaxAreaCode(String faxAreaCode) {
		this.faxAreaCode = faxAreaCode;
	}
	public void setHomePhoneAreaCode(String homePhoneAreaCode) {
		this.homePhoneAreaCode = homePhoneAreaCode;
	}
	public void setWorkPhoneAreaCode(String workPhoneAreaCode) {
		this.workPhoneAreaCode = workPhoneAreaCode;
	}
	public void setMailingName2(String mailingName2) {
		this.mailingName2 = mailingName2;
	}
	public void setMailingName3(String mailingName3) {
		this.mailingName3 = mailingName3;
	}
	public void setLanguageCode(String languageCode) {
		this.languageCode = languageCode;
	}
	public void setSsnExt(String ssnExt) {
		this.ssnExt = ssnExt;
	}
	public void setSsnExtRsnCode(String ssnExtRsnCode) {
		this.ssnExtRsnCode = ssnExtRsnCode;
	}
	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}
	public void setLastNonAdminPdoffLoanDate(String lastNonAdminPdoffLoanDate) {
		this.lastNonAdminPdoffLoanDate = lastNonAdminPdoffLoanDate;
	}
	public void setBirthDateDefaultIndic(String birthDateDefaultIndic) {
		this.birthDateDefaultIndic = birthDateDefaultIndic;
	}
	public void setPassCodeExpDate(String passCodeExpDate) {
		this.passCodeExpDate = passCodeExpDate;
	}
	public void setContactVerificationDPDate(String contactVerificationDPDate) {
		this.contactVerificationDPDate = contactVerificationDPDate;
	}
	public void setMobilePhoneAreaCode(String mobilePhoneAreaCode) {
		this.mobilePhoneAreaCode = mobilePhoneAreaCode;
	}
	public void setMobilePhoneNbr(String mobilePhoneNbr) {
		this.mobilePhoneNbr = mobilePhoneNbr;
	}
	public void setIntlPhoneNbr(String intlPhoneNbr) {
		this.intlPhoneNbr = intlPhoneNbr;
	}
	public void setIntlPhoneCountryCode(String intlPhoneCountryCode) {
		this.intlPhoneCountryCode = intlPhoneCountryCode;
	}
}

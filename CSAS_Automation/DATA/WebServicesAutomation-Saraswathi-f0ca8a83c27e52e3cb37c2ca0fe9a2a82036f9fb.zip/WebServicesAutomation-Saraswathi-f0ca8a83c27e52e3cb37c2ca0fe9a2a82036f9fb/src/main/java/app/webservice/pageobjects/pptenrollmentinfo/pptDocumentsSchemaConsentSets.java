package app.webservice.pageobjects.pptenrollmentinfo;

public class pptDocumentsSchemaConsentSets {

	String myPart;
	String myEffdate;
	String myTermdate;
	String mySchemaTypeCode;
	String mySchemaCode;
	String mySchemaLabel;
	String mySchemaDescr;
//	String myObjHolder;
	String myDocumentSchemaGrpgConsents;
	
	public void setMyPart(String myPart) {
		this.myPart = myPart;
	}
	public void setMyEffdate(String myEffdate) {
		this.myEffdate = myEffdate;
	}
	public void setMyTermdate(String myTermdate) {
		this.myTermdate = myTermdate;
	}
	public void setMySchemaTypeCode(String mySchemaTypeCode) {
		this.mySchemaTypeCode = mySchemaTypeCode;
	}
	public void setMySchemaCode(String mySchemaCode) {
		this.mySchemaCode = mySchemaCode;
	}
	public void setMySchemaLabel(String mySchemaLabel) {
		this.mySchemaLabel = mySchemaLabel;
	}
	public void setMySchemaDescr(String mySchemaDescr) {
		this.mySchemaDescr = mySchemaDescr;
	}
	
	MyObjHolder myObjHolder;
	public MyObjHolder getMyObjHolder() {
		return myObjHolder;
	}
	public void setMyObjHolder(MyObjHolder myObjHolder) {
		this.myObjHolder = myObjHolder;
	}
	
	
	public void setMyDocumentSchemaGrpgConsents(String myDocumentSchemaGrpgConsents) {
		this.myDocumentSchemaGrpgConsents = myDocumentSchemaGrpgConsents;
	}
	
	
}

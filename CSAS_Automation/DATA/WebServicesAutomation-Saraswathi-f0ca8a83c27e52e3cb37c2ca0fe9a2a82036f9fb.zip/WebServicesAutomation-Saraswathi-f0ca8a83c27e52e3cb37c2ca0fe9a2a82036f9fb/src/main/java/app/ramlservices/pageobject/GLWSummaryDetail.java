package app.ramlservices.pageobject;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;

import lib.DB;
import lib.Reporter;
import lib.Stock;
import util.CommonLib;
import app.webservice.pageobjects.JsonReadWriteUtils;

import com.aventstack.extentreports.Status;

public class GLWSummaryDetail {
	
	CommonLib utilities;
	ResultSet queryResultSet;
	
	

	
	/**
	 * Validate InvestmentSevice Details.
	 * @throws SQLException
	 * @throws ParseException
	 */
	public void validateGLWSummaryDetails() throws SQLException, ParseException {
		utilities = new CommonLib();
		String responseString = utilities.getHttpResponseAsString();
		System.out.println("res is    "+responseString);
		Reporter.logEvent(Status.INFO, "Json response", responseString,false);
		String DB =Stock.GetParameterValue("DBParam");
		String gaID =Stock.GetParameterValue("GAIDParam");
		queryResultSet = getGLWSummaryDetailsResulSet(DB, gaID);
		verifyGLWSummaryDetail(responseString,queryResultSet);
	}
	
	public ResultSet getGLWSummaryDetailsResulSet(String DatabaseName,String gaID){
		
		String query =Stock.getTestQuery("getGLWSummaryDetails")[1];
		String updatedFutureRateQuery  = query.replace("?", gaID);
		 return queryResultSet=DB.executeQuery(DatabaseName,updatedFutureRateQuery);
	}
	
	public void verifyAutoEnrollCodeDetails(String responseString,String DatabaseName){
		String query =Stock.getTestQuery("getAutoEnrollCode")[1];
		 queryResultSet=DB.executeQuery(DatabaseName,query);
		
	}
	
	public void verifyGLWSummaryDetail(String responseString,ResultSet queryResultSet ) throws SQLException, ParseException{
		
		if(queryResultSet!= null){
			while (queryResultSet.next()) {
			System.out.println(responseString);
			String id = queryResultSet.getString("ID");
			String actualID = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
					"$..id");
			JsonReadWriteUtils.compareValueAndLogReport(id, actualID, "ID");
			
			String gcID = queryResultSet.getString("GCID");
			String actualGCID = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
					"$..gcId");
			JsonReadWriteUtils.compareValueAndLogReport(gcID, actualGCID, "GCID");
		 	
			String actualeffdate = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
					"$..effdate");
			JsonReadWriteUtils.compareDbWithDateInResponse(actualeffdate,queryResultSet.getDate("EFFDATE"), "DPDATETIME");
			String annivDate = queryResultSet.getString("ANNIVDATE");
			String actualannivDate = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
					"$..annivDate");
			JsonReadWriteUtils.compareValueAndLogReport(annivDate, actualannivDate, "annivDate");
			
			String actualfirstEligDate= JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
					"$..firstEligDate");
			JsonReadWriteUtils.compareDbWithDateInResponse(actualfirstEligDate,queryResultSet.getDate("FIRSTELIGDATE"), "FIRSTELIGDATE");
			
			String actualtermdate= JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
					"$..termdate");
			JsonReadWriteUtils.compareDbWithDateInResponse(actualtermdate,queryResultSet.getDate("TERMDATE"), "TERMDATE");
		 	
			String mailingName1 = queryResultSet.getString("MAILINGNAME1");
			String actualmailingName1 = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
					"$..mailingName1");
			JsonReadWriteUtils.compareValueAndLogReport(mailingName1, actualmailingName1, "MAILINGNAME1");
			
			String mailingName2 = queryResultSet.getString("MAILINGNAME2");
			String actualmailingName2 = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
					"$..mailingName2");
			JsonReadWriteUtils.compareValueAndLogReport(mailingName2, actualmailingName2, "MAILINGNAME2");
			
			String mailingName3 = queryResultSet.getString("MAILINGNAME3");
			String actualmailingName3 = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
					"$..mailingName3");
			JsonReadWriteUtils.compareValueAndLogReport(mailingName3, actualmailingName3, "MAILINGNAME3");
			
			String firstLineMailing = queryResultSet.getString("FIRSTLINEMAILING");
			String actualfirstLineMailing = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
					"$..firstLineMailing");
			JsonReadWriteUtils.compareValueAndLogReport(firstLineMailing, actualfirstLineMailing, "FIRSTLINEMAILING");
			
			String scndLineMailing = queryResultSet.getString("SCNDLINEMAILING");
			String actualsecondLineMailing = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
					"$..scndLineMailing");
			JsonReadWriteUtils.compareValueAndLogReport(scndLineMailing, actualsecondLineMailing, "SCNDLINEMAILING");
			
			String city = queryResultSet.getString("CITY");
			String actualcity = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
					"$..city");
			JsonReadWriteUtils.compareValueAndLogReport(city, actualcity, "CITY");
			
			String country = queryResultSet.getString("COUNTRY");
			String actualcountry = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
					"$..country");
			JsonReadWriteUtils.compareValueAndLogReport(country, actualcountry, "COUNTRY");
			
			String stateCode = queryResultSet.getString("STATECODE");
			String actualstateCode = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
					"$..stateCode");
			JsonReadWriteUtils.compareValueAndLogReport(stateCode, actualstateCode, "STATECODE");
			
			String zipCode = queryResultSet.getString("ZIPCODE");
			String actualzipCode = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
					"$..zipCode");
			JsonReadWriteUtils.compareValueAndLogReport(zipCode, actualzipCode, "ZIPCODE");
			
			String emailAddress = queryResultSet.getString("EMAILADDRESS");
			String actualemailAddress = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
					"$..emailAddress");
			JsonReadWriteUtils.compareValueAndLogReport(emailAddress, actualemailAddress, "EMAILADDRESS");
			
			String saleType = queryResultSet.getString("SALETYPE");
			String actualsaleType = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
					"$..saleType");
			JsonReadWriteUtils.compareValueAndLogReport(saleType, actualsaleType, "SALETYPE");
			
			String exBccInd = queryResultSet.getString("EXBCCIND");
			String actualexBccInd = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
					"$..exBccInd");
			JsonReadWriteUtils.compareValueAndLogReport(exBccInd, actualexBccInd, "EXBCCIND");
			
			String exCarrierInd = queryResultSet.getString("EXCARRIERIND");
			String actualexCarrierInd = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
					"$..exCarrierInd");
			JsonReadWriteUtils.compareValueAndLogReport(exCarrierInd, actualexCarrierInd, "EXCARRIERIND");
			
			String docType = queryResultSet.getString("DOCTYPE");
			String actualdocType = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
					"$..docType");
			JsonReadWriteUtils.compareValueAndLogReport(docType, actualdocType ,"DOCTYPE");
			
			String docVersNbr = queryResultSet.getString("DOCVERSNBR");
			String actualdocVersNbr = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
					"$..docVersNbr");
			JsonReadWriteUtils.compareValueAndLogReport(docVersNbr, actualdocVersNbr, "DOCVERSNBR");
			
			String planSponsorType = queryResultSet.getString("PLANSPONSORTYPE");
			String actualplanSponsorType = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
					"$..planSponsorType");
			JsonReadWriteUtils.compareValueAndLogReport(planSponsorType, actualplanSponsorType, "PLANSPONSERTYPE");

			String empSponInd = queryResultSet.getString("EMPSPONIND");
			String actualempSponInd = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
					"$..empSponInd");
			JsonReadWriteUtils.compareValueAndLogReport(empSponInd, actualempSponInd, "EMPSPONIND");
			
			String eeType = queryResultSet.getString("EETYPE");
			String actualeeType = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
					"$..eeType");
			JsonReadWriteUtils.compareValueAndLogReport(eeType, actualeeType, "EETYPE");
			
			String erisaComplInd = queryResultSet.getString("ERISACOMPLIND");
			String actualerisaComplInd = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
					"$..erisaComplInd");
			JsonReadWriteUtils.compareValueAndLogReport(erisaComplInd, actualerisaComplInd, "ERISACOMPIND");
			
			String ppsInd = queryResultSet.getString("PPSIND");
			String actualppsInd = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
					"$..ppsInd");
			JsonReadWriteUtils.compareValueAndLogReport(ppsInd, actualppsInd, "PPSIND");
			
			String planInfo = queryResultSet.getString("PLANINFO");
			String actualplanInfo = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
					"$..planInfo");
			JsonReadWriteUtils.compareValueAndLogReport(planInfo, actualplanInfo, "PLANINFO");
			
			String loanAdminInd = queryResultSet.getString("LOANADMININD");
			String actualloanAdminInd = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
					"$..loanAdminInd");
			JsonReadWriteUtils.compareValueAndLogReport(loanAdminInd, actualloanAdminInd, "LOANADMININD");
			
			String loanBeforeHardshipInd = queryResultSet.getString("LOANBEFOREHARDSHIPIND");
			String actualloanBeforeHardshipInd = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
					"$..loanBeforeHardshipInd");
			JsonReadWriteUtils.compareValueAndLogReport(loanBeforeHardshipInd, actualloanBeforeHardshipInd, "LOANBEFOREHARDSHIPIND");
			
			String eligibilityServiceLevel = queryResultSet.getString("ELIGIBILITYSERVICELEVEL");
			String actualeligibilityServiceLevel = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
					"$..eligibilityServiceLevel");
			JsonReadWriteUtils.compareValueAndLogReport(eligibilityServiceLevel, actualeligibilityServiceLevel, "ELIGIBILITYSERVICELEVEL");

			/*String eligibilityServiceLevelDesc = queryResultSet.getString("ELIGIBILITYSERVICELEVELDESC");
			String actualeligibilityServiceLevelDesc = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
					"$..eligibilityServiceLevelDesc");
			JsonReadWriteUtils.compareValueAndLogReport(eligibilityServiceLevelDesc, actualeligibilityServiceLevelDesc, "ELIGIBILITYSERVICELEVELDESC");
			*/
			String vestServLevel = queryResultSet.getString("VESTSERVLEVEL");
			String actualvestServLevel = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
					"$..vestServLevel");
			JsonReadWriteUtils.compareValueAndLogReport(vestServLevel, actualvestServLevel, "VESTSERVLEVEL");
			
			String vestingCalculationInput = queryResultSet.getString("VESTINGCALCULATIONINPUT");
			String actualvestingCalculationInput = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
					"$..vestingCalculationInput");
			JsonReadWriteUtils.compareValueAndLogReport(vestingCalculationInput, actualvestingCalculationInput, "VESTINGCALCULATIONINPUT");
			
			String forfDispCode = queryResultSet.getString("FORFDISPCODE");
			String actualforfDispCode = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
					"$..forfDispCode");
			JsonReadWriteUtils.compareValueAndLogReport(forfDispCode, actualforfDispCode, "FORDISPCODE");
			
			String failsafePlanInd = queryResultSet.getString("FAILSAFEPLANIND");
			String actualfailsafePlanInd = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
					"$..failsafePlanInd");
			JsonReadWriteUtils.compareValueAndLogReport(failsafePlanInd, actualfailsafePlanInd, "FAILSSAFEPLANIND");

			String safeHarborInd = queryResultSet.getString("SAFEHARBORIND");
			String actualsafeHarborInd = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
					"$..safeHarborInd");
			JsonReadWriteUtils.compareValueAndLogReport(safeHarborInd, actualsafeHarborInd ,"SAFEHARBORIND");
			
			String hardshipRule = queryResultSet.getString("HARDSHIPRULE");
			String actualhardshipRule = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
					"$..hardshipRule");
			JsonReadWriteUtils.compareValueAndLogReport(hardshipRule, actualhardshipRule, "HARDSHIPRULE");
			
			String hardshipRuleSusPeriod = queryResultSet.getString("HARDSHIPRULESUSPERIOD");
			String actualhardshipRuleSusPeriod = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
					"$..hardshipRuleSusPeriod");
			JsonReadWriteUtils.compareValueAndLogReport(hardshipRuleSusPeriod, actualhardshipRuleSusPeriod, "HARDSHIPRULESUPERIOD");
			
			String hardshipProcessingCode = queryResultSet.getString("HARDSHIPPROCESSINGCODE");
			String actualhardshipProcessingCode = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
					"$..hardshipProcessingCode");
			JsonReadWriteUtils.compareValueAndLogReport(hardshipProcessingCode, actualhardshipProcessingCode, "HARDSHIPPROCESSINGCODE");

			String annuityOfferInd = queryResultSet.getString("ANNUITYOFFERIND");
			String actualannuityOfferInd = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
					"$..annuityOfferInd");
			JsonReadWriteUtils.compareValueAndLogReport(annuityOfferInd, actualannuityOfferInd, "ANNUITYOFFERIND");
			
			String onlineEnrollCode = queryResultSet.getString("ONLINEENROLLCODE");
			String actualonlineEnrollCode = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
					"$..onlineEnrollCode");
			JsonReadWriteUtils.compareValueAndLogReport(onlineEnrollCode, actualonlineEnrollCode, "ONLINEENROLLCODE");
			
			String onlineEnrollWeekendHolCode = queryResultSet.getString("ONLINEENROLLWEEKENDHOLCODE");
			String actualonlineEnrollWeekendHolCode = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
					"$..onlineEnrollWeekendHolCode");
			JsonReadWriteUtils.compareValueAndLogReport(onlineEnrollWeekendHolCode, actualonlineEnrollWeekendHolCode, "ONLINEENROLLWEEKENDHOLCODE");
			
			String oeEnrollInviteCode = queryResultSet.getString("OEENROLLINVITECODE");
			String actualoeEnrollInviteCode = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
					"$..oeEnrollInviteCode");
			JsonReadWriteUtils.compareValueAndLogReport(oeEnrollInviteCode, actualoeEnrollInviteCode, "OEENROLLINVITECODE");
			
			String autoEnrollCode = queryResultSet.getString("AUTOENROLLCODE");
			String actualautoEnrollCode = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
					"$..autoEnrollCode");
			JsonReadWriteUtils.compareValueAndLogReport(autoEnrollCode, actualautoEnrollCode, "AUTOENROLLCODE");

			/*String autoEnrollCodeDescr = queryResultSet.getString("AUTOENROLLCODEDESCR");
			String actualautoEnrollCodeDescr = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
					"$..autoEnrollCodeDescr");
			JsonReadWriteUtils.compareValueAndLogReport(autoEnrollCodeDescr, actualautoEnrollCodeDescr ,"AUTOENROLLCODEDESCR");
			*/
			String ficaExclusionInd = queryResultSet.getString("FICAEXCLUSIONIND");
			String actualficaExclusionInd = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
					"$..ficaExclusionInd");
			JsonReadWriteUtils.compareValueAndLogReport(ficaExclusionInd, actualficaExclusionInd, "FICAEXCLUSIONIND");
			
			String beneRecordkeeperCode = queryResultSet.getString("BENERECORDKEEPERCODE");
			String actualbeneRecordkeeperCode = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
					"$..beneRecordkeeperCode");
			JsonReadWriteUtils.compareValueAndLogReport(beneRecordkeeperCode, actualbeneRecordkeeperCode, "BENERECORDKEEPERCODE");
			
			String beneRequiredFieldsCode = queryResultSet.getString("BENEREQUIREDFIELDSCODE");
			String actualbeneRequiredFieldsCode = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
					"$..beneRequiredFieldsCode");
			JsonReadWriteUtils.compareValueAndLogReport(beneRequiredFieldsCode, actualbeneRequiredFieldsCode, "BENEREQUIREDFIELDSCODE");
			
			String beneSpousalRuleCode = queryResultSet.getString("BENESPOUSALRULECODE");
			String actualbeneSpousalRuleCode = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
					"$..beneSpousalRuleCode");
			JsonReadWriteUtils.compareValueAndLogReport(beneSpousalRuleCode, actualbeneSpousalRuleCode ,"BENESPOUSALRULECODE");
			
			String disbSpousalConsentInd = queryResultSet.getString("DISBSPOUSALCONSENTIND");
			String actualdisbSpousalConsentInd = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
					"$..disbSpousalConsentInd");
			JsonReadWriteUtils.compareValueAndLogReport(disbSpousalConsentInd, actualdisbSpousalConsentInd, "DISBSPOUSALCONSENTIND");
	
		 	String irrevElectNbrChgsAllowed = queryResultSet.getString("IRREVELECTNBRCHGSALLOWED");
			String actualirrevElectNbrChgsAllowed = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
					"$..irrevElectNbrChgsAllowed");
			JsonReadWriteUtils.compareValueAndLogReport(irrevElectNbrChgsAllowed, actualirrevElectNbrChgsAllowed, "IRREVELECTNBRCHGSALLOWED");
			
			String irrevElectDefaultMthd = queryResultSet.getString("IRREVELECTDEFAULTMTHD");
			String actualirrevElectDefaultMthd = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
					"$..irrevElectDefaultMthd");
			JsonReadWriteUtils.compareValueAndLogReport(irrevElectDefaultMthd, actualirrevElectDefaultMthd, "IRREVELECTDEFAULTMTHD");
			
			String voidExistingIrrevocablesInd = queryResultSet.getString("VOIDEXISTINGIRREVOCABLESIND");
			String actualvoidExistingIrrevocablesInd = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
					"$..voidExistingIrrevocablesInd");
			JsonReadWriteUtils.compareValueAndLogReport(voidExistingIrrevocablesInd, actualvoidExistingIrrevocablesInd ,"VOIDEXISTINGIRREVOCABLESIND");
			
			String allowIrrevocablesInd = queryResultSet.getString("ALLOWIRREVOCABLESIND");
			String actualallowIrrevocablesInd = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
					"$..allowIrrevocablesInd");
			JsonReadWriteUtils.compareValueAndLogReport(allowIrrevocablesInd, actualallowIrrevocablesInd, "ALLOWIRREVOCABLESIND");
			
			String ageCatchUpAllowedInd = queryResultSet.getString("AGECATCHUPALLOWEDIND");
			String actualageCatchUpAllowedInd = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
					"$..ageCatchUpAllowedInd");
			JsonReadWriteUtils.compareValueAndLogReport(ageCatchUpAllowedInd, actualageCatchUpAllowedInd, "AGECATCHUPALLOWEDIND");
			
			String ageCatchUpMethodCode = queryResultSet.getString("AGECATCHUPMETHODCODE");
			String actualageCatchUpMethodCode = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
					"$..ageCatchUpMethodCode");
			JsonReadWriteUtils.compareValueAndLogReport(ageCatchUpMethodCode, actualageCatchUpMethodCode, "AGECATCHUPMETHODCODE");
			
			/*String consolidateIoag = queryResultSet.getString("BENESPOUSALRUCONSOLIDATEIOAGLECODE");
			String actualconsolidateIoag = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
					"$..beneSpousalRuconsolidateIoagleCode");
			JsonReadWriteUtils.compareValueAndLogReport(consolidateIoag, actualconsolidateIoag ,"BENESPOUSALRUCONSOLIDATEIOAGLECODE");
			*/
			String deferralFrequencyCode = queryResultSet.getString("DEFERRALFREQUENCYCODE");
			String actualdeferralFrequencyCode = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
					"$..deferralFrequencyCode");
			JsonReadWriteUtils.compareValueAndLogReport(deferralFrequencyCode, actualdeferralFrequencyCode, "DEERRALFREQUENCYCODE");
			
			String ageCatchUpErMatchCalcInd = queryResultSet.getString("AGECATCHUPERMATCHCALCIND");
			String actualageCatchUpErMatchCalcInd = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
					"$..ageCatchUpErMatchCalcInd");
			JsonReadWriteUtils.compareValueAndLogReport(ageCatchUpErMatchCalcInd, actualageCatchUpErMatchCalcInd ,"AGECATCHUPERMATCHCALCIND");
			
			String allowDefrlChangeNbr = queryResultSet.getString("ALLOWDEFRLCHANGENBR");
			String actualallowDefrlChangeNbr = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
					"$..allowDefrlChangeNbr");
			JsonReadWriteUtils.compareValueAndLogReport(allowDefrlChangeNbr, actualallowDefrlChangeNbr, "ALLOWDEFRLCHANGENBR");
		 	
		 	String allowDefrlFreq = queryResultSet.getString("ALLOWDEFRLFREQ");
			String actualallowDefrlFreq = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
					"$..allowDefrlFreq");
			JsonReadWriteUtils.compareValueAndLogReport(allowDefrlFreq, actualallowDefrlFreq ,"ALLOWDEFRLFREQ");
			
			String allowDefrlFreqCode = queryResultSet.getString("ALLOWDEFRLFREQCODE");
			String actualallowDefrlFreqCode = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
					"$..allowDefrlFreqCode");
			JsonReadWriteUtils.compareValueAndLogReport(allowDefrlFreqCode, actualallowDefrlFreqCode, "ALLOWDEFRLFREQCODE");
	
		 	String defrlRestrcStartDate = queryResultSet.getString("DEFRLRESTRCSTARTDATE");
			String actualdefrlRestrcStartDate = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
					"$..defrlRestrcStartDate");
			JsonReadWriteUtils.compareValueAndLogReport(defrlRestrcStartDate, actualdefrlRestrcStartDate, "DEFRLRESTRCSTARTDATE");
			
			String defrlRestrcLevel = queryResultSet.getString("DEFRLRESTRCLEVEL");
			String actualdefrlRestrcLevel = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
					"$..defrlRestrcLevel");
			JsonReadWriteUtils.compareValueAndLogReport(defrlRestrcLevel, actualdefrlRestrcLevel, "DEFRLRESTRCLEVEL");
			
			String payrollFeedLookbackDays = queryResultSet.getString("PAYROLLFEEDLOOKBACKDAYS");
			String actualpayrollFeedLookbackDays = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
					"$..payrollFeedLookbackDays");
			JsonReadWriteUtils.compareValueAndLogReport(payrollFeedLookbackDays, actualpayrollFeedLookbackDays ,"PAYROLLFEEDLOOKBACKDAYS");
			
			String allowFutureDefrlInd = queryResultSet.getString("ALLOWFUTUREDEFRLIND");
			String actualallowFutureDefrlInd = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
					"$..allowFutureDefrlInd");
			JsonReadWriteUtils.compareValueAndLogReport(allowFutureDefrlInd, actualallowFutureDefrlInd, "ALLOWFUTUREDEFRLIND");
			
			String allowOneTimeDefrlInd = queryResultSet.getString("ALLOWONETIMEDEFRLIND");
			String actualallowOneTimeDefrlInd = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
					"$..allowOneTimeDefrlInd");
			JsonReadWriteUtils.compareValueAndLogReport(allowOneTimeDefrlInd, actualallowOneTimeDefrlInd, "ALLOWONETIMEDEFRLIND");
			
			String allowScheduleDefrlInd = queryResultSet.getString("ALLOWSCHEDULEDEFRLIND");
			String actualallowScheduleDefrlInd = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
					"$..allowScheduleDefrlInd");
			JsonReadWriteUtils.compareValueAndLogReport(allowScheduleDefrlInd, actualallowScheduleDefrlInd, "ALLOWSCHEDULEDEFRLIND");
			
			String taxId = queryResultSet.getString("TAXID");
			String actualtaxId= JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
					"$..taxId");
			JsonReadWriteUtils.compareValueAndLogReport(taxId, actualtaxId ,"TAXID");
			
			String acaCode = queryResultSet.getString("ACACODE");
			String actualacaCode = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
					"$..acaCode");
			JsonReadWriteUtils.compareValueAndLogReport(acaCode, actualacaCode, "ACACODE");
			
			/*String acaCodeDescr = queryResultSet.getString("ACACODEDESCR");
			String actualacaCodeDescr = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
					"$..acaCodeDescr");
			JsonReadWriteUtils.compareValueAndLogReport(acaCodeDescr, actualacaCodeDescr ,"ACACODEDESCR");
			*/
			String heartActLeaveTypeCode = queryResultSet.getString("HEARTACTLEAVETYPECODE");
			String actualheartActLeaveTypeCode = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
					"$..heartActLeaveTypeCode");
			JsonReadWriteUtils.compareValueAndLogReport(heartActLeaveTypeCode, actualheartActLeaveTypeCode, "HEARTACTLEAVETYPECODE");
			
			String heartActLeaveSuspMths = queryResultSet.getString("HEARTACTLEAVESUSPMTHS");
			String actualheartActLeaveSuspMths= JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
					"$..heartActLeaveSuspMths");
			JsonReadWriteUtils.compareValueAndLogReport(heartActLeaveSuspMths, actualheartActLeaveSuspMths ,"HEARTACTLEAVESUSPMTHS");
			
			String rollovrContribInAllowedInd = queryResultSet.getString("ROLLOVRCONTRIBINALLOWEDIND");
			String actualrollovrContribInAllowedInd = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
					"$..rollovrContribInAllowedInd");
			JsonReadWriteUtils.compareValueAndLogReport(rollovrContribInAllowedInd, actualrollovrContribInAllowedInd, "ROLLOVRCONTRIBINALLOWEDIND");
			
			String rolloverAllowedEligCode = queryResultSet.getString("ROLLOVERALLOWEDELIGCODE");
			String actualrolloverAllowedEligCode = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
					"$..rolloverAllowedEligCode");
			JsonReadWriteUtils.compareValueAndLogReport(rolloverAllowedEligCode, actualrolloverAllowedEligCode ,"ROLLOVRALLOWEDELIGCODE");
			
			String dolPlanNbr = queryResultSet.getString("DOLPLANNBR");
			String actualdolPlanNbr = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
					"$..dolPlanNbr");
			JsonReadWriteUtils.compareValueAndLogReport(dolPlanNbr, actualdolPlanNbr, "DOLPLANNBR");

			String coannuitantSpouseReqdInd = queryResultSet.getString("COANNUITANTSPOUSEREQDIND");
			String actualcoannuitantSpouseReqdInd = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
					"$..coannuitantSpouseReqdInd");
			JsonReadWriteUtils.compareValueAndLogReport(coannuitantSpouseReqdInd, actualcoannuitantSpouseReqdInd, "COANNUITANTSPOUSEREQIND");
			
			String qjsaQosaQpsaInd = queryResultSet.getString("QJSAQOSAQPSAIND");
			String actualqjsaQosaQpsaInd= JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
					"$..qjsaQosaQpsaInd");
			JsonReadWriteUtils.compareValueAndLogReport(qjsaQosaQpsaInd, actualqjsaQosaQpsaInd ,"QJSAQOSAQPSAIND");
			
		/*	String canShowVestedAcctBalance = queryResultSet.getString("CANSHOWVESTEDACCTBALANCE");
			String actualcanShowVestedAcctBalance = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
					"$..canShowVestedAcctBalance");
			JsonReadWriteUtils.compareValueAndLogReport(canShowVestedAcctBalance, actualcanShowVestedAcctBalance, "CANSHOWVESTEDACCTBALANCE");
			*/
			String qdiaagreementInd = queryResultSet.getString("QDIAAGREEMENTIND");
			String actualqdiaagreementInd = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
					"$..qdiaagreementInd");
			JsonReadWriteUtils.compareValueAndLogReport(qdiaagreementInd, actualqdiaagreementInd ,"QDIAAGREEMENTIND");
			
			/*String qdiaagreementIndDesc = queryResultSet.getString("QDIAAGREEMENTINDDESC");
			String actualqdiaagreementIndDesc = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
					"$..qdiaagreementIndDesc");
			JsonReadWriteUtils.compareValueAndLogReport(qdiaagreementIndDesc, actualqdiaagreementIndDesc, "QDIAAGREEMENTINDDESC");
			*/
		}
			}else{
				System.out.println("Result set is null");
			}
	}
	

}

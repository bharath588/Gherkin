package app.webservice.pageobjects.pptenrollmentinfo;

public class Employment {

	String indId;
	String gcId;
	String erAssignedId;
	String hireDate;
	String percentOwnership;
	String empTermdate;
	String highlyCompensatedInd;
	String officerInd;
	String jobDescr;
	String employmentType;
	String terminationReasonCode;
	String termNotificationDateTime;
	String sarbanesOxleyReportingInd;
	String erClassificationCode;
	String erClassificationChgDpdate;
	String empTermdateChgDpdateTime;
	String insiderInd;
	String superOfficerInd;
	String unionInd;
	String overseasInd;
	String overseasEffdate;
	String fullPartTimeEmployee;
	
	public void setIndId(String indId) {
		this.indId = indId;
	}
	public void setGcId(String gcId) {
		this.gcId = gcId;
	}
	public void setErAssignedId(String erAssignedId) {
		this.erAssignedId = erAssignedId;
	}
	public void setHireDate(String hireDate) {
		this.hireDate = hireDate;
	}
	public void setPercentOwnership(String percentOwnership) {
		this.percentOwnership = percentOwnership;
	}
	public void setEmpTermdate(String empTermdate) {
		this.empTermdate = empTermdate;
	}
	public void setHighlyCompensatedInd(String highlyCompensatedInd) {
		this.highlyCompensatedInd = highlyCompensatedInd;
	}
	public void setOfficerInd(String officerInd) {
		this.officerInd = officerInd;
	}
	public void setJobDescr(String jobDescr) {
		this.jobDescr = jobDescr;
	}
	public void setEmploymentType(String employmentType) {
		this.employmentType = employmentType;
	}
	public void setTerminationReasonCode(String terminationReasonCode) {
		this.terminationReasonCode = terminationReasonCode;
	}
	public void setTermNotificationDateTime(String termNotificationDateTime) {
		this.termNotificationDateTime = termNotificationDateTime;
	}
	public void setSarbanesOxleyReportingInd(String sarbanesOxleyReportingInd) {
		this.sarbanesOxleyReportingInd = sarbanesOxleyReportingInd;
	}
	public void setErClassificationCode(String erClassificationCode) {
		this.erClassificationCode = erClassificationCode;
	}
	public void setErClassificationChgDpdate(String erClassificationChgDpdate) {
		this.erClassificationChgDpdate = erClassificationChgDpdate;
	}
	public void setEmpTermdateChgDpdateTime(String empTermdateChgDpdateTime) {
		this.empTermdateChgDpdateTime = empTermdateChgDpdateTime;
	}
	public void setInsiderInd(String insiderInd) {
		this.insiderInd = insiderInd;
	}
	public void setSuperOfficerInd(String superOfficerInd) {
		this.superOfficerInd = superOfficerInd;
	}
	public void setUnionInd(String unionInd) {
		this.unionInd = unionInd;
	}
	public void setOverseasInd(String overseasInd) {
		this.overseasInd = overseasInd;
	}
	public void setOverseasEffdate(String overseasEffdate) {
		this.overseasEffdate = overseasEffdate;
	}
	public void setFullPartTimeEmployee(String fullPartTimeEmployee) {
		this.fullPartTimeEmployee = fullPartTimeEmployee;
	}
}


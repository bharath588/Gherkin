package app.practice;

import java.util.List;

public class Department {

	
	String deptName;
	int deptId;
	
	List<Clazz> objClass;
	
	public List<Clazz> getObjClass() {
		return objClass;
	}
	public void setObjClass(List<Clazz> objClass) {
		this.objClass = objClass;
	}
	public String getDeptName() {
		return deptName;
	}
	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}
	public int getDeptId() {
		return deptId;
	}
	public void setDeptId(int deptId) {
		this.deptId = deptId;
	}
}

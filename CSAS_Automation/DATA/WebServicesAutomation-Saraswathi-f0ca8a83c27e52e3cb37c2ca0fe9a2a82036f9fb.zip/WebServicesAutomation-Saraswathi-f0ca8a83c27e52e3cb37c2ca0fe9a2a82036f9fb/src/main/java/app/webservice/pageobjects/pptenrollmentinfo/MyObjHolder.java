package app.webservice.pageobjects.pptenrollmentinfo;

import org.openqa.selenium.WebDriver;

public class MyObjHolder {

}

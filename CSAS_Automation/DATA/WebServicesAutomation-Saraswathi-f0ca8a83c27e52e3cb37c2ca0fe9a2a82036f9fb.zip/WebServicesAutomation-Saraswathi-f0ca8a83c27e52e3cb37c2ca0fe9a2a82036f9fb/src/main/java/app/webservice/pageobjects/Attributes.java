package app.webservice.pageobjects;

public class Attributes {

	String username;
	String password;
	String accuCode;
	String database;
	String gaId;
	String indId;
	public void setDatabase(String database) {
		this.database = database;
	}
	public void setGaId(String gaId) {
		this.gaId = gaId;
	}
	public void setIndId(String indId) {
		this.indId = indId;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getAccuCode() {
		return accuCode;
	}
	public void setAccuCode(String accuCode) {
		this.accuCode = accuCode;
	}
	public String getDatabase() {
		return database;
	}
	public String getGaId() {
		return gaId;
	}
	public String getIndId() {
		return indId;
	}

}

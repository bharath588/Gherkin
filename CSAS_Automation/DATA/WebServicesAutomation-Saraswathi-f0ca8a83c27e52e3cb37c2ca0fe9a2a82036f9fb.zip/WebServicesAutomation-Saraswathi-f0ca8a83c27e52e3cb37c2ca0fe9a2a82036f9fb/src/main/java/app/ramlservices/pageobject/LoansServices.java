package app.ramlservices.pageobject;
import java.sql.ResultSet;
import com.aventstack.extentreports.Status;
import lib.DB;
import lib.Reporter;
import lib.Stock;
import util.CommonLib;
import app.webservice.pageobjects.JsonReadWriteUtils;

public class LoansServices {

	CommonLib utilities;
	ResultSet queryResultSet;


	/**<pre> Method to validate the response body of GrpLoanStrucLoanReason web service</pre>
	 * @param requestUrl
	 */
	public void validateResponseGrpLoanStrucLoanReason(){
		String loanReasonCode = Stock.GetParameterValue("LOAN_REASON_CODE");
		try{
			utilities = new CommonLib();
			String responseString = utilities.getHttpResponseAsString();
			Reporter.logEvent(Status.INFO, "The response", responseString,
					false);
			Stock.setConfigParam("TARGETDB",
					"D_" + Stock.GetParameterValue("queryDB").toUpperCase());
			queryResultSet=DB.executeQuery("TARGETDB", Stock.getTestQuery("getGrpLoanStrucLoanReason")[1], 
					Stock.GetParameterValue("gls.gaId"),
					Stock.GetParameterValue("LOAN_REASON_CODE"));

			while(queryResultSet.next()){

				String effdate = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
						"$..[?(@.loanReasonCode=='"+loanReasonCode+"')]..effdate");
				String gaId = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
						"$..[?(@.loanReasonCode=='"+loanReasonCode+"')]..gaId");
				String sdlnstCode = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
						"$..[?(@.loanReasonCode=='"+loanReasonCode+"')]..sdlnstCode");
				String formsEffdate = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
						"$..[?(@.loanReasonCode=='"+loanReasonCode+"')]..formsEffdate");
				String sdirtyCode = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
						"$..[?(@.loanReasonCode=='"+loanReasonCode+"')]..sdirtyCode");
				String strucDescr = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
						"$..[?(@.loanReasonCode=='"+loanReasonCode+"')]..strucDescr");
				String loanTypeCode = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
						"$..[?(@.loanReasonCode=='"+loanReasonCode+"')]..loanTypeCode");
				String extCarrierLoanInd = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
						"$..[?(@.loanReasonCode=='"+loanReasonCode+"')]..extCarrierLoanInd");
				String minLoanAmt = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
						"$..[?(@.loanReasonCode=='"+loanReasonCode+"')]..minLoanAmt");
				String effdateMthdDays = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
						"$..[?(@.loanReasonCode=='"+loanReasonCode+"')]..effdateMthdDays");
				String repayMthdCode = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
						"$..[?(@.loanReasonCode=='"+loanReasonCode+"')]..repayMthdCode");
				String repayToleranceAmt = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
						"$..[?(@.loanReasonCode=='"+loanReasonCode+"')]..repayToleranceAmt");
				String repayCurePerdDays = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
						"$..[?(@.loanReasonCode=='"+loanReasonCode+"')]..repayCurePerdDays");
				String prepayAllowedCode = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
						"$..[?(@.loanReasonCode=='"+loanReasonCode+"')]..prepayAllowedCode");
				String payoffToleranceAmt = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
						"$..[?(@.loanReasonCode=='"+loanReasonCode+"')]..payoffToleranceAmt");
				String consolidateInd = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
						"$..[?(@.loanReasonCode=='"+loanReasonCode+"')]..consolidateInd");
				String defaultTypeCode = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
						"$..[?(@.loanReasonCode=='"+loanReasonCode+"')]..defaultTypeCode");
				String intCrMthdCode = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
						"$..[?(@.loanReasonCode=='"+loanReasonCode+"')]..intCrMthdCode");
				String intRateTypeCode = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
						"$..[?(@.loanReasonCode=='"+loanReasonCode+"')]..intRateTypeCode");
				String fullPrepayAllowedInd = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
						"$..[?(@.loanReasonCode=='"+loanReasonCode+"')]..fullPrepayAllowedInd");
				String waitPromissoryNoteInd = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
						"$..[?(@.loanReasonCode=='"+loanReasonCode+"')]..waitPromissoryNoteInd");
				String payAheadAllowedInd = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
						"$..[?(@.loanReasonCode=='"+loanReasonCode+"')]..payAheadAllowedInd");
				String principalReductionAllowInd = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
						"$..[?(@.loanReasonCode=='"+loanReasonCode+"')]..principalReductionAllowInd");
				String loanDefaultHoldInd = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
						"$..[?(@.loanReasonCode=='"+loanReasonCode+"')]..loanDefaultHoldInd");
				String intRateChangeMthd = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
						"$..[?(@.loanReasonCode=='"+loanReasonCode+"')]..intRateChangeMthd");
				String loanIssuePerd = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
						"$..[?(@.loanReasonCode=='"+loanReasonCode+"')]..loanIssuePerd");
				String loanIssueQual = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
						"$..[?(@.loanReasonCode=='"+loanReasonCode+"')]..loanIssueQual");
				String debitMethodCode = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
						"$..[?(@.loanReasonCode=='"+loanReasonCode+"')]..debitMethodCode");
				String earlyPayoffIntDays = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
						"$..[?(@.loanReasonCode=='"+loanReasonCode+"')]..earlyPayoffIntDays");
				String earlyPayoffGraceDays = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
						"$..[?(@.loanReasonCode=='"+loanReasonCode+"')]..earlyPayoffGraceDays");
				String prepayRestrcPerd = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
						"$..[?(@.loanReasonCode=='"+loanReasonCode+"')]..prepayRestrcPerd");
				String prepayRestrcQual = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
						"$..[?(@.loanReasonCode=='"+loanReasonCode+"')]..prepayRestrcQual");
				String collateralFactor = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
						"$..[?(@.loanReasonCode=='"+loanReasonCode+"')]..collateralFactor");
				String termdate = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
						"$..[?(@.loanReasonCode=='"+loanReasonCode+"')]..termdate");
				String formsTermdate = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
						"$..[?(@.loanReasonCode=='"+loanReasonCode+"')]..formsTermdate");
				String maxSamePrdLoanIssues = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
						"$..[?(@.loanReasonCode=='"+loanReasonCode+"')]..maxSamePrdLoanIssues");
				String defaultedLoansAllowedInd = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
						"$..[?(@.loanReasonCode=='"+loanReasonCode+"')]..defaultedLoansAllowedInd");
				String terminatedEmployeeLoanInd = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
						"$..[?(@.loanReasonCode=='"+loanReasonCode+"')]..terminatedEmployeeLoanInd");
				String contributionHistoryDays = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
						"$..[?(@.loanReasonCode=='"+loanReasonCode+"')]..contributionHistoryDays");
				String mortgagePaperworkReviewInd = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
						"$..[?(@.loanReasonCode=='"+loanReasonCode+"')]..mortgagePaperworkReviewInd");
				String payAheadMaxDays = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
						"$..[?(@.loanReasonCode=='"+loanReasonCode+"')]..payAheadMaxDays");
				String defaultLoanPrepayMthdCode = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
						"$..[?(@.loanReasonCode=='"+loanReasonCode+"')]..defaultLoanPrepayMthdCode");
				String mailCheckToEmployerInd = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
						"$..[?(@.loanReasonCode=='"+loanReasonCode+"')]..mailCheckToEmployerInd");
				String autoAuthInd = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
						"$..[?(@.loanReasonCode=='"+loanReasonCode+"')]..autoAuthInd");
				String loanReasonCodeRes = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
						"$..[?(@.loanReasonCode=='"+loanReasonCode+"')]..loanReasonCode");
				String loanTermQual = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
						"$..[?(@.loanReasonCode=='"+loanReasonCode+"')]..loanTermQual");
				String lowThresh = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
						"$..[?(@.loanReasonCode=='"+loanReasonCode+"')]..lowThresh");
				String highThresh = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
						"$..[?(@.loanReasonCode=='"+loanReasonCode+"')]..highThresh");
				String maxLoansAllowed = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
						"$..[?(@.loanReasonCode=='"+loanReasonCode+"')]..maxLoansAllowed");
				String allowAutoLoanOffsetInd = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
						"$..[?(@.loanReasonCode=='"+loanReasonCode+"')]..allowAutoLoanOffsetInd");
				String loanOffsetWaitingDays = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
						"$..[?(@.loanReasonCode=='"+loanReasonCode+"')]..loanOffsetWaitingDays");
				String nonCertPaymentWaitDays = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
						"$..[?(@.loanReasonCode=='"+loanReasonCode+"')]..nonCertPaymentWaitDays");
				String extendMaturityDateInd = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
						"$..[?(@.loanReasonCode=='"+loanReasonCode+"')]..extendMaturityDateInd");
				String maxLoanCalcAmount = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
						"$..[?(@.loanReasonCode=='"+loanReasonCode+"')]..maxLoanCalcAmount");
				String proceedsByAch = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
						"$..[?(@.loanReasonCode=='"+loanReasonCode+"')]..proceedsByAch");
				String loanDeminimusInd = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
						"$..[?(@.loanReasonCode=='"+loanReasonCode+"')]..loanDeminimusInd");
				String loanHardshipInd = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
						"$..[?(@.loanReasonCode=='"+loanReasonCode+"')]..loanHardshipInd");
				String planMaxLoansAllowed = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
						"$..[?(@.loanReasonCode=='"+loanReasonCode+"')]..planMaxLoansAllowed");
				String allowLoansDisabilityLoaInd = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
						"$..[?(@.loanReasonCode=='"+loanReasonCode+"')]..allowLoansDisabilityLoaInd");
				String allowLoansEmpLoaInd = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
						"$..[?(@.loanReasonCode=='"+loanReasonCode+"')]..allowLoansEmpLoaInd");
				String allowLoansMilitaryLoaInd = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
						"$..[?(@.loanReasonCode=='"+loanReasonCode+"')]..allowLoansMilitaryLoaInd");
				String excludeDefaultedLoansFromActiveLoanCount = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
						"$..[?(@.loanReasonCode=='"+loanReasonCode+"')]..excludeDefaultedLoansFromActiveLoanCount");
				String partGrpgPlanId = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
						"$..[?(@.loanReasonCode=='"+loanReasonCode+"')]..partGrpgPlanId");
				String newLoanWaitDays = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
						"$..[?(@.loanReasonCode=='"+loanReasonCode+"')]..newLoanWaitDays");
				String paymentAfterTerminationInd = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
						"$..[?(@.loanReasonCode=='"+loanReasonCode+"')]..paymentAfterTerminationInd");

				JsonReadWriteUtils.compareDbWithDateInResponse(effdate, queryResultSet.getDate("EFFDATE"),"EFFDATE");
				JsonReadWriteUtils.compareValueAndLogReport(gaId, queryResultSet.getString("GA_ID"), "GA_ID");
				JsonReadWriteUtils.compareValueAndLogReport(sdlnstCode, queryResultSet.getString("SDLNST_CODE"), "SDLNST_CODE");
				JsonReadWriteUtils.compareDbWithDateInResponse(formsEffdate, queryResultSet.getDate("FORMS_EFFDATE"), "FORMS_EFFDATE");
				JsonReadWriteUtils.compareValueAndLogReport(sdirtyCode, queryResultSet.getString("SDIRTY_CODE"), "SDIRTY_CODE");
				JsonReadWriteUtils.compareValueAndLogReport(strucDescr, queryResultSet.getString("STRUC_DESCR"), "STRUC_DESCR");
				JsonReadWriteUtils.compareValueAndLogReport(loanTypeCode,queryResultSet.getString("LOAN_TYPE_CODE"),"LOAN_TYPE_CODE");
				JsonReadWriteUtils.compareValueAndLogReport(extCarrierLoanInd,queryResultSet.getString("EXT_CARRIER_LOAN_IND"),"EXT_CARRIER_LOAN_IND");
				JsonReadWriteUtils.compareNumericValues(minLoanAmt,queryResultSet.getString("MIN_LOAN_AMT"),"MIN_LOAN_AMT");
				JsonReadWriteUtils.compareValueAndLogReport(effdateMthdDays,queryResultSet.getString("EFFDATE_MTHD_DAYS"),"EFFDATE_MTHD_DAYS");
				//Verify REPAY_MTHD_CODE
				if(repayMthdCode.equalsIgnoreCase("CHECK") && queryResultSet.getString("REPAY_MTHD_CODE").equalsIgnoreCase("payroll")){
					Reporter.logEvent(Status.PASS,"Verify if REPAY_MTHD_CODE is PAYROLL in DB then response "
							+ "value of repayMthdCode is CHECK" , "REPAY_MTHD_CODE is \nPAYROLL in DB \nand "
									+ "response value of repayMthdCode is \nCHECK", false);
				}
				else{
					JsonReadWriteUtils.compareValueAndLogReport(repayMthdCode,queryResultSet.getString("REPAY_MTHD_CODE"),"REPAY_MTHD_CODE");
				}//Verification ends here

				JsonReadWriteUtils.compareNumericValues(repayToleranceAmt,queryResultSet.getString("REPAY_TOLERANCE_AMT"),"REPAY_TOLERANCE_AMT");
				JsonReadWriteUtils.compareNumericValues(repayCurePerdDays,queryResultSet.getString("REPAY_CURE_PERD_DAYS"),"REPAY_CURE_PERD_DAYS");
				JsonReadWriteUtils.compareValueAndLogReport(prepayAllowedCode,queryResultSet.getString("PREPAY_ALLOWED_CODE"),"PREPAY_ALLOWED_CODE");
				JsonReadWriteUtils.compareNumericValues(payoffToleranceAmt,queryResultSet.getString("PAYOFF_TOLERANCE_AMT"),"PAYOFF_TOLERANCE_AMT");
				JsonReadWriteUtils.compareValueAndLogReport(consolidateInd,queryResultSet.getString("CONSOLIDATE_IND"),"CONSOLIDATE_IND");
				JsonReadWriteUtils.compareValueAndLogReport(defaultTypeCode,queryResultSet.getString("DEFAULT_TYPE_CODE"),"DEFAULT_TYPE_CODE");
				JsonReadWriteUtils.compareValueAndLogReport(intCrMthdCode,queryResultSet.getString("INT_CR_MTHD_CODE"),"INT_CR_MTHD_CODE");
				JsonReadWriteUtils.compareValueAndLogReport(intRateTypeCode,queryResultSet.getString("INT_RATE_TYPE_CODE"),"INT_RATE_TYPE_CODE");
				JsonReadWriteUtils.compareValueAndLogReport(fullPrepayAllowedInd,queryResultSet.getString("FULL_PREPAY_ALLOWED_IND"),"FULL_PREPAY_ALLOWED_IND");
				JsonReadWriteUtils.compareValueAndLogReport(waitPromissoryNoteInd,queryResultSet.getString("WAIT_PROMISSORY_NOTE_IND"),"WAIT_PROMISSORY_NOTE_IND");
				JsonReadWriteUtils.compareValueAndLogReport(payAheadAllowedInd,queryResultSet.getString("PAY_AHEAD_ALLOWED_IND"),"PAY_AHEAD_ALLOWED_IND");
				JsonReadWriteUtils.compareValueAndLogReport(principalReductionAllowInd,queryResultSet.getString("PRINCIPAL_REDUCTION_ALLOW_IND"),"PRINCIPAL_REDUCTION_ALLOW_IND");
				JsonReadWriteUtils.compareValueAndLogReport(loanDefaultHoldInd,queryResultSet.getString("LOAN_DEFAULT_HOLD_IND"),"LOAN_DEFAULT_HOLD_IND");
				JsonReadWriteUtils.compareValueAndLogReport(intRateChangeMthd,queryResultSet.getString("INT_RATE_CHANGE_MTHD"),"INT_RATE_CHANGE_MTHD");
				JsonReadWriteUtils.compareValueAndLogReport(loanIssuePerd,queryResultSet.getString("LOAN_ISSUE_PERD"),"LOAN_ISSUE_PERD");
				JsonReadWriteUtils.compareValueAndLogReport(loanIssueQual,queryResultSet.getString("LOAN_ISSUE_QUAL"),"LOAN_ISSUE_QUAL");
				JsonReadWriteUtils.compareValueAndLogReport(debitMethodCode,queryResultSet.getString("DEBIT_METHOD_CODE"),"DEBIT_METHOD_CODE");
				JsonReadWriteUtils.compareValueAndLogReport(earlyPayoffIntDays,queryResultSet.getString("EARLY_PAYOFF_INT_DAYS"),"EARLY_PAYOFF_INT_DAYS");
				JsonReadWriteUtils.compareValueAndLogReport(earlyPayoffGraceDays,queryResultSet.getString("EARLY_PAYOFF_GRACE_DAYS"),"EARLY_PAYOFF_GRACE_DAYS");
				JsonReadWriteUtils.compareValueAndLogReport(prepayRestrcPerd,queryResultSet.getString("PREPAY_RESTRC_PERD"),"PREPAY_RESTRC_PERD");
				JsonReadWriteUtils.compareValueAndLogReport(prepayRestrcQual,queryResultSet.getString("PREPAY_RESTRC_QUAL"),"PREPAY_RESTRC_QUAL");
				JsonReadWriteUtils.compareNumericValues(collateralFactor,queryResultSet.getString("COLLATERAL_FACTOR"),"COLLATERAL_FACTOR");
				JsonReadWriteUtils.compareDbWithDateInResponse(termdate,queryResultSet.getDate("TERMDATE"),"TERMDATE");
				JsonReadWriteUtils.compareDbWithDateInResponse(formsTermdate,queryResultSet.getDate("FORMS_TERMDATE"),"FORMS_TERMDATE");
				JsonReadWriteUtils.compareValueAndLogReport(maxSamePrdLoanIssues,queryResultSet.getString("MAX_SAME_PRD_LOAN_ISSUES"),"MAX_SAME_PRD_LOAN_ISSUES");
				JsonReadWriteUtils.compareValueAndLogReport(contributionHistoryDays,queryResultSet.getString("CONTRIBUTION_HISTORY_DAYS"),"CONTRIBUTION_HISTORY_DAYS");
				JsonReadWriteUtils.compareValueAndLogReport(defaultedLoansAllowedInd,queryResultSet.getString("DEFAULTED_LOANS_ALLOWED_IND"),"DEFAULTED_LOANS_ALLOWED_IND");
				JsonReadWriteUtils.compareValueAndLogReport(terminatedEmployeeLoanInd,queryResultSet.getString("TERMINATED_EMPLOYEE_LOAN_IND"),"TERMINATED_EMPLOYEE_LOAN_IND");
				JsonReadWriteUtils.compareValueAndLogReport(mortgagePaperworkReviewInd,queryResultSet.getString("MORTGAGE_PAPERWORK_REVIEW_IND"),"MORTGAGE_PAPERWORK_REVIEW_IND");
				JsonReadWriteUtils.compareValueAndLogReport(payAheadMaxDays,queryResultSet.getString("PAY_AHEAD_MAX_DAYS"),"PAY_AHEAD_MAX_DAYS");
				JsonReadWriteUtils.compareValueAndLogReport(defaultLoanPrepayMthdCode,queryResultSet.getString("DEFAULT_LOAN_PREPAY_MTHD_CODE"),"DEFAULT_LOAN_PREPAY_MTHD_CODE");
				JsonReadWriteUtils.compareValueAndLogReport(mailCheckToEmployerInd,queryResultSet.getString("MAIL_CHECK_TO_EMPLOYER_IND"),"MAIL_CHECK_TO_EMPLOYER_IND");
				JsonReadWriteUtils.compareValueAndLogReport(autoAuthInd,queryResultSet.getString("AUTO_AUTH_IND"),"AUTO_AUTH_IND");
				JsonReadWriteUtils.compareValueAndLogReport(loanReasonCodeRes,queryResultSet.getString("LOAN_REASON_CODE"),"LOAN_REASON_CODE");
				JsonReadWriteUtils.compareValueAndLogReport(loanTermQual,queryResultSet.getString("LOAN_TERM_QUAL"),"LOAN_TERM_QUAL");
				JsonReadWriteUtils.compareValueAndLogReport(lowThresh,queryResultSet.getString("LOW_THRESH"),"LOW_THRESH");
				JsonReadWriteUtils.compareValueAndLogReport(highThresh,queryResultSet.getString("HIGH_THRESH"),"HIGH_THRESH");
				JsonReadWriteUtils.compareValueAndLogReport(maxLoansAllowed,queryResultSet.getString(79),"MAX_LOANS_ALLOWED_1");

				JsonReadWriteUtils.compareValueAndLogReport(allowAutoLoanOffsetInd,queryResultSet.getString("ALLOW_AUTO_LOAN_OFFSET_IND"),"ALLOW_AUTO_LOAN_OFFSET_IND");
				JsonReadWriteUtils.compareValueAndLogReport(loanOffsetWaitingDays,queryResultSet.getString("LOAN_OFFSET_WAITING_DAYS"),"LOAN_OFFSET_WAITING_DAYS");
				JsonReadWriteUtils.compareValueAndLogReport(nonCertPaymentWaitDays,queryResultSet.getString("NON_CERT_PAYMENT_WAIT_DAYS"),"NON_CERT_PAYMENT_WAIT_DAYS");
				JsonReadWriteUtils.compareValueAndLogReport(extendMaturityDateInd,queryResultSet.getString("EXTEND_MATURITY_DATE_IND"),"EXTEND_MATURITY_DATE_IND");

				//For verifying MAX_LOAN_CALC_AMOUNT
				System.out.println(queryResultSet.getString("MAX_LOAN_CALC_AMOUNT"));
				if(queryResultSet.getString("MAX_LOAN_CALC_AMOUNT")==null){
					if(maxLoanCalcAmount.equalsIgnoreCase("50000.0")){
						Reporter.logEvent(Status.PASS, "Verify if MAX_LOAN_CALC_AMOUNT is null in "
								+ "DB then default value in response is 50000.0", 
								"MAX_LOAN_CALC_AMOUNT is null in DB and default value in response "
										+ "is 50000.0", false);
					}
					else{
						Reporter.logEvent(Status.FAIL, "Verify if MAX_LOAN_CALC_AMOUNT is null in "
								+ "DB then default value in response is 50000.0", 
								"MAX_LOAN_CALC_AMOUNT is null in DB and default value in response "
										+ "is NOT 50000.0", false);
					}
				}
				else{
					JsonReadWriteUtils.compareNumericValues(maxLoanCalcAmount,queryResultSet.getString("MAX_LOAN_CALC_AMOUNT"),"MAX_LOAN_CALC_AMOUNT");
				}
				//Verification of MAX_LOAN_CALC_AMOUNT ends here.

				JsonReadWriteUtils.compareValueAndLogReport(proceedsByAch,queryResultSet.getString("PROCEEDS_BY_ACH"),"PROCEEDS_BY_ACH");
				JsonReadWriteUtils.compareValueAndLogReport(loanDeminimusInd,queryResultSet.getString("LOAN_DEMINIMUS_IND"),"LOAN_DEMINIMUS_IND");
				JsonReadWriteUtils.compareValueAndLogReport(loanHardshipInd,queryResultSet.getString("LOAN_HARDSHIP_IND"),"LOAN_HARDSHIP_IND");
				JsonReadWriteUtils.compareValueAndLogReport(planMaxLoansAllowed,queryResultSet.getString("MAX_LOANS_ALLOWED"),"MAX_LOANS_ALLOWED");
				JsonReadWriteUtils.compareValueAndLogReport(allowLoansDisabilityLoaInd,queryResultSet.getString("ALLOW_LOANS_DISABILITY_LOA_IND"),"ALLOW_LOANS_DISABILITY_LOA_IND");
				JsonReadWriteUtils.compareValueAndLogReport(allowLoansEmpLoaInd,queryResultSet.getString("ALLOW_LOANS_EMP_LOA_IND"),"ALLOW_LOANS_EMP_LOA_IND");

				JsonReadWriteUtils.compareValueAndLogReport(allowLoansMilitaryLoaInd,queryResultSet.getString("ALLOW_LOANS_MILITARY_LOA_IND"),"ALLOW_LOANS_MILITARY_LOA_IND");
				JsonReadWriteUtils.compareValueAndLogReport(excludeDefaultedLoansFromActiveLoanCount,queryResultSet.getString("EXCL_DFLT_LN_FROM_ACT_LN_CNT"),"excludeDefaultedLoansFromActiveLoanCount");
				Reporter.logEvent(Status.INFO, "partGrpgPlanId cannot be verified", "partGrpgPlanId cannot be verified", false);
				//cannot be verified:-JsonReadWriteUtils.compareValueAndLogReport(partGrpgPlanId,queryResultSet.getString("PROCEEDS_BY_ACH"),"partGrpgPlanId");
				JsonReadWriteUtils.compareValueAndLogReport(newLoanWaitDays,queryResultSet.getString("NEW_LOAN_WAIT_DAYS"),"NEW_LOAN_WAIT_DAYS");
				JsonReadWriteUtils.compareValueAndLogReport(paymentAfterTerminationInd,queryResultSet.getString("PAYMENT_AFTER_TERMINATION_IND"),"PAYMENT_AFTER_TERMINATION_IND");	

			}
		}
		catch(Exception e){
			e.printStackTrace();
		}
	}


	public void validateResponseLoanAcctSummary() {
		try{
			utilities = new CommonLib();
			String responseString = utilities.getHttpResponseAsString();
			Reporter.logEvent(Status.INFO, "The response", responseString,
					false);
			Stock.setConfigParam("TARGETDB",
					"D_" + Stock.GetParameterValue("queryDB").toUpperCase());
			queryResultSet=DB.executeQuery("TARGETDB", Stock.getTestQuery("getLoanAccountDetails")[1], 
					Stock.GetParameterValue("las.gaId"),
					Stock.GetParameterValue("las.indId"),
					Stock.GetParameterValue("las.effDate"));

			while(queryResultSet.next()){
				String seqNum = queryResultSet.getString("INLNAG_SEQNBR");
				String gaId = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
						"$..[?(@.inlnagSeqnbr=='"+seqNum+"')]..gaId");
				String indId = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
						"$..[?(@.inlnagSeqnbr=='"+seqNum+"')]..indId");
				String sdlnstCode = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
						"$..[?(@.inlnagSeqnbr=='"+seqNum+"')]..sdlnstCode");
				String grlnstEffdate = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
						"$..[?(@.inlnagSeqnbr=='"+seqNum+"')]..grlnstEffdate");
				String loanTerm = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
						"$..[?(@.inlnagSeqnbr=='"+seqNum+"')]..loanTerm");
				String loanTermQual = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
						"$..[?(@.inlnagSeqnbr=='"+seqNum+"')]..loanTermQual");
				String loanReasonCode = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
						"$..[?(@.inlnagSeqnbr=='"+seqNum+"')]..loanReasonCode");
				String maturityDate = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
						"$..[?(@.inlnagSeqnbr=='"+seqNum+"')]..maturityDate");
				String loanAmt = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
						"$..[?(@.inlnagSeqnbr=='"+seqNum+"')]..loanAmt");
				String effdate = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
						"$..[?(@.inlnagSeqnbr=='"+seqNum+"')]..effdate");
				String statusCode = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
						"$..[?(@.inlnagSeqnbr=='"+seqNum+"')]..statusCode");
				String statusChgEffdate = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
						"$..[?(@.inlnagSeqnbr=='"+seqNum+"')]..statusChgEffdate");
				String statusChgDpdate = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
						"$..[?(@.inlnagSeqnbr=='"+seqNum+"')]..statusChgDpdate");
				String repayFreq = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
						"$..[?(@.inlnagSeqnbr=='"+seqNum+"')]..repayFreq");
				String repayMthdCode = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
						"$..[?(@.inlnagSeqnbr=='"+seqNum+"')]..repayMthdCode");
				String trfLoanAcctInd= JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
						"$..[?(@.inlnagSeqnbr=='"+seqNum+"')]..trfLoanAcctInd");
				String defaultInd= JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
						"$..[?(@.inlnagSeqnbr=='"+seqNum+"')]..defaultInd");
				String defaultDate = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
						"$..[?(@.inlnagSeqnbr=='"+seqNum+"')]..defaultDate");
				String  repayAmt= JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
						"$..[?(@.inlnagSeqnbr=='"+seqNum+"')]..repayAmt");
				String firstDueDate= JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
						"$..[?(@.inlnagSeqnbr=='"+seqNum+"')]..firstDueDate");
				String origLoanAmt= JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
						"$..[?(@.inlnagSeqnbr=='"+seqNum+"')]..origLoanAmt");
				String origEffdate= JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
						"$..[?(@.inlnagSeqnbr=='"+seqNum+"')]..origEffdate");
				String fixedIntRate= JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
						"$..[?(@.inlnagSeqnbr=='"+seqNum+"')]..fixedIntRate");
				String equivDailyEffRate= JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
						"$..[?(@.inlnagSeqnbr=='"+seqNum+"')]..equivDailyEffRate");
				String originationFee= JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
						"$..[?(@.inlnagSeqnbr=='"+seqNum+"')]..originationFee");
				String trfLoanAcctId= JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
						"$..[?(@.inlnagSeqnbr=='"+seqNum+"')]..trfLoanAcctId");
				String dsrsCode= JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
						"$..[?(@.inlnagSeqnbr=='"+seqNum+"')]..dsrsCode");
				String defaultInlnagSeqnbr= JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
						"$..[?(@.inlnagSeqnbr=='"+seqNum+"')]..defaultInlnagSeqnbr");
				String defaultGaId= JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
						"$..[?(@.inlnagSeqnbr=='"+seqNum+"')]..defaultGaId");
				String defaultIndId= JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
						"$..[?(@.inlnagSeqnbr=='"+seqNum+"')]..defaultIndId");
				String defaultHoldInd= JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
						"$..[?(@.inlnagSeqnbr=='"+seqNum+"')]..defaultHoldInd");
				String reamortizationDpdateTime= JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
						"$..[?(@.inlnagSeqnbr=='"+seqNum+"')]..reamortizationDpdateTime");
				JsonReadWriteUtils.compareValueAndLogReport(gaId, queryResultSet.getString("GA_ID"), "gaId");
				JsonReadWriteUtils.compareValueAndLogReport(indId, queryResultSet.getString("IND_ID"), "indId");
				JsonReadWriteUtils.compareValueAndLogReport(sdlnstCode, queryResultSet.getString("sdlnst_code"), "sdlnstCode");
				JsonReadWriteUtils.compareDbWithDateInResponse(grlnstEffdate, queryResultSet.getDate("grlnst_effdate"), "grlnstEffdate");
				JsonReadWriteUtils.compareValueAndLogReport(loanTerm, queryResultSet.getString("LOAN_TERM"), "loanTerm");
				JsonReadWriteUtils.compareValueAndLogReport(loanTermQual, queryResultSet.getString("LOAN_TERM_QUAL"), "loanTermQual");
				JsonReadWriteUtils.compareValueAndLogReport(loanReasonCode, queryResultSet.getString("LOAN_REASON_CODE"), "loanReasonCode");
				JsonReadWriteUtils.compareDbWithDateInResponse(maturityDate, queryResultSet.getDate("MATURITY_DATE"), "maturityDate");
				JsonReadWriteUtils.compareNumericValues(loanAmt, queryResultSet.getString("LOAN_AMT"), "loanAmt");
				JsonReadWriteUtils.compareDbWithDateInResponse(effdate, queryResultSet.getDate("EFFDATE"), "effdate");
				JsonReadWriteUtils.compareValueAndLogReport(statusCode, queryResultSet.getString("STATUS_CODE"), "statusCode");
				JsonReadWriteUtils.compareDbWithDateInResponse(statusChgEffdate, queryResultSet.getDate("STATUS_CHG_EFFDATE"), "statusChgEffdate");
				JsonReadWriteUtils.compareTimestamp(statusChgDpdate, queryResultSet.getTimestamp("STATUS_CHG_DPDATE"), "statusChgDpdate");
				//System.out.println(queryResultSet.getTimestamp("STATUS_CHG_DPDATE"));
				
				JsonReadWriteUtils.compareValueAndLogReport(repayFreq, queryResultSet.getString("REPAY_FREQ"), "repayFreq");
				JsonReadWriteUtils.compareValueAndLogReport(repayMthdCode, queryResultSet.getString("REPAY_MTHD_CODE"), "repayMthdCode");
				JsonReadWriteUtils.compareValueAndLogReport(trfLoanAcctInd, queryResultSet.getString("TRF_LOAN_ACCT_IND"), "trfLoanAcctInd");
				JsonReadWriteUtils.compareValueAndLogReport(defaultInd, queryResultSet.getString("DEFAULT_IND"), "defaultInd");
				JsonReadWriteUtils.compareValueAndLogReport(defaultDate, queryResultSet.getString("DEFAULT_DATE"), "defaultDate");
				JsonReadWriteUtils.compareNumericValues(repayAmt, queryResultSet.getString("REPAY_AMT"), "repayAmt");
				
				JsonReadWriteUtils.compareDbWithDateInResponse(firstDueDate, queryResultSet.getDate("FIRST_DUE_DATE"), "firstDueDate");
				JsonReadWriteUtils.compareNumericValues(origLoanAmt, queryResultSet.getString("ORIG_LOAN_AMT"), "origLoanAmt");
				JsonReadWriteUtils.compareDbWithDateInResponse(origEffdate, queryResultSet.getDate("ORIG_EFFDATE"), "origEffdate");
				JsonReadWriteUtils.compareNumericValues(fixedIntRate, queryResultSet.getString("FIXED_INT_RATE"), "fixedIntRate");
				JsonReadWriteUtils.compareNumericValues(equivDailyEffRate, queryResultSet.getString("EQUIV_DAILY_EFF_RATE"), "equivDailyEffRate");
				
				JsonReadWriteUtils.compareValueAndLogReport(originationFee, queryResultSet.getString("ORIGINATION_FEE"), "originationFee");
				JsonReadWriteUtils.compareValueAndLogReport(trfLoanAcctId, queryResultSet.getString("TRF_LOAN_ACCT_ID"), "trfLoanAcctId");
				JsonReadWriteUtils.compareValueAndLogReport(dsrsCode, queryResultSet.getString("DSRS_CODE"), "dsrsCode");
				JsonReadWriteUtils.compareValueAndLogReport(defaultInlnagSeqnbr, queryResultSet.getString("DEFAULT_INLNAG_SEQNBR"), "defaultInlnagSeqnbr");
				JsonReadWriteUtils.compareValueAndLogReport(defaultGaId, queryResultSet.getString("DEFAULT_GA_ID"), "defaultGaId");
				JsonReadWriteUtils.compareValueAndLogReport(defaultIndId, queryResultSet.getString("DEFAULT_IND_ID"), "defaultIndId");
				JsonReadWriteUtils.compareValueAndLogReport(defaultHoldInd, queryResultSet.getString("DEFAULT_HOLD_IND"), "defaultHoldInd");
				JsonReadWriteUtils.compareTimestamp(reamortizationDpdateTime, queryResultSet.getTimestamp("REAMORTIZATION_DPDATE_TIME"), "reamortizationDpdateTime");
				
			}
		}
		catch(Exception e){
			e.printStackTrace();
		}

	}
	
	public void validateRuleViolation() {
		try{
			utilities = new CommonLib();
			String responseString = utilities.getHttpResponseAsString();
			System.out.println("Response    "+responseString);
			Reporter.logEvent(Status.INFO, "The response", responseString,
					false);
			String expectedRuleViolation = Stock.GetParameterValue("RuleViolation");
			String ruleViolation = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
						"$..ruleViolation");
			JsonReadWriteUtils.compareValueAndLogReport(ruleViolation, expectedRuleViolation, "ruleViolation");
				
		}
		catch(Exception e){
			e.printStackTrace();
		}

	}
	
	public void validateErrorMessage(){
		try{
			utilities = new CommonLib();
			String responseString = utilities.getHttpResponseAsString();
			System.out.println("Response    "+responseString);
			Reporter.logEvent(Status.INFO, "The response", responseString,
					false);
			String expectedCode = Stock.GetParameterValue("Code");
			String actualCode = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
						"$..code");
			JsonReadWriteUtils.compareValueAndLogReport(actualCode, expectedCode, "code");
			
			String expectedMessage = Stock.GetParameterValue("Message");
			String actualMessage = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
						"$..message");
			JsonReadWriteUtils.compareValueAndLogReport(actualMessage, expectedMessage, "Message");
				
				
		}
		catch(Exception e){
			e.printStackTrace();
		}
		
	}



}

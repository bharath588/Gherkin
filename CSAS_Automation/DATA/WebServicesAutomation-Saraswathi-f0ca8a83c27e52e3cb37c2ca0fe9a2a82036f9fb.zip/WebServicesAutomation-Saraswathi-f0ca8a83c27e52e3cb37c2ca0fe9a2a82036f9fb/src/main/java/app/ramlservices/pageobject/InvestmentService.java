package app.ramlservices.pageobject;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import lib.DB;
import lib.Reporter;
import lib.Stock;
import util.CommonLib;
import app.webservice.pageobjects.JsonReadWriteUtils;

import com.aventstack.extentreports.Status;

public class InvestmentService {
	CommonLib utilities;
	ResultSet queryResultSet;
	
	

	
	/**
	 * Validate InvestmentSevice Details.
	 * @throws SQLException
	 * @throws ParseException
	 */
	public void validateInvestmentServiceDetails() throws SQLException, ParseException {
		utilities = new CommonLib();
		String responseString = utilities.getHttpResponseAsString();
		System.out.println("res is    "+responseString);
		Reporter.logEvent(Status.INFO, "The response", responseString,false);
		String investmentType =Stock.GetParameterValue("InvestmentType");
		String parameter =Stock.GetParameterValue("GAIDParam");
		String db = Stock.GetParameterValue("DataBase");
		if(investmentType.equalsIgnoreCase("Future")){
			queryResultSet = getFutureRateRsultSet(parameter, db);
			validateFuturetDateInvestmentDetails(queryResultSet, responseString);
		}else if(investmentType.equalsIgnoreCase("Current")){
			queryResultSet = getCurrentRateRsultSet(parameter, db);
			validateCurrentDateInvestmentDetails(queryResultSet, responseString);
		}else{
			queryResultSet = getFutureRateRsultSet(parameter, db);
			validateFuturetDateInvestmentDetails(queryResultSet, responseString);
			queryResultSet = getCurrentRateRsultSet(parameter, db);
			validateCurrentDateInvestmentDetails(queryResultSet, responseString);
		}
		
	}
	
	public ResultSet getFutureRateRsultSet(String parameter,String db){
		String query =Stock.getTestQuery("getFutureRateInvestmentDetails")[1];
		String updatedFutureRateQuery  = query.replace("?", parameter);
		return queryResultSet=DB.executeQuery(db,updatedFutureRateQuery);
	}
	public ResultSet getCurrentRateRsultSet(String parameter,String db){
		String query =Stock.getTestQuery("fetchCurrentRateInvestmentDetails")[1];
		String updatedFutureRateQuery  = query.replace("?", parameter);
		return queryResultSet=DB.executeQuery(db,updatedFutureRateQuery);
	}
	
	public void validateCurrentRateInvestmentDetails() throws SQLException, ParseException{
		String parameter =Stock.GetParameterValue("GAIDParam");
		String db = Stock.getTestQuery("fetchCurrentRateInvestmentDetails")[0];
		utilities = new CommonLib();
		queryResultSet = getCurrentRateRsultSet(parameter, db);
		String responseString = utilities.getHttpResponseAsString();
		if(queryResultSet!= null){
			while (queryResultSet.next()) {
				System.out.println(responseString);
			String expectedTerm = queryResultSet.getString("SDTELENGTH");
			String expectedTermValue = expectedTerm+ " "+"Month";			
			Timestamp startDate = queryResultSet.getTimestamp("RATESTARTDATE");
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			String startDateTime  = sdf.format(startDate);
			
			String term = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
					"$..[?(@.term==\""+expectedTermValue+"\")]..term");
			
			JsonReadWriteUtils.compareValueAndLogReport(term, expectedTermValue, "term");
			
			String investmentOption = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
					"$..[?(@.term==\""+expectedTermValue+"\")]..investmentOption");
			String expectedInvestmentOption = queryResultSet.getString("SDIOID");
			JsonReadWriteUtils.compareValueAndLogReport(investmentOption, expectedInvestmentOption, "investmentOption");
			
			String legalName = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
					"$..[?(@.term==\""+expectedTermValue+"\")]..legalName");
			String expectedLegalName = queryResultSet.getString("LEGALNAME");
			JsonReadWriteUtils.compareValueAndLogReport(legalName, expectedLegalName, "legalName");
			

			
			String rate = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
					"$..[?(@.term==\""+expectedTermValue+"\")]..rate");
			String expectedFutureRate = queryResultSet.getString("INTRATE");
			JsonReadWriteUtils.compareNumericValues(rate, expectedFutureRate, "rate");
			
			/*String term = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
					"$..[?(@.term==\""+expectedTermValue+"\")]..term");
			JsonReadWriteUtils.compareValueAndLogReport(term, startDateTime, "term");*/
			
			Timestamp stopDate = queryResultSet.getTimestamp("RATESTOPDATE");
			String stopDateTime  = sdf.format(stopDate);
			String rateStopDate = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
					"$..[?(@.term==\""+expectedTermValue+"\")]..rateStopDate");
			JsonReadWriteUtils.compareValueAndLogReport(rateStopDate, stopDateTime, "rateStopDate");
			
		}
			}else{
				System.out.println("Result set is null");
			}
	}
	
	
	public void validateCurrentDateInvestmentDetails(ResultSet queryResultSet,String responseString ) throws SQLException, ParseException{
		if(queryResultSet!= null){
			while (queryResultSet.next()) {
			Timestamp startDate = queryResultSet.getTimestamp("RATESTARTDATE");
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			String startDateTime  = sdf.format(startDate);
			
			String investmentOption = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
					"$..[?(@.rateStartDate==\""+startDateTime+"\")]..investmentOption");
			String expectedInvestmentOption = queryResultSet.getString("SDIOID");
			JsonReadWriteUtils.compareValueAndLogReport(investmentOption, expectedInvestmentOption, "investmentOption");
			
			String legalName = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
					"$..[?(@.rateStartDate==\""+startDateTime+"\")]..legalName");
			String expectedLegalName = queryResultSet.getString("LEGALNAME");
			JsonReadWriteUtils.compareValueAndLogReport(legalName, expectedLegalName, "legalName");
			
			String term = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
					"$..[?(@.rateStartDate==\""+startDateTime+"\")]..term");
			String expectedTerm = queryResultSet.getString("SDTELENGTH");
			JsonReadWriteUtils.compareValueAndLogReport(term, expectedTerm, "term");
			
			String rate = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
					"$..[?(@.rateStartDate==\""+startDateTime+"\")]..rate");
			String expectedFutureRate = queryResultSet.getString("INTRATE");
			JsonReadWriteUtils.compareNumericValues(rate, expectedFutureRate, "rate");
			
			String rateStartDate = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
					"$..[?(@.rateStartDate==\""+startDateTime+"\")]..rateStartDate");
			JsonReadWriteUtils.compareValueAndLogReport(rateStartDate, startDateTime, "rateStartDate");
			
			Timestamp stopDate = queryResultSet.getTimestamp("RATESTOPDATE");
			String stopDateTime  = sdf.format(stopDate);
			String rateStopDate = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
					"$..[?(@.rateStartDate==\""+startDateTime+"\")]..rateStopDate");
			JsonReadWriteUtils.compareValueAndLogReport(rateStopDate, stopDateTime, "rateStopDate");
			
		}
			}else{
				System.out.println("Result set is null");
			}
	}
	
	public void validateFuturetDateInvestmentDetails(ResultSet queryResultSet,String responseString ) throws SQLException, ParseException{
		if(queryResultSet!= null){
			while (queryResultSet.next()) {
			Timestamp startDate = queryResultSet.getTimestamp("RATESTARTDATE");
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			String startDateTime  = sdf.format(startDate);
			
			String investmentOption = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
					"$..[?(@.futureRateEffDate==\""+startDateTime+"\")]..investmentOption");
			String expectedInvestmentOption = queryResultSet.getString("SDIOID");
			JsonReadWriteUtils.compareValueAndLogReport(investmentOption, expectedInvestmentOption, "investmentOption");
			
			String legalName = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
					"$..[?(@.futureRateEffDate==\""+startDateTime+"\")]..legalName");
			String expectedLegalName = queryResultSet.getString("LEGALNAME");
			JsonReadWriteUtils.compareValueAndLogReport(legalName, expectedLegalName, "legalName");
			
			String term = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
					"$..[?(@.futureRateEffDate==\""+startDateTime+"\")]..term");
			String expectedTerm = queryResultSet.getString("INTRATE");
			JsonReadWriteUtils.compareValueAndLogReport(term, expectedTerm, "term");
			
			String futureRate = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
					"$..[?(@.futureRateEffDate==\""+startDateTime+"\")]..futureRate");
			String expectedFutureRate = queryResultSet.getString("INRATE");
			JsonReadWriteUtils.compareValueAndLogReport(futureRate, expectedFutureRate, "futureRate");
			
			String rateStartDate = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
					"$..[?(@.futureRateEffDate==\""+startDateTime+"\")]..futureRateEffDate");
			JsonReadWriteUtils.compareDbWithDateInResponse(rateStartDate, queryResultSet.getDate("RATESTARTDATE"), "rateStartDate");
			
			String rateStopDate = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
					"$..[?(@.futureRateEffDate==\""+startDateTime+"\")]..futureRateStopDate");
			JsonReadWriteUtils.compareDbWithDateInResponse(rateStopDate, queryResultSet.getDate("RATESTOPDATE"), "rateStartDate");
			
		}
			}else{
				System.out.println("Result set is null");
			}
	}

}

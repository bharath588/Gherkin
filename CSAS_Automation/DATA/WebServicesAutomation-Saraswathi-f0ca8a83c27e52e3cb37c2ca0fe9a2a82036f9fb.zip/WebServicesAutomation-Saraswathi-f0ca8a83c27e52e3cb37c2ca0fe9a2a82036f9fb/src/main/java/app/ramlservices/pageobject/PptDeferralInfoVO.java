package app.ramlservices.pageobject;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import lib.DB;
import lib.Reporter;
import lib.Stock;
import util.CommonLib;
import app.webservice.pageobjects.JsonReadWriteUtils;

import com.aventstack.extentreports.Status;

public class PptDeferralInfoVO {
	
	CommonLib utilities;
	ResultSet queryResultSet;
	
	

	
	/**
	 * Validate InvestmentSevice Details.
	 * @throws SQLException
	 * @throws ParseException
	 */
	public void validatePptDeferralInfoVODetails() throws SQLException, ParseException {
		utilities = new CommonLib();
		String responseString = utilities.getHttpResponseAsString();
		System.out.println("res is    "+responseString);
		Reporter.logEvent(Status.INFO, "The response", responseString,false);
		String planNumber =Stock.GetParameterValue("PlanNumber");
		String parameter =Stock.GetParameterValue("INDIDParam");
		queryResultSet = getPptDeferralInfoVOResulSet(parameter, planNumber);
		validatePptDeferralInfoVODetails(responseString,queryResultSet);
	}
	
	public ResultSet getPptDeferralInfoVOResulSet(String parameter,String planNumber){
		if(planNumber.equalsIgnoreCase("1260028-01")){
		String query =Stock.getTestQuery("getPptDeferralInfoDetails")[1];
		String updatedFutureRateQuery  = query.replace("?", parameter);
		return queryResultSet=DB.executeQuery(Stock.getTestQuery("getPptDeferralInfoDetails")[0],updatedFutureRateQuery);
		}else{
			String query =Stock.getTestQuery("getPptDeferralInfoDetailsForDiffrentPaln")[1];
			String updatedFutureRateQuery  = query.replace("?", parameter);
			return queryResultSet=DB.executeQuery(Stock.getTestQuery("getPptDeferralInfoDetailsForDiffrentPaln")[0],updatedFutureRateQuery);
		}
	}
	
	public void validatePptDeferralInfoVODetails(String responseString,ResultSet queryResultSet ) throws SQLException, ParseException{
		
		if(queryResultSet!= null){
			while (queryResultSet.next()) {
			System.out.println(responseString);
			String IndId = queryResultSet.getString("INDID");
			String actualIndID = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
					"$..indEligibilityDTO.indId");
			JsonReadWriteUtils.compareValueAndLogReport(IndId, actualIndID, "INDID");
			
			String PlanId = queryResultSet.getString("PLANID");
			String actualPlanID = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
					"$..indEligibilityDTO.planId");
			JsonReadWriteUtils.compareValueAndLogReport(PlanId, actualPlanID, "PLANID");
			
			String actualDpDateTime = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
					"$..indEligibilityDTO.dpdateTime");
			JsonReadWriteUtils.compareDbWithDateInResponse(actualDpDateTime,queryResultSet.getDate("DPDATETIME"), "DPDATETIME");
			
			String actualParticipationDate= JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
					"$..indEligibilityDTO.participationDate");
			JsonReadWriteUtils.compareDbWithDateInResponse(actualParticipationDate,queryResultSet.getDate("PARTICIPATIONDATE"), "PARTICIPATIONDATE");
			
			String ParticipationDateSource = queryResultSet.getString("PARTICIPATIONDATESOURCE");
			String actualParticipationDateSource = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
					"$..indEligibilityDTO.participationDateSource");
			JsonReadWriteUtils.compareValueAndLogReport(actualParticipationDateSource,ParticipationDateSource, "PARTICIPATIONDATESOURCE");
			
			
			String EligibilityInd = queryResultSet.getString("ELIGIBILITYIND");
			String actualEligibilityInd = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
					"$..indEligibilityDTO.eligibilityInd");
			JsonReadWriteUtils.compareValueAndLogReport(EligibilityInd, actualEligibilityInd, "EligibilityInd");
			
			
			String EligibilityReasonCode = queryResultSet.getString("INELIGIBILITYREASONCODE");
			String actualEligibilityReasonCode = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
					"$..indEligibilityDTO.ineligibilityReasonCode");
			JsonReadWriteUtils.compareValueAndLogReport(EligibilityReasonCode, actualEligibilityReasonCode, "EligibilityReasonCode");
			
			String EligibilityDate = queryResultSet.getString("ELIGIBILITYDATE");
			String actualEligibilityDate = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
					"$..indEligibilityDTO.eligibilityDate");
			JsonReadWriteUtils.compareDbWithDateInResponse(actualEligibilityDate,queryResultSet.getDate("ELIGIBILITYDATE"), "ELIGIBILITYDATE");
			
			
			String EnrollInviteDateTime = queryResultSet.getString("ENROLLINVITEDATETIME");
			String actualEnrollInviteDateTime = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
					"$..indEligibilityDTO.enrollInviteDateTime");
			JsonReadWriteUtils.compareValueAndLogReport(EnrollInviteDateTime, actualEnrollInviteDateTime, "EnrollInviteDateTime");
			
			String EnrollInviteReplyDateTime = queryResultSet.getString("ENROLLINVITEREPLYDATETIME");
			String actualEnrollInviteReplyDateTime = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
					"$..indEligibilityDTO.enrollInviteReplyDateTime");
			JsonReadWriteUtils.compareValueAndLogReport(EnrollInviteReplyDateTime, actualEnrollInviteReplyDateTime, "EnrollInviteReplyDateTime");
			
			String actualEnrollNotificationDateTime = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
					"$..indEligibilityDTO.enrollNotificationDateTime");
			JsonReadWriteUtils.compareDbWithDateInResponse(actualEnrollNotificationDateTime,queryResultSet.getDate("ENROLLNOTIFICATIONDATETIME"), "ENROLLNOTIFICATIONDATETIME");
			
			
			String actualEnrollPinDateTime = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
					"$..indEligibilityDTO.enrollPinDateTime");
			JsonReadWriteUtils.compareDbWithDateInResponse(actualEnrollPinDateTime,queryResultSet.getDate("ENROLLPINDATETIME"), "ENROLLPINDATETIME");
			
			
			String SupressAutoEnrollInd = queryResultSet.getString("SUPPRESSAUTOENROLLIND");
			String actualSupressAutoEnrollInd = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
					"$..indEligibilityDTO.suppressAutoEnrollInd");
			JsonReadWriteUtils.compareValueAndLogReport(SupressAutoEnrollInd, actualSupressAutoEnrollInd, "SupressAutoEnrollInd");
			
			String RowID = queryResultSet.getString("ROWIDENTIFIER");
			String actualRowID = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
					"$..indEligibilityDTO.rowId");
			JsonReadWriteUtils.compareValueAndLogReport(RowID, actualRowID, "RowID");
			
		}
			}else{
				System.out.println("Result set is null");
			}
	}
	
	public void validateBcom_5643_StatusInfoDetails(){
		utilities = new CommonLib();
		String responseString = utilities.getHttpResponseAsString();
		System.out.println("res is    "+responseString);
		Reporter.logEvent(Status.INFO, "The response", responseString,false);
		
		String errorMessage = Stock.GetParameterValue("errorMessage");
		String actualerrorMessage= JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
				"$..errorMessage");
		JsonReadWriteUtils.compareValueAndLogReport(errorMessage, actualerrorMessage, "errorMessage");
		
		String errorCode = Stock.GetParameterValue("errorCode");
		String actualerrorCode= JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
				"$..errorCode");
		JsonReadWriteUtils.compareValueAndLogReport(errorCode, actualerrorCode, "errorCode");
		
		String quickEnrollAllowed = Stock.GetParameterValue("quickEnrollAllowed");
		String actualquickEnrollAllowed= JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
				"$..quickEnrollAllowed");
		JsonReadWriteUtils.compareValueAndLogReport(quickEnrollAllowed, actualquickEnrollAllowed, "quickEnrollAllowed");
		
		String ageCatchupAllowed = Stock.GetParameterValue("ageCatchupAllowed");
		String actualageCatchupAllowed= JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
				"$..ageCatchupAllowed");
		JsonReadWriteUtils.compareValueAndLogReport(ageCatchupAllowed, actualageCatchupAllowed, "ageCatchupAllowed");
		
		String ageCatchupMethod = Stock.GetParameterValue("ageCatchupMethod");
		String actualageCatchupMethod= JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
				"$..ageCatchupMethod");
		JsonReadWriteUtils.compareValueAndLogReport(ageCatchupMethod, actualageCatchupMethod, "ageCatchupMethod");
		
		String pptIsAgeEligible = Stock.GetParameterValue("pptIsAgeEligible");
		String actualpptIsAgeEligible = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
				"$..pptIsAgeEligible");
		JsonReadWriteUtils.compareValueAndLogReport(pptIsAgeEligible, actualpptIsAgeEligible, "pptIsAgeEligible");
		
		String pptInRegularCatchup = Stock.GetParameterValue("pptInRegularCatchup");
		String actualpptInRegularCatchup= JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
				"$..pptInRegularCatchup");
		JsonReadWriteUtils.compareValueAndLogReport(pptInRegularCatchup, actualpptInRegularCatchup, "pptInRegularCatchup");
		
		String pptIsHCE = Stock.GetParameterValue("pptIsHCE");
		String actualpptIsHCE= JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
				"$..pptIsHCE");
		JsonReadWriteUtils.compareValueAndLogReport(pptIsHCE, actualpptIsHCE, "pptIsHCE");
		
		String pptHasDefaultDefrl = Stock.GetParameterValue("pptHasDefaultDefrl");
		String actualpptHasDefaultDefrl= JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
				"$..pptHasDefaultDefrl");
		JsonReadWriteUtils.compareValueAndLogReport(pptHasDefaultDefrl, actualpptHasDefaultDefrl, "pptHasDefaultDefrl");
		
		String gracePeriodEndDate = Stock.GetParameterValue("gracePeriodEndDate");
		String actualgracePeriodEndDate= JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
				"$..gracePeriodEndDate");
		JsonReadWriteUtils.compareValueAndLogReport(gracePeriodEndDate, actualgracePeriodEndDate, "gracePeriodEndDate");
		
		String nextAvailablePayrollDate = Stock.GetParameterValue("nextAvailablePayrollDate");
		String actualnextAvailablePayrollDate = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
				"$..nextAvailablePayrollDate");
		JsonReadWriteUtils.compareValueAndLogReport(nextAvailablePayrollDate, actualnextAvailablePayrollDate, "nextAvailablePayrollDate");
		
		String allowedToDeferCode = Stock.GetParameterValue("allowedToDeferCode");
		String actualallowedToDeferCode= JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
				"$..allowedToDeferCode");
		JsonReadWriteUtils.compareValueAndLogReport(allowedToDeferCode, actualallowedToDeferCode, "allowedToDeferCode");
		
	 	String allowedToDefer = Stock.GetParameterValue("allowedToDefer");
		String actualallowedToDefer= JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
				"$..allowedToDefer");
		JsonReadWriteUtils.compareValueAndLogReport(allowedToDefer, actualallowedToDefer, "allowedToDefer");
		
		String pptIsAutoEnrolled = Stock.GetParameterValue("pptIsAutoEnrolled");
		String actualpptIsAutoEnrolled= JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
				"$..pptIsAutoEnrolled");
		JsonReadWriteUtils.compareValueAndLogReport(pptIsAutoEnrolled, actualpptIsAutoEnrolled, "pptIsAutoEnrolled");
		
		String invAllocEnrollElig = Stock.GetParameterValue("invAllocEnrollElig");
		String actualinvAllocEnrollElig= JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
				"$..invAllocEnrollElig");
		JsonReadWriteUtils.compareValueAndLogReport(invAllocEnrollElig, actualinvAllocEnrollElig, "invAllocEnrollElig");
		
		String defrlEnrollElig = Stock.GetParameterValue("defrlEnrollElig");
		String actuadefrlEnrollElig = JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
				"$..defrlEnrollElig");
		JsonReadWriteUtils.compareValueAndLogReport(defrlEnrollElig, actuadefrlEnrollElig, "defrlEnrollElig");
		
		String defrlChangeOnly = Stock.GetParameterValue("defrlChangeOnly");
		String actualdefrlChangeOnly= JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
				"$..defrlChangeOnly");
		JsonReadWriteUtils.compareValueAndLogReport(defrlChangeOnly, actualdefrlChangeOnly, "defrlChangeOnly");
		
		String employerDirectedAllocationsOnly = Stock.GetParameterValue("employerDirectedAllocationsOnly");
		String actualemployerDirectedAllocationsOnly= JsonReadWriteUtils.getNodeValueUsingJpath(responseString, 
				"$..employerDirectedAllocationsOnly");
		JsonReadWriteUtils.compareValueAndLogReport(employerDirectedAllocationsOnly, actualemployerDirectedAllocationsOnly, "employerDirectedAllocationsOnly");
		
	}
	

}

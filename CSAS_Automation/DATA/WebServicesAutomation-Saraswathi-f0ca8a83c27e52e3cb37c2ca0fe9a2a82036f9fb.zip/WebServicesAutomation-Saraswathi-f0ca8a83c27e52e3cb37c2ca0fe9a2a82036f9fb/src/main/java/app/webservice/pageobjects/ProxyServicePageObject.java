package app.webservice.pageobjects;



import java.util.HashSet;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;




import org.w3c.dom.Document;
import org.w3c.dom.Node;


public class ProxyServicePageObject {

	private static DocumentBuilderFactory dbFactory =null;
	private static DocumentBuilder dBuilder = null;
	private static Document document=null;
	private static TransformerFactory transformerFactory =null;
	private static Transformer transformer =null;
	private static DOMSource source = null;		
	private static StreamResult result =null;
	
	

	public void initDocument() throws ParserConfigurationException
	{
		dbFactory = DocumentBuilderFactory.newInstance();
        dBuilder = dbFactory.newDocumentBuilder();       
	}

	
	public static void generateRequestXML()
    {
           try {
      
        	   Node parentNode = 
        	   
                  (Node) (// write the content into xml file
			  transformerFactory = TransformerFactory.newInstance());
                                      transformer = transformerFactory.newTransformer();
                                      transformer.setOutputProperty(OutputKeys.INDENT, "yes");
                                      transformer.setOutputProperty(
                                                    "{http://xml.apache.org/xslt}indent-amount", "1");
                                      source = new DOMSource(document);
                                     
                                      
                                   //put filename   result = new StreamResult();
                                      
                                      transformer.transform(source, result);
                                      
           }catch (TransformerConfigurationException e) {
                 e.printStackTrace();
           } catch (TransformerException e) {
        	   	e.printStackTrace();           
           }
    }

}


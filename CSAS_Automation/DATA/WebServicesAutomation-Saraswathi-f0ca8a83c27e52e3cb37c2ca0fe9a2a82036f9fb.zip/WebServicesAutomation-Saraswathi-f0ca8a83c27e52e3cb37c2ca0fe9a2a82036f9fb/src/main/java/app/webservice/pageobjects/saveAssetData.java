package app.webservice.pageobjects;



public class saveAssetData {

	String assetId;
	String individualId;
	String clientId;
	String planId;
	String name;
	String value;
	String categoryId;
	String presentValue;
	String status;
	String createdDate;
	String createdBy;
	String updatedBy;
	String updatedDate;
	String actionCode;
	String editableCode;
	String deletableCode;
	String viewableCode;
	String moneyType;
	String source;

	public void setIndividualId(String individualId) {
		this.individualId = individualId;
	}
	public void setValue(String value) {
		this.value = value;
	}
	public void setCategoryId(String categoryId) {
		this.categoryId = categoryId;
	}
	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}
	public void setActionCode(String actionCode) {
		this.actionCode = actionCode;
	}
	public void setEditableCode(String editableCode) {
		this.editableCode = editableCode;
	}
	public void setDeletableCode(String deletableCode) {
		this.deletableCode = deletableCode;
	}
	public void setViewableCode(String viewableCode) {
		this.viewableCode = viewableCode;
	}
	public void setMoneyType(String moneyType) {
		this.moneyType = moneyType;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public void setAssetId(String assetId) {
		this.assetId = assetId;
	}
	
	public void setClientId(String clientId) {
		this.clientId = clientId;
	}
	public void setPlanId(String planId) {
		this.planId = planId;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	public void setPresentValue(String presentValue) {
		this.presentValue = presentValue;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}
	public void setUpdatedDate(String updatedDate) {
		this.updatedDate = updatedDate;
	}
}

package util;

import java.io.IOException;
import java.net.URLEncoder;
import java.util.Base64.Decoder;
import java.util.Base64.Encoder;
import java.util.Map;
import java.util.Properties;

import lib.Reporter;
import lib.Stock;

import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.utils.URLEncodedUtils;

import webservices.util.JsonUtil;
import webservices.util.WebserviceUtil;
import app.webservice.pageobjects.Response;

import com.aventstack.extentreports.Status;

/**
 * @author rvpndy
 *
 */
public class CommonLib {
	static Properties testConfig = null;	
	public static String APP = "";
	WebserviceUtil web = null;
	Response response;
	String jsonRequestString;
	String jsonResponseString;
	HttpGet getRequest;
	HttpPost postRequest;
	HttpResponse authResponse;
	public static HttpResponse serviceResponse;
	
	/**<pre> To get the test data as string for an iteration
	 * @param testdata
	 * @return String test data
	 */
	public static String getIterationDataAsString(Map<String, String> testdata){
		String result = "";
		for(Map.Entry<String,String> td : testdata.entrySet()){
			result = result+(td.getKey()+" : "+td.getValue())+" | ";
		}
		return result.substring(0,result.lastIndexOf("|"));
	}
	
	/**
	 * @return Authorization code
	 */
	private String getAuthCode(){
		String authCode = null;
		try{
		web = new WebserviceUtil();
		response = new Response();
		response.setusername(Stock.GetParameterValue("username"));
		response.setPassword(Stock.GetParameterValue("password"));
		jsonRequestString = JsonUtil.writeToJson(response);
		authResponse = web.getResponseasJsonforPostRequest(Stock.getConfigParam("authURL"), jsonRequestString);
		authCode = authResponse.getFirstHeader("Authorization").getValue();
		}
		catch(Exception e){
			e.printStackTrace();
		}
		return authCode;
	}
	
	/**<pre> Adds Authorization header to HttpRequest object.</pre> 
	 * @param requestUrl : URI
	 */
	private void addAuthorizationHeader(String requestUrl){
		getRequest = new HttpGet(requestUrl);
		
		if(Stock.GetParameterValue("Header").equalsIgnoreCase("valid"))
			getRequest.addHeader("Authorization", "JWT " + getAuthCode());
		else{
			if(Stock.GetParameterValue("authCode")!=null)
				getRequest.addHeader("Authorization", Stock.GetParameterValue("JWT") + Stock.GetParameterValue("authCode"));
			else
				getRequest.addHeader("Authorization", Stock.GetParameterValue("JWT") + getAuthCode());
		}
	}
	
	/**<pre> Adds Authorization header to HttpRequest object without JWT</pre> 
	 * @param requestUrl : URI
	 */
	private void addAuthorizationHeaderWithoutJWT(String requestUrl){
		getRequest = new HttpGet(requestUrl);
		
		if(Stock.GetParameterValue("Header").equalsIgnoreCase("valid")&& Stock.GetParameterValue("JWT").equalsIgnoreCase("null"))
			getRequest.addHeader("Authorization", "" + getAuthCode());
		else if(Stock.GetParameterValue("Header").equalsIgnoreCase("invalid")&& Stock.GetParameterValue("JWT").equalsIgnoreCase("JWT")){
			getRequest.addHeader("Authorization", "JWT " + getAuthCode());
		}	
	}
	
	/**<pre> It returns the JSON response of a web service</pre>
	 * @param requestUrl
	 * @return HttpResponse
	 * @throws ClientProtocolException
	 * @throws IOException
	 */
	private HttpResponse getHttpResponse(String requestUrl) throws ClientProtocolException, IOException{
		web = new WebserviceUtil();
		/*String requestURL1  = URLEncoder.encode(requestUrl,"UTF-8");
		System.out.println("Encoded url is   "+requestURL1);*/
		getRequest = new HttpGet(requestUrl);
		addAuthorizationHeader(requestUrl);
		
		return serviceResponse = web.getResponseasJsonforGet(getRequest);
		
	}
	
	/**<pre> It returns the JSON response of a web service</pre>
	 * @param requestUrl
	 * @return HttpResponse
	 * @throws ClientProtocolException
	 * @throws IOException
	 */
	private HttpResponse getHttpResponseWhenAuthTokenDoesNotHaveJWT(String requestUrl) throws ClientProtocolException, IOException{
		web = new WebserviceUtil();
		getRequest = new HttpGet(requestUrl);
		addAuthorizationHeaderWithoutJWT(requestUrl);
		return serviceResponse = web.getResponseasJsonforGet(getRequest);
		
	}
	
	/**<pre> It returns the integer status code of a web service</pre>
	 * @param requestUrl
	 * @return status code e.g. 200, 400 etc.
	 * @throws ClientProtocolException
	 * @throws IOException
	 */
	private int getReponseStatusCode() throws ClientProtocolException, IOException{
		return serviceResponse.getStatusLine().getStatusCode();
		
	}
	
	/**<pre> It returns the reason phrase of a Web Service.
	 * @param requestUrl
	 * @return String reason phrase e.g. <b>Internal Server Error</b>
	 * @throws ClientProtocolException
	 * @throws IOException
	 */
	private String getReasonPhrase() throws ClientProtocolException, IOException{
		return serviceResponse.getStatusLine().getReasonPhrase();
	}
	
	public void getResponse(HttpResponse res){
		serviceResponse = res;
	}
	
	/**<pre> Method to validate the response codes for positive and negative scenarios</pre>
	 * @param requestUrl
	 * @throws ClientProtocolException
	 * @throws IOException
	 */
	public void validateResponseStatusCode() throws ClientProtocolException, IOException{
		int code = getReponseStatusCode();
		if(Integer.toString(code).equalsIgnoreCase(Stock.GetParameterValue("responseCode"))&& code==HttpStatus.SC_OK){
			Reporter.logEvent(Status.PASS, "Verify the status code",
					"Expected " +Stock.GetParameterValue("responseCode") + " Actual " + code+"\nReason Phrase "+getReasonPhrase(), false);
		}
		else if(Integer.toString(code).equalsIgnoreCase(Stock.GetParameterValue("responseCode"))&& code!=HttpStatus.SC_OK)
		{
			Reporter.logEvent(Status.PASS, "Verify the status code",
					"Expected " +Stock.GetParameterValue("responseCode") + " Actual " + code+"\nReason Phrase "+getReasonPhrase()+"\n"+"Exception message is "
							+serviceResponse.getFirstHeader("exceptionMessage").getValue(), false);
		}
		else
		{
			Reporter.logEvent(Status.FAIL, "Verify the status code",
					"Expected " +Stock.GetParameterValue("responseCode") + " Actual " + code, false);

		}
	}
	
	/**<pre> Method to return the HttpResponse as string.</pre>
	 * @return String HttpResponse
	 */
	public String getHttpResponseAsString(){
		web = new WebserviceUtil();
		 return web.getHttpResponseAsString(serviceResponse);
		
	}
	 public HttpResponse getHttpRes(){
		 return serviceResponse;
	 }
	
	/**<pre> Method to trigger the service and get the response</pre>
	 * @param requestUrl
	 * @throws ClientProtocolException
	 * @throws IOException
	 */
	public void triggerService(String requestUrl) throws ClientProtocolException, IOException{
		getHttpResponse(requestUrl);
	}
	
	/**<pre> Method to trigger the service and get the response</pre>
	 * @param requestUrl
	 * @throws ClientProtocolException
	 * @throws IOException
	 */
	public void triggerServiceWhenAuthDoesNotHaveJWT(String requestUrl) throws ClientProtocolException, IOException{
		getHttpResponseWhenAuthTokenDoesNotHaveJWT(requestUrl);
	}
	
	/**<pre> Method to validate the response codes for positive and negative scenarios</pre>
	 * @param requestUrl
	 * @throws ClientProtocolException
	 * @throws IOException
	 */
	public void validateResponseStatusCodeWithoutClientMessage() throws ClientProtocolException, IOException{
		int code = getReponseStatusCode();
		String reasonPhrase = getReasonPhrase();
		if(Integer.toString(code).equalsIgnoreCase(Stock.GetParameterValue("responseCode"))&& code==HttpStatus.SC_OK){
			Reporter.logEvent(Status.PASS, "Verify the status code",
					"Expected :" +Stock.GetParameterValue("responseCode") + "\n Actual : " + code+"\nReason Phrase "+getReasonPhrase(), false);
		}
		else if(Integer.toString(code).equalsIgnoreCase(Stock.GetParameterValue("responseCode"))&& code!=HttpStatus.SC_OK)
		{
			Reporter.logEvent(Status.PASS, "Verify the status code",
					"Expected "+Stock.GetParameterValue("responseCode") + " Actual " +code+"\nReason Phrase "+getReasonPhrase(), false);
		}
		else
		{
			Reporter.logEvent(Status.FAIL, "Verify the status code",
					"Expected " +Stock.GetParameterValue("responseCode") + " Actual " +code+"\nReason Phrase "+getReasonPhrase(), false);

		}
	}
	
}

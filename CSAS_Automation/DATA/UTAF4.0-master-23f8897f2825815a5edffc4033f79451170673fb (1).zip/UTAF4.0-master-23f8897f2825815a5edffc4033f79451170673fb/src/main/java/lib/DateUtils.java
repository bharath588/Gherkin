package lib;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * This class wis for Date Utility
 * @author sddprd
 *
 */

public class DateUtils {

	public static final String DATE_FORMAT = "MM/dd/yyyy";
	 private static SimpleDateFormat timeFormatter = new SimpleDateFormat("hh:mm:ss");

	public static String changeMonth(int month) {
		SimpleDateFormat sdf = new SimpleDateFormat(DATE_FORMAT);
		Calendar c1 = Calendar.getInstance();
		c1.add(Calendar.MONTH, month);
		return sdf.format(c1.getTime());
	}

	public static String getCurrentDate() {
		SimpleDateFormat sdf = new SimpleDateFormat(DATE_FORMAT);
		Calendar c1 = Calendar.getInstance();
		return sdf.format(c1.getTime());
	}

	public static String getStartEndDates(int month)
	{
		String endDate = getCurrentDate();
		String startDate = changeMonth(month);
		return startDate + "-" + endDate;
	}
	
	 /**
     * Formats Current Date into a date/time string.
     *
     * @return the formatted time string
     */
    public static String getCurrentTime()
    {
        return timeFormatter.format(new Date());
    }
	public static long getTime()
	{
		//Date now = new Date();
		return new Date().getTime();
	}

	public static String getDateTimeStamp()
	{
		//Date now = new Date();
		return DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.MEDIUM).format(new Date()).replace('/', '_').replace(':', '-').replace(' ', '_' );
	}

    /**
     * Returns current time in milliseconds
     */
    public static long millis() {
    	Calendar cal = new GregorianCalendar();;
        return cal.getTimeInMillis();
    }

	
	public static boolean isDateGreaterThan(String[] dates, String compareDate)
	{
		ArrayList <Date> sortedDates = sortDates(dates);
		Date greaterThanDate = stringToDate(compareDate);
		if (greaterThanDate == null || sortedDates == null)
			return false;
		return (sortedDates.get(sortedDates.size()-1).compareTo(greaterThanDate) > 0);
	}

	public static boolean isDateLessThan(String[] dates, String compareDate)
	{
		ArrayList <Date> sortedDates = sortDates(dates);
		Date greaterThanDate = stringToDate(compareDate);
		if (greaterThanDate == null || sortedDates == null)
			return false;
		return (sortedDates.get(0).compareTo(greaterThanDate) < 0);
	}

	public static boolean isSameDate(String[] dates, String compareDate)
	{
		ArrayList <Date> sortedDates = sortDates(dates);
		Date isDate = stringToDate(compareDate);
		if (isDate == null || sortedDates == null)
			return false;
		return (sortedDates.get(0).compareTo(isDate) == 0 && sortedDates.get(sortedDates.size()-1).compareTo(isDate) == 0);
	}

	public static boolean isDateBetween(String[] dates, String compareDateRange)
	{
		ArrayList <Date> sortedDates = sortDates(dates);
		String [] betweenDates = compareDateRange.split("-");
		Date equalLessThanDate = stringToDate(betweenDates[0]);
		Date equalGreaterThanDate = stringToDate(betweenDates[1]);
		if (equalLessThanDate == null || equalGreaterThanDate == null || sortedDates == null)
			return false;
		return ((sortedDates.get(0).compareTo(equalLessThanDate) >= 0) && (sortedDates.get(sortedDates.size()-1).compareTo(equalGreaterThanDate) <= 0));
	}

	public static Date stringToDate(String date)
	{
		try
		{
			DateFormat df = new SimpleDateFormat(DATE_FORMAT);
			return df.parse(date);
		} catch (ParseException e)
		{
			return null;
		}
		
	}

	public static ArrayList <Date> sortDates(String [] dateToBeSorted)
	{
		ArrayList <Date> dates = new ArrayList <Date>();
		DateCompare compare = new DateCompare();
		for (String dateString: dateToBeSorted)
			dates.add(stringToDate(dateString));
		try {
			Collections.sort(dates, compare);
			return dates;
		}
		catch (Exception e){
			return null;
		}
		
	}
}

class DateCompare implements Comparator<Date> {
	public int compare(Date one, Date two){
		return one.compareTo(two);
	}
}
